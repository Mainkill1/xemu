# PGR2 lag v2 cumulative-S Vulkan CPU profile

- Runtime image base: `0x7ff7aca70000`
- Process samples: 328,351
- xemu image samples: 161,339

## Modules

| Module | Samples | Process share |
|---|---:|---:|
| xemu.exe | 161,339 | 49.14% |
| ntdll.dll | 57,459 | 17.50% |
| Unknown | 49,732 | 15.15% |
| ntoskrnl.exe | 34,987 | 10.66% |
| msvcrt.dll | 13,005 | 3.96% |
| nvoglv64.dll | 7,556 | 2.30% |
| nvlddmkm.sys | 1,947 | 0.59% |
| dxgkrnl.sys | 664 | 0.20% |
| vulkan-1.dll | 357 | 0.11% |
| win32u.dll | 225 | 0.07% |
| dxgmms2.sys | 225 | 0.07% |
| KernelBase.dll | 201 | 0.06% |
| kernel32.dll | 178 | 0.05% |
| win32kbase.sys | 161 | 0.05% |
| win32kfull.sys | 85 | 0.03% |

## xemu functions

| Function | Samples | xemu share | Process share |
|---|---:|---:|---:|
| `sinc_stereo_vari_process` | 32,419 | 20.09% | 9.87% |
| `__divti3` | 17,068 | 10.58% | 5.20% |
| `compiler_builtins::int::specialized_div_rem::u128_div_rem` | 9,463 | 5.87% | 2.88% |
| `cpu_exec_loop` | 7,272 | 4.51% | 2.21% |
| `os_host_main_loop_wait` | 6,282 | 3.89% | 1.91% |
| `voice_get_samples` | 5,735 | 3.55% | 1.75% |
| `voice_get_mask.lto_priv.0` | 5,622 | 3.48% | 1.71% |
| `helper_lookup_tb_ptr` | 4,755 | 2.95% | 1.45% |
| `apply_uniform_updates.lto_priv.0` | 4,695 | 2.91% | 1.43% |
| `voice_process` | 4,245 | 2.63% | 1.29% |
| `XXH3_accumulate_512_avx2.lto_priv.0` | 3,956 | 2.45% | 1.20% |
| `address_space_translate_internal.lto_priv.0` | 3,147 | 1.95% | 0.96% |
| `log2l` | 2,429 | 1.51% | 0.74% |
| `flatview_translate.isra.0` | 2,323 | 1.44% | 0.71% |
| `get_ptr_rcu_reader` | 2,306 | 1.43% | 0.70% |
| `exp2l` | 2,107 | 1.31% | 0.64% |
| `qht_lookup_custom` | 1,996 | 1.24% | 0.61% |
| `physical_memory_all_dirty` | 1,617 | 1.00% | 0.49% |
| `float32_mul` | 1,448 | 0.90% | 0.44% |
| `voice_set_mask` | 1,427 | 0.88% | 0.43% |
| `voice_worker_thread.lto_priv.0` | 1,327 | 0.82% | 0.40% |
| `cpu_tb_exec` | 1,131 | 0.70% | 0.34% |
| `pow` | 1,115 | 0.69% | 0.34% |
| `pfifo_thread` | 1,088 | 0.67% | 0.33% |
| `create_pipeline` | 1,037 | 0.64% | 0.32% |
| `float32_add` | 963 | 0.60% | 0.29% |
| `fmax` | 904 | 0.56% | 0.28% |
| `lru_lookup.lto_priv.5` | 820 | 0.51% | 0.25% |
| `pgraph_method` | 805 | 0.50% | 0.25% |
| `memcpy` | 795 | 0.49% | 0.24% |
| `qemu_ram_ptr_length.isra.0` | 784 | 0.49% | 0.24% |
| `flush_draw_checked` | 722 | 0.45% | 0.22% |
| `tb_htable_lookup_common` | 714 | 0.44% | 0.22% |
| `pgraph_glsl_set_psh_uniform_values` | 712 | 0.44% | 0.22% |
| `helper_mulss` | 687 | 0.43% | 0.21% |
| `se_frame` | 641 | 0.40% | 0.20% |
| `SDL_DelayPrecise_REAL` | 631 | 0.39% | 0.19% |
| `pgraph_method_non_inc` | 615 | 0.38% | 0.19% |
| `float32_sub` | 594 | 0.37% | 0.18% |
| `pgraph_vk_surface_update` | 581 | 0.36% | 0.18% |
| `qemu_mutex_lock_impl` | 556 | 0.34% | 0.17% |
| `find_next_zero_bit` | 552 | 0.34% | 0.17% |
| `lrint` | 522 | 0.32% | 0.16% |
| `tb_lookup_cmp` | 473 | 0.29% | 0.14% |
| `tlb_reset_dirty_range_all` | 463 | 0.29% | 0.14% |
| `pgraph_vk_bind_vertex_attributes` | 436 | 0.27% | 0.13% |
| `probe_access_internal.isra.0` | 435 | 0.27% | 0.13% |
| `helper_comiss` | 429 | 0.27% | 0.13% |
| `invalidate_and_set_dirty.lto_priv.0` | 428 | 0.27% | 0.13% |
| `pgraph_method_inc` | 422 | 0.26% | 0.13% |
| `src_callback_read` | 421 | 0.26% | 0.13% |
| `physical_memory_test_and_clear_dirty.part.0` | 415 | 0.26% | 0.13% |
| `XXH3_hashLong_internal_loop.constprop.0` | 400 | 0.25% | 0.12% |
| `qemu_mutex_unlock_impl` | 394 | 0.24% | 0.12% |
| `pgraph_calculate_texture_encoded_size.lto_priv.0` | 385 | 0.24% | 0.12% |
| `soft_f32_mul` | 381 | 0.24% | 0.12% |
| `tlb_set_page_full` | 380 | 0.24% | 0.12% |
| `XXH3_scrambleAcc_avx2.lto_priv.0` | 378 | 0.23% | 0.12% |
| `do_ld4_mmu.lto_priv.0` | 346 | 0.21% | 0.11% |
| `pgraph_get_texture_shape` | 344 | 0.21% | 0.10% |

## xemu samples by thread

### TID 15676 (33,055 xemu samples)

- `__divti3`: 17,024 (51.50%)
- `compiler_builtins::int::specialized_div_rem::u128_div_rem`: 9,444 (28.57%)
- `os_host_main_loop_wait`: 6,282 (19.00%)
- `mem_check_access_callback_ramaddr.isra.0`: 20 (0.06%)
- `timerlistgroup_deadline_ns`: 15 (0.05%)
- `qemu_mutex_lock_impl`: 12 (0.04%)
- `g_main_context_prepare_unlocked.part.0.constprop.0`: 12 (0.04%)
- `qemu_mutex_unlock_impl`: 11 (0.03%)

### TID 14916 (28,721 xemu samples)

- `cpu_exec_loop`: 7,272 (25.32%)
- `helper_lookup_tb_ptr`: 4,755 (16.56%)
- `qht_lookup_custom`: 1,996 (6.95%)
- `float32_mul`: 1,448 (5.04%)
- `cpu_tb_exec`: 1,131 (3.94%)
- `float32_add`: 963 (3.35%)
- `tb_htable_lookup_common`: 714 (2.49%)
- `helper_mulss`: 687 (2.39%)

### TID 3344 (25,893 xemu samples)

- `apply_uniform_updates.lto_priv.0`: 4,695 (18.13%)
- `XXH3_accumulate_512_avx2.lto_priv.0`: 3,956 (15.28%)
- `pfifo_thread`: 1,088 (4.20%)
- `create_pipeline`: 1,037 (4.00%)
- `lru_lookup.lto_priv.5`: 820 (3.17%)
- `pgraph_method`: 805 (3.11%)
- `memcpy`: 793 (3.06%)
- `flush_draw_checked`: 722 (2.79%)

### TID 12364 (4,791 xemu samples)

- `sinc_stereo_vari_process`: 2,250 (46.96%)
- `voice_get_samples`: 346 (7.22%)
- `voice_get_mask.lto_priv.0`: 297 (6.20%)
- `voice_process`: 292 (6.09%)
- `address_space_translate_internal.lto_priv.0`: 201 (4.20%)
- `log2l`: 180 (3.76%)
- `flatview_translate.isra.0`: 174 (3.63%)
- `exp2l`: 153 (3.19%)

### TID 15244 (4,541 xemu samples)

- `sinc_stereo_vari_process`: 2,226 (49.02%)
- `voice_get_samples`: 358 (7.88%)
- `voice_get_mask.lto_priv.0`: 289 (6.36%)
- `voice_process`: 270 (5.95%)
- `address_space_translate_internal.lto_priv.0`: 181 (3.99%)
- `log2l`: 165 (3.63%)
- `exp2l`: 131 (2.88%)
- `get_ptr_rcu_reader`: 128 (2.82%)

### TID 11016 (4,501 xemu samples)

- `sinc_stereo_vari_process`: 2,108 (46.83%)
- `voice_get_samples`: 329 (7.31%)
- `voice_get_mask.lto_priv.0`: 314 (6.98%)
- `voice_process`: 273 (6.07%)
- `address_space_translate_internal.lto_priv.0`: 179 (3.98%)
- `flatview_translate.isra.0`: 151 (3.35%)
- `log2l`: 146 (3.24%)
- `exp2l`: 137 (3.04%)

### TID 12024 (4,494 xemu samples)

- `sinc_stereo_vari_process`: 2,136 (47.53%)
- `voice_get_samples`: 369 (8.21%)
- `voice_get_mask.lto_priv.0`: 330 (7.34%)
- `voice_process`: 276 (6.14%)
- `address_space_translate_internal.lto_priv.0`: 198 (4.41%)
- `flatview_translate.isra.0`: 129 (2.87%)
- `exp2l`: 129 (2.87%)
- `get_ptr_rcu_reader`: 127 (2.83%)

### TID 10076 (4,393 xemu samples)

- `sinc_stereo_vari_process`: 2,107 (47.96%)
- `voice_get_samples`: 389 (8.85%)
- `voice_get_mask.lto_priv.0`: 316 (7.19%)
- `voice_process`: 272 (6.19%)
- `address_space_translate_internal.lto_priv.0`: 197 (4.48%)
- `flatview_translate.isra.0`: 129 (2.94%)
- `get_ptr_rcu_reader`: 129 (2.94%)
- `log2l`: 126 (2.87%)

### TID 13128 (4,334 xemu samples)

- `sinc_stereo_vari_process`: 1,965 (45.34%)
- `voice_get_samples`: 392 (9.04%)
- `voice_get_mask.lto_priv.0`: 304 (7.01%)
- `voice_process`: 273 (6.30%)
- `log2l`: 176 (4.06%)
- `address_space_translate_internal.lto_priv.0`: 166 (3.83%)
- `get_ptr_rcu_reader`: 154 (3.55%)
- `flatview_translate.isra.0`: 128 (2.95%)

### TID 4172 (4,326 xemu samples)

- `sinc_stereo_vari_process`: 2,064 (47.71%)
- `voice_get_samples`: 401 (9.27%)
- `voice_get_mask.lto_priv.0`: 292 (6.75%)
- `voice_process`: 248 (5.73%)
- `address_space_translate_internal.lto_priv.0`: 179 (4.14%)
- `get_ptr_rcu_reader`: 142 (3.28%)
- `log2l`: 132 (3.05%)
- `flatview_translate.isra.0`: 123 (2.84%)

### TID 12664 (4,303 xemu samples)

- `sinc_stereo_vari_process`: 1,971 (45.81%)
- `voice_get_samples`: 364 (8.46%)
- `voice_get_mask.lto_priv.0`: 298 (6.93%)
- `voice_process`: 244 (5.67%)
- `get_ptr_rcu_reader`: 169 (3.93%)
- `log2l`: 160 (3.72%)
- `address_space_translate_internal.lto_priv.0`: 159 (3.70%)
- `flatview_translate.isra.0`: 151 (3.51%)

### TID 10312 (4,264 xemu samples)

- `sinc_stereo_vari_process`: 1,939 (45.47%)
- `voice_get_samples`: 368 (8.63%)
- `voice_get_mask.lto_priv.0`: 313 (7.34%)
- `voice_process`: 236 (5.53%)
- `address_space_translate_internal.lto_priv.0`: 186 (4.36%)
- `log2l`: 164 (3.85%)
- `flatview_translate.isra.0`: 145 (3.40%)
- `exp2l`: 139 (3.26%)


# PGR2 lag-objective cumulative-S Vulkan profile

Status: baseline profiling complete; QPC-v2 candidate build and A/B validation pending.

- Source: `208e4596832a1f949bd63822d5ddd962c4575067`
- Tree: `3d7eeb113b81f449e31d9b8d713696d72c7b36d2`
- Release executable SHA-256: `6c41b50acb94fc71442ae6f217c8c236ffcc3fda12ce81e7553cb391b1fd2527`
- Snapshot: `vm-20260907142321`
- Renderer: Vulkan, surface scale 1
- Measured interval: 60.028 seconds
- Guest cadence: 26.460 FPS; p95 45.487 ms; p99 50.409 ms
- Host presentation: 59.979 FPS; p95 29.907 ms; p99 32.954 ms
- xemu CPU time: 266.330 seconds, or 4.437 logical cores averaged over the interval
- Device GPU: 32.67% mean; VRAM 905 MiB; power 22.28 W

## Main findings

1. Exact Windows QPC conversion performs compiler 128-bit division on the main-loop thread. `__divti3` plus its unsigned division helper account for 26,531 samples: 16.44% of xemu-image samples and 8.08% of all xemu-process samples. TID 15676 consumed 56.733 CPU seconds and spent 80.07% of its xemu-image samples in those two division routines.
2. Sixteen APU voice workers consumed 69,395 xemu-image samples. `sinc_stereo_vari_process` alone was the largest function at 32,419 samples. This is a large host-efficiency cost and may add scheduling pressure, but the current trace does not prove it controls each frame boundary.
3. The NV2A/PFIFO thread consumed 36.198 CPU seconds. Its leading xemu costs were `apply_uniform_updates` (18.13% of that thread's xemu samples), XXH3 accumulation (15.28%), pipeline creation (4.00%), LRU lookup (3.17%), PGRAPH method handling (3.11%), and `memcpy` (3.06%). These are the next Vulkan-specific targets after the clock control.
4. The vCPU thread consumed 56.122 CPU seconds. `cpu_exec_loop`, TB lookup, hash lookup, and soft-float helpers dominate its xemu samples. This is separate from the Vulkan-side work.

The 32.70% mean device-GPU utilization and 4.15% mean GPU-memory utilization do not indicate device saturation. The trace supports host-side throughput and scheduling pressure as the immediate explanation for 26.46 FPS. It does not yet assign every long frame to one function.

Full ETL remains on the test PC at `[local path omitted]`.

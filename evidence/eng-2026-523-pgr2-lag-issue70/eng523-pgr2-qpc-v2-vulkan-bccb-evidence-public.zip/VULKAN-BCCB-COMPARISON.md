# PGR2 lag-objective QPC-v2 Vulkan comparison

Order: B1-C1-C2-B2. All runs are 60 seconds from immutable snapshot `vm-20260907142321`.

| Run | Source | FPS | Mean ms | p95 ms | p99 ms | GPU mean | Power mean | Status |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| B1 | Baseline | 26.460 | 37.793 | 45.487 | 50.409 | 32.67% | 22.28 W | complete |
| C1 | Candidate | 26.527 | 37.697 | 45.749 | 51.410 | 33.23% | 22.31 W | complete |
| C2 | Candidate | 26.605 | 37.587 | 45.412 | 51.897 | 33.40% | 22.36 W | complete |
| B2 | Baseline | 26.268 | 38.069 | 46.285 | 51.374 | 32.49% | 22.77 W | complete |

| Aggregate mean | Baseline | Candidate | Delta |
| --- | ---: | ---: | ---: |
| Guest cadence | 26.364 FPS | 26.566 FPS | +0.77% |
| Mean interval | 37.931 ms | 37.642 ms | -0.76% |
| p95 | 45.886 ms | 45.581 ms | -0.67% |
| p99 | 50.892 ms | 51.653 ms | +1.50% |
| Device GPU | 32.583% | 33.318% | +2.26% |
| Power | 22.529 W | 22.335 W | -0.86% |

Decision: **Revise / continue attribution.** Average cadence and p95 move favorably, but the improvement is small and p99 regresses. Patch A removes the intended division samples in a partial profile without proving a lag/stutter fix. Measure the short-deadline spin before patch B.

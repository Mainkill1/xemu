#!/usr/bin/env bash
set -euo pipefail
root=/home/deck/xemu-research
revision=55a360daf82a699ecd12d69d8484f32bf1cf3752
archive="$root/runner-55a360d.tar.gz"
app="$root/runner-55a360d"
old_app="$root/runner-2c4254d"
old_unit=xemu-research-runner-20261003-2c4254d.service
new_unit=xemu-research-runner-20261003-55a360d
config="$root/runner.json"
expected_archive=cfd66fdc806a14b2543e5d4065f68eec154c521c729b8e56b0a31f53a11fb8ac
actual_archive=$(sha256sum "$archive")
test "${actual_archive%% *}" = "$expected_archive"
test ! -e "$app"
test -r /run/user/1000/xauth_IUEWSd
mkdir "$app"
tar -xzf "$archive" -C "$app" --strip-components=1
python3 - "$app" "$revision" <<'VERIFY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);manifest=json.loads((root/'release.json').read_text())
assert manifest['sourceCommit']==sys.argv[2]
for name,e in manifest['files'].items():
 p=root/name
 with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 assert p.stat().st_size==e['bytes'] and actual==e['sha256'],name
print(json.dumps({'sourceCommit':manifest['sourceCommit'],'verifiedFiles':len(manifest['files'])}))
VERIFY
test "$("$app/XemuTestRunner" --version)" = "0.2.0+$revision"
config_hash=$(sha256sum "$config")
launch_runner() {
 systemd-run --user --unit="$1" --working-directory="$root" \
 --setenv=DISPLAY=:0 --setenv=XAUTHORITY=/run/user/1000/xauth_IUEWSd \
 --setenv=XDG_RUNTIME_DIR=/run/user/1000 \
 --setenv=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus \
 "$2/XemuTestRunner" run -c "$config" --non-interactive
}
recover() {
 systemctl --user stop "$new_unit.service" 2>/dev/null || true
 launch_runner xemu-research-runner-20261003-2c4254d-recovery "$old_app"
}
trap recover ERR
# Operator upgrade only. LAN HTTP preflight has confirmed idle and zero queued work.
systemctl --user stop "$old_unit"
python3 - "$root" <<'BACKUP'
from pathlib import Path
import hashlib,json,tarfile
root=Path(__import__('sys').argv[1]);dest=root/'upgrade-55a360d'
dest.mkdir(exist_ok=False)
files=[root/'runner.json']
pending=root/'workspace/Queue/Pending'
for directory in ('.agent-tests','.xiso-suites','.xiso-campaigns','.requested-tests'):
 files.extend(sorted((pending/directory).rglob('*.json')))
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(dest/'metadata-before.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
(dest/'hashes-before.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps({'independentMetadataBackupFiles':len(files),'backup':str(dest)}))
BACKUP
launch_runner "$new_unit" "$app"
systemctl --user is-active "$new_unit.service"
test "$(sha256sum "$config")" = "$config_hash"
trap - ERR
printf '%s\n' 'Updated runner started; config, original application and metadata backup retained.'

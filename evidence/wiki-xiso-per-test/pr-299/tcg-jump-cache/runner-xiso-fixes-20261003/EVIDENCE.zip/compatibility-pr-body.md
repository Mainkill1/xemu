## Recommendation: HOLD

**Summary:** Preserve archived XISO campaign identities after #97 adds the optional configuration-source field. The Deck upgrade reproduced rejection of an already completed campaign; a retained HTTP regression reproduces it before this fix and passes afterward. Keep this PR draft for review.
**Remaining:** Review of this compatibility fix. No merge requested.

### Problem

Older canonical requests have eight fields. Deserializing them into the extended record adds a null `ConfigurationSource` during hashing, so both archive reads and idempotent creation reject their original immutable identities. This affects access to historical results rather than the execution outcome of those results.

### What this PR changes

`MatchesXisoCampaignRequest` validates the current request format, then accepts the exact previous eight-field format only when the source is unspecified. Both archive reads and idempotent creation use it. Plan hashes, selections, source choices, authorization and stored files remain checked and unchanged.

### Why this approach

```text
BEFORE: old request -> extended serialization -> different hash -> archive rejected
AFTER: current hash or exact old request hash with unspecified source -> verified archive
```

This preserves both older requests and requests created by #97 without rewriting evidence or weakening integrity checks.

### Validation and results

The retained real HTTP test first fails with the observed identity error. With the fix, all 26 XISO checks pass on this independent branch. The regression checks read access, idempotence, rejection of changed selections and explicit source choices, corrupt-hash rejection, and byte preservation of the original file. The integration branch also passes all eleven managed suites.

Steam Deck `.123` runs the integrated fix. HTTP checks confirm its archived A/A status, frozen plan and report are identical to their pre-upgrade values. Configuration-source controls are checked through HTTP without starting new emulator measurements. Detailed maintenance evidence belongs to xemu PR #299 and will be linked here after publication. Performance improvement: N/A.

### Risks and related work

Compatibility recognizes only the previous known request shape; explicitly changed configuration sources require a new identity. This PR is independent of the standalone-process tool in #89. Relates to #97; preserves #96's stop-after-setup-failure behavior.

> **Agent Declaration:** Created and verified with Codex / GPT-6 assistance; no merge performed.

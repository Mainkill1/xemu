## Recommendation: HOLD

**Summary:** Retain standalone component tests through the maintained HTTP runner, now including main `23763249`’s portable saved-test identity fix. Default xemu jobs preserve the controller binding and measurement-start scene guards. Head `c264004dfc906eef008c8a7235764c37daee330b` passes fresh API, runner, XISO, state and finalization checks. The Deck runner is upgraded and all 29 retained jump-cache component checks pass through HTTP. Keep this PR draft for review.
**Remaining:** Human review; native Windows process/cancellation/crash qualification is not added here.

### Problem

Component fixtures need process supervision, canonical outcomes and archival without xemu QMP arguments/readiness. The production RAM benchmark in [xemu #275](https://github.com/Mainkill1/xemu/pull/275) uses this retained tool. Old runner deployments also lacked main's latest controller/scene safeguards.

### What this PR changes

- `JobDefinition` accepts strict string `TargetKind: "process"`, rejects guest/input/RenderDoc/diagnostic contracts, and omits default xemu kind from serialization to preserve existing identities.
- `RunnerEngine` launches declared arguments without QMP readiness/watchdog or automatic xemu bundles. It retains exit/crash handling, wall-clock timeout, cancellation, telemetry, artifact checks, metrics and archival.
- `DiagnosticHub.ClearCompleted` resets detached diagnostic records before process preflight; the preceding run's finalized evidence stays intact.
- Main #95’s portable identity support accepts existing Windows newline hashes while preserving immutable revisions; catalog listing validates definitions and reports corrupt entries.
- HTTP discovery advertises `standaloneProcesses`; the submit client verifies it before mutation and rejects ambiguous case-variant target keys. Retained example and real child-process fixtures remain included.

### Why this approach

```text
BEFORE: every target -> xemu QMP setup -> control/watchdog -> archival
AFTER: strict target kind
       xemu -> existing guarded control/scene path -> archival
       process -> exact arguments + native supervision -> archival
```

Process jobs cannot qualify guest/renderer state. Integration regression failed on the old feature before replaying fixed main. Fresh review exposed cross-run diagnostic leakage and duplicate-key capability bypass; both have observed failing-then-passing regressions.

### Validation

| Fresh check at `c264004` | Result |
| --- | --- |
| RunnerChecks / AgentChecks | 48/48 / 142/142 |
| XISO / state / finalization | 23/23 / 16/16 / 6/6 |
| Self-contained release build | Passed |
| Current CI | 21/21 successful at `c264004` |

Previous head `62eff1c` passed the remaining managed/controller, Python, embedded-client, packaging and native-helper checks listed in its retained history. Only main #95’s identity changes were added; helper source is byte-identical and its verified packaged binary is retained.

Local Python loopback fixtures initially rejected inherited SSH markers; those failures were retained and only fixture subprocess markers cleared. Deck used LAN HTTP throughout normal testing; production anti-SSH policy remains enforced.

### Results

Deck `.123` runs exact packaged head `c264004`, with all 59 payload files verified. The configuration and previous application are retained. All 571 archived entries and all 238 saved-test identities survive the upgrade; the validated catalog reports zero integrity issues. Three retained xemu jump-cache fixtures pass 13/13, 7/7 and 9/9 checks with exact `--tap` arguments, no QMP or automatic diagnostics, and 63 archived files with zero exclusions. Emulator results and upgrade qualification records belong to [xemu #299’s evidence packet](https://github.com/Mainkill1/xemu/blob/9b55e8fa90834bf7a816124ef012d46396fbb8a8/evidence/wiki-xiso-per-test/pr-299/tcg-jump-cache/REPORT.md).
Emulator raw output and assertions are in [xemu #275's native packet](https://github.com/Mainkill1/xemu/blob/61acae8fa10b19ef38735efac96c580955c7d991/docs/evidence/issue197-runner-maintenance-20261003/REPORT.md). **Performance: N/A**—this maintenance qualifies process execution and contracts, not a speedup. Future game measurements use fresh immutable controller/scene gates and A/A before ABBA/BAAB.

### Risks and related work

Native Windows process execution and new native cancellation/crash coverage remain unqualified; existing shared managed paths pass. A process result does not establish game, guest, Mesa or audio performance. Replaces the historical `f5b3e58` deployment; [main controller #93](https://github.com/Mainkill1/Xemu-Test-Runner/pull/93) and [scene #94](https://github.com/Mainkill1/Xemu-Test-Runner/pull/94) safeguards and [portable identity #95](https://github.com/Mainkill1/Xemu-Test-Runner/pull/95) are included. No merge requested.

> **Agent Declaration**: This pull request was created with assistance from Codex / GPT-6; final code review by GPT-6-astra.


"""Read-only upgrade qualification using maintained LAN HTTP clients."""
from pathlib import Path
import json
import sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
OUT = ROOT / 'artifacts/runner-xiso-fixes-upgrade-20261003'
OLD = ROOT / 'artifacts/issue167-corrected-matrix-20261003'
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi

api = RunnerApi('http://10.0.0.123:9368')
records = []
for case in ('aa', 'parity', 'dormant', 'counters', 'conflicts'):
    campaign = f'i167-correct-{case}-31c-001'
    for suffix, route in (
        ('plan', '?view=plan'),
        ('report', '/report?format=json'),
        ('terminal-status', ''),
    ):
        current = api.json('/api/v1/xiso-campaigns/' + campaign + route)
        original = json.loads((OLD / f'{case}-{suffix}.json').read_text())
        assert current == original, (case, suffix)
        (OUT / f'preserved-{case}-{suffix}.json').write_text(json.dumps(current, indent=2) + '\n')
    records.append({'campaign': campaign, 'originalPlanReportStatusIdentical': True})
status = api.json('/api/v1/status')
discovery = api.require('standaloneProcesses')
assert discovery['version'] == '0.2.0+' + json.loads((OUT / 'fixed-package-provenance.json').read_text())['sourceCommit']
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
assert status['Queue'] == json.loads((OUT / 'before-status.json').read_text())['Queue']
assert json.loads((OUT / 'original-metadata-preservation.json').read_text())['unchanged']
summary = {
    'runnerVersion': discovery['version'],
    'host': api.base_url if hasattr(api, 'base_url') else 'http://10.0.0.123:9368',
    'preservedCampaigns': records,
    'preservedNativeAttempts': 40,
    'originalMetadataFilesUnchanged': 1091,
    'newMeasurementAttempts': 0,
    'archivedNativeEntries': status['Queue']['Tested'],
    'idle': True,
    'performanceClaim': False,
}
(OUT / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))

## XISO campaign i167-correct-parity-31c-001 — eligible

Suite `i167-corrected-parity-v1-suite` · ISO `74a10c400f4fb280dcb4037e38e7e4d3150e73e0061a04f65b3c68cc61a49e63` · catalog `sha256:34b8ee7f91f3412b5e7758aab9f4ca08746ef2e97fee8b5c61be8947e145f7f4` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 0 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 2 | 0 | 0 | -0.38% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.code_stable | 2515605.25 | 2522349.50 | -0.27% | -0.10% | -0.15% | — |
| cpu | cpu_translation_blocks.code_rewrite | 3005848.75 | 3020585.50 | -0.49% | -2.17% | -0.22% | — |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

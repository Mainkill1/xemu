## XISO campaign issue167-stable-conflicts-7cb38844-001 — ineligible

Suite `issue167-deck-cpu-conflicts-7cb38844-suite-v1` · ISO `74a10c400f4fb280dcb4037e38e7e4d3150e73e0061a04f65b3c68cc61a49e63` · catalog `sha256:34b8ee7f91f3412b5e7758aab9f4ca08746ef2e97fee8b5c61be8947e145f7f4` · suite qualification `unverified`
Indexed attempts: 1/1. Changes above 1%: 0 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Comparison blockers
- The campaign does not contain eight attempts per chunk.
- Chunk 1: ABBA/BAAB schedule is missing or out of order.

No numeric gains are published until every planned attempt is indexed and eligible.

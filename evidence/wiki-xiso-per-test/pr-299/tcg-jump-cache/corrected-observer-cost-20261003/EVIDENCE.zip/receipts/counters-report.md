## XISO campaign i167-correct-counters-31c-001 — eligible

Suite `i167-corrected-counters-v1-suite` · ISO `74a10c400f4fb280dcb4037e38e7e4d3150e73e0061a04f65b3c68cc61a49e63` · catalog `sha256:34b8ee7f91f3412b5e7758aab9f4ca08746ef2e97fee8b5c61be8947e145f7f4` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 10 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 2 | 0 | 2 | -4.32% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.code_stable | 2513478.00 | 2634314.75 | -4.81% | -4.41% | -5.49% | max_us -4.28%, mean_us -4.65%, median_us -4.81%, min_us -5.48%, p95_us -4.28% |
| cpu | cpu_translation_blocks.code_rewrite | 2987102.00 | 3101423.50 | -3.83% | -6.15% | -3.01% | max_us -2.95%, mean_us -3.64%, median_us -3.83%, min_us -3.74%, p95_us -2.95% |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

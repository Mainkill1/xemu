## XISO campaign i167-victim8-enabled-5679-001 — inconclusive

Suite `i167-corrected-aa-v1-suite` · ISO `74a10c400f4fb280dcb4037e38e7e4d3150e73e0061a04f65b3c68cc61a49e63` · catalog `sha256:34b8ee7f91f3412b5e7758aab9f4ca08746ef2e97fee8b5c61be8947e145f7f4` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 7 metric rows. Opposite ABBA/BAAB outcomes: 1.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 2 | 1 | 0 | +1.18% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.code_stable | 2533433.75 | 2454694.00 | +3.11% | +2.57% | +3.76% | max_us +3.67%, mean_us +3.23%, median_us +3.11%, min_us +3.29%, p95_us +3.67% |
| cpu | cpu_translation_blocks.code_rewrite | 3116576.00 | 3139722.00 | -0.74% | +1.18% | -2.72% | max_us -1.39%, p95_us -1.39% (orders disagree) |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

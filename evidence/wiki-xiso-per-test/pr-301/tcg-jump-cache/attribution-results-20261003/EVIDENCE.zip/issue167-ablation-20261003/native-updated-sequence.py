"""Frozen attribution campaigns, using maintained LAN HTTP and no reruns."""
import sys,json,subprocess,hashlib
from pathlib import Path
out=Path(__file__).parent;native=out/'native-updated';client=Path('/home/codex/src/steamdeck-xemu/worktrees/runner-standalone-process');sys.path.insert(0,str(client/'scripts'))
from runner_transport import RunnerApi
from runner_xiso import follow,common_contract
api=RunnerApi('http://10.0.0.123:9368');contract=json.loads((out/'CONTRACT-updated.json').read_text());packages=json.loads((out/'PACKAGES.json').read_text())
def call(label,script,args):
 path=native/(label+'.json');assert not path.exists(),str(path)
 p=subprocess.run(['python3',str(client/'scripts'/script),'--url',api.url,*args],capture_output=True);path.write_bytes(p.stdout);(native/(label+'.stderr.log')).write_bytes(p.stderr)
 assert p.returncode==0,p.stderr.decode()+p.stdout.decode()
 return json.loads(p.stdout)
def idle():
 s=api.json('/api/v1/status');assert s['Phase']=='idle' and s['Queue']['Pending']==s['Queue']['Testing']==0,s
idle()
info=api.json('/api/v1/agent?view=summary');(native/'runner-discovery.json').write_text(json.dumps(info,indent=2)+'\n')
assert contract['runnerCommit'] in json.dumps(info),info
for mode in ['inline','bypass']:
 for name,digest in packages[mode]['files'].items():assert hashlib.sha256((out/(mode+'-package')/name).read_bytes()).hexdigest()==digest
 call(mode+'-uploaded','runner_tests.py',['upload',str(out/(mode+'-package')),'--exe','xemu','--id',packages[mode]['application']])
base=json.loads((out/'native/aa-plan.json').read_text());expected=common_contract(base)
for case,selection in [('aa',contract['aa']),*contract['comparisons'].items()]:
 idle();cid=selection['campaign'];call(case+'-selected','runner_xiso.py',['select',selection['B'],'--reference',selection['A'],'--suite',contract['suite'],'--id',cid,'--configuration-source','suite','--test',contract['selectedLeaves'][0],'--test',contract['selectedLeaves'][1],'--mode','monolithic'])
 plan=call(case+'-plan','runner_xiso.py',['plan',cid]);assert common_contract(plan)==expected,(case,common_contract(plan),expected)
 call(case+'-start','runner_xiso.py',['start',cid]);print('Started '+cid+' physical ABBA then BAAB',flush=True)
 r=follow(api,cid,False);(native/(case+'-sequence-wait.json')).write_text(json.dumps(r,indent=2)+'\n')
 assert r['terminal'] and r['passed']==8 and r['failed']==r['incomplete']==0,r
 subprocess.run(['python3',str(out/'collect-updated-via-http.py'),case],check=True)
 print(case+' all eight qualified and collected',flush=True)
(native/'SEQUENCE-COMPLETE.json').write_text(json.dumps({'complete':True,'campaigns':['aa','inline','recovery'],'runner':contract['runnerCommit'],'attempts':24},indent=2)+'\n')


/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-on/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000041c070 <tcg_victim_cache_lookup>:
  41c070:	53                   	push   %rbx
  41c071:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  41c076:	48 8b 87 10 00 01 00 	mov    0x10010(%rdi),%rax
  41c07d:	48 39 c2             	cmp    %rax,%rdx
  41c080:	74 26                	je     41c0a8 <tcg_victim_cache_lookup+0x38>
  41c082:	c7 87 28 00 01 00 00 	movl   $0x0,0x10028(%rdi)
  41c089:	00 00 00 
  41c08c:	31 db                	xor    %ebx,%ebx
  41c08e:	48 89 d8             	mov    %rbx,%rax
  41c091:	5b                   	pop    %rbx
  41c092:	31 d2                	xor    %edx,%edx
  41c094:	31 c9                	xor    %ecx,%ecx
  41c096:	31 f6                	xor    %esi,%esi
  41c098:	31 ff                	xor    %edi,%edi
  41c09a:	45 31 c0             	xor    %r8d,%r8d
  41c09d:	45 31 c9             	xor    %r9d,%r9d
  41c0a0:	c3                   	ret
  41c0a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  41c0a8:	8b 8f 18 00 01 00    	mov    0x10018(%rdi),%ecx
  41c0ae:	85 c9                	test   %ecx,%ecx
  41c0b0:	75 d0                	jne    41c082 <tcg_victim_cache_lookup+0x12>
  41c0b2:	8b 87 28 00 01 00    	mov    0x10028(%rdi),%eax
  41c0b8:	85 c0                	test   %eax,%eax
  41c0ba:	75 0f                	jne    41c0cb <tcg_victim_cache_lookup+0x5b>
  41c0bc:	eb ce                	jmp    41c08c <tcg_victim_cache_lookup+0x1c>
  41c0be:	66 90                	xchg   %ax,%ax
  41c0c0:	83 c1 01             	add    $0x1,%ecx
  41c0c3:	3b 8f 28 00 01 00    	cmp    0x10028(%rdi),%ecx
  41c0c9:	73 c1                	jae    41c08c <tcg_victim_cache_lookup+0x1c>
  41c0cb:	89 c8                	mov    %ecx,%eax
  41c0cd:	48 c1 e0 04          	shl    $0x4,%rax
  41c0d1:	48 01 f8             	add    %rdi,%rax
  41c0d4:	4c 3b 88 38 00 01 00 	cmp    0x10038(%rax),%r9
  41c0db:	75 e3                	jne    41c0c0 <tcg_victim_cache_lookup+0x50>
  41c0dd:	48 8b 98 30 00 01 00 	mov    0x10030(%rax),%rbx
  41c0e4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  41c0e9:	48 39 43 08          	cmp    %rax,0x8(%rbx)
  41c0ed:	75 d1                	jne    41c0c0 <tcg_victim_cache_lookup+0x50>
  41c0ef:	8b 44 24 18          	mov    0x18(%rsp),%eax
  41c0f3:	39 43 10             	cmp    %eax,0x10(%rbx)
  41c0f6:	75 c8                	jne    41c0c0 <tcg_victim_cache_lookup+0x50>
  41c0f8:	8b 43 14             	mov    0x14(%rbx),%eax
  41c0fb:	39 44 24 1c          	cmp    %eax,0x1c(%rsp)
  41c0ff:	75 bf                	jne    41c0c0 <tcg_victim_cache_lookup+0x50>
  41c101:	49 89 d0             	mov    %rdx,%r8
  41c104:	48 89 d9             	mov    %rbx,%rcx
  41c107:	4c 89 ca             	mov    %r9,%rdx
  41c10a:	e8 31 fd ff ff       	call   41be40 <tcg_victim_cache_fill>
  41c10f:	84 c0                	test   %al,%al
  41c111:	0f 85 77 ff ff ff    	jne    41c08e <tcg_victim_cache_lookup+0x1e>
  41c117:	e9 70 ff ff ff       	jmp    41c08c <tcg_victim_cache_lookup+0x1c>

Disassembly of section .fini:


/home/codex/src/steamdeck-xemu/worktrees/issue167-parent-76c23c7d/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040b720 <cpu_exec_loop>:
  40b720:	41 57                	push   %r15
  40b722:	49 89 f7             	mov    %rsi,%r15
  40b725:	41 56                	push   %r14
  40b727:	41 55                	push   %r13
  40b729:	41 54                	push   %r12
  40b72b:	55                   	push   %rbp
  40b72c:	53                   	push   %rbx
  40b72d:	48 89 fb             	mov    %rdi,%rbx
  40b730:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  40b737:	8b af d0 02 00 00    	mov    0x2d0(%rdi),%ebp
  40b73d:	85 ed                	test   %ebp,%ebp
  40b73f:	0f 89 09 07 00 00    	jns    40be4e <cpu_exec_loop+0x72e>
  40b745:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40b74c:	00 00 00 00 
  40b750:	e8 7b 5a fc ff       	call   3d11d0 <replay_has_exception>
  40b755:	84 c0                	test   %al,%al
  40b757:	74 17                	je     40b770 <cpu_exec_loop+0x50>
  40b759:	0f b7 83 50 4b 00 00 	movzwl 0x4b50(%rbx),%eax
  40b760:	48 03 83 e0 00 00 00 	add    0xe0(%rbx),%rax
  40b767:	0f 84 6a 08 00 00    	je     40bfd7 <cpu_exec_loop+0x8b7>
  40b76d:	0f 1f 00             	nopl   (%rax)
  40b770:	8b 83 cc 00 00 00    	mov    0xcc(%rbx),%eax
  40b776:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
  40b77d:	00 
  40b77e:	45 31 ed             	xor    %r13d,%r13d
  40b781:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40b788:	00 00 00 00 
  40b78c:	0f 1f 40 00          	nopl   0x0(%rax)
  40b790:	83 f8 ff             	cmp    $0xffffffff,%eax
  40b793:	74 0b                	je     40b7a0 <cpu_exec_loop+0x80>
  40b795:	a9 00 00 01 00       	test   $0x10000,%eax
  40b79a:	0f 85 a0 00 00 00    	jne    40b840 <cpu_exec_loop+0x120>
  40b7a0:	31 c0                	xor    %eax,%eax
  40b7a2:	66 87 83 52 4b 00 00 	xchg   %ax,0x4b52(%rbx)
  40b7a9:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40b7af:	85 c0                	test   %eax,%eax
  40b7b1:	0f 85 a9 05 00 00    	jne    40bd60 <cpu_exec_loop+0x640>
  40b7b7:	0f b6 83 c7 00 00 00 	movzbl 0xc7(%rbx),%eax
  40b7be:	84 c0                	test   %al,%al
  40b7c0:	75 2a                	jne    40b7ec <cpu_exec_loop+0xcc>
  40b7c2:	8b 0d b0 2b 32 01    	mov    0x1322bb0(%rip),%ecx        # 172e378 <use_icount>
  40b7c8:	85 c9                	test   %ecx,%ecx
  40b7ca:	74 74                	je     40b840 <cpu_exec_loop+0x120>
  40b7cc:	8b 83 cc 00 00 00    	mov    0xcc(%rbx),%eax
  40b7d2:	83 f8 ff             	cmp    $0xffffffff,%eax
  40b7d5:	74 05                	je     40b7dc <cpu_exec_loop+0xbc>
  40b7d7:	f6 c4 20             	test   $0x20,%ah
  40b7da:	74 64                	je     40b840 <cpu_exec_loop+0x120>
  40b7dc:	0f b7 83 50 4b 00 00 	movzwl 0x4b50(%rbx),%eax
  40b7e3:	48 03 83 e0 00 00 00 	add    0xe0(%rbx),%rax
  40b7ea:	75 54                	jne    40b840 <cpu_exec_loop+0x120>
  40b7ec:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40b7f2:	83 fd ff             	cmp    $0xffffffff,%ebp
  40b7f5:	0f 85 42 ff ff ff    	jne    40b73d <cpu_exec_loop+0x1d>
  40b7fb:	c7 83 d0 02 00 00 00 	movl   $0x10000,0x2d0(%rbx)
  40b802:	00 01 00 
  40b805:	bd 00 00 01 00       	mov    $0x10000,%ebp
  40b80a:	c7 83 d0 02 00 00 ff 	movl   $0xffffffff,0x2d0(%rbx)
  40b811:	ff ff ff 
  40b814:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  40b81b:	89 e8                	mov    %ebp,%eax
  40b81d:	5b                   	pop    %rbx
  40b81e:	5d                   	pop    %rbp
  40b81f:	41 5c                	pop    %r12
  40b821:	41 5d                	pop    %r13
  40b823:	41 5e                	pop    %r14
  40b825:	41 5f                	pop    %r15
  40b827:	31 d2                	xor    %edx,%edx
  40b829:	31 c9                	xor    %ecx,%ecx
  40b82b:	31 f6                	xor    %esi,%esi
  40b82d:	31 ff                	xor    %edi,%edi
  40b82f:	45 31 c0             	xor    %r8d,%r8d
  40b832:	45 31 c9             	xor    %r9d,%r9d
  40b835:	45 31 d2             	xor    %r10d,%r10d
  40b838:	c3                   	ret
  40b839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40b840:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40b847:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  40b84c:	48 89 de             	mov    %rbx,%rsi
  40b84f:	48 8b 80 50 01 00 00 	mov    0x150(%rax),%rax
  40b856:	ff 50 18             	call   *0x18(%rax)
  40b859:	44 8b 83 cc 00 00 00 	mov    0xcc(%rbx),%r8d
  40b860:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
  40b865:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
  40b869:	0f 84 99 03 00 00    	je     40bc08 <cpu_exec_loop+0x4e8>
  40b86f:	c7 83 cc 00 00 00 ff 	movl   $0xffffffff,0xcc(%rbx)
  40b876:	ff ff ff 
  40b879:	48 83 bb 40 02 00 00 	cmpq   $0x0,0x240(%rbx)
  40b880:	00 
  40b881:	0f 85 c9 03 00 00    	jne    40bc50 <cpu_exec_loop+0x530>
  40b887:	8b 05 b7 72 2d 01    	mov    0x12d72b7(%rip),%eax        # 16e2b44 <target_page+0x4>
  40b88d:	8b 54 24 48          	mov    0x48(%rsp),%edx
  40b891:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  40b896:	4c 8b 8b 18 02 00 00 	mov    0x218(%rbx),%r9
  40b89d:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  40b8a2:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  40b8a7:	8d 48 fa             	lea    -0x6(%rax),%ecx
  40b8aa:	4c 89 f0             	mov    %r14,%rax
  40b8ad:	48 d3 e8             	shr    %cl,%rax
  40b8b0:	4c 31 f0             	xor    %r14,%rax
  40b8b3:	49 89 c4             	mov    %rax,%r12
  40b8b6:	83 e0 3f             	and    $0x3f,%eax
  40b8b9:	49 d3 ec             	shr    %cl,%r12
  40b8bc:	41 81 e4 c0 0f 00 00 	and    $0xfc0,%r12d
  40b8c3:	41 09 c4             	or     %eax,%r12d
  40b8c6:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
  40b8cb:	48 c1 e1 04          	shl    $0x4,%rcx
  40b8cf:	4d 8d 14 09          	lea    (%r9,%rcx,1),%r10
  40b8d3:	49 8b 2a             	mov    (%r10),%rbp
  40b8d6:	48 85 ed             	test   %rbp,%rbp
  40b8d9:	0f 84 f1 01 00 00    	je     40bad0 <cpu_exec_loop+0x3b0>
  40b8df:	4c 89 e0             	mov    %r12,%rax
  40b8e2:	48 c1 e0 04          	shl    $0x4,%rax
  40b8e6:	4e 39 74 08 18       	cmp    %r14,0x18(%rax,%r9,1)
  40b8eb:	0f 85 df 01 00 00    	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b8f1:	48 39 75 08          	cmp    %rsi,0x8(%rbp)
  40b8f5:	0f 85 d5 01 00 00    	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b8fb:	39 55 10             	cmp    %edx,0x10(%rbp)
  40b8fe:	0f 85 cc 01 00 00    	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b904:	8b 45 14             	mov    0x14(%rbp),%eax
  40b907:	41 39 c0             	cmp    %eax,%r8d
  40b90a:	0f 85 c0 01 00 00    	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b910:	8b 45 14             	mov    0x14(%rbp),%eax
  40b913:	a9 00 00 02 00       	test   $0x20000,%eax
  40b918:	75 0a                	jne    40b924 <cpu_exec_loop+0x204>
  40b91a:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
  40b91e:	0f 85 10 cb dd ff    	jne    1e8434 <cpu_exec_loop.cold+0x1f>
  40b924:	48 83 7d 50 ff       	cmpq   $0xffffffffffffffff,0x50(%rbp)
  40b929:	75 05                	jne    40b930 <cpu_exec_loop+0x210>
  40b92b:	4d 85 ed             	test   %r13,%r13
  40b92e:	75 78                	jne    40b9a8 <cpu_exec_loop+0x288>
  40b930:	44 8b 05 11 d6 33 01 	mov    0x133d611(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40b937:	45 85 c0             	test   %r8d,%r8d
  40b93a:	0f 85 40 01 00 00    	jne    40ba80 <cpu_exec_loop+0x360>
  40b940:	48 8d 54 24 2c       	lea    0x2c(%rsp),%rdx
  40b945:	48 89 ee             	mov    %rbp,%rsi
  40b948:	48 89 df             	mov    %rbx,%rdi
  40b94b:	e8 b0 fb ff ff       	call   40b500 <cpu_tb_exec>
  40b950:	83 7c 24 2c 03       	cmpl   $0x3,0x2c(%rsp)
  40b955:	49 89 c5             	mov    %rax,%r13
  40b958:	0f 84 22 02 00 00    	je     40bb80 <cpu_exec_loop+0x460>
  40b95e:	80 3d 17 2a 32 01 00 	cmpb   $0x0,0x1322a17(%rip)        # 172e37c <icount_align_option>
  40b965:	74 33                	je     40b99a <cpu_exec_loop+0x27a>
  40b967:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  40b96b:	0f b7 ab 50 4b 00 00 	movzwl 0x4b50(%rbx),%ebp
  40b972:	48 03 ab e0 00 00 00 	add    0xe0(%rbx),%rbp
  40b979:	48 29 ef             	sub    %rbp,%rdi
  40b97c:	e8 4f cd 01 00       	call   4286d0 <icount_to_ns>
  40b981:	49 03 07             	add    (%r15),%rax
  40b984:	49 89 6f 08          	mov    %rbp,0x8(%r15)
  40b988:	49 89 07             	mov    %rax,(%r15)
  40b98b:	48 89 c1             	mov    %rax,%rcx
  40b98e:	48 3d c0 c6 2d 00    	cmp    $0x2dc6c0,%rax
  40b994:	0f 8f 46 03 00 00    	jg     40bce0 <cpu_exec_loop+0x5c0>
  40b99a:	8b 83 cc 00 00 00    	mov    0xcc(%rbx),%eax
  40b9a0:	e9 eb fd ff ff       	jmp    40b790 <cpu_exec_loop+0x70>
  40b9a5:	0f 1f 00             	nopl   (%rax)
  40b9a8:	8b 74 24 2c          	mov    0x2c(%rsp),%esi
  40b9ac:	83 fe 01             	cmp    $0x1,%esi
  40b9af:	0f 87 60 ca dd ff    	ja     1e8415 <cpu_exec_loop.cold>
  40b9b5:	4c 8d 65 58          	lea    0x58(%rbp),%r12
  40b9b9:	ba 01 00 00 00       	mov    $0x1,%edx
  40b9be:	89 d0                	mov    %edx,%eax
  40b9c0:	41 87 04 24          	xchg   %eax,(%r12)
  40b9c4:	85 c0                	test   %eax,%eax
  40b9c6:	0f 85 ee 00 00 00    	jne    40baba <cpu_exec_loop+0x39a>
  40b9cc:	f6 45 15 40          	testb  $0x40,0x15(%rbp)
  40b9d0:	0f 85 9a 01 00 00    	jne    40bb70 <cpu_exec_loop+0x450>
  40b9d6:	4c 63 c6             	movslq %esi,%r8
  40b9d9:	31 c0                	xor    %eax,%eax
  40b9db:	49 8d 50 12          	lea    0x12(%r8),%rdx
  40b9df:	f0 49 0f b1 6c d5 00 	lock cmpxchg %rbp,0x0(%r13,%rdx,8)
  40b9e6:	0f 85 84 01 00 00    	jne    40bb70 <cpu_exec_loop+0x450>
  40b9ec:	48 8b 45 28          	mov    0x28(%rbp),%rax
  40b9f0:	43 0f b7 54 45 60    	movzwl 0x60(%r13,%r8,2),%edx
  40b9f6:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  40b9fb:	49 03 55 28          	add    0x28(%r13),%rdx
  40b9ff:	48 8b 3d c2 8a 30 01 	mov    0x1308ac2(%rip),%rdi        # 17144c8 <tcg_splitwx_diff>
  40ba06:	89 34 24             	mov    %esi,(%rsp)
  40ba09:	4b 89 44 c5 68       	mov    %rax,0x68(%r13,%r8,8)
  40ba0e:	48 89 d1             	mov    %rdx,%rcx
  40ba11:	48 29 f9             	sub    %rdi,%rcx
  40ba14:	4c 01 ef             	add    %r13,%rdi
  40ba17:	e8 04 6d fd ff       	call   3e2720 <tb_target_set_jmp_target>
  40ba1c:	48 8b 45 78          	mov    0x78(%rbp),%rax
  40ba20:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  40ba25:	4b 89 84 c5 80 00 00 	mov    %rax,0x80(%r13,%r8,8)
  40ba2c:	00 
  40ba2d:	4d 09 e8             	or     %r13,%r8
  40ba30:	4c 89 45 78          	mov    %r8,0x78(%rbp)
  40ba34:	41 c7 04 24 00 00 00 	movl   $0x0,(%r12)
  40ba3b:	00 
  40ba3c:	f6 05 9d d1 33 01 20 	testb  $0x20,0x133d19d(%rip)        # 1748be0 <qemu_loglevel>
  40ba43:	8b 34 24             	mov    (%rsp),%esi
  40ba46:	0f 84 e4 fe ff ff    	je     40b930 <cpu_exec_loop+0x210>
  40ba4c:	49 8b 45 28          	mov    0x28(%r13),%rax
  40ba50:	48 8b 4d 28          	mov    0x28(%rbp),%rcx
  40ba54:	89 f2                	mov    %esi,%edx
  40ba56:	48 8d 3d 1b dc cc 00 	lea    0xccdc1b(%rip),%rdi        # 10d9678 <anon.53529a8b42b516fa44fa3e141ddff7ec.0.llvm.534248872324339782+0x2db4f>
  40ba5d:	48 89 c6             	mov    %rax,%rsi
  40ba60:	31 c0                	xor    %eax,%eax
  40ba62:	e8 89 28 26 00       	call   66e2f0 <qemu_log>
  40ba67:	44 8b 05 da d4 33 01 	mov    0x133d4da(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40ba6e:	45 85 c0             	test   %r8d,%r8d
  40ba71:	0f 84 c9 fe ff ff    	je     40b940 <cpu_exec_loop+0x220>
  40ba77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40ba7e:	00 00 
  40ba80:	66 83 3d 8e c7 33 01 	cmpw   $0x0,0x133c78e(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40ba87:	00 
  40ba88:	0f 84 b2 fe ff ff    	je     40b940 <cpu_exec_loop+0x220>
  40ba8e:	f6 05 4c d1 33 01 80 	testb  $0x80,0x133d14c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40ba95:	0f 84 a5 fe ff ff    	je     40b940 <cpu_exec_loop+0x220>
  40ba9b:	4c 89 f2             	mov    %r14,%rdx
  40ba9e:	48 89 ee             	mov    %rbp,%rsi
  40baa1:	48 8d 3d 01 cd c4 00 	lea    0xc4cd01(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40baa8:	31 c0                	xor    %eax,%eax
  40baaa:	e8 41 28 26 00       	call   66e2f0 <qemu_log>
  40baaf:	e9 8c fe ff ff       	jmp    40b940 <cpu_exec_loop+0x220>
  40bab4:	0f 1f 40 00          	nopl   0x0(%rax)
  40bab8:	f3 90                	pause
  40baba:	41 8b 04 24          	mov    (%r12),%eax
  40babe:	85 c0                	test   %eax,%eax
  40bac0:	75 f6                	jne    40bab8 <cpu_exec_loop+0x398>
  40bac2:	e9 f7 fe ff ff       	jmp    40b9be <cpu_exec_loop+0x29e>
  40bac7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40bace:	00 00 
  40bad0:	66 0f 6e c2          	movd   %edx,%xmm0
  40bad4:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  40bad9:	48 83 ec 20          	sub    $0x20,%rsp
  40badd:	48 89 df             	mov    %rbx,%rdi
  40bae0:	66 41 0f 6e c8       	movd   %r8d,%xmm1
  40bae5:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  40baea:	48 8d 15 4f f4 ff ff 	lea    -0xbb1(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40baf1:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
  40baf5:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  40bafa:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  40baff:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
  40bb06:	00 
  40bb07:	44 89 44 24 20       	mov    %r8d,0x20(%rsp)
  40bb0c:	66 0f d6 84 24 88 00 	movq   %xmm0,0x88(%rsp)
  40bb13:	00 00 
  40bb15:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  40bb1c:	00 00 
  40bb1e:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  40bb23:	48 8d 35 b6 27 32 01 	lea    0x13227b6(%rip),%rsi        # 172e2e0 <tb_ctx>
  40bb2a:	0f 11 04 24          	movups %xmm0,(%rsp)
  40bb2e:	e8 ad f5 ff ff       	call   40b0e0 <tb_htable_lookup_common>
  40bb33:	48 83 c4 20          	add    $0x20,%rsp
  40bb37:	44 8b 04 24          	mov    (%rsp),%r8d
  40bb3b:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  40bb40:	48 85 c0             	test   %rax,%rax
  40bb43:	48 89 c5             	mov    %rax,%rbp
  40bb46:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  40bb4b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  40bb50:	0f 84 32 01 00 00    	je     40bc88 <cpu_exec_loop+0x568>
  40bb56:	49 c1 e4 04          	shl    $0x4,%r12
  40bb5a:	4f 89 74 0c 18       	mov    %r14,0x18(%r12,%r9,1)
  40bb5f:	49 89 02             	mov    %rax,(%r10)
  40bb62:	e9 a9 fd ff ff       	jmp    40b910 <cpu_exec_loop+0x1f0>
  40bb67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40bb6e:	00 00 
  40bb70:	41 c7 04 24 00 00 00 	movl   $0x0,(%r12)
  40bb77:	00 
  40bb78:	e9 b3 fd ff ff       	jmp    40b930 <cpu_exec_loop+0x210>
  40bb7d:	0f 1f 00             	nopl   (%rax)
  40bb80:	8b 83 50 4b 00 00    	mov    0x4b50(%rbx),%eax
  40bb86:	85 c0                	test   %eax,%eax
  40bb88:	78 70                	js     40bbfa <cpu_exec_loop+0x4da>
  40bb8a:	8b 3d e8 27 32 01    	mov    0x13227e8(%rip),%edi        # 172e378 <use_icount>
  40bb90:	85 ff                	test   %edi,%edi
  40bb92:	0f 84 da c8 dd ff    	je     1e8472 <cpu_exec_loop.cold+0x5d>
  40bb98:	48 89 df             	mov    %rbx,%rdi
  40bb9b:	e8 30 ca 01 00       	call   4285d0 <icount_update>
  40bba0:	48 8b 93 d8 00 00 00 	mov    0xd8(%rbx),%rdx
  40bba7:	b8 ff ff 00 00       	mov    $0xffff,%eax
  40bbac:	48 39 c2             	cmp    %rax,%rdx
  40bbaf:	48 0f 4e c2          	cmovle %rdx,%rax
  40bbb3:	48 63 c8             	movslq %eax,%rcx
  40bbb6:	66 89 83 50 4b 00 00 	mov    %ax,0x4b50(%rbx)
  40bbbd:	48 29 ca             	sub    %rcx,%rdx
  40bbc0:	48 89 93 e0 00 00 00 	mov    %rdx,0xe0(%rbx)
  40bbc7:	85 c0                	test   %eax,%eax
  40bbc9:	7e 2f                	jle    40bbfa <cpu_exec_loop+0x4da>
  40bbcb:	41 0f b7 4d 1a       	movzwl 0x1a(%r13),%ecx
  40bbd0:	39 c8                	cmp    %ecx,%eax
  40bbd2:	7d 26                	jge    40bbfa <cpu_exec_loop+0x4da>
  40bbd4:	3d ff 01 00 00       	cmp    $0x1ff,%eax
  40bbd9:	0f 8f 74 c8 dd ff    	jg     1e8453 <cpu_exec_loop.cold+0x3e>
  40bbdf:	48 85 d2             	test   %rdx,%rdx
  40bbe2:	0f 85 a9 c8 dd ff    	jne    1e8491 <cpu_exec_loop.cold+0x7c>
  40bbe8:	41 8b 55 14          	mov    0x14(%r13),%edx
  40bbec:	81 e2 00 fe ff ff    	and    $0xfffffe00,%edx
  40bbf2:	09 d0                	or     %edx,%eax
  40bbf4:	89 83 cc 00 00 00    	mov    %eax,0xcc(%rbx)
  40bbfa:	45 31 ed             	xor    %r13d,%r13d
  40bbfd:	e9 5c fd ff ff       	jmp    40b95e <cpu_exec_loop+0x23e>
  40bc02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40bc08:	44 8b 8b d4 00 00 00 	mov    0xd4(%rbx),%r9d
  40bc0f:	44 8b 83 c8 02 00 00 	mov    0x2c8(%rbx),%r8d
  40bc16:	45 85 c9             	test   %r9d,%r9d
  40bc19:	0f 85 f1 02 00 00    	jne    40bf10 <cpu_exec_loop+0x7f0>
  40bc1f:	0f b6 05 a6 26 32 01 	movzbl 0x13226a6(%rip),%eax        # 172e2cc <one_insn_per_tb>
  40bc26:	84 c0                	test   %al,%al
  40bc28:	0f 84 1a 01 00 00    	je     40bd48 <cpu_exec_loop+0x628>
  40bc2e:	41 81 c8 01 02 00 00 	or     $0x201,%r8d
  40bc35:	48 83 bb 40 02 00 00 	cmpq   $0x0,0x240(%rbx)
  40bc3c:	00 
  40bc3d:	0f 84 44 fc ff ff    	je     40b887 <cpu_exec_loop+0x167>
  40bc43:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40bc4a:	00 00 00 00 
  40bc4e:	66 90                	xchg   %ax,%ax
  40bc50:	48 8d 54 24 4c       	lea    0x4c(%rsp),%rdx
  40bc55:	4c 89 f6             	mov    %r14,%rsi
  40bc58:	48 89 df             	mov    %rbx,%rdi
  40bc5b:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  40bc60:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  40bc65:	e8 66 f3 ff ff       	call   40afd0 <check_for_breakpoints_slow>
  40bc6a:	84 c0                	test   %al,%al
  40bc6c:	0f 85 ce 01 00 00    	jne    40be40 <cpu_exec_loop+0x720>
  40bc72:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
  40bc77:	44 8b 44 24 4c       	mov    0x4c(%rsp),%r8d
  40bc7c:	e9 06 fc ff ff       	jmp    40b887 <cpu_exec_loop+0x167>
  40bc81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40bc88:	48 89 0c 24          	mov    %rcx,(%rsp)
  40bc8c:	48 83 ec 20          	sub    $0x20,%rsp
  40bc90:	48 89 df             	mov    %rbx,%rdi
  40bc93:	49 c1 e4 04          	shl    $0x4,%r12
  40bc97:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  40bc9c:	44 89 44 24 6c       	mov    %r8d,0x6c(%rsp)
  40bca1:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  40bca7:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  40bcac:	0f 11 04 24          	movups %xmm0,(%rsp)
  40bcb0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  40bcb5:	e8 26 e5 00 00       	call   41a1e0 <tb_gen_code>
  40bcba:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  40bcbf:	48 83 c4 20          	add    $0x20,%rsp
  40bcc3:	48 89 c5             	mov    %rax,%rbp
  40bcc6:	48 8b 83 18 02 00 00 	mov    0x218(%rbx),%rax
  40bccd:	4d 89 74 04 18       	mov    %r14,0x18(%r12,%rax,1)
  40bcd2:	48 89 2c 08          	mov    %rbp,(%rax,%rcx,1)
  40bcd6:	e9 49 fc ff ff       	jmp    40b924 <cpu_exec_loop+0x204>
  40bcdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40bce0:	66 0f ef c0          	pxor   %xmm0,%xmm0
  40bce4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  40bce9:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  40bcee:	48 b8 b3 94 d6 26 e8 	movabs $0x112e0be826d694b3,%rax
  40bcf5:	0b 2e 11 
  40bcf8:	48 f7 e9             	imul   %rcx
  40bcfb:	48 89 c8             	mov    %rcx,%rax
  40bcfe:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  40bd03:	48 c1 f8 3f          	sar    $0x3f,%rax
  40bd07:	48 c1 fa 1a          	sar    $0x1a,%rdx
  40bd0b:	48 29 c2             	sub    %rax,%rdx
  40bd0e:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  40bd13:	48 69 d2 00 ca 9a 3b 	imul   $0x3b9aca00,%rdx,%rdx
  40bd1a:	48 29 d1             	sub    %rdx,%rcx
  40bd1d:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  40bd22:	e8 89 a9 dc ff       	call   1d66b0 <nanosleep@plt>
  40bd27:	89 c2                	mov    %eax,%edx
  40bd29:	31 c0                	xor    %eax,%eax
  40bd2b:	85 d2                	test   %edx,%edx
  40bd2d:	79 0e                	jns    40bd3d <cpu_exec_loop+0x61d>
  40bd2f:	48 69 44 24 60 00 ca 	imul   $0x3b9aca00,0x60(%rsp),%rax
  40bd36:	9a 3b 
  40bd38:	48 03 44 24 68       	add    0x68(%rsp),%rax
  40bd3d:	49 89 07             	mov    %rax,(%r15)
  40bd40:	e9 55 fc ff ff       	jmp    40b99a <cpu_exec_loop+0x27a>
  40bd45:	0f 1f 00             	nopl   (%rax)
  40bd48:	44 89 c0             	mov    %r8d,%eax
  40bd4b:	80 cc 02             	or     $0x2,%ah
  40bd4e:	f6 05 8c ce 33 01 20 	testb  $0x20,0x133ce8c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bd55:	44 0f 45 c0          	cmovne %eax,%r8d
  40bd59:	e9 1b fb ff ff       	jmp    40b879 <cpu_exec_loop+0x159>
  40bd5e:	66 90                	xchg   %ax,%ax
  40bd60:	be 52 03 00 00       	mov    $0x352,%esi
  40bd65:	48 8d 3d df c9 c4 00 	lea    0xc4c9df(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40bd6c:	e8 7f d2 f5 ff       	call   368ff0 <bql_lock_impl>
  40bd71:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bd77:	a8 80                	test   $0x80,%al
  40bd79:	0f 85 d9 01 00 00    	jne    40bf58 <cpu_exec_loop+0x838>
  40bd7f:	83 3d a2 85 30 01 02 	cmpl   $0x2,0x13085a2(%rip)        # 1714328 <replay_mode>
  40bd86:	0f 84 54 01 00 00    	je     40bee0 <cpu_exec_loop+0x7c0>
  40bd8c:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bd92:	a8 20                	test   $0x20,%al
  40bd94:	0f 85 86 01 00 00    	jne    40bf20 <cpu_exec_loop+0x800>
  40bd9a:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40bda1:	8b ab d0 00 00 00    	mov    0xd0(%rbx),%ebp
  40bda7:	4c 8b a0 50 01 00 00 	mov    0x150(%rax),%r12
  40bdae:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bdb4:	f6 c4 04             	test   $0x4,%ah
  40bdb7:	75 6e                	jne    40be27 <cpu_exec_loop+0x707>
  40bdb9:	89 e8                	mov    %ebp,%eax
  40bdbb:	48 89 df             	mov    %rbx,%rdi
  40bdbe:	25 a5 ed ff ff       	and    $0xffffeda5,%eax
  40bdc3:	f6 83 d4 00 00 00 02 	testb  $0x2,0xd4(%rbx)
  40bdca:	0f 45 e8             	cmovne %eax,%ebp
  40bdcd:	89 ee                	mov    %ebp,%esi
  40bdcf:	41 ff 54 24 58       	call   *0x58(%r12)
  40bdd4:	84 c0                	test   %al,%al
  40bdd6:	74 30                	je     40be08 <cpu_exec_loop+0x6e8>
  40bdd8:	49 8b 84 24 b8 00 00 	mov    0xb8(%r12),%rax
  40bddf:	00 
  40bde0:	48 85 c0             	test   %rax,%rax
  40bde3:	74 3b                	je     40be20 <cpu_exec_loop+0x700>
  40bde5:	89 ef                	mov    %ebp,%edi
  40bde7:	ff d0                	call   *%rax
  40bde9:	84 c0                	test   %al,%al
  40bdeb:	75 33                	jne    40be20 <cpu_exec_loop+0x700>
  40bded:	8b b3 d4 00 00 00    	mov    0xd4(%rbx),%esi
  40bdf3:	85 f6                	test   %esi,%esi
  40bdf5:	0f 85 51 02 00 00    	jne    40c04c <cpu_exec_loop+0x92c>
  40bdfb:	c7 83 d0 02 00 00 ff 	movl   $0xffffffff,0x2d0(%rbx)
  40be02:	ff ff ff 
  40be05:	45 31 ed             	xor    %r13d,%r13d
  40be08:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40be0e:	a8 04                	test   $0x4,%al
  40be10:	0f 85 e5 00 00 00    	jne    40befb <cpu_exec_loop+0x7db>
  40be16:	e8 25 d2 f5 ff       	call   369040 <bql_unlock>
  40be1b:	e9 97 f9 ff ff       	jmp    40b7b7 <cpu_exec_loop+0x97>
  40be20:	e8 eb 53 fc ff       	call   3d1210 <replay_interrupt>
  40be25:	eb c6                	jmp    40bded <cpu_exec_loop+0x6cd>
  40be27:	e8 e4 53 fc ff       	call   3d1210 <replay_interrupt>
  40be2c:	48 89 df             	mov    %rbx,%rdi
  40be2f:	41 ff 54 24 60       	call   *0x60(%r12)
  40be34:	e8 07 d2 f5 ff       	call   369040 <bql_unlock>
  40be39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40be40:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40be46:	85 ed                	test   %ebp,%ebp
  40be48:	0f 88 02 f9 ff ff    	js     40b750 <cpu_exec_loop+0x30>
  40be4e:	81 fd ff ff 00 00    	cmp    $0xffff,%ebp
  40be54:	0f 8f 25 01 00 00    	jg     40bf7f <cpu_exec_loop+0x85f>
  40be5a:	e8 81 52 fc ff       	call   3d10e0 <replay_exception>
  40be5f:	84 c0                	test   %al,%al
  40be61:	0f 84 59 01 00 00    	je     40bfc0 <cpu_exec_loop+0x8a0>
  40be67:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40be6e:	be 06 03 00 00       	mov    $0x306,%esi
  40be73:	48 8d 3d d1 c8 c4 00 	lea    0xc4c8d1(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40be7a:	48 8b a8 50 01 00 00 	mov    0x150(%rax),%rbp
  40be81:	e8 6a d1 f5 ff       	call   368ff0 <bql_lock_impl>
  40be86:	48 89 df             	mov    %rbx,%rdi
  40be89:	ff 55 50             	call   *0x50(%rbp)
  40be8c:	e8 af d1 f5 ff       	call   369040 <bql_unlock>
  40be91:	8b 83 d4 00 00 00    	mov    0xd4(%rbx),%eax
  40be97:	c7 83 d0 02 00 00 ff 	movl   $0xffffffff,0x2d0(%rbx)
  40be9e:	ff ff ff 
  40bea1:	85 c0                	test   %eax,%eax
  40bea3:	0f 84 c7 f8 ff ff    	je     40b770 <cpu_exec_loop+0x50>
  40bea9:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40beb0:	48 83 bb 60 02 00 00 	cmpq   $0x0,0x260(%rbx)
  40beb7:	00 
  40beb8:	48 8b 90 50 01 00 00 	mov    0x150(%rax),%rdx
  40bebf:	0f 84 a1 01 00 00    	je     40c066 <cpu_exec_loop+0x946>
  40bec5:	48 8b 42 40          	mov    0x40(%rdx),%rax
  40bec9:	48 85 c0             	test   %rax,%rax
  40becc:	74 05                	je     40bed3 <cpu_exec_loop+0x7b3>
  40bece:	48 89 df             	mov    %rbx,%rdi
  40bed1:	ff d0                	call   *%rax
  40bed3:	bd 02 00 01 00       	mov    $0x10002,%ebp
  40bed8:	e9 37 f9 ff ff       	jmp    40b814 <cpu_exec_loop+0xf4>
  40bedd:	0f 1f 00             	nopl   (%rax)
  40bee0:	e8 1b 54 fc ff       	call   3d1300 <replay_has_interrupt>
  40bee5:	84 c0                	test   %al,%al
  40bee7:	0f 85 9f fe ff ff    	jne    40bd8c <cpu_exec_loop+0x66c>
  40beed:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bef3:	a8 04                	test   $0x4,%al
  40bef5:	0f 84 1b ff ff ff    	je     40be16 <cpu_exec_loop+0x6f6>
  40befb:	be 04 00 00 00       	mov    $0x4,%esi
  40bf00:	48 89 df             	mov    %rbx,%rdi
  40bf03:	45 31 ed             	xor    %r13d,%r13d
  40bf06:	e8 45 d0 e3 ff       	call   248f50 <cpu_reset_interrupt>
  40bf0b:	e9 06 ff ff ff       	jmp    40be16 <cpu_exec_loop+0x6f6>
  40bf10:	41 81 c8 01 0e 00 00 	or     $0xe01,%r8d
  40bf17:	e9 5d f9 ff ff       	jmp    40b879 <cpu_exec_loop+0x159>
  40bf1c:	0f 1f 40 00          	nopl   0x0(%rax)
  40bf20:	e8 eb 52 fc ff       	call   3d1210 <replay_interrupt>
  40bf25:	be 20 00 00 00       	mov    $0x20,%esi
  40bf2a:	48 89 df             	mov    %rbx,%rdi
  40bf2d:	e8 1e d0 e3 ff       	call   248f50 <cpu_reset_interrupt>
  40bf32:	48 b8 01 00 00 00 01 	movabs $0x1000100000001,%rax
  40bf39:	00 01 00 
  40bf3c:	48 89 83 cc 02 00 00 	mov    %rax,0x2cc(%rbx)
  40bf43:	e8 f8 d0 f5 ff       	call   369040 <bql_unlock>
  40bf48:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40bf4e:	e9 ea f7 ff ff       	jmp    40b73d <cpu_exec_loop+0x1d>
  40bf53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40bf58:	be 80 00 00 00       	mov    $0x80,%esi
  40bf5d:	48 89 df             	mov    %rbx,%rdi
  40bf60:	e8 eb cf e3 ff       	call   248f50 <cpu_reset_interrupt>
  40bf65:	c7 83 d0 02 00 00 02 	movl   $0x10002,0x2d0(%rbx)
  40bf6c:	00 01 00 
  40bf6f:	e8 cc d0 f5 ff       	call   369040 <bql_unlock>
  40bf74:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40bf7a:	e9 be f7 ff ff       	jmp    40b73d <cpu_exec_loop+0x1d>
  40bf7f:	81 fd 02 00 01 00    	cmp    $0x10002,%ebp
  40bf85:	0f 85 7f f8 ff ff    	jne    40b80a <cpu_exec_loop+0xea>
  40bf8b:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40bf92:	48 83 bb 60 02 00 00 	cmpq   $0x0,0x260(%rbx)
  40bf99:	00 
  40bf9a:	48 8b 90 50 01 00 00 	mov    0x150(%rax),%rdx
  40bfa1:	74 77                	je     40c01a <cpu_exec_loop+0x8fa>
  40bfa3:	48 8b 42 40          	mov    0x40(%rdx),%rax
  40bfa7:	48 85 c0             	test   %rax,%rax
  40bfaa:	0f 84 5a f8 ff ff    	je     40b80a <cpu_exec_loop+0xea>
  40bfb0:	48 89 df             	mov    %rbx,%rdi
  40bfb3:	ff d0                	call   *%rax
  40bfb5:	e9 50 f8 ff ff       	jmp    40b80a <cpu_exec_loop+0xea>
  40bfba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40bfc0:	e8 3b 53 fc ff       	call   3d1300 <replay_has_interrupt>
  40bfc5:	84 c0                	test   %al,%al
  40bfc7:	0f 85 a3 f7 ff ff    	jne    40b770 <cpu_exec_loop+0x50>
  40bfcd:	bd 00 00 01 00       	mov    $0x10000,%ebp
  40bfd2:	e9 3d f8 ff ff       	jmp    40b814 <cpu_exec_loop+0xf4>
  40bfd7:	8b 93 d4 00 00 00    	mov    0xd4(%rbx),%edx
  40bfdd:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
  40bfe3:	85 d2                	test   %edx,%edx
  40bfe5:	0f 85 a0 00 00 00    	jne    40c08b <cpu_exec_loop+0x96b>
  40bfeb:	0f b6 15 da 22 32 01 	movzbl 0x13222da(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40bff2:	84 d2                	test   %dl,%dl
  40bff4:	75 4f                	jne    40c045 <cpu_exec_loop+0x925>
  40bff6:	89 c2                	mov    %eax,%edx
  40bff8:	80 ce 02             	or     $0x2,%dh
  40bffb:	f6 05 df cb 33 01 20 	testb  $0x20,0x133cbdf(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c002:	0f 45 c2             	cmovne %edx,%eax
  40c005:	25 fe df fe ff       	and    $0xfffedffe,%eax
  40c00a:	0d 01 00 01 00       	or     $0x10001,%eax
  40c00f:	89 83 cc 00 00 00    	mov    %eax,0xcc(%rbx)
  40c015:	e9 5c f7 ff ff       	jmp    40b776 <cpu_exec_loop+0x56>
  40c01a:	48 8b 83 50 02 00 00 	mov    0x250(%rbx),%rax
  40c021:	48 85 c0             	test   %rax,%rax
  40c024:	0f 84 79 ff ff ff    	je     40bfa3 <cpu_exec_loop+0x883>
  40c02a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40c030:	81 60 20 3f ff ff ff 	andl   $0xffffff3f,0x20(%rax)
  40c037:	48 8b 40 28          	mov    0x28(%rax),%rax
  40c03b:	48 85 c0             	test   %rax,%rax
  40c03e:	75 f0                	jne    40c030 <cpu_exec_loop+0x910>
  40c040:	e9 5e ff ff ff       	jmp    40bfa3 <cpu_exec_loop+0x883>
  40c045:	0d 01 02 00 00       	or     $0x201,%eax
  40c04a:	eb b9                	jmp    40c005 <cpu_exec_loop+0x8e5>
  40c04c:	c7 83 d0 02 00 00 02 	movl   $0x10002,0x2d0(%rbx)
  40c053:	00 01 00 
  40c056:	e8 e5 cf f5 ff       	call   369040 <bql_unlock>
  40c05b:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40c061:	e9 d7 f6 ff ff       	jmp    40b73d <cpu_exec_loop+0x1d>
  40c066:	48 8b 83 50 02 00 00 	mov    0x250(%rbx),%rax
  40c06d:	48 85 c0             	test   %rax,%rax
  40c070:	0f 84 4f fe ff ff    	je     40bec5 <cpu_exec_loop+0x7a5>
  40c076:	81 60 20 3f ff ff ff 	andl   $0xffffff3f,0x20(%rax)
  40c07d:	48 8b 40 28          	mov    0x28(%rax),%rax
  40c081:	48 85 c0             	test   %rax,%rax
  40c084:	75 f0                	jne    40c076 <cpu_exec_loop+0x956>
  40c086:	e9 3a fe ff ff       	jmp    40bec5 <cpu_exec_loop+0x7a5>
  40c08b:	0d 01 0e 00 00       	or     $0xe01,%eax
  40c090:	e9 70 ff ff ff       	jmp    40c005 <cpu_exec_loop+0x8e5>

Disassembly of section .fini:

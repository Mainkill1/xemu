
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8-bypass/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000041c070 <tcg_victim_cache_lookup>:
  41c070:	31 c0                	xor    %eax,%eax
  41c072:	c3                   	ret

Disassembly of section .fini:

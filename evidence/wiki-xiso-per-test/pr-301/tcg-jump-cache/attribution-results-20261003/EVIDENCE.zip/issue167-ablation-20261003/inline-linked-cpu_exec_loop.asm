
/home/codex/src/steamdeck-xemu/worktrees/issue167-inline-only/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040b8d0 <cpu_exec_loop>:
  40b8d0:	41 57                	push   %r15
  40b8d2:	49 89 f7             	mov    %rsi,%r15
  40b8d5:	41 56                	push   %r14
  40b8d7:	41 55                	push   %r13
  40b8d9:	41 54                	push   %r12
  40b8db:	55                   	push   %rbp
  40b8dc:	53                   	push   %rbx
  40b8dd:	48 89 fb             	mov    %rdi,%rbx
  40b8e0:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  40b8e7:	8b af d0 02 00 00    	mov    0x2d0(%rdi),%ebp
  40b8ed:	85 ed                	test   %ebp,%ebp
  40b8ef:	0f 89 19 07 00 00    	jns    40c00e <cpu_exec_loop+0x73e>
  40b8f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40b8fc:	00 00 00 00 
  40b900:	e8 cb 58 fc ff       	call   3d11d0 <replay_has_exception>
  40b905:	84 c0                	test   %al,%al
  40b907:	74 17                	je     40b920 <cpu_exec_loop+0x50>
  40b909:	0f b7 83 50 4b 00 00 	movzwl 0x4b50(%rbx),%eax
  40b910:	48 03 83 e0 00 00 00 	add    0xe0(%rbx),%rax
  40b917:	0f 84 7a 08 00 00    	je     40c197 <cpu_exec_loop+0x8c7>
  40b91d:	0f 1f 00             	nopl   (%rax)
  40b920:	8b 83 cc 00 00 00    	mov    0xcc(%rbx),%eax
  40b926:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
  40b92d:	00 
  40b92e:	45 31 ed             	xor    %r13d,%r13d
  40b931:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40b938:	00 00 00 00 
  40b93c:	0f 1f 40 00          	nopl   0x0(%rax)
  40b940:	83 f8 ff             	cmp    $0xffffffff,%eax
  40b943:	74 0b                	je     40b950 <cpu_exec_loop+0x80>
  40b945:	a9 00 00 01 00       	test   $0x10000,%eax
  40b94a:	0f 85 a0 00 00 00    	jne    40b9f0 <cpu_exec_loop+0x120>
  40b950:	31 c0                	xor    %eax,%eax
  40b952:	66 87 83 52 4b 00 00 	xchg   %ax,0x4b52(%rbx)
  40b959:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40b95f:	85 c0                	test   %eax,%eax
  40b961:	0f 85 59 05 00 00    	jne    40bec0 <cpu_exec_loop+0x5f0>
  40b967:	0f b6 83 c7 00 00 00 	movzbl 0xc7(%rbx),%eax
  40b96e:	84 c0                	test   %al,%al
  40b970:	75 2a                	jne    40b99c <cpu_exec_loop+0xcc>
  40b972:	8b 0d 00 2a 32 01    	mov    0x1322a00(%rip),%ecx        # 172e378 <use_icount>
  40b978:	85 c9                	test   %ecx,%ecx
  40b97a:	74 74                	je     40b9f0 <cpu_exec_loop+0x120>
  40b97c:	8b 83 cc 00 00 00    	mov    0xcc(%rbx),%eax
  40b982:	83 f8 ff             	cmp    $0xffffffff,%eax
  40b985:	74 05                	je     40b98c <cpu_exec_loop+0xbc>
  40b987:	f6 c4 20             	test   $0x20,%ah
  40b98a:	74 64                	je     40b9f0 <cpu_exec_loop+0x120>
  40b98c:	0f b7 83 50 4b 00 00 	movzwl 0x4b50(%rbx),%eax
  40b993:	48 03 83 e0 00 00 00 	add    0xe0(%rbx),%rax
  40b99a:	75 54                	jne    40b9f0 <cpu_exec_loop+0x120>
  40b99c:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40b9a2:	83 fd ff             	cmp    $0xffffffff,%ebp
  40b9a5:	0f 85 42 ff ff ff    	jne    40b8ed <cpu_exec_loop+0x1d>
  40b9ab:	c7 83 d0 02 00 00 00 	movl   $0x10000,0x2d0(%rbx)
  40b9b2:	00 01 00 
  40b9b5:	bd 00 00 01 00       	mov    $0x10000,%ebp
  40b9ba:	c7 83 d0 02 00 00 ff 	movl   $0xffffffff,0x2d0(%rbx)
  40b9c1:	ff ff ff 
  40b9c4:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  40b9cb:	89 e8                	mov    %ebp,%eax
  40b9cd:	5b                   	pop    %rbx
  40b9ce:	5d                   	pop    %rbp
  40b9cf:	41 5c                	pop    %r12
  40b9d1:	41 5d                	pop    %r13
  40b9d3:	41 5e                	pop    %r14
  40b9d5:	41 5f                	pop    %r15
  40b9d7:	31 d2                	xor    %edx,%edx
  40b9d9:	31 c9                	xor    %ecx,%ecx
  40b9db:	31 f6                	xor    %esi,%esi
  40b9dd:	31 ff                	xor    %edi,%edi
  40b9df:	45 31 c0             	xor    %r8d,%r8d
  40b9e2:	45 31 c9             	xor    %r9d,%r9d
  40b9e5:	45 31 d2             	xor    %r10d,%r10d
  40b9e8:	c3                   	ret
  40b9e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40b9f0:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40b9f7:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  40b9fc:	48 89 de             	mov    %rbx,%rsi
  40b9ff:	48 8b 80 50 01 00 00 	mov    0x150(%rax),%rax
  40ba06:	ff 50 18             	call   *0x18(%rax)
  40ba09:	44 8b 8b cc 00 00 00 	mov    0xcc(%rbx),%r9d
  40ba10:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  40ba15:	41 83 f9 ff          	cmp    $0xffffffff,%r9d
  40ba19:	0f 84 99 03 00 00    	je     40bdb8 <cpu_exec_loop+0x4e8>
  40ba1f:	c7 83 cc 00 00 00 ff 	movl   $0xffffffff,0xcc(%rbx)
  40ba26:	ff ff ff 
  40ba29:	48 83 bb 40 02 00 00 	cmpq   $0x0,0x240(%rbx)
  40ba30:	00 
  40ba31:	0f 85 c9 03 00 00    	jne    40be00 <cpu_exec_loop+0x530>
  40ba37:	8b 05 07 71 2d 01    	mov    0x12d7107(%rip),%eax        # 16e2b44 <target_page+0x4>
  40ba3d:	8b 54 24 48          	mov    0x48(%rsp),%edx
  40ba41:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  40ba46:	8d 48 fa             	lea    -0x6(%rax),%ecx
  40ba49:	4c 89 c0             	mov    %r8,%rax
  40ba4c:	48 d3 e8             	shr    %cl,%rax
  40ba4f:	4c 31 c0             	xor    %r8,%rax
  40ba52:	49 89 c4             	mov    %rax,%r12
  40ba55:	83 e0 3f             	and    $0x3f,%eax
  40ba58:	49 d3 ec             	shr    %cl,%r12
  40ba5b:	48 8b 8b 18 02 00 00 	mov    0x218(%rbx),%rcx
  40ba62:	41 81 e4 c0 0f 00 00 	and    $0xfc0,%r12d
  40ba69:	41 09 c4             	or     %eax,%r12d
  40ba6c:	45 8d 74 24 01       	lea    0x1(%r12),%r14d
  40ba71:	49 c1 e6 04          	shl    $0x4,%r14
  40ba75:	4e 8d 14 31          	lea    (%rcx,%r14,1),%r10
  40ba79:	49 8b 2a             	mov    (%r10),%rbp
  40ba7c:	48 85 ed             	test   %rbp,%rbp
  40ba7f:	0f 84 fb 01 00 00    	je     40bc80 <cpu_exec_loop+0x3b0>
  40ba85:	4c 89 e0             	mov    %r12,%rax
  40ba88:	48 c1 e0 04          	shl    $0x4,%rax
  40ba8c:	4c 39 44 08 18       	cmp    %r8,0x18(%rax,%rcx,1)
  40ba91:	0f 85 e9 01 00 00    	jne    40bc80 <cpu_exec_loop+0x3b0>
  40ba97:	48 39 75 08          	cmp    %rsi,0x8(%rbp)
  40ba9b:	0f 85 df 01 00 00    	jne    40bc80 <cpu_exec_loop+0x3b0>
  40baa1:	3b 55 10             	cmp    0x10(%rbp),%edx
  40baa4:	0f 85 d6 01 00 00    	jne    40bc80 <cpu_exec_loop+0x3b0>
  40baaa:	8b 45 14             	mov    0x14(%rbp),%eax
  40baad:	44 39 c8             	cmp    %r9d,%eax
  40bab0:	0f 85 ca 01 00 00    	jne    40bc80 <cpu_exec_loop+0x3b0>
  40bab6:	8b 45 14             	mov    0x14(%rbp),%eax
  40bab9:	a9 00 00 02 00       	test   $0x20000,%eax
  40babe:	75 0a                	jne    40baca <cpu_exec_loop+0x1fa>
  40bac0:	4c 39 45 00          	cmp    %r8,0x0(%rbp)
  40bac4:	0f 85 89 c9 dd ff    	jne    1e8453 <cpu_exec_loop.cold+0x1f>
  40baca:	48 83 7d 50 ff       	cmpq   $0xffffffffffffffff,0x50(%rbp)
  40bacf:	75 05                	jne    40bad6 <cpu_exec_loop+0x206>
  40bad1:	4d 85 ed             	test   %r13,%r13
  40bad4:	75 7a                	jne    40bb50 <cpu_exec_loop+0x280>
  40bad6:	44 8b 0d 6b d4 33 01 	mov    0x133d46b(%rip),%r9d        # 1748f48 <trace_events_enabled_count>
  40badd:	45 85 c9             	test   %r9d,%r9d
  40bae0:	0f 85 4a 01 00 00    	jne    40bc30 <cpu_exec_loop+0x360>
  40bae6:	48 8d 54 24 2c       	lea    0x2c(%rsp),%rdx
  40baeb:	48 89 ee             	mov    %rbp,%rsi
  40baee:	48 89 df             	mov    %rbx,%rdi
  40baf1:	e8 ba fb ff ff       	call   40b6b0 <cpu_tb_exec>
  40baf6:	83 7c 24 2c 03       	cmpl   $0x3,0x2c(%rsp)
  40bafb:	49 89 c5             	mov    %rax,%r13
  40bafe:	0f 84 2c 02 00 00    	je     40bd30 <cpu_exec_loop+0x460>
  40bb04:	80 3d 71 28 32 01 00 	cmpb   $0x0,0x1322871(%rip)        # 172e37c <icount_align_option>
  40bb0b:	74 33                	je     40bb40 <cpu_exec_loop+0x270>
  40bb0d:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  40bb11:	0f b7 ab 50 4b 00 00 	movzwl 0x4b50(%rbx),%ebp
  40bb18:	48 03 ab e0 00 00 00 	add    0xe0(%rbx),%rbp
  40bb1f:	48 29 ef             	sub    %rbp,%rdi
  40bb22:	e8 a9 cb 01 00       	call   4286d0 <icount_to_ns>
  40bb27:	49 03 07             	add    (%r15),%rax
  40bb2a:	49 89 6f 08          	mov    %rbp,0x8(%r15)
  40bb2e:	49 89 07             	mov    %rax,(%r15)
  40bb31:	48 89 c1             	mov    %rax,%rcx
  40bb34:	48 3d c0 c6 2d 00    	cmp    $0x2dc6c0,%rax
  40bb3a:	0f 8f f8 02 00 00    	jg     40be38 <cpu_exec_loop+0x568>
  40bb40:	8b 83 cc 00 00 00    	mov    0xcc(%rbx),%eax
  40bb46:	e9 f5 fd ff ff       	jmp    40b940 <cpu_exec_loop+0x70>
  40bb4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40bb50:	8b 74 24 2c          	mov    0x2c(%rsp),%esi
  40bb54:	83 fe 01             	cmp    $0x1,%esi
  40bb57:	0f 87 d7 c8 dd ff    	ja     1e8434 <cpu_exec_loop.cold>
  40bb5d:	4c 8d 65 58          	lea    0x58(%rbp),%r12
  40bb61:	ba 01 00 00 00       	mov    $0x1,%edx
  40bb66:	89 d0                	mov    %edx,%eax
  40bb68:	41 87 04 24          	xchg   %eax,(%r12)
  40bb6c:	85 c0                	test   %eax,%eax
  40bb6e:	0f 85 f6 00 00 00    	jne    40bc6a <cpu_exec_loop+0x39a>
  40bb74:	f6 45 15 40          	testb  $0x40,0x15(%rbp)
  40bb78:	0f 85 a2 01 00 00    	jne    40bd20 <cpu_exec_loop+0x450>
  40bb7e:	4c 63 f6             	movslq %esi,%r14
  40bb81:	31 c0                	xor    %eax,%eax
  40bb83:	49 8d 56 12          	lea    0x12(%r14),%rdx
  40bb87:	f0 49 0f b1 6c d5 00 	lock cmpxchg %rbp,0x0(%r13,%rdx,8)
  40bb8e:	0f 85 8c 01 00 00    	jne    40bd20 <cpu_exec_loop+0x450>
  40bb94:	48 8b 45 28          	mov    0x28(%rbp),%rax
  40bb98:	43 0f b7 54 75 60    	movzwl 0x60(%r13,%r14,2),%edx
  40bb9e:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  40bba3:	49 03 55 28          	add    0x28(%r13),%rdx
  40bba7:	48 8b 3d 1a 89 30 01 	mov    0x130891a(%rip),%rdi        # 17144c8 <tcg_splitwx_diff>
  40bbae:	89 34 24             	mov    %esi,(%rsp)
  40bbb1:	4b 89 44 f5 68       	mov    %rax,0x68(%r13,%r14,8)
  40bbb6:	48 89 d1             	mov    %rdx,%rcx
  40bbb9:	48 29 f9             	sub    %rdi,%rcx
  40bbbc:	4c 01 ef             	add    %r13,%rdi
  40bbbf:	e8 5c 6b fd ff       	call   3e2720 <tb_target_set_jmp_target>
  40bbc4:	48 8b 45 78          	mov    0x78(%rbp),%rax
  40bbc8:	4b 89 84 f5 80 00 00 	mov    %rax,0x80(%r13,%r14,8)
  40bbcf:	00 
  40bbd0:	4d 09 ee             	or     %r13,%r14
  40bbd3:	4c 89 75 78          	mov    %r14,0x78(%rbp)
  40bbd7:	41 c7 04 24 00 00 00 	movl   $0x0,(%r12)
  40bbde:	00 
  40bbdf:	f6 05 fa cf 33 01 20 	testb  $0x20,0x133cffa(%rip)        # 1748be0 <qemu_loglevel>
  40bbe6:	8b 34 24             	mov    (%rsp),%esi
  40bbe9:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  40bbee:	0f 84 e2 fe ff ff    	je     40bad6 <cpu_exec_loop+0x206>
  40bbf4:	49 8b 45 28          	mov    0x28(%r13),%rax
  40bbf8:	48 8b 4d 28          	mov    0x28(%rbp),%rcx
  40bbfc:	89 f2                	mov    %esi,%edx
  40bbfe:	4c 89 04 24          	mov    %r8,(%rsp)
  40bc02:	48 8d 3d 07 d9 cc 00 	lea    0xccd907(%rip),%rdi        # 10d9510 <anon.53529a8b42b516fa44fa3e141ddff7ec.0.llvm.534248872324339782+0x2d9e7>
  40bc09:	48 89 c6             	mov    %rax,%rsi
  40bc0c:	31 c0                	xor    %eax,%eax
  40bc0e:	e8 dd 26 26 00       	call   66e2f0 <qemu_log>
  40bc13:	44 8b 0d 2e d3 33 01 	mov    0x133d32e(%rip),%r9d        # 1748f48 <trace_events_enabled_count>
  40bc1a:	4c 8b 04 24          	mov    (%rsp),%r8
  40bc1e:	45 85 c9             	test   %r9d,%r9d
  40bc21:	0f 84 bf fe ff ff    	je     40bae6 <cpu_exec_loop+0x216>
  40bc27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40bc2e:	00 00 
  40bc30:	66 83 3d de c5 33 01 	cmpw   $0x0,0x133c5de(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40bc37:	00 
  40bc38:	0f 84 a8 fe ff ff    	je     40bae6 <cpu_exec_loop+0x216>
  40bc3e:	f6 05 9c cf 33 01 80 	testb  $0x80,0x133cf9c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bc45:	0f 84 9b fe ff ff    	je     40bae6 <cpu_exec_loop+0x216>
  40bc4b:	4c 89 c2             	mov    %r8,%rdx
  40bc4e:	48 89 ee             	mov    %rbp,%rsi
  40bc51:	48 8d 3d 51 cb c4 00 	lea    0xc4cb51(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40bc58:	31 c0                	xor    %eax,%eax
  40bc5a:	e8 91 26 26 00       	call   66e2f0 <qemu_log>
  40bc5f:	e9 82 fe ff ff       	jmp    40bae6 <cpu_exec_loop+0x216>
  40bc64:	0f 1f 40 00          	nopl   0x0(%rax)
  40bc68:	f3 90                	pause
  40bc6a:	41 8b 04 24          	mov    (%r12),%eax
  40bc6e:	85 c0                	test   %eax,%eax
  40bc70:	75 f6                	jne    40bc68 <cpu_exec_loop+0x398>
  40bc72:	e9 ef fe ff ff       	jmp    40bb66 <cpu_exec_loop+0x296>
  40bc77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40bc7e:	00 00 
  40bc80:	66 0f 6e c2          	movd   %edx,%xmm0
  40bc84:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  40bc89:	48 83 ec 20          	sub    $0x20,%rsp
  40bc8d:	48 89 df             	mov    %rbx,%rdi
  40bc90:	66 41 0f 6e c9       	movd   %r9d,%xmm1
  40bc95:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
  40bc9a:	48 8d 15 9f f2 ff ff 	lea    -0xd61(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40bca1:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
  40bca5:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  40bcaa:	4c 89 84 24 80 00 00 	mov    %r8,0x80(%rsp)
  40bcb1:	00 
  40bcb2:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
  40bcb7:	44 89 4c 24 20       	mov    %r9d,0x20(%rsp)
  40bcbc:	66 0f d6 84 24 88 00 	movq   %xmm0,0x88(%rsp)
  40bcc3:	00 00 
  40bcc5:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  40bccc:	00 00 
  40bcce:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  40bcd3:	48 8d 35 06 26 32 01 	lea    0x1322606(%rip),%rsi        # 172e2e0 <tb_ctx>
  40bcda:	0f 11 04 24          	movups %xmm0,(%rsp)
  40bcde:	e8 fd f3 ff ff       	call   40b0e0 <tb_htable_lookup_common>
  40bce3:	48 83 c4 20          	add    $0x20,%rsp
  40bce7:	44 8b 0c 24          	mov    (%rsp),%r9d
  40bceb:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  40bcf0:	48 85 c0             	test   %rax,%rax
  40bcf3:	48 89 c5             	mov    %rax,%rbp
  40bcf6:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  40bcfb:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  40bd00:	0f 84 8a 02 00 00    	je     40bf90 <cpu_exec_loop+0x6c0>
  40bd06:	49 c1 e4 04          	shl    $0x4,%r12
  40bd0a:	4d 89 44 0c 18       	mov    %r8,0x18(%r12,%rcx,1)
  40bd0f:	49 89 02             	mov    %rax,(%r10)
  40bd12:	e9 9f fd ff ff       	jmp    40bab6 <cpu_exec_loop+0x1e6>
  40bd17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40bd1e:	00 00 
  40bd20:	41 c7 04 24 00 00 00 	movl   $0x0,(%r12)
  40bd27:	00 
  40bd28:	e9 a9 fd ff ff       	jmp    40bad6 <cpu_exec_loop+0x206>
  40bd2d:	0f 1f 00             	nopl   (%rax)
  40bd30:	8b 83 50 4b 00 00    	mov    0x4b50(%rbx),%eax
  40bd36:	85 c0                	test   %eax,%eax
  40bd38:	78 70                	js     40bdaa <cpu_exec_loop+0x4da>
  40bd3a:	8b 3d 38 26 32 01    	mov    0x1322638(%rip),%edi        # 172e378 <use_icount>
  40bd40:	85 ff                	test   %edi,%edi
  40bd42:	0f 84 49 c7 dd ff    	je     1e8491 <cpu_exec_loop.cold+0x5d>
  40bd48:	48 89 df             	mov    %rbx,%rdi
  40bd4b:	e8 80 c8 01 00       	call   4285d0 <icount_update>
  40bd50:	48 8b 93 d8 00 00 00 	mov    0xd8(%rbx),%rdx
  40bd57:	b8 ff ff 00 00       	mov    $0xffff,%eax
  40bd5c:	48 39 c2             	cmp    %rax,%rdx
  40bd5f:	48 0f 4e c2          	cmovle %rdx,%rax
  40bd63:	48 63 c8             	movslq %eax,%rcx
  40bd66:	66 89 83 50 4b 00 00 	mov    %ax,0x4b50(%rbx)
  40bd6d:	48 29 ca             	sub    %rcx,%rdx
  40bd70:	48 89 93 e0 00 00 00 	mov    %rdx,0xe0(%rbx)
  40bd77:	85 c0                	test   %eax,%eax
  40bd79:	7e 2f                	jle    40bdaa <cpu_exec_loop+0x4da>
  40bd7b:	41 0f b7 4d 1a       	movzwl 0x1a(%r13),%ecx
  40bd80:	39 c8                	cmp    %ecx,%eax
  40bd82:	7d 26                	jge    40bdaa <cpu_exec_loop+0x4da>
  40bd84:	3d ff 01 00 00       	cmp    $0x1ff,%eax
  40bd89:	0f 8f e3 c6 dd ff    	jg     1e8472 <cpu_exec_loop.cold+0x3e>
  40bd8f:	48 85 d2             	test   %rdx,%rdx
  40bd92:	0f 85 18 c7 dd ff    	jne    1e84b0 <cpu_exec_loop.cold+0x7c>
  40bd98:	41 8b 55 14          	mov    0x14(%r13),%edx
  40bd9c:	81 e2 00 fe ff ff    	and    $0xfffffe00,%edx
  40bda2:	09 d0                	or     %edx,%eax
  40bda4:	89 83 cc 00 00 00    	mov    %eax,0xcc(%rbx)
  40bdaa:	45 31 ed             	xor    %r13d,%r13d
  40bdad:	e9 52 fd ff ff       	jmp    40bb04 <cpu_exec_loop+0x234>
  40bdb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40bdb8:	44 8b 93 d4 00 00 00 	mov    0xd4(%rbx),%r10d
  40bdbf:	44 8b 8b c8 02 00 00 	mov    0x2c8(%rbx),%r9d
  40bdc6:	45 85 d2             	test   %r10d,%r10d
  40bdc9:	0f 85 01 03 00 00    	jne    40c0d0 <cpu_exec_loop+0x800>
  40bdcf:	0f b6 05 f6 24 32 01 	movzbl 0x13224f6(%rip),%eax        # 172e2cc <one_insn_per_tb>
  40bdd6:	84 c0                	test   %al,%al
  40bdd8:	0f 84 c2 00 00 00    	je     40bea0 <cpu_exec_loop+0x5d0>
  40bdde:	41 81 c9 01 02 00 00 	or     $0x201,%r9d
  40bde5:	48 83 bb 40 02 00 00 	cmpq   $0x0,0x240(%rbx)
  40bdec:	00 
  40bded:	0f 84 44 fc ff ff    	je     40ba37 <cpu_exec_loop+0x167>
  40bdf3:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40bdfa:	00 00 00 00 
  40bdfe:	66 90                	xchg   %ax,%ax
  40be00:	48 8d 54 24 4c       	lea    0x4c(%rsp),%rdx
  40be05:	4c 89 c6             	mov    %r8,%rsi
  40be08:	48 89 df             	mov    %rbx,%rdi
  40be0b:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
  40be10:	44 89 4c 24 4c       	mov    %r9d,0x4c(%rsp)
  40be15:	e8 b6 f1 ff ff       	call   40afd0 <check_for_breakpoints_slow>
  40be1a:	84 c0                	test   %al,%al
  40be1c:	0f 85 de 01 00 00    	jne    40c000 <cpu_exec_loop+0x730>
  40be22:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  40be27:	44 8b 4c 24 4c       	mov    0x4c(%rsp),%r9d
  40be2c:	e9 06 fc ff ff       	jmp    40ba37 <cpu_exec_loop+0x167>
  40be31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40be38:	66 0f ef c0          	pxor   %xmm0,%xmm0
  40be3c:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  40be41:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  40be46:	48 b8 b3 94 d6 26 e8 	movabs $0x112e0be826d694b3,%rax
  40be4d:	0b 2e 11 
  40be50:	48 f7 e9             	imul   %rcx
  40be53:	48 89 c8             	mov    %rcx,%rax
  40be56:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  40be5b:	48 c1 f8 3f          	sar    $0x3f,%rax
  40be5f:	48 c1 fa 1a          	sar    $0x1a,%rdx
  40be63:	48 29 c2             	sub    %rax,%rdx
  40be66:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  40be6b:	48 69 d2 00 ca 9a 3b 	imul   $0x3b9aca00,%rdx,%rdx
  40be72:	48 29 d1             	sub    %rdx,%rcx
  40be75:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  40be7a:	e8 31 a8 dc ff       	call   1d66b0 <nanosleep@plt>
  40be7f:	89 c2                	mov    %eax,%edx
  40be81:	31 c0                	xor    %eax,%eax
  40be83:	85 d2                	test   %edx,%edx
  40be85:	79 0e                	jns    40be95 <cpu_exec_loop+0x5c5>
  40be87:	48 69 44 24 60 00 ca 	imul   $0x3b9aca00,0x60(%rsp),%rax
  40be8e:	9a 3b 
  40be90:	48 03 44 24 68       	add    0x68(%rsp),%rax
  40be95:	49 89 07             	mov    %rax,(%r15)
  40be98:	e9 a3 fc ff ff       	jmp    40bb40 <cpu_exec_loop+0x270>
  40be9d:	0f 1f 00             	nopl   (%rax)
  40bea0:	44 89 c8             	mov    %r9d,%eax
  40bea3:	80 cc 02             	or     $0x2,%ah
  40bea6:	f6 05 34 cd 33 01 20 	testb  $0x20,0x133cd34(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bead:	44 0f 45 c8          	cmovne %eax,%r9d
  40beb1:	e9 73 fb ff ff       	jmp    40ba29 <cpu_exec_loop+0x159>
  40beb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  40bebd:	00 00 00 
  40bec0:	be 53 03 00 00       	mov    $0x353,%esi
  40bec5:	48 8d 3d 7f c8 c4 00 	lea    0xc4c87f(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40becc:	e8 1f d1 f5 ff       	call   368ff0 <bql_lock_impl>
  40bed1:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bed7:	a8 80                	test   $0x80,%al
  40bed9:	0f 85 39 02 00 00    	jne    40c118 <cpu_exec_loop+0x848>
  40bedf:	83 3d 42 84 30 01 02 	cmpl   $0x2,0x1308442(%rip)        # 1714328 <replay_mode>
  40bee6:	0f 84 b4 01 00 00    	je     40c0a0 <cpu_exec_loop+0x7d0>
  40beec:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bef2:	a8 20                	test   $0x20,%al
  40bef4:	0f 85 e6 01 00 00    	jne    40c0e0 <cpu_exec_loop+0x810>
  40befa:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40bf01:	8b ab d0 00 00 00    	mov    0xd0(%rbx),%ebp
  40bf07:	4c 8b a0 50 01 00 00 	mov    0x150(%rax),%r12
  40bf0e:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bf14:	f6 c4 04             	test   $0x4,%ah
  40bf17:	0f 85 c7 00 00 00    	jne    40bfe4 <cpu_exec_loop+0x714>
  40bf1d:	89 e8                	mov    %ebp,%eax
  40bf1f:	48 89 df             	mov    %rbx,%rdi
  40bf22:	25 a5 ed ff ff       	and    $0xffffeda5,%eax
  40bf27:	f6 83 d4 00 00 00 02 	testb  $0x2,0xd4(%rbx)
  40bf2e:	0f 45 e8             	cmovne %eax,%ebp
  40bf31:	89 ee                	mov    %ebp,%esi
  40bf33:	41 ff 54 24 58       	call   *0x58(%r12)
  40bf38:	84 c0                	test   %al,%al
  40bf3a:	74 30                	je     40bf6c <cpu_exec_loop+0x69c>
  40bf3c:	49 8b 84 24 b8 00 00 	mov    0xb8(%r12),%rax
  40bf43:	00 
  40bf44:	48 85 c0             	test   %rax,%rax
  40bf47:	74 3b                	je     40bf84 <cpu_exec_loop+0x6b4>
  40bf49:	89 ef                	mov    %ebp,%edi
  40bf4b:	ff d0                	call   *%rax
  40bf4d:	84 c0                	test   %al,%al
  40bf4f:	75 33                	jne    40bf84 <cpu_exec_loop+0x6b4>
  40bf51:	8b b3 d4 00 00 00    	mov    0xd4(%rbx),%esi
  40bf57:	85 f6                	test   %esi,%esi
  40bf59:	0f 85 ad 02 00 00    	jne    40c20c <cpu_exec_loop+0x93c>
  40bf5f:	c7 83 d0 02 00 00 ff 	movl   $0xffffffff,0x2d0(%rbx)
  40bf66:	ff ff ff 
  40bf69:	45 31 ed             	xor    %r13d,%r13d
  40bf6c:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40bf72:	a8 04                	test   $0x4,%al
  40bf74:	0f 85 41 01 00 00    	jne    40c0bb <cpu_exec_loop+0x7eb>
  40bf7a:	e8 c1 d0 f5 ff       	call   369040 <bql_unlock>
  40bf7f:	e9 e3 f9 ff ff       	jmp    40b967 <cpu_exec_loop+0x97>
  40bf84:	e8 87 52 fc ff       	call   3d1210 <replay_interrupt>
  40bf89:	eb c6                	jmp    40bf51 <cpu_exec_loop+0x681>
  40bf8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40bf90:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
  40bf95:	48 83 ec 20          	sub    $0x20,%rsp
  40bf99:	48 89 df             	mov    %rbx,%rdi
  40bf9c:	49 c1 e4 04          	shl    $0x4,%r12
  40bfa0:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  40bfa5:	44 89 4c 24 6c       	mov    %r9d,0x6c(%rsp)
  40bfaa:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  40bfb0:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  40bfb5:	0f 11 04 24          	movups %xmm0,(%rsp)
  40bfb9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  40bfbe:	e8 1d e2 00 00       	call   41a1e0 <tb_gen_code>
  40bfc3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  40bfc8:	48 83 c4 20          	add    $0x20,%rsp
  40bfcc:	48 89 c5             	mov    %rax,%rbp
  40bfcf:	48 8b 83 18 02 00 00 	mov    0x218(%rbx),%rax
  40bfd6:	4d 89 44 04 18       	mov    %r8,0x18(%r12,%rax,1)
  40bfdb:	4a 89 2c 30          	mov    %rbp,(%rax,%r14,1)
  40bfdf:	e9 e6 fa ff ff       	jmp    40baca <cpu_exec_loop+0x1fa>
  40bfe4:	e8 27 52 fc ff       	call   3d1210 <replay_interrupt>
  40bfe9:	48 89 df             	mov    %rbx,%rdi
  40bfec:	41 ff 54 24 60       	call   *0x60(%r12)
  40bff1:	e8 4a d0 f5 ff       	call   369040 <bql_unlock>
  40bff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  40bffd:	00 00 00 
  40c000:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40c006:	85 ed                	test   %ebp,%ebp
  40c008:	0f 88 f2 f8 ff ff    	js     40b900 <cpu_exec_loop+0x30>
  40c00e:	81 fd ff ff 00 00    	cmp    $0xffff,%ebp
  40c014:	0f 8f 25 01 00 00    	jg     40c13f <cpu_exec_loop+0x86f>
  40c01a:	e8 c1 50 fc ff       	call   3d10e0 <replay_exception>
  40c01f:	84 c0                	test   %al,%al
  40c021:	0f 84 59 01 00 00    	je     40c180 <cpu_exec_loop+0x8b0>
  40c027:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40c02e:	be 07 03 00 00       	mov    $0x307,%esi
  40c033:	48 8d 3d 11 c7 c4 00 	lea    0xc4c711(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c03a:	48 8b a8 50 01 00 00 	mov    0x150(%rax),%rbp
  40c041:	e8 aa cf f5 ff       	call   368ff0 <bql_lock_impl>
  40c046:	48 89 df             	mov    %rbx,%rdi
  40c049:	ff 55 50             	call   *0x50(%rbp)
  40c04c:	e8 ef cf f5 ff       	call   369040 <bql_unlock>
  40c051:	8b 83 d4 00 00 00    	mov    0xd4(%rbx),%eax
  40c057:	c7 83 d0 02 00 00 ff 	movl   $0xffffffff,0x2d0(%rbx)
  40c05e:	ff ff ff 
  40c061:	85 c0                	test   %eax,%eax
  40c063:	0f 84 b7 f8 ff ff    	je     40b920 <cpu_exec_loop+0x50>
  40c069:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40c070:	48 83 bb 60 02 00 00 	cmpq   $0x0,0x260(%rbx)
  40c077:	00 
  40c078:	48 8b 90 50 01 00 00 	mov    0x150(%rax),%rdx
  40c07f:	0f 84 a1 01 00 00    	je     40c226 <cpu_exec_loop+0x956>
  40c085:	48 8b 42 40          	mov    0x40(%rdx),%rax
  40c089:	48 85 c0             	test   %rax,%rax
  40c08c:	74 05                	je     40c093 <cpu_exec_loop+0x7c3>
  40c08e:	48 89 df             	mov    %rbx,%rdi
  40c091:	ff d0                	call   *%rax
  40c093:	bd 02 00 01 00       	mov    $0x10002,%ebp
  40c098:	e9 27 f9 ff ff       	jmp    40b9c4 <cpu_exec_loop+0xf4>
  40c09d:	0f 1f 00             	nopl   (%rax)
  40c0a0:	e8 5b 52 fc ff       	call   3d1300 <replay_has_interrupt>
  40c0a5:	84 c0                	test   %al,%al
  40c0a7:	0f 85 3f fe ff ff    	jne    40beec <cpu_exec_loop+0x61c>
  40c0ad:	8b 83 d0 00 00 00    	mov    0xd0(%rbx),%eax
  40c0b3:	a8 04                	test   $0x4,%al
  40c0b5:	0f 84 bf fe ff ff    	je     40bf7a <cpu_exec_loop+0x6aa>
  40c0bb:	be 04 00 00 00       	mov    $0x4,%esi
  40c0c0:	48 89 df             	mov    %rbx,%rdi
  40c0c3:	45 31 ed             	xor    %r13d,%r13d
  40c0c6:	e8 85 ce e3 ff       	call   248f50 <cpu_reset_interrupt>
  40c0cb:	e9 aa fe ff ff       	jmp    40bf7a <cpu_exec_loop+0x6aa>
  40c0d0:	41 81 c9 01 0e 00 00 	or     $0xe01,%r9d
  40c0d7:	e9 4d f9 ff ff       	jmp    40ba29 <cpu_exec_loop+0x159>
  40c0dc:	0f 1f 40 00          	nopl   0x0(%rax)
  40c0e0:	e8 2b 51 fc ff       	call   3d1210 <replay_interrupt>
  40c0e5:	be 20 00 00 00       	mov    $0x20,%esi
  40c0ea:	48 89 df             	mov    %rbx,%rdi
  40c0ed:	e8 5e ce e3 ff       	call   248f50 <cpu_reset_interrupt>
  40c0f2:	48 b8 01 00 00 00 01 	movabs $0x1000100000001,%rax
  40c0f9:	00 01 00 
  40c0fc:	48 89 83 cc 02 00 00 	mov    %rax,0x2cc(%rbx)
  40c103:	e8 38 cf f5 ff       	call   369040 <bql_unlock>
  40c108:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40c10e:	e9 da f7 ff ff       	jmp    40b8ed <cpu_exec_loop+0x1d>
  40c113:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40c118:	be 80 00 00 00       	mov    $0x80,%esi
  40c11d:	48 89 df             	mov    %rbx,%rdi
  40c120:	e8 2b ce e3 ff       	call   248f50 <cpu_reset_interrupt>
  40c125:	c7 83 d0 02 00 00 02 	movl   $0x10002,0x2d0(%rbx)
  40c12c:	00 01 00 
  40c12f:	e8 0c cf f5 ff       	call   369040 <bql_unlock>
  40c134:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40c13a:	e9 ae f7 ff ff       	jmp    40b8ed <cpu_exec_loop+0x1d>
  40c13f:	81 fd 02 00 01 00    	cmp    $0x10002,%ebp
  40c145:	0f 85 6f f8 ff ff    	jne    40b9ba <cpu_exec_loop+0xea>
  40c14b:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  40c152:	48 83 bb 60 02 00 00 	cmpq   $0x0,0x260(%rbx)
  40c159:	00 
  40c15a:	48 8b 90 50 01 00 00 	mov    0x150(%rax),%rdx
  40c161:	74 77                	je     40c1da <cpu_exec_loop+0x90a>
  40c163:	48 8b 42 40          	mov    0x40(%rdx),%rax
  40c167:	48 85 c0             	test   %rax,%rax
  40c16a:	0f 84 4a f8 ff ff    	je     40b9ba <cpu_exec_loop+0xea>
  40c170:	48 89 df             	mov    %rbx,%rdi
  40c173:	ff d0                	call   *%rax
  40c175:	e9 40 f8 ff ff       	jmp    40b9ba <cpu_exec_loop+0xea>
  40c17a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40c180:	e8 7b 51 fc ff       	call   3d1300 <replay_has_interrupt>
  40c185:	84 c0                	test   %al,%al
  40c187:	0f 85 93 f7 ff ff    	jne    40b920 <cpu_exec_loop+0x50>
  40c18d:	bd 00 00 01 00       	mov    $0x10000,%ebp
  40c192:	e9 2d f8 ff ff       	jmp    40b9c4 <cpu_exec_loop+0xf4>
  40c197:	8b 93 d4 00 00 00    	mov    0xd4(%rbx),%edx
  40c19d:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
  40c1a3:	85 d2                	test   %edx,%edx
  40c1a5:	0f 85 a0 00 00 00    	jne    40c24b <cpu_exec_loop+0x97b>
  40c1ab:	0f b6 15 1a 21 32 01 	movzbl 0x132211a(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40c1b2:	84 d2                	test   %dl,%dl
  40c1b4:	75 4f                	jne    40c205 <cpu_exec_loop+0x935>
  40c1b6:	89 c2                	mov    %eax,%edx
  40c1b8:	80 ce 02             	or     $0x2,%dh
  40c1bb:	f6 05 1f ca 33 01 20 	testb  $0x20,0x133ca1f(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c1c2:	0f 45 c2             	cmovne %edx,%eax
  40c1c5:	25 fe df fe ff       	and    $0xfffedffe,%eax
  40c1ca:	0d 01 00 01 00       	or     $0x10001,%eax
  40c1cf:	89 83 cc 00 00 00    	mov    %eax,0xcc(%rbx)
  40c1d5:	e9 4c f7 ff ff       	jmp    40b926 <cpu_exec_loop+0x56>
  40c1da:	48 8b 83 50 02 00 00 	mov    0x250(%rbx),%rax
  40c1e1:	48 85 c0             	test   %rax,%rax
  40c1e4:	0f 84 79 ff ff ff    	je     40c163 <cpu_exec_loop+0x893>
  40c1ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40c1f0:	81 60 20 3f ff ff ff 	andl   $0xffffff3f,0x20(%rax)
  40c1f7:	48 8b 40 28          	mov    0x28(%rax),%rax
  40c1fb:	48 85 c0             	test   %rax,%rax
  40c1fe:	75 f0                	jne    40c1f0 <cpu_exec_loop+0x920>
  40c200:	e9 5e ff ff ff       	jmp    40c163 <cpu_exec_loop+0x893>
  40c205:	0d 01 02 00 00       	or     $0x201,%eax
  40c20a:	eb b9                	jmp    40c1c5 <cpu_exec_loop+0x8f5>
  40c20c:	c7 83 d0 02 00 00 02 	movl   $0x10002,0x2d0(%rbx)
  40c213:	00 01 00 
  40c216:	e8 25 ce f5 ff       	call   369040 <bql_unlock>
  40c21b:	8b ab d0 02 00 00    	mov    0x2d0(%rbx),%ebp
  40c221:	e9 c7 f6 ff ff       	jmp    40b8ed <cpu_exec_loop+0x1d>
  40c226:	48 8b 83 50 02 00 00 	mov    0x250(%rbx),%rax
  40c22d:	48 85 c0             	test   %rax,%rax
  40c230:	0f 84 4f fe ff ff    	je     40c085 <cpu_exec_loop+0x7b5>
  40c236:	81 60 20 3f ff ff ff 	andl   $0xffffff3f,0x20(%rax)
  40c23d:	48 8b 40 28          	mov    0x28(%rax),%rax
  40c241:	48 85 c0             	test   %rax,%rax
  40c244:	75 f0                	jne    40c236 <cpu_exec_loop+0x966>
  40c246:	e9 3a fe ff ff       	jmp    40c085 <cpu_exec_loop+0x7b5>
  40c24b:	0d 01 0e 00 00       	or     $0xe01,%eax
  40c250:	e9 70 ff ff ff       	jmp    40c1c5 <cpu_exec_loop+0x8f5>

Disassembly of section .fini:

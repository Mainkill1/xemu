
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8-bypass/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040b940 <cpu_exec_loop>:
  40b940:	41 57                	push   %r15
  40b942:	49 89 f7             	mov    %rsi,%r15
  40b945:	41 56                	push   %r14
  40b947:	49 89 fe             	mov    %rdi,%r14
  40b94a:	41 55                	push   %r13
  40b94c:	41 54                	push   %r12
  40b94e:	55                   	push   %rbp
  40b94f:	53                   	push   %rbx
  40b950:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  40b957:	8b 9f d0 02 00 00    	mov    0x2d0(%rdi),%ebx
  40b95d:	85 db                	test   %ebx,%ebx
  40b95f:	0f 89 6a 07 00 00    	jns    40c0cf <cpu_exec_loop+0x78f>
  40b965:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40b96c:	00 00 00 00 
  40b970:	e8 5b 58 fc ff       	call   3d11d0 <replay_has_exception>
  40b975:	84 c0                	test   %al,%al
  40b977:	74 17                	je     40b990 <cpu_exec_loop+0x50>
  40b979:	41 0f b7 86 50 4b 00 	movzwl 0x4b50(%r14),%eax
  40b980:	00 
  40b981:	49 03 86 e0 00 00 00 	add    0xe0(%r14),%rax
  40b988:	0f 84 51 09 00 00    	je     40c2df <cpu_exec_loop+0x99f>
  40b98e:	66 90                	xchg   %ax,%ax
  40b990:	41 8b 86 cc 00 00 00 	mov    0xcc(%r14),%eax
  40b997:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
  40b99c:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
  40b9a3:	00 
  40b9a4:	45 31 e4             	xor    %r12d,%r12d
  40b9a7:	48 89 0c 24          	mov    %rcx,(%rsp)
  40b9ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40b9b0:	83 f8 ff             	cmp    $0xffffffff,%eax
  40b9b3:	74 0b                	je     40b9c0 <cpu_exec_loop+0x80>
  40b9b5:	a9 00 00 01 00       	test   $0x10000,%eax
  40b9ba:	0f 85 a8 00 00 00    	jne    40ba68 <cpu_exec_loop+0x128>
  40b9c0:	31 c0                	xor    %eax,%eax
  40b9c2:	66 41 87 86 52 4b 00 	xchg   %ax,0x4b52(%r14)
  40b9c9:	00 
  40b9ca:	41 8b 86 d0 00 00 00 	mov    0xd0(%r14),%eax
  40b9d1:	85 c0                	test   %eax,%eax
  40b9d3:	0f 85 07 06 00 00    	jne    40bfe0 <cpu_exec_loop+0x6a0>
  40b9d9:	41 0f b6 86 c7 00 00 	movzbl 0xc7(%r14),%eax
  40b9e0:	00 
  40b9e1:	84 c0                	test   %al,%al
  40b9e3:	75 2c                	jne    40ba11 <cpu_exec_loop+0xd1>
  40b9e5:	8b 0d 8d 29 32 01    	mov    0x132298d(%rip),%ecx        # 172e378 <use_icount>
  40b9eb:	85 c9                	test   %ecx,%ecx
  40b9ed:	74 79                	je     40ba68 <cpu_exec_loop+0x128>
  40b9ef:	41 8b 86 cc 00 00 00 	mov    0xcc(%r14),%eax
  40b9f6:	83 f8 ff             	cmp    $0xffffffff,%eax
  40b9f9:	74 05                	je     40ba00 <cpu_exec_loop+0xc0>
  40b9fb:	f6 c4 20             	test   $0x20,%ah
  40b9fe:	74 68                	je     40ba68 <cpu_exec_loop+0x128>
  40ba00:	41 0f b7 86 50 4b 00 	movzwl 0x4b50(%r14),%eax
  40ba07:	00 
  40ba08:	49 03 86 e0 00 00 00 	add    0xe0(%r14),%rax
  40ba0f:	75 57                	jne    40ba68 <cpu_exec_loop+0x128>
  40ba11:	41 8b 9e d0 02 00 00 	mov    0x2d0(%r14),%ebx
  40ba18:	83 fb ff             	cmp    $0xffffffff,%ebx
  40ba1b:	0f 85 3c ff ff ff    	jne    40b95d <cpu_exec_loop+0x1d>
  40ba21:	41 c7 86 d0 02 00 00 	movl   $0x10000,0x2d0(%r14)
  40ba28:	00 00 01 00 
  40ba2c:	bb 00 00 01 00       	mov    $0x10000,%ebx
  40ba31:	41 c7 86 d0 02 00 00 	movl   $0xffffffff,0x2d0(%r14)
  40ba38:	ff ff ff ff 
  40ba3c:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  40ba43:	89 d8                	mov    %ebx,%eax
  40ba45:	5b                   	pop    %rbx
  40ba46:	5d                   	pop    %rbp
  40ba47:	41 5c                	pop    %r12
  40ba49:	41 5d                	pop    %r13
  40ba4b:	41 5e                	pop    %r14
  40ba4d:	41 5f                	pop    %r15
  40ba4f:	31 d2                	xor    %edx,%edx
  40ba51:	31 c9                	xor    %ecx,%ecx
  40ba53:	31 f6                	xor    %esi,%esi
  40ba55:	31 ff                	xor    %edi,%edi
  40ba57:	45 31 c0             	xor    %r8d,%r8d
  40ba5a:	45 31 c9             	xor    %r9d,%r9d
  40ba5d:	45 31 d2             	xor    %r10d,%r10d
  40ba60:	45 31 db             	xor    %r11d,%r11d
  40ba63:	c3                   	ret
  40ba64:	0f 1f 40 00          	nopl   0x0(%rax)
  40ba68:	49 8b 86 98 00 00 00 	mov    0x98(%r14),%rax
  40ba6f:	48 8b 3c 24          	mov    (%rsp),%rdi
  40ba73:	4c 89 f6             	mov    %r14,%rsi
  40ba76:	48 8b 80 50 01 00 00 	mov    0x150(%rax),%rax
  40ba7d:	ff 50 18             	call   *0x18(%rax)
  40ba80:	45 8b 86 cc 00 00 00 	mov    0xcc(%r14),%r8d
  40ba87:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  40ba8c:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
  40ba90:	0f 84 3a 04 00 00    	je     40bed0 <cpu_exec_loop+0x590>
  40ba96:	41 c7 86 cc 00 00 00 	movl   $0xffffffff,0xcc(%r14)
  40ba9d:	ff ff ff ff 
  40baa1:	49 83 be 40 02 00 00 	cmpq   $0x0,0x240(%r14)
  40baa8:	00 
  40baa9:	0f 85 61 04 00 00    	jne    40bf10 <cpu_exec_loop+0x5d0>
  40baaf:	8b 05 8f 70 2d 01    	mov    0x12d708f(%rip),%eax        # 16e2b44 <target_page+0x4>
  40bab5:	4d 8b 96 18 02 00 00 	mov    0x218(%r14),%r10
  40babc:	44 8b 6c 24 58       	mov    0x58(%rsp),%r13d
  40bac1:	4c 8b 5c 24 60       	mov    0x60(%rsp),%r11
  40bac6:	8d 48 fa             	lea    -0x6(%rax),%ecx
  40bac9:	4c 89 c8             	mov    %r9,%rax
  40bacc:	48 d3 e8             	shr    %cl,%rax
  40bacf:	4c 31 c8             	xor    %r9,%rax
  40bad2:	48 89 c5             	mov    %rax,%rbp
  40bad5:	83 e0 3f             	and    $0x3f,%eax
  40bad8:	48 d3 ed             	shr    %cl,%rbp
  40badb:	81 e5 c0 0f 00 00    	and    $0xfc0,%ebp
  40bae1:	09 c5                	or     %eax,%ebp
  40bae3:	8d 45 01             	lea    0x1(%rbp),%eax
  40bae6:	48 c1 e0 04          	shl    $0x4,%rax
  40baea:	4c 01 d0             	add    %r10,%rax
  40baed:	48 8b 18             	mov    (%rax),%rbx
  40baf0:	48 85 db             	test   %rbx,%rbx
  40baf3:	0f 84 f7 01 00 00    	je     40bcf0 <cpu_exec_loop+0x3b0>
  40baf9:	89 e8                	mov    %ebp,%eax
  40bafb:	48 c1 e0 04          	shl    $0x4,%rax
  40baff:	4e 39 4c 10 18       	cmp    %r9,0x18(%rax,%r10,1)
  40bb04:	0f 85 e6 01 00 00    	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb0a:	4c 39 5b 08          	cmp    %r11,0x8(%rbx)
  40bb0e:	0f 85 dc 01 00 00    	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb14:	44 3b 6b 10          	cmp    0x10(%rbx),%r13d
  40bb18:	0f 85 d2 01 00 00    	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb1e:	8b 43 14             	mov    0x14(%rbx),%eax
  40bb21:	44 39 c0             	cmp    %r8d,%eax
  40bb24:	0f 85 c6 01 00 00    	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb2a:	8b 43 14             	mov    0x14(%rbx),%eax
  40bb2d:	a9 00 00 02 00       	test   $0x20000,%eax
  40bb32:	75 09                	jne    40bb3d <cpu_exec_loop+0x1fd>
  40bb34:	4c 39 0b             	cmp    %r9,(%rbx)
  40bb37:	0f 85 16 c9 dd ff    	jne    1e8453 <cpu_exec_loop.cold+0x1f>
  40bb3d:	48 83 7b 50 ff       	cmpq   $0xffffffffffffffff,0x50(%rbx)
  40bb42:	75 05                	jne    40bb49 <cpu_exec_loop+0x209>
  40bb44:	4d 85 e4             	test   %r12,%r12
  40bb47:	75 77                	jne    40bbc0 <cpu_exec_loop+0x280>
  40bb49:	44 8b 05 f8 d3 33 01 	mov    0x133d3f8(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40bb50:	45 85 c0             	test   %r8d,%r8d
  40bb53:	0f 85 47 01 00 00    	jne    40bca0 <cpu_exec_loop+0x360>
  40bb59:	48 8d 54 24 3c       	lea    0x3c(%rsp),%rdx
  40bb5e:	48 89 de             	mov    %rbx,%rsi
  40bb61:	4c 89 f7             	mov    %r14,%rdi
  40bb64:	e8 b7 fb ff ff       	call   40b720 <cpu_tb_exec>
  40bb69:	83 7c 24 3c 03       	cmpl   $0x3,0x3c(%rsp)
  40bb6e:	49 89 c4             	mov    %rax,%r12
  40bb71:	0f 84 c9 02 00 00    	je     40be40 <cpu_exec_loop+0x500>
  40bb77:	80 3d fe 27 32 01 00 	cmpb   $0x0,0x13227fe(%rip)        # 172e37c <icount_align_option>
  40bb7e:	74 34                	je     40bbb4 <cpu_exec_loop+0x274>
  40bb80:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  40bb84:	41 0f b7 9e 50 4b 00 	movzwl 0x4b50(%r14),%ebx
  40bb8b:	00 
  40bb8c:	49 03 9e e0 00 00 00 	add    0xe0(%r14),%rbx
  40bb93:	48 29 df             	sub    %rbx,%rdi
  40bb96:	e8 35 d0 01 00       	call   428bd0 <icount_to_ns>
  40bb9b:	49 03 07             	add    (%r15),%rax
  40bb9e:	49 89 5f 08          	mov    %rbx,0x8(%r15)
  40bba2:	49 89 07             	mov    %rax,(%r15)
  40bba5:	48 89 c1             	mov    %rax,%rcx
  40bba8:	48 3d c0 c6 2d 00    	cmp    $0x2dc6c0,%rax
  40bbae:	0f 8f 94 03 00 00    	jg     40bf48 <cpu_exec_loop+0x608>
  40bbb4:	41 8b 86 cc 00 00 00 	mov    0xcc(%r14),%eax
  40bbbb:	e9 f0 fd ff ff       	jmp    40b9b0 <cpu_exec_loop+0x70>
  40bbc0:	8b 74 24 3c          	mov    0x3c(%rsp),%esi
  40bbc4:	83 fe 01             	cmp    $0x1,%esi
  40bbc7:	0f 87 67 c8 dd ff    	ja     1e8434 <cpu_exec_loop.cold>
  40bbcd:	48 8d 6b 58          	lea    0x58(%rbx),%rbp
  40bbd1:	ba 01 00 00 00       	mov    $0x1,%edx
  40bbd6:	89 d0                	mov    %edx,%eax
  40bbd8:	87 45 00             	xchg   %eax,0x0(%rbp)
  40bbdb:	85 c0                	test   %eax,%eax
  40bbdd:	0f 85 f7 00 00 00    	jne    40bcda <cpu_exec_loop+0x39a>
  40bbe3:	f6 43 15 40          	testb  $0x40,0x15(%rbx)
  40bbe7:	0f 85 43 02 00 00    	jne    40be30 <cpu_exec_loop+0x4f0>
  40bbed:	4c 63 ee             	movslq %esi,%r13
  40bbf0:	31 c0                	xor    %eax,%eax
  40bbf2:	49 8d 55 12          	lea    0x12(%r13),%rdx
  40bbf6:	f0 49 0f b1 1c d4    	lock cmpxchg %rbx,(%r12,%rdx,8)
  40bbfc:	0f 85 2e 02 00 00    	jne    40be30 <cpu_exec_loop+0x4f0>
  40bc02:	48 8b 43 28          	mov    0x28(%rbx),%rax
  40bc06:	43 0f b7 54 6c 60    	movzwl 0x60(%r12,%r13,2),%edx
  40bc0c:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
  40bc11:	49 03 54 24 28       	add    0x28(%r12),%rdx
  40bc16:	48 8b 3d ab 88 30 01 	mov    0x13088ab(%rip),%rdi        # 17144c8 <tcg_splitwx_diff>
  40bc1d:	89 74 24 08          	mov    %esi,0x8(%rsp)
  40bc21:	4b 89 44 ec 68       	mov    %rax,0x68(%r12,%r13,8)
  40bc26:	48 89 d1             	mov    %rdx,%rcx
  40bc29:	48 29 f9             	sub    %rdi,%rcx
  40bc2c:	4c 01 e7             	add    %r12,%rdi
  40bc2f:	e8 ec 6a fd ff       	call   3e2720 <tb_target_set_jmp_target>
  40bc34:	48 8b 43 78          	mov    0x78(%rbx),%rax
  40bc38:	4b 89 84 ec 80 00 00 	mov    %rax,0x80(%r12,%r13,8)
  40bc3f:	00 
  40bc40:	4d 09 e5             	or     %r12,%r13
  40bc43:	4c 89 6b 78          	mov    %r13,0x78(%rbx)
  40bc47:	c7 45 00 00 00 00 00 	movl   $0x0,0x0(%rbp)
  40bc4e:	f6 05 8b cf 33 01 20 	testb  $0x20,0x133cf8b(%rip)        # 1748be0 <qemu_loglevel>
  40bc55:	8b 74 24 08          	mov    0x8(%rsp),%esi
  40bc59:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  40bc5e:	0f 84 e5 fe ff ff    	je     40bb49 <cpu_exec_loop+0x209>
  40bc64:	49 8b 44 24 28       	mov    0x28(%r12),%rax
  40bc69:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
  40bc6d:	89 f2                	mov    %esi,%edx
  40bc6f:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
  40bc74:	48 8d 3d b5 d9 cc 00 	lea    0xccd9b5(%rip),%rdi        # 10d9630 <anon.53529a8b42b516fa44fa3e141ddff7ec.0.llvm.534248872324339782+0x2db07>
  40bc7b:	48 89 c6             	mov    %rax,%rsi
  40bc7e:	31 c0                	xor    %eax,%eax
  40bc80:	e8 6b 2b 26 00       	call   66e7f0 <qemu_log>
  40bc85:	44 8b 05 bc d2 33 01 	mov    0x133d2bc(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40bc8c:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  40bc91:	45 85 c0             	test   %r8d,%r8d
  40bc94:	0f 84 bf fe ff ff    	je     40bb59 <cpu_exec_loop+0x219>
  40bc9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40bca0:	66 83 3d 6e c5 33 01 	cmpw   $0x0,0x133c56e(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40bca7:	00 
  40bca8:	0f 84 ab fe ff ff    	je     40bb59 <cpu_exec_loop+0x219>
  40bcae:	f6 05 2c cf 33 01 80 	testb  $0x80,0x133cf2c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bcb5:	0f 84 9e fe ff ff    	je     40bb59 <cpu_exec_loop+0x219>
  40bcbb:	4c 89 ca             	mov    %r9,%rdx
  40bcbe:	48 89 de             	mov    %rbx,%rsi
  40bcc1:	48 8d 3d e1 ca c4 00 	lea    0xc4cae1(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40bcc8:	31 c0                	xor    %eax,%eax
  40bcca:	e8 21 2b 26 00       	call   66e7f0 <qemu_log>
  40bccf:	e9 85 fe ff ff       	jmp    40bb59 <cpu_exec_loop+0x219>
  40bcd4:	0f 1f 40 00          	nopl   0x0(%rax)
  40bcd8:	f3 90                	pause
  40bcda:	8b 45 00             	mov    0x0(%rbp),%eax
  40bcdd:	85 c0                	test   %eax,%eax
  40bcdf:	75 f7                	jne    40bcd8 <cpu_exec_loop+0x398>
  40bce1:	e9 f0 fe ff ff       	jmp    40bbd6 <cpu_exec_loop+0x296>
  40bce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  40bced:	00 00 00 
  40bcf0:	66 41 0f 6e d0       	movd   %r8d,%xmm2
  40bcf5:	66 41 0f 6e cd       	movd   %r13d,%xmm1
  40bcfa:	4c 89 d7             	mov    %r10,%rdi
  40bcfd:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  40bd02:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
  40bd06:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
  40bd0b:	44 89 44 24 2c       	mov    %r8d,0x2c(%rsp)
  40bd10:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
  40bd15:	66 0f d6 4c 24 08    	movq   %xmm1,0x8(%rsp)
  40bd1b:	e8 e0 00 01 00       	call   41be00 <tcg_victim_cache_epoch>
  40bd20:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  40bd25:	48 83 ec 20          	sub    $0x20,%rsp
  40bd29:	89 ee                	mov    %ebp,%esi
  40bd2b:	49 89 c5             	mov    %rax,%r13
  40bd2e:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
  40bd33:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  40bd38:	4c 89 8c 24 90 00 00 	mov    %r9,0x90(%rsp)
  40bd3f:	00 
  40bd40:	4c 89 ea             	mov    %r13,%rdx
  40bd43:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  40bd4a:	00 
  40bd4b:	4c 89 9c 24 a0 00 00 	mov    %r11,0xa0(%rsp)
  40bd52:	00 
  40bd53:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  40bd58:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  40bd5f:	00 00 
  40bd61:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
  40bd66:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
  40bd6b:	0f 11 04 24          	movups %xmm0,(%rsp)
  40bd6f:	e8 fc 02 01 00       	call   41c070 <tcg_victim_cache_lookup>
  40bd74:	48 83 c4 20          	add    $0x20,%rsp
  40bd78:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  40bd7d:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  40bd82:	48 85 c0             	test   %rax,%rax
  40bd85:	48 89 c3             	mov    %rax,%rbx
  40bd88:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  40bd8d:	44 8b 44 24 2c       	mov    0x2c(%rsp),%r8d
  40bd92:	0f 85 92 fd ff ff    	jne    40bb2a <cpu_exec_loop+0x1ea>
  40bd98:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  40bd9d:	44 89 44 24 18       	mov    %r8d,0x18(%rsp)
  40bda2:	4c 89 f7             	mov    %r14,%rdi
  40bda5:	48 83 ec 20          	sub    $0x20,%rsp
  40bda9:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
  40bdae:	48 8d 15 8b f1 ff ff 	lea    -0xe75(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40bdb5:	48 8d 35 24 25 32 01 	lea    0x1322524(%rip),%rsi        # 172e2e0 <tb_ctx>
  40bdbc:	4c 89 8c 24 b0 00 00 	mov    %r9,0xb0(%rsp)
  40bdc3:	00 
  40bdc4:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
  40bdc9:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  40bdd0:	00 
  40bdd1:	4c 89 9c 24 c0 00 00 	mov    %r11,0xc0(%rsp)
  40bdd8:	00 
  40bdd9:	66 0f 6f 84 24 b0 00 	movdqa 0xb0(%rsp),%xmm0
  40bde0:	00 00 
  40bde2:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
  40bde7:	0f 11 04 24          	movups %xmm0,(%rsp)
  40bdeb:	e8 f0 f2 ff ff       	call   40b0e0 <tb_htable_lookup_common>
  40bdf0:	48 83 c4 20          	add    $0x20,%rsp
  40bdf4:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  40bdf9:	44 8b 44 24 18       	mov    0x18(%rsp),%r8d
  40bdfe:	48 85 c0             	test   %rax,%rax
  40be01:	48 89 c3             	mov    %rax,%rbx
  40be04:	0f 84 9e 03 00 00    	je     40c1a8 <cpu_exec_loop+0x868>
  40be0a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  40be0f:	4c 89 ca             	mov    %r9,%rdx
  40be12:	4d 89 e8             	mov    %r13,%r8
  40be15:	48 89 c1             	mov    %rax,%rcx
  40be18:	89 ee                	mov    %ebp,%esi
  40be1a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
  40be1f:	e8 1c 00 01 00       	call   41be40 <tcg_victim_cache_fill>
  40be24:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  40be29:	e9 fc fc ff ff       	jmp    40bb2a <cpu_exec_loop+0x1ea>
  40be2e:	66 90                	xchg   %ax,%ax
  40be30:	c7 45 00 00 00 00 00 	movl   $0x0,0x0(%rbp)
  40be37:	e9 0d fd ff ff       	jmp    40bb49 <cpu_exec_loop+0x209>
  40be3c:	0f 1f 40 00          	nopl   0x0(%rax)
  40be40:	41 8b 86 50 4b 00 00 	mov    0x4b50(%r14),%eax
  40be47:	85 c0                	test   %eax,%eax
  40be49:	78 74                	js     40bebf <cpu_exec_loop+0x57f>
  40be4b:	8b 3d 27 25 32 01    	mov    0x1322527(%rip),%edi        # 172e378 <use_icount>
  40be51:	85 ff                	test   %edi,%edi
  40be53:	0f 84 38 c6 dd ff    	je     1e8491 <cpu_exec_loop.cold+0x5d>
  40be59:	4c 89 f7             	mov    %r14,%rdi
  40be5c:	e8 6f cc 01 00       	call   428ad0 <icount_update>
  40be61:	49 8b 96 d8 00 00 00 	mov    0xd8(%r14),%rdx
  40be68:	b8 ff ff 00 00       	mov    $0xffff,%eax
  40be6d:	48 39 c2             	cmp    %rax,%rdx
  40be70:	48 0f 4e c2          	cmovle %rdx,%rax
  40be74:	48 63 c8             	movslq %eax,%rcx
  40be77:	66 41 89 86 50 4b 00 	mov    %ax,0x4b50(%r14)
  40be7e:	00 
  40be7f:	48 29 ca             	sub    %rcx,%rdx
  40be82:	49 89 96 e0 00 00 00 	mov    %rdx,0xe0(%r14)
  40be89:	85 c0                	test   %eax,%eax
  40be8b:	7e 32                	jle    40bebf <cpu_exec_loop+0x57f>
  40be8d:	41 0f b7 4c 24 1a    	movzwl 0x1a(%r12),%ecx
  40be93:	39 c8                	cmp    %ecx,%eax
  40be95:	7d 28                	jge    40bebf <cpu_exec_loop+0x57f>
  40be97:	3d ff 01 00 00       	cmp    $0x1ff,%eax
  40be9c:	0f 8f d0 c5 dd ff    	jg     1e8472 <cpu_exec_loop.cold+0x3e>
  40bea2:	48 85 d2             	test   %rdx,%rdx
  40bea5:	0f 85 05 c6 dd ff    	jne    1e84b0 <cpu_exec_loop.cold+0x7c>
  40beab:	41 8b 54 24 14       	mov    0x14(%r12),%edx
  40beb0:	81 e2 00 fe ff ff    	and    $0xfffffe00,%edx
  40beb6:	09 d0                	or     %edx,%eax
  40beb8:	41 89 86 cc 00 00 00 	mov    %eax,0xcc(%r14)
  40bebf:	45 31 e4             	xor    %r12d,%r12d
  40bec2:	e9 b0 fc ff ff       	jmp    40bb77 <cpu_exec_loop+0x237>
  40bec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40bece:	00 00 
  40bed0:	45 8b 96 d4 00 00 00 	mov    0xd4(%r14),%r10d
  40bed7:	45 8b 86 c8 02 00 00 	mov    0x2c8(%r14),%r8d
  40bede:	45 85 d2             	test   %r10d,%r10d
  40bee1:	0f 85 b1 02 00 00    	jne    40c198 <cpu_exec_loop+0x858>
  40bee7:	0f b6 05 de 23 32 01 	movzbl 0x13223de(%rip),%eax        # 172e2cc <one_insn_per_tb>
  40beee:	84 c0                	test   %al,%al
  40bef0:	0f 84 ca 00 00 00    	je     40bfc0 <cpu_exec_loop+0x680>
  40bef6:	41 81 c8 01 02 00 00 	or     $0x201,%r8d
  40befd:	49 83 be 40 02 00 00 	cmpq   $0x0,0x240(%r14)
  40bf04:	00 
  40bf05:	0f 84 a4 fb ff ff    	je     40baaf <cpu_exec_loop+0x16f>
  40bf0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  40bf10:	48 8d 54 24 5c       	lea    0x5c(%rsp),%rdx
  40bf15:	4c 89 ce             	mov    %r9,%rsi
  40bf18:	4c 89 f7             	mov    %r14,%rdi
  40bf1b:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
  40bf20:	44 89 44 24 5c       	mov    %r8d,0x5c(%rsp)
  40bf25:	e8 a6 f0 ff ff       	call   40afd0 <check_for_breakpoints_slow>
  40bf2a:	84 c0                	test   %al,%al
  40bf2c:	0f 85 8e 01 00 00    	jne    40c0c0 <cpu_exec_loop+0x780>
  40bf32:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  40bf37:	44 8b 44 24 5c       	mov    0x5c(%rsp),%r8d
  40bf3c:	e9 6e fb ff ff       	jmp    40baaf <cpu_exec_loop+0x16f>
  40bf41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40bf48:	48 b8 b3 94 d6 26 e8 	movabs $0x112e0be826d694b3,%rax
  40bf4f:	0b 2e 11 
  40bf52:	66 0f ef c0          	pxor   %xmm0,%xmm0
  40bf56:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  40bf5b:	48 f7 e9             	imul   %rcx
  40bf5e:	48 89 c8             	mov    %rcx,%rax
  40bf61:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  40bf68:	00 
  40bf69:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  40bf70:	00 
  40bf71:	48 c1 f8 3f          	sar    $0x3f,%rax
  40bf75:	48 c1 fa 1a          	sar    $0x1a,%rdx
  40bf79:	48 29 c2             	sub    %rax,%rdx
  40bf7c:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  40bf81:	48 69 d2 00 ca 9a 3b 	imul   $0x3b9aca00,%rdx,%rdx
  40bf88:	48 29 d1             	sub    %rdx,%rcx
  40bf8b:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  40bf90:	e8 1b a7 dc ff       	call   1d66b0 <nanosleep@plt>
  40bf95:	89 c2                	mov    %eax,%edx
  40bf97:	31 c0                	xor    %eax,%eax
  40bf99:	85 d2                	test   %edx,%edx
  40bf9b:	79 14                	jns    40bfb1 <cpu_exec_loop+0x671>
  40bf9d:	48 69 84 24 90 00 00 	imul   $0x3b9aca00,0x90(%rsp),%rax
  40bfa4:	00 00 ca 9a 3b 
  40bfa9:	48 03 84 24 98 00 00 	add    0x98(%rsp),%rax
  40bfb0:	00 
  40bfb1:	49 89 07             	mov    %rax,(%r15)
  40bfb4:	e9 fb fb ff ff       	jmp    40bbb4 <cpu_exec_loop+0x274>
  40bfb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40bfc0:	44 89 c0             	mov    %r8d,%eax
  40bfc3:	80 cc 02             	or     $0x2,%ah
  40bfc6:	f6 05 14 cc 33 01 20 	testb  $0x20,0x133cc14(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bfcd:	44 0f 45 c0          	cmovne %eax,%r8d
  40bfd1:	e9 cb fa ff ff       	jmp    40baa1 <cpu_exec_loop+0x161>
  40bfd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  40bfdd:	00 00 00 
  40bfe0:	be 65 03 00 00       	mov    $0x365,%esi
  40bfe5:	48 8d 3d 5f c7 c4 00 	lea    0xc4c75f(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40bfec:	e8 ff cf f5 ff       	call   368ff0 <bql_lock_impl>
  40bff1:	41 8b 86 d0 00 00 00 	mov    0xd0(%r14),%eax
  40bff8:	a8 80                	test   $0x80,%al
  40bffa:	0f 85 60 02 00 00    	jne    40c260 <cpu_exec_loop+0x920>
  40c000:	83 3d 21 83 30 01 02 	cmpl   $0x2,0x1308321(%rip)        # 1714328 <replay_mode>
  40c007:	0f 84 53 01 00 00    	je     40c160 <cpu_exec_loop+0x820>
  40c00d:	41 8b 86 d0 00 00 00 	mov    0xd0(%r14),%eax
  40c014:	a8 20                	test   $0x20,%al
  40c016:	0f 85 0c 02 00 00    	jne    40c228 <cpu_exec_loop+0x8e8>
  40c01c:	49 8b 86 98 00 00 00 	mov    0x98(%r14),%rax
  40c023:	41 8b 9e d0 00 00 00 	mov    0xd0(%r14),%ebx
  40c02a:	48 8b a8 50 01 00 00 	mov    0x150(%rax),%rbp
  40c031:	41 8b 86 d0 00 00 00 	mov    0xd0(%r14),%eax
  40c038:	f6 c4 04             	test   $0x4,%ah
  40c03b:	75 6f                	jne    40c0ac <cpu_exec_loop+0x76c>
  40c03d:	89 d8                	mov    %ebx,%eax
  40c03f:	4c 89 f7             	mov    %r14,%rdi
  40c042:	25 a5 ed ff ff       	and    $0xffffeda5,%eax
  40c047:	41 f6 86 d4 00 00 00 	testb  $0x2,0xd4(%r14)
  40c04e:	02 
  40c04f:	0f 45 d8             	cmovne %eax,%ebx
  40c052:	89 de                	mov    %ebx,%esi
  40c054:	ff 55 58             	call   *0x58(%rbp)
  40c057:	84 c0                	test   %al,%al
  40c059:	74 31                	je     40c08c <cpu_exec_loop+0x74c>
  40c05b:	48 8b 85 b8 00 00 00 	mov    0xb8(%rbp),%rax
  40c062:	48 85 c0             	test   %rax,%rax
  40c065:	74 3e                	je     40c0a5 <cpu_exec_loop+0x765>
  40c067:	89 df                	mov    %ebx,%edi
  40c069:	ff d0                	call   *%rax
  40c06b:	84 c0                	test   %al,%al
  40c06d:	75 36                	jne    40c0a5 <cpu_exec_loop+0x765>
  40c06f:	41 8b b6 d4 00 00 00 	mov    0xd4(%r14),%esi
  40c076:	85 f6                	test   %esi,%esi
  40c078:	0f 85 de 02 00 00    	jne    40c35c <cpu_exec_loop+0xa1c>
  40c07e:	41 c7 86 d0 02 00 00 	movl   $0xffffffff,0x2d0(%r14)
  40c085:	ff ff ff ff 
  40c089:	45 31 e4             	xor    %r12d,%r12d
  40c08c:	41 8b 86 d0 00 00 00 	mov    0xd0(%r14),%eax
  40c093:	a8 04                	test   $0x4,%al
  40c095:	0f 85 e1 00 00 00    	jne    40c17c <cpu_exec_loop+0x83c>
  40c09b:	e8 a0 cf f5 ff       	call   369040 <bql_unlock>
  40c0a0:	e9 34 f9 ff ff       	jmp    40b9d9 <cpu_exec_loop+0x99>
  40c0a5:	e8 66 51 fc ff       	call   3d1210 <replay_interrupt>
  40c0aa:	eb c3                	jmp    40c06f <cpu_exec_loop+0x72f>
  40c0ac:	e8 5f 51 fc ff       	call   3d1210 <replay_interrupt>
  40c0b1:	4c 89 f7             	mov    %r14,%rdi
  40c0b4:	ff 55 60             	call   *0x60(%rbp)
  40c0b7:	e8 84 cf f5 ff       	call   369040 <bql_unlock>
  40c0bc:	0f 1f 40 00          	nopl   0x0(%rax)
  40c0c0:	41 8b 9e d0 02 00 00 	mov    0x2d0(%r14),%ebx
  40c0c7:	85 db                	test   %ebx,%ebx
  40c0c9:	0f 88 a1 f8 ff ff    	js     40b970 <cpu_exec_loop+0x30>
  40c0cf:	81 fb ff ff 00 00    	cmp    $0xffff,%ebx
  40c0d5:	0f 8f ae 01 00 00    	jg     40c289 <cpu_exec_loop+0x949>
  40c0db:	e8 00 50 fc ff       	call   3d10e0 <replay_exception>
  40c0e0:	84 c0                	test   %al,%al
  40c0e2:	0f 84 e0 01 00 00    	je     40c2c8 <cpu_exec_loop+0x988>
  40c0e8:	49 8b 86 98 00 00 00 	mov    0x98(%r14),%rax
  40c0ef:	be 19 03 00 00       	mov    $0x319,%esi
  40c0f4:	48 8d 3d 50 c6 c4 00 	lea    0xc4c650(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c0fb:	48 8b 98 50 01 00 00 	mov    0x150(%rax),%rbx
  40c102:	e8 e9 ce f5 ff       	call   368ff0 <bql_lock_impl>
  40c107:	4c 89 f7             	mov    %r14,%rdi
  40c10a:	ff 53 50             	call   *0x50(%rbx)
  40c10d:	e8 2e cf f5 ff       	call   369040 <bql_unlock>
  40c112:	41 8b 86 d4 00 00 00 	mov    0xd4(%r14),%eax
  40c119:	41 c7 86 d0 02 00 00 	movl   $0xffffffff,0x2d0(%r14)
  40c120:	ff ff ff ff 
  40c124:	85 c0                	test   %eax,%eax
  40c126:	0f 84 64 f8 ff ff    	je     40b990 <cpu_exec_loop+0x50>
  40c12c:	49 8b 86 98 00 00 00 	mov    0x98(%r14),%rax
  40c133:	49 83 be 60 02 00 00 	cmpq   $0x0,0x260(%r14)
  40c13a:	00 
  40c13b:	48 8b 90 50 01 00 00 	mov    0x150(%rax),%rdx
  40c142:	0f 84 30 02 00 00    	je     40c378 <cpu_exec_loop+0xa38>
  40c148:	48 8b 42 40          	mov    0x40(%rdx),%rax
  40c14c:	48 85 c0             	test   %rax,%rax
  40c14f:	74 05                	je     40c156 <cpu_exec_loop+0x816>
  40c151:	4c 89 f7             	mov    %r14,%rdi
  40c154:	ff d0                	call   *%rax
  40c156:	bb 02 00 01 00       	mov    $0x10002,%ebx
  40c15b:	e9 dc f8 ff ff       	jmp    40ba3c <cpu_exec_loop+0xfc>
  40c160:	e8 9b 51 fc ff       	call   3d1300 <replay_has_interrupt>
  40c165:	84 c0                	test   %al,%al
  40c167:	0f 85 a0 fe ff ff    	jne    40c00d <cpu_exec_loop+0x6cd>
  40c16d:	41 8b 86 d0 00 00 00 	mov    0xd0(%r14),%eax
  40c174:	a8 04                	test   $0x4,%al
  40c176:	0f 84 1f ff ff ff    	je     40c09b <cpu_exec_loop+0x75b>
  40c17c:	be 04 00 00 00       	mov    $0x4,%esi
  40c181:	4c 89 f7             	mov    %r14,%rdi
  40c184:	45 31 e4             	xor    %r12d,%r12d
  40c187:	e8 c4 cd e3 ff       	call   248f50 <cpu_reset_interrupt>
  40c18c:	e9 0a ff ff ff       	jmp    40c09b <cpu_exec_loop+0x75b>
  40c191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40c198:	41 81 c8 01 0e 00 00 	or     $0xe01,%r8d
  40c19f:	e9 fd f8 ff ff       	jmp    40baa1 <cpu_exec_loop+0x161>
  40c1a4:	0f 1f 40 00          	nopl   0x0(%rax)
  40c1a8:	49 8b be 18 02 00 00 	mov    0x218(%r14),%rdi
  40c1af:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
  40c1b4:	44 89 44 24 10       	mov    %r8d,0x10(%rsp)
  40c1b9:	e8 42 fc 00 00       	call   41be00 <tcg_victim_cache_epoch>
  40c1be:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  40c1c3:	44 8b 44 24 10       	mov    0x10(%rsp),%r8d
  40c1c8:	4c 89 f7             	mov    %r14,%rdi
  40c1cb:	48 83 ec 20          	sub    $0x20,%rsp
  40c1cf:	49 89 c5             	mov    %rax,%r13
  40c1d2:	4c 89 4c 24 70       	mov    %r9,0x70(%rsp)
  40c1d7:	44 89 44 24 7c       	mov    %r8d,0x7c(%rsp)
  40c1dc:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
  40c1e2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  40c1e9:	00 
  40c1ea:	0f 11 04 24          	movups %xmm0,(%rsp)
  40c1ee:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  40c1f3:	e8 c8 e1 00 00       	call   41a3c0 <tb_gen_code>
  40c1f8:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  40c1fd:	48 83 c4 20          	add    $0x20,%rsp
  40c201:	89 ee                	mov    %ebp,%esi
  40c203:	49 8b be 18 02 00 00 	mov    0x218(%r14),%rdi
  40c20a:	4d 89 e8             	mov    %r13,%r8
  40c20d:	48 89 c1             	mov    %rax,%rcx
  40c210:	48 89 c3             	mov    %rax,%rbx
  40c213:	e8 28 fc 00 00       	call   41be40 <tcg_victim_cache_fill>
  40c218:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  40c21d:	e9 1b f9 ff ff       	jmp    40bb3d <cpu_exec_loop+0x1fd>
  40c222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40c228:	e8 e3 4f fc ff       	call   3d1210 <replay_interrupt>
  40c22d:	be 20 00 00 00       	mov    $0x20,%esi
  40c232:	4c 89 f7             	mov    %r14,%rdi
  40c235:	e8 16 cd e3 ff       	call   248f50 <cpu_reset_interrupt>
  40c23a:	48 b8 01 00 00 00 01 	movabs $0x1000100000001,%rax
  40c241:	00 01 00 
  40c244:	49 89 86 cc 02 00 00 	mov    %rax,0x2cc(%r14)
  40c24b:	e8 f0 cd f5 ff       	call   369040 <bql_unlock>
  40c250:	41 8b 9e d0 02 00 00 	mov    0x2d0(%r14),%ebx
  40c257:	e9 01 f7 ff ff       	jmp    40b95d <cpu_exec_loop+0x1d>
  40c25c:	0f 1f 40 00          	nopl   0x0(%rax)
  40c260:	be 80 00 00 00       	mov    $0x80,%esi
  40c265:	4c 89 f7             	mov    %r14,%rdi
  40c268:	e8 e3 cc e3 ff       	call   248f50 <cpu_reset_interrupt>
  40c26d:	41 c7 86 d0 02 00 00 	movl   $0x10002,0x2d0(%r14)
  40c274:	02 00 01 00 
  40c278:	e8 c3 cd f5 ff       	call   369040 <bql_unlock>
  40c27d:	41 8b 9e d0 02 00 00 	mov    0x2d0(%r14),%ebx
  40c284:	e9 d4 f6 ff ff       	jmp    40b95d <cpu_exec_loop+0x1d>
  40c289:	81 fb 02 00 01 00    	cmp    $0x10002,%ebx
  40c28f:	0f 85 9c f7 ff ff    	jne    40ba31 <cpu_exec_loop+0xf1>
  40c295:	49 8b 86 98 00 00 00 	mov    0x98(%r14),%rax
  40c29c:	49 83 be 60 02 00 00 	cmpq   $0x0,0x260(%r14)
  40c2a3:	00 
  40c2a4:	48 8b 90 50 01 00 00 	mov    0x150(%rax),%rdx
  40c2ab:	74 78                	je     40c325 <cpu_exec_loop+0x9e5>
  40c2ad:	48 8b 42 40          	mov    0x40(%rdx),%rax
  40c2b1:	48 85 c0             	test   %rax,%rax
  40c2b4:	0f 84 77 f7 ff ff    	je     40ba31 <cpu_exec_loop+0xf1>
  40c2ba:	4c 89 f7             	mov    %r14,%rdi
  40c2bd:	ff d0                	call   *%rax
  40c2bf:	e9 6d f7 ff ff       	jmp    40ba31 <cpu_exec_loop+0xf1>
  40c2c4:	0f 1f 40 00          	nopl   0x0(%rax)
  40c2c8:	e8 33 50 fc ff       	call   3d1300 <replay_has_interrupt>
  40c2cd:	84 c0                	test   %al,%al
  40c2cf:	0f 85 bb f6 ff ff    	jne    40b990 <cpu_exec_loop+0x50>
  40c2d5:	bb 00 00 01 00       	mov    $0x10000,%ebx
  40c2da:	e9 5d f7 ff ff       	jmp    40ba3c <cpu_exec_loop+0xfc>
  40c2df:	41 8b 96 d4 00 00 00 	mov    0xd4(%r14),%edx
  40c2e6:	41 8b 86 c8 02 00 00 	mov    0x2c8(%r14),%eax
  40c2ed:	85 d2                	test   %edx,%edx
  40c2ef:	0f 85 a8 00 00 00    	jne    40c39d <cpu_exec_loop+0xa5d>
  40c2f5:	0f b6 15 d0 1f 32 01 	movzbl 0x1321fd0(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40c2fc:	84 d2                	test   %dl,%dl
  40c2fe:	75 55                	jne    40c355 <cpu_exec_loop+0xa15>
  40c300:	89 c2                	mov    %eax,%edx
  40c302:	80 ce 02             	or     $0x2,%dh
  40c305:	f6 05 d5 c8 33 01 20 	testb  $0x20,0x133c8d5(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c30c:	0f 45 c2             	cmovne %edx,%eax
  40c30f:	25 fe df fe ff       	and    $0xfffedffe,%eax
  40c314:	0d 01 00 01 00       	or     $0x10001,%eax
  40c319:	41 89 86 cc 00 00 00 	mov    %eax,0xcc(%r14)
  40c320:	e9 72 f6 ff ff       	jmp    40b997 <cpu_exec_loop+0x57>
  40c325:	49 8b 86 50 02 00 00 	mov    0x250(%r14),%rax
  40c32c:	48 85 c0             	test   %rax,%rax
  40c32f:	0f 84 78 ff ff ff    	je     40c2ad <cpu_exec_loop+0x96d>
  40c335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40c33c:	00 00 00 00 
  40c340:	81 60 20 3f ff ff ff 	andl   $0xffffff3f,0x20(%rax)
  40c347:	48 8b 40 28          	mov    0x28(%rax),%rax
  40c34b:	48 85 c0             	test   %rax,%rax
  40c34e:	75 f0                	jne    40c340 <cpu_exec_loop+0xa00>
  40c350:	e9 58 ff ff ff       	jmp    40c2ad <cpu_exec_loop+0x96d>
  40c355:	0d 01 02 00 00       	or     $0x201,%eax
  40c35a:	eb b3                	jmp    40c30f <cpu_exec_loop+0x9cf>
  40c35c:	41 c7 86 d0 02 00 00 	movl   $0x10002,0x2d0(%r14)
  40c363:	02 00 01 00 
  40c367:	e8 d4 cc f5 ff       	call   369040 <bql_unlock>
  40c36c:	41 8b 9e d0 02 00 00 	mov    0x2d0(%r14),%ebx
  40c373:	e9 e5 f5 ff ff       	jmp    40b95d <cpu_exec_loop+0x1d>
  40c378:	49 8b 86 50 02 00 00 	mov    0x250(%r14),%rax
  40c37f:	48 85 c0             	test   %rax,%rax
  40c382:	0f 84 c0 fd ff ff    	je     40c148 <cpu_exec_loop+0x808>
  40c388:	81 60 20 3f ff ff ff 	andl   $0xffffff3f,0x20(%rax)
  40c38f:	48 8b 40 28          	mov    0x28(%rax),%rax
  40c393:	48 85 c0             	test   %rax,%rax
  40c396:	75 f0                	jne    40c388 <cpu_exec_loop+0xa48>
  40c398:	e9 ab fd ff ff       	jmp    40c148 <cpu_exec_loop+0x808>
  40c39d:	0d 01 0e 00 00       	or     $0xe01,%eax
  40c3a2:	e9 68 ff ff ff       	jmp    40c30f <cpu_exec_loop+0x9cf>

Disassembly of section .fini:

"""Verify recovery bypass changes no compiled caller or retained clear/fill work."""
import subprocess,hashlib,json,re
from pathlib import Path
root=Path('/home/codex/src/steamdeck-xemu/worktrees');out=Path(__file__).parent;records={};sections={};modules={}
for name,build in [('candidate','issue167-victim8/build-on'),('bypass','issue167-victim8-bypass/build')]:
 obj=root/build/'libsystem.a.p/accel_tcg_cpu-exec.c.o';records[name]={'object':str(obj)};sections[name]={}
 for section in ['.text','.text.unlikely','.rodata','.rodata.str1.1']:
  path=out/(name+'-caller'+section);subprocess.run(['objcopy','--dump-section',section+'='+str(path),str(obj)],check=True);b=path.read_bytes();sections[name][section]=b;records[name][section]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 raw=subprocess.check_output(['readelf','-Wr',str(obj)],text=True);parts=raw.split('Relocation section ');rel='\n'.join(x for x in parts[1:] if x.startswith("'.rela.text"));(out/(name+'-caller-relocations.txt')).write_text(rel)
 # ELF file section placement depends on debug paths. Preserve every actual
 # relocation offset/type/symbol/addend and the declared entry counts.
 normalized=re.sub(r" at offset 0x[0-9a-f]+ contains",' contains',rel);sections[name]['relocations']=normalized;records[name]['textRelocationsSha256']=hashlib.sha256(normalized.encode()).hexdigest()
 obj=root/build/'libsystem.a.p/accel_tcg_tb-victim-cache.c.o';path=out/(name+'-helpers.text');subprocess.run(['objcopy','--dump-section','.text='+str(path),str(obj)],check=True);data=path.read_bytes();nm=subprocess.check_output(['nm','-S',str(obj)],text=True);modules[name]={}
 for fn in ['tcg_victim_cache_epoch','tcg_victim_cache_fill','tcg_victim_cache_invalidate_begin','tcg_victim_cache_invalidate_end']:
  row=next(x.split() for x in nm.splitlines() if x.endswith(' '+fn));start,size=int(row[0],16),int(row[1],16);modules[name][fn]={'bytes':size,'sha256':hashlib.sha256(data[start:start+size]).hexdigest()}
for key in sections['candidate']:assert sections['candidate'][key]==sections['bypass'][key],key
assert modules['candidate']==modules['bypass'],modules
proof={'compiledCallersIdentical':True,'retainedHelperInstructionsIdentical':True,'normalization':'Only ELF file offsets of relocation sections; entry offsets, symbols, types and addends unchanged. Original raw headers retained.','callers':records,'helpers':modules}
(out/'identical-caller-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))

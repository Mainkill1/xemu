import subprocess,json
from pathlib import Path
p=Path(__file__).parent;source=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-fifo-ring/accel/tcg/tb-victim-cache.c');original=source.read_text();rows=[]
mutations=[('skip-oldest-slot', 'jc->victim.head = victim_index(jc, 1);', 'jc->victim.head = victim_index(jc, 2);'),('wrong-middle-shift', 'jc->victim.entries[victim_index(jc, i + 1)];', 'jc->victim.entries[victim_index(jc, i)];')]
try:
 for name,old,new in mutations:
  assert original.count(old)==1;source.write_text(original.replace(old,new))
  with (p/(name+'-build.log')).open('w') as log:subprocess.run(['python3',str(p/'build-unit.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
  result=subprocess.run([str(p/'test-tcg-victim-cache'),'-p','/tcg/victim8/reference-fifo-trace-20000'],capture_output=True);(p/(name+'.log')).write_bytes(result.stdout+result.stderr);assert result.returncode!=0 and b'ERROR:' in result.stdout+result.stderr and b'not ok' in result.stdout+result.stderr
  rows.append({'mutation':name,'returncode':result.returncode,'functionalTraceRejected':True})
finally:
 source.write_text(original)
 with (p/'restored-build.log').open('w') as log:subprocess.run(['python3',str(p/'build-unit.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
 result=subprocess.run([str(p/'test-tcg-victim-cache')],capture_output=True);(p/'restored-green.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0,result.stdout+result.stderr
(p/'negative-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))

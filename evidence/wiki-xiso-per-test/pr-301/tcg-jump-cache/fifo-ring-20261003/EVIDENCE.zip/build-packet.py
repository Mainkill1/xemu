"""Preserve the maintained runner's results with the owning xemu draft."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path('/home/codex/src/steamdeck-xemu')
p = Path(__file__).parent
n = p / 'native-balanced'
d = root / 'worktrees/issue167-victim8/evidence/wiki-xiso-per-test/pr-301/tcg-jump-cache/fifo-ring-20261003'
assert json.loads((n / 'SEQUENCE-COMPLETE.json').read_text())['complete']
d.mkdir(parents=True, exist_ok=True)
labels = {'aa': 'Identical previous candidate A/A', 'fifo': 'Previous FIFO → circular FIFO', 'parent': 'Production parent → circular FIFO'}
names = {'jump_cache_collision2': '2 colliding targets', 'jump_cache_collision8': '8 colliding targets', 'jump_cache_collision10': '10 colliding targets (above capacity)', 'jump_cache_noncollision8': '8 noncolliding targets (control)'}
summary = {}
table = ['| Comparison | Workload | Backend | Before | After | Time saved | Improvement % | ABBA / BAAB | CPU correctness |', '|---|---|---|---:|---:|---:|---:|---:|---|']
count = 0
for case in ['aa', 'fifo', 'parent']:
    rows = json.loads((n / (case + '-SUMMARY.json')).read_text())
    report = json.loads((n / (case + '-report.json')).read_text())
    attempts = json.loads((n / (case + '-attempts.json')).read_text())['items']
    cache = json.loads((n / (case + '-cache-qualification.json')).read_text())
    assert report['indexedAttempts'] == 8 and not report['blockers']
    assert len(attempts) == len(cache) == 8
    assert all(x['correctness'] == 'passed' and x['evidence'] == 'complete' and x['comparison'] == 'eligible' for x in attempts)
    assert all(x['DriverNamespaceVerified'] and x['ComparisonReady'] and not x['Issues'] and not x['AllowUncontrolledDriverCache'] for x in cache)
    for attempt in attempts:
        receipt = json.loads((n / (case + '-' + attempt['label'] + '-collection.json')).read_text())
        assert receipt['complete'] and receipt['excluded'] == 0
        count += receipt['fileCount']
    summary[case] = {'comparison': labels[case], 'status': report['status'], 'rows': rows}
    for row in rows:
        table.append(f"| {labels[case]} | {names[row['testId'].split('.')[-1]]} | Vulkan | {row['baselineSeconds']:.6f} s | {row['candidateSeconds']:.6f} s | {row['timeSavedSeconds']:+.6f} s | {row['improvementPercent']:+.2f}% | {row['abbaImprovementPercent']:+.2f}% / {row['baabImprovementPercent']:+.2f}% | 8/8 PASS |")

interpretation = (p / 'interpretation.md').read_text()
report_text = f'''# Circular FIFO: controlled cost and benefit

Recommendation: HOLD for the owning production draft. The circular FIFO experiment is rejected for integration: its incremental benefits are inconclusive and eight-target work is slower. This follows the previous eight-entry candidate, whose deliberate two/eight-target work measured about25% improvement but ten targets cost56%. The experimental implementation changes physical FIFO storage only; the current PR retains its original runtime and the useful independent correctness trace. Read production-parent results for net benefit and previous-FIFO results for the incremental effect. Do not subtract percentages across independent campaigns.

## Results

'''+ '\n'.join(table) + f'''

Positive Improvement %=100*(before-after)/before. Times are medians of four attempt-level mean guest work times; ten samples of8,000,000 dynamic calls per selected leaf, per attempt. Physical order A1 B1 B2 A2 B3 A3 A4 B4. These are guest work seconds, not displayed FPS, host CPU time, frame time or suite wall time. Four attempts per label are not forty independent observations. A/A results describe variation, not optimization. No confidence bound, universal noise floor or outlier removal is claimed.

## Interpretation

{interpretation}

## What changed and exact inputs

Previous product `5679cce099eb777977e761245de47e77d05d0c05` shifts retained identities when deleting the oldest slot. Candidate `6aeb757c56c34c5a429702cf738157b5bf186745` adds owner-local circular head, advances it for oldest eviction/promotion, and maps lookup/deduplication/middle deletion through logical indices. A full eviction changes one physical payload, rather than eight; middle deletion still compacts its logical suffix. Eight-entry budget, logical FIFO, primary hits, full keys, generation validation, barriers and existing exclusive TB-storage lifetime remain unchanged. No observer counters/clocks, adaptive policy or bigger cache were added. The head uses existing padding on the tested 64-bit host only: CPUJumpCache 65,712 bytes, primary offset 16 / size 65,536, same as previous candidate.

Production baseline `76c23c7d444a6f12c9778bb2c35fab513f6c8056` SHA 5a3e3d8bc02abb602c1167ec19bff60afdbd072db791196f764cb34dad01c97b. Previous full candidate SHA 51cd99ef27b7212ba75029c489b31b36b44f732302cee27276c2c62756357c24. Circular candidate SHA 3afad0bc876dae0027b6e82268ef738fe6229795490a2c6b51fe2fa16c2482ad. Exact packages and frozen input manifests retained. Previous baseline/control binaries were never rebuilt or overwritten. Dispatch object text and relocations, plus epoch/invalidation helper instructions, match previous candidate. Fill/lookup instructions and linked layout intentionally differ. Fourteen dependency source sets and the pinned DSP archive match the previous build; copied package companions match byte for byte. GCC 14 / O2 i386-softmmu, no LTO.

Deck 10.0.0.123, SteamOS/AMD Custom APU 0405, Vulkan/RADV, 128 MiB; runner 0e05af4a240576638df4ed6611439273f6cdf584. Same reviewed source 19f252d ISO SHA 87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f, catalog sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012, arithmetic-suite revision a7cbe7d53b011dae8b9d7efd189cf62407fcd4414c72aabc27bdf0b5bc361171. Reference SHA db086d21eb0e600f30246c1a8bc129290dcce0f16f4308ead9765f35cd49876b independently derives recurrence/page hashes from test source; it reads no measured output and contains no framebuffer/timing golden. Explicit suite config SHA aa356a9d..., zero warmups, multiplier 1, per_iteration. Private HDD/EEPROM inputs and cold application/private Mesa disk caches; no waiver or global purge. OS page cache, driver memory cache and host power/CPU clock policy are not fully controlled. No PMU attribution claimed.

All24 attempts pass these four CPU contracts with complete evidence and qualified Mesa. All{count:,} indexed artifacts collected, zero exclusions; raw guest bytes match extraction SHA. Fifteen actual-helper checks also pass on Deck, with21artifacts collected. Source draft #54 retains the useful XISO fixtures/tools for later merge; its source/reference is unchanged in this campaign. Rendering, other159leaf contracts and physical Xbox are unqualified. The original failed five-leaf missing-oracle pilot remains visible in the earlier collision packet and was not retried/waived.

## Correctness and limitations

Fresh emulator build and 15 helper cases pass locally/natively, including unchanged full-key/invalidation/alias/10,000 delayed-publication/storage-reuse checks. Experiment checks: old full implementation fails the one-payload guard (observed 8); circular implementation passes (observed 1). Independent compact-list reference covers 20,000 deterministic operations (3,256 hits, 6,746 misses, 2,848 middle promotions, 4,461 full evictions). Both faulty oldest advance and middle shift mutations are rejected. Initial trace operation/group coupling allowed a mutation to escape; original output is retained, the selector was corrected, and visited-path assertions added. A mistaken failure-log text matcher was corrected without rerunning a native measurement. Dependency/setup preflight failures and build/restoration ordering are documented in setup-notes.md.

Read-only review found no Critical/Important issue and confirmed all head positions, wraparound, logical removals, aliases and nonzero-head clears. The rejected experimental header has an unqualified padding comment, a minor documentation finding; this report qualifies that claim to the tested host. No ring code is integrated. The independent behavioral trace is retained in source commit 8b5ed0c266709736157a7341198d081111b59b3d, with 14 local/native helper checks; full-eviction one-payload guard remains specific to the archived ring experiment. A complete changed-file check confirms current draft runtime source still equals product 5679cce. Helper tests do not qualify arbitrary concurrent storage reclamation, real VM remap/second-page translation, reset/load or SMC/code-cache exhaustion. Full unit rebuild previously fails in unchanged resampler missing math declarations; full suite success is not claimed. Retail, OpenGL, broader XISO and resource checks remain required for readiness. PGR2 needs300seconds in a verified reached scene.

## Evidence ownership

The current xemu PR #301 body contains the decision and quick comparison. EVIDENCE.zip retains maintained runner reports, all public measurements, raw guest results, run/input manifests, reviews, negative controls and orchestration. INDEX.json inventories collected lengths/SHA values. Private runtime/cache bytes and redundant diagnostics.zip are manifest-only. No firmware/EEPROM/private HDD bytes are published. Same-length resumed client files are not claimed to have been remotely rehashed; guest extraction SHA is independently checked. Results are stored with xemu, never in evidence-only runner or test-tool commits. No merge authorized.
'''
# Fix prose spacing without touching literal identifiers or measurements.
for a, b in [('about25%', 'about 25%'), ('cost56%', 'cost 56%'), ('of8,000,000', 'of 8,000,000'), ('All24', 'All 24'), ('All'+str(count), 'All '+str(count)), ('All'+f'{count:,}', 'All '+f'{count:,}'), ('with21artifacts', 'with 21 artifacts'), ('other159leaf', 'other 159 leaf'), ('needs300seconds', 'needs 300 seconds'), ('default64', 'default 64')]:
    report_text = report_text.replace(a, b)
(d / 'REPORT.md').write_text(report_text)

files = [f for f in n.rglob('*') if f.is_file()]
files += [f for f in (p / 'native-unit').rglob('*') if f.is_file()]
files += [f for f in (p / 'retained-trace/native').rglob('*') if f.is_file()]
files += [f for f in (p / 'retained-trace').rglob('*') if f.is_file() and f.suffix in ['.json', '.log', '.py', '.md', '.txt']]
files += [f for f in p.iterdir() if f.is_file() and f.suffix in ['.json', '.log', '.py', '.md', '.txt']]
index = []
with zipfile.ZipFile(d / 'EVIDENCE.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in sorted(set(files)):
        name = f.relative_to(p).as_posix()
        data = f.read_bytes()
        include = '/state/' not in name and not name.endswith('diagnostics.zip')
        index.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'publicBytesIncluded': include})
        if include:
            z.writestr(name, data)
(d / 'INDEX.json').write_text(json.dumps(index, indent=2) + '\n')
summary.update(decision='HOLD', ringIntegrated=False, candidateCommit='6aeb757c56c34c5a429702cf738157b5bf186745', retainedTraceCommit='8b5ed0c266709736157a7341198d081111b59b3d', unchangedCurrentRuntimeProduct='5679cce099eb777977e761245de47e77d05d0c05', attempts=24, collectedFiles=count, ringHelperCases=15, ringHelperFiles=21, retainedHelperCases=14, retainedHelperFiles=21, excluded=0, CPUCorrect=True, MesaQualified=True, renderingQualified=False, zipSha256=hashlib.sha256((d / 'EVIDENCE.zip').read_bytes()).hexdigest())
(d / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k not in labels}, indent=2))

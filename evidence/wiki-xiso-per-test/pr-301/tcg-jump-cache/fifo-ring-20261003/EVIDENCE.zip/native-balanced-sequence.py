"""Retained orchestration of maintained HTTP client comparisons; never rerun."""
import sys,json,subprocess,hashlib
from pathlib import Path
p=Path(__file__).parent;n=p/'native-balanced';client=Path('/home/codex/src/steamdeck-xemu/worktrees/runner-standalone-process');sys.path.insert(0,str(client/'scripts'))
from runner_transport import RunnerApi
from runner_xiso import follow,read_report,common_contract
from runner_workflows import Workflows
api=RunnerApi('http://10.0.0.123:9368');contract=json.loads((p/'BALANCED-CONTRACT.json').read_text())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def call(label,args):
 path=n/(label+'.json');assert not path.exists(),path
 r=subprocess.run(['python3',str(client/'scripts/runner_xiso.py'),'--url',api.url,*args],capture_output=True);path.write_bytes(r.stdout);(n/(label+'.stderr.log')).write_bytes(r.stderr);assert r.returncode==0,r.stdout.decode()+r.stderr.decode();return json.loads(r.stdout)
def idle():
 s=api.json('/api/v1/status');assert s['Phase']=='idle' and s['Queue']['Pending']==s['Queue']['Testing']==0,s
idle();info=api.json('/api/v1/agent?view=summary');save(n/'runner-discovery.json',info);assert contract['runnerCommit'] in json.dumps(info)
expected=None
for case,sel in contract['comparisons'].items():
 idle();cid=sel['campaign'];args=['select',sel['B'],'--reference',sel['A'],'--suite',contract['suite'],'--id',cid,'--configuration-source','suite','--mode','monolithic']
 for leaf in contract['selectedLeaves']:args+=['--test',leaf]
 call(case+'-selected',args);plan=call(case+'-plan',['plan',cid]);assert plan['isoSha256']=='87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f';assert set(plan['tests'])==set(contract['selectedLeaves']);assert plan['settings']==contract['settings'];assert [x['label'] for x in plan['attempts']]==['A1','B1','B2','A2','B3','A3','A4','B4'];c=common_contract(plan)
 if expected is None:expected=c
 else:assert c==expected,(c,expected)
 call(case+'-start',['start',cid]);print('Started '+cid+' physical ABBA then BAAB',flush=True)
 r=follow(api,cid,False);save(n/(case+'-sequence-wait.json'),r);assert r['terminal'];attempts=api.json('/api/v1/xiso-campaigns/'+cid+'/attempts');save(n/(case+'-attempts.json'),attempts);assert len(attempts['items'])==8 and attempts['nextOffset'] is None
 cache=[]
 for row in attempts['items']:
  collected=Workflows(api).collect(row['id'],n/(case+'-collected'),None,True);save(n/(case+'-'+row['label']+'-collection.json'),collected);b=n/(case+'-collected')/row['runId'];d=json.loads((b/'diagnostics/run-state/report.json').read_text());ex=json.loads((b/'guest/extraction.json').read_text());assert hashlib.sha256((b/'guest/results.txt').read_bytes()).hexdigest()==ex['sha256'];cache.append({k:d.get(k) for k in ['Status','DriverNamespaceVerified','DriverQualification','ComparisonReady','AllowUncontrolledDriverCache','Issues']});print(case,row['label'],row['correctness'],row['comparison'],'files',collected['fileCount'],'exclusions',collected['excluded'],flush=True)
 save(n/(case+'-cache-qualification.json'),cache)
 for fmt in ['json','markdown','csv']:
  result=read_report(api,cid,fmt);dest=n/(case+'-report.'+('md' if fmt=='markdown' else fmt));save(dest,result) if fmt=='json' else dest.write_text(result)
 report=json.loads((n/(case+'-report.json')).read_text());assert r['passed']==8 and r['failed']==r['incomplete']==0,r;assert all(x['correctness']=='passed' and x['comparison']=='eligible' for x in attempts['items']);assert all(x['DriverNamespaceVerified'] and x['ComparisonReady'] and not x['Issues'] and not x['AllowUncontrolledDriverCache'] for x in cache);assert report['indexedAttempts']==8 and not report['blockers'] and report['status'] in ['eligible','inconclusive'];rows=[x for x in report['rows'] if x['metric']=='mean_us'];assert len(rows)==4
 summary=[{'testId':x['testId'],'baselineSeconds':x['a']['median']/1e6,'candidateSeconds':x['b']['median']/1e6,'timeSavedSeconds':(x['a']['median']-x['b']['median'])/1e6,'improvementPercent':x['improvementPercent'],'abbaImprovementPercent':x['abbaImprovementPercent'],'baabImprovementPercent':x['baabImprovementPercent'],'aSamplesSeconds':[v/1e6 for v in x['aSamples']],'bSamplesSeconds':[v/1e6 for v in x['bSamples']]} for x in rows];save(n/(case+'-SUMMARY.json'),summary);print(json.dumps(summary),flush=True)
 print(case+' all eight qualified and collected',flush=True)
save(n/'SEQUENCE-COMPLETE.json',{'complete':True,'campaigns':list(contract['comparisons']),'attempts':24,'runner':contract['runnerCommit']})

## XISO campaign i167-ring-parent-20261003-001 — eligible

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 20 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 3 | 1 | +15.11% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 833684.00 | 553371.50 | +33.62% | +34.09% | +32.24% | max_us +34.12%, mean_us +33.97%, median_us +33.62%, min_us +33.94%, p95_us +34.12% |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 870151.75 | 624971.50 | +28.18% | +28.18% | +27.45% | max_us +26.17%, mean_us +27.48%, median_us +28.18%, min_us +27.05%, p95_us +26.17% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 891749.00 | 1188162.25 | -33.24% | -25.39% | -33.77% | max_us -33.34%, mean_us -33.24%, median_us -33.24%, min_us -34.67%, p95_us -33.34% |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 377169.50 | 369428.00 | +2.05% | +1.70% | +2.15% | max_us +1.58%, mean_us +2.08%, median_us +2.05%, min_us +1.79%, p95_us +1.58% |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

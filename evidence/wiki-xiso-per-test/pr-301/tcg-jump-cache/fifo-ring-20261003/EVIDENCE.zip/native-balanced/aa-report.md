## XISO campaign i167-ring-aa-20261003-001 — eligible

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 18 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 2 | 1 | +1.59% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 664935.00 | 549581.50 | +17.35% | +16.32% | +22.73% | max_us +21.28%, mean_us +15.94%, median_us +17.35%, min_us +6.00%, p95_us +21.28% |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 602174.75 | 600313.00 | +0.31% | +0.21% | +22.01% | max_us +20.98%, mean_us +7.27%, p95_us +20.98% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 1103873.75 | 1253229.75 | -13.53% | -13.64% | -6.08% | max_us -13.66%, mean_us -14.57%, median_us -13.53%, min_us -18.04%, p95_us -13.66% |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 377745.75 | 366875.50 | +2.88% | +4.16% | +2.70% | max_us +4.91%, mean_us +3.98%, median_us +2.88%, min_us +1.41%, p95_us +4.91% |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

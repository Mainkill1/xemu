## XISO campaign i167-ring-fifo-20261003-001 — inconclusive

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 14 metric rows. Opposite ABBA/BAAB outcomes: 7.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 1 | 2 | -0.66% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 549345.75 | 546274.50 | +0.56% | -1.18% | +2.80% | min_us +1.02% (orders disagree) |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 599611.00 | 628072.00 | -4.75% | -5.29% | -3.41% | max_us -4.83%, mean_us -4.09%, median_us -4.75%, min_us -4.23%, p95_us -4.83% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 1244451.25 | 1211957.50 | +2.61% | +2.28% | -4.30% | max_us +2.02%, mean_us +2.62%, median_us +2.61%, min_us +2.66%, p95_us +2.02% (orders disagree) |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 367060.25 | 373935.25 | -1.87% | -3.37% | +0.71% | mean_us -2.00%, median_us -1.87%, min_us -1.30% (orders disagree) |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

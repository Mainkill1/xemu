
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-on/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040c550 <cpu_exec_step_atomic>:
  40c550:	push   %r15
  40c552:	xor    %esi,%esi
  40c554:	push   %r14
  40c556:	push   %r13
  40c558:	push   %r12
  40c55a:	push   %rbp
  40c55b:	push   %rbx
  40c55c:	sub    $0x98,%rsp
  40c563:	mov    %rdi,(%rsp)
  40c567:	add    $0xf0,%rdi
  40c56e:	movl   $0x0,0x2c(%rsp)
  40c576:	call   1d7ed0 <__sigsetjmp@plt>
  40c57b:	test   %eax,%eax
  40c57d:	jne    40c740 <cpu_exec_step_atomic+0x1f0>
  40c583:	call   24a650 <start_exclusive>
  40c588:	mov    $0xfffffffffffff938,%rax
  40c58f:	mov    (%rsp),%rcx
  40c593:	cmp    %rcx,%fs:(%rax)
  40c597:	jne    40c848 <cpu_exec_step_atomic+0x2f8>
  40c59d:	mov    (%rsp),%rbx
  40c5a1:	cmpb   $0x0,0xb4(%rbx)
  40c5a8:	mov    %rbx,%rsi
  40c5ab:	jne    40c903 <cpu_exec_step_atomic+0x3b3>
  40c5b1:	mov    0x98(%rbx),%rax
  40c5b8:	movb   $0x1,0xb4(%rbx)
  40c5bf:	lea    0x30(%rsp),%rdi
  40c5c4:	mov    0x150(%rax),%rax
  40c5cb:	call   *0x18(%rax)
  40c5ce:	mov    %rbx,%rsi
  40c5d1:	mov    0x2c8(%rbx),%ebx
  40c5d7:	mov    0xd4(%rsi),%esi
  40c5dd:	test   %esi,%esi
  40c5df:	jne    40c870 <cpu_exec_step_atomic+0x320>
  40c5e5:	movzbl 0x1321ce0(%rip),%eax        # 172e2cc <one_insn_per_tb>
  40c5ec:	test   %al,%al
  40c5ee:	je     40c750 <cpu_exec_step_atomic+0x200>
  40c5f4:	or     $0x201,%ebx
  40c5fa:	mov    0x30(%rsp),%r13
  40c5ff:	mov    0x12d653f(%rip),%eax        # 16e2b44 <target_page+0x4>
  40c605:	and    $0x7f,%bh
  40c608:	or     $0x601,%ebx
  40c60e:	mov    0x38(%rsp),%edx
  40c612:	mov    0x40(%rsp),%r15
  40c617:	lea    -0x6(%rax),%ecx
  40c61a:	mov    %r13,%rax
  40c61d:	mov    %ebx,0x3c(%rsp)
  40c621:	shr    %cl,%rax
  40c624:	xor    %r13,%rax
  40c627:	mov    %rax,%r12
  40c62a:	and    $0x3f,%eax
  40c62d:	shr    %cl,%r12
  40c630:	and    $0xfc0,%r12d
  40c637:	or     %eax,%r12d
  40c63a:	mov    (%rsp),%rax
  40c63e:	mov    0x218(%rax),%r14
  40c645:	lea    0x1(%r12),%eax
  40c64a:	shl    $0x4,%rax
  40c64e:	add    %r14,%rax
  40c651:	mov    (%rax),%rbp
  40c654:	test   %rbp,%rbp
  40c657:	je     40c768 <cpu_exec_step_atomic+0x218>
  40c65d:	mov    %r12d,%eax
  40c660:	shl    $0x4,%rax
  40c664:	cmp    0x18(%rax,%r14,1),%r13
  40c669:	jne    40c768 <cpu_exec_step_atomic+0x218>
  40c66f:	cmp    0x8(%rbp),%r15
  40c673:	jne    40c768 <cpu_exec_step_atomic+0x218>
  40c679:	cmp    0x10(%rbp),%edx
  40c67c:	jne    40c768 <cpu_exec_step_atomic+0x218>
  40c682:	mov    0x14(%rbp),%eax
  40c685:	cmp    %eax,%ebx
  40c687:	jne    40c768 <cpu_exec_step_atomic+0x218>
  40c68d:	mov    0x14(%rbp),%eax
  40c690:	test   $0x20000,%eax
  40c695:	jne    40c6a1 <cpu_exec_step_atomic+0x151>
  40c697:	cmp    0x0(%rbp),%r13
  40c69b:	jne    1e84cf <cpu_exec_step_atomic.cold>
  40c6a1:	mov    (%rsp),%rax
  40c6a5:	mov    0x98(%rax),%rax
  40c6ac:	mov    0x150(%rax),%rax
  40c6b3:	mov    0x30(%rax),%rax
  40c6b7:	test   %rax,%rax
  40c6ba:	je     40c6c2 <cpu_exec_step_atomic+0x172>
  40c6bc:	mov    (%rsp),%rdi
  40c6c0:	call   *%rax
  40c6c2:	mov    0x133c880(%rip),%ecx        # 1748f48 <trace_events_enabled_count>
  40c6c8:	test   %ecx,%ecx
  40c6ca:	jne    40c880 <cpu_exec_step_atomic+0x330>
  40c6d0:	mov    (%rsp),%rbx
  40c6d4:	lea    0x2c(%rsp),%rdx
  40c6d9:	mov    %rbp,%rsi
  40c6dc:	mov    %rbx,%rdi
  40c6df:	call   40b720 <cpu_tb_exec>
  40c6e4:	mov    0x98(%rbx),%rax
  40c6eb:	mov    0x150(%rax),%rax
  40c6f2:	mov    0x38(%rax),%rax
  40c6f6:	test   %rax,%rax
  40c6f9:	je     40c701 <cpu_exec_step_atomic+0x1b1>
  40c6fb:	mov    (%rsp),%rdi
  40c6ff:	call   *%rax
  40c701:	mov    (%rsp),%rax
  40c705:	mov    0xc8(%rax),%edx
  40c70b:	test   %edx,%edx
  40c70d:	je     40c8e2 <cpu_exec_step_atomic+0x392>
  40c713:	movb   $0x0,0xb4(%rax)
  40c71a:	call   24a810 <end_exclusive>
  40c71f:	add    $0x98,%rsp
  40c726:	pop    %rbx
  40c727:	pop    %rbp
  40c728:	pop    %r12
  40c72a:	pop    %r13
  40c72c:	pop    %r14
  40c72e:	pop    %r15
  40c730:	xor    %eax,%eax
  40c732:	xor    %edx,%edx
  40c734:	xor    %ecx,%ecx
  40c736:	xor    %esi,%esi
  40c738:	xor    %edi,%edi
  40c73a:	xor    %r8d,%r8d
  40c73d:	ret
  40c73e:	xchg   %ax,%ax
  40c740:	mov    (%rsp),%rdi
  40c744:	call   40b580 <cpu_exec_longjmp_cleanup>
  40c749:	jmp    40c701 <cpu_exec_step_atomic+0x1b1>
  40c74b:	nopl   0x0(%rax,%rax,1)
  40c750:	mov    %ebx,%eax
  40c752:	or     $0x2,%ah
  40c755:	testb  $0x20,0x133c485(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c75c:	cmovne %eax,%ebx
  40c75f:	jmp    40c5fa <cpu_exec_step_atomic+0xaa>
  40c764:	nopl   0x0(%rax)
  40c768:	mov    %r14,%rdi
  40c76b:	mov    %edx,0x14(%rsp)
  40c76f:	call   41be00 <tcg_victim_cache_epoch>
  40c774:	mov    0x14(%rsp),%edx
  40c778:	movd   %ebx,%xmm2
  40c77c:	mov    %r12d,%esi
  40c77f:	mov    %rax,0x18(%rsp)
  40c784:	sub    $0x20,%rsp
  40c788:	mov    %r14,%rdi
  40c78b:	movd   %edx,%xmm0
  40c78f:	mov    %r13,0x70(%rsp)
  40c794:	mov    %rax,%rdx
  40c797:	punpckldq %xmm2,%xmm0
  40c79b:	mov    %r15,0x80(%rsp)
  40c7a3:	movq   %xmm0,0x78(%rsp)
  40c7a9:	movq   %xmm0,0x28(%rsp)
  40c7af:	movdqa 0x70(%rsp),%xmm1
  40c7b5:	mov    %r15,0x10(%rsp)
  40c7ba:	movups %xmm1,(%rsp)
  40c7be:	call   41c070 <tcg_victim_cache_lookup>
  40c7c3:	add    $0x20,%rsp
  40c7c7:	movq   0x8(%rsp),%xmm0
  40c7cd:	test   %rax,%rax
  40c7d0:	mov    %rax,%rbp
  40c7d3:	jne    40c68d <cpu_exec_step_atomic+0x13d>
  40c7d9:	mov    %r13,0x70(%rsp)
  40c7de:	sub    $0x20,%rsp
  40c7e2:	lea    -0x18a9(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40c7e9:	lea    0x1321af0(%rip),%rsi        # 172e2e0 <tb_ctx>
  40c7f0:	movq   %xmm0,0x98(%rsp)
  40c7f9:	mov    %r15,0xa0(%rsp)
  40c801:	mov    0x20(%rsp),%rdi
  40c806:	movdqa 0x90(%rsp),%xmm0
  40c80f:	mov    %r15,0x10(%rsp)
  40c814:	movups %xmm0,(%rsp)
  40c818:	call   40b0e0 <tb_htable_lookup_common>
  40c81d:	add    $0x20,%rsp
  40c821:	mov    %rax,%rbp
  40c824:	test   %rax,%rax
  40c827:	je     40c8b4 <cpu_exec_step_atomic+0x364>
  40c82d:	mov    0x18(%rsp),%r8
  40c832:	mov    %rax,%rcx
  40c835:	mov    %r13,%rdx
  40c838:	mov    %r12d,%esi
  40c83b:	mov    %r14,%rdi
  40c83e:	call   41be40 <tcg_victim_cache_fill>
  40c843:	jmp    40c68d <cpu_exec_step_atomic+0x13d>
  40c848:	lea    0xc4bf14(%rip),%r8        # 1058763 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e23>
  40c84f:	lea    0xdd819a(%rip),%rcx        # 11e49f0 <__func__.10>
  40c856:	mov    $0x26e,%edx
  40c85b:	xor    %edi,%edi
  40c85d:	lea    0xc4bee7(%rip),%rsi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c864:	call   1d54e0 <g_assertion_message_expr@plt>
  40c869:	nopl   0x0(%rax)
  40c870:	or     $0xe01,%ebx
  40c876:	jmp    40c5fa <cpu_exec_step_atomic+0xaa>
  40c87b:	nopl   0x0(%rax,%rax,1)
  40c880:	cmpw   $0x0,0x133b98e(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40c888:	je     40c6d0 <cpu_exec_step_atomic+0x180>
  40c88e:	testb  $0x80,0x133c34c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c895:	je     40c6d0 <cpu_exec_step_atomic+0x180>
  40c89b:	mov    %r13,%rdx
  40c89e:	mov    %rbp,%rsi
  40c8a1:	lea    0xc4bf01(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40c8a8:	xor    %eax,%eax
  40c8aa:	call   66e8b0 <qemu_log>
  40c8af:	jmp    40c6d0 <cpu_exec_step_atomic+0x180>
  40c8b4:	sub    $0x20,%rsp
  40c8b8:	movdqa 0x50(%rsp),%xmm0
  40c8be:	mov    0x60(%rsp),%rax
  40c8c3:	mov    0x20(%rsp),%rdi
  40c8c8:	mov    %rax,0x10(%rsp)
  40c8cd:	movups %xmm0,(%rsp)
  40c8d1:	call   41a3c0 <tb_gen_code>
  40c8d6:	add    $0x20,%rsp
  40c8da:	mov    %rax,%rbp
  40c8dd:	jmp    40c6a1 <cpu_exec_step_atomic+0x151>
  40c8e2:	lea    0xc4bf19(%rip),%r8        # 1058802 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13ec2>
  40c8e9:	lea    0xdd8100(%rip),%rcx        # 11e49f0 <__func__.10>
  40c8f0:	mov    $0x295,%edx
  40c8f5:	xor    %edi,%edi
  40c8f7:	lea    0xc4be4d(%rip),%rsi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c8fe:	call   1d54e0 <g_assertion_message_expr@plt>
  40c903:	lea    0xc4beea(%rip),%r8        # 10587f4 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13eb4>
  40c90a:	lea    0xdd80df(%rip),%rcx        # 11e49f0 <__func__.10>
  40c911:	mov    $0x26f,%edx
  40c916:	xor    %edi,%edi
  40c918:	lea    0xc4be2c(%rip),%rsi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c91f:	call   1d54e0 <g_assertion_message_expr@plt>

Disassembly of section .fini:


/home/codex/src/steamdeck-xemu/worktrees/issue167-parent-76c23c7d/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000041aef0 <tcg_flush_jmp_cache>:
  41aef0:	mov    0x218(%rdi),%rdx
  41aef7:	test   %rdx,%rdx
  41aefa:	je     41af28 <tcg_flush_jmp_cache+0x38>
  41aefc:	lea    0x10(%rdx),%rax
  41af00:	add    $0x10010,%rdx
  41af07:	nopw   0x0(%rax,%rax,1)
  41af10:	movq   $0x0,(%rax)
  41af17:	add    $0x20,%rax
  41af1b:	movq   $0x0,-0x10(%rax)
  41af23:	cmp    %rdx,%rax
  41af26:	jne    41af10 <tcg_flush_jmp_cache+0x20>
  41af28:	xor    %eax,%eax
  41af2a:	xor    %edx,%edx
  41af2c:	xor    %edi,%edi
  41af2e:	ret

Disassembly of section .fini:

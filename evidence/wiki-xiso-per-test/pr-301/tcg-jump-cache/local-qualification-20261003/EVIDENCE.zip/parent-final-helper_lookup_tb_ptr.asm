
/home/codex/src/steamdeck-xemu/worktrees/issue167-parent-76c23c7d/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040c2e0 <helper_lookup_tb_ptr>:
  40c2e0:	push   %rbp
  40c2e1:	lea    -0x4b60(%rdi),%rbp
  40c2e8:	push   %rbx
  40c2e9:	mov    %rdi,%rbx
  40c2ec:	mov    %rbp,%rsi
  40c2ef:	sub    $0x28,%rsp
  40c2f3:	mov    -0x4ac8(%rbx),%rax
  40c2fa:	mov    %rsp,%rdi
  40c2fd:	mov    0x150(%rax),%rax
  40c304:	call   *0x18(%rax)
  40c307:	mov    -0x4a8c(%rbx),%edx
  40c30d:	mov    -0x4898(%rbx),%eax
  40c313:	test   %edx,%edx
  40c315:	jne    40c370 <helper_lookup_tb_ptr+0x90>
  40c317:	movzbl 0x1321fae(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40c31e:	test   %dl,%dl
  40c320:	jne    40c368 <helper_lookup_tb_ptr+0x88>
  40c322:	mov    %eax,%edx
  40c324:	or     $0x2,%dh
  40c327:	testb  $0x20,0x133c8b3(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c32e:	cmovne %edx,%eax
  40c331:	mov    %eax,0xc(%rsp)
  40c335:	sub    $0x20,%rsp
  40c339:	mov    %rbp,%rdi
  40c33c:	movdqa 0x20(%rsp),%xmm0
  40c342:	mov    0x30(%rsp),%rax
  40c347:	movups %xmm0,(%rsp)
  40c34b:	mov    %rax,0x10(%rsp)
  40c350:	call   40c0f0 <lookup_tb_ptr_common>
  40c355:	add    $0x48,%rsp
  40c359:	pop    %rbx
  40c35a:	pop    %rbp
  40c35b:	xor    %edx,%edx
  40c35d:	xor    %esi,%esi
  40c35f:	xor    %edi,%edi
  40c361:	ret
  40c362:	nopw   0x0(%rax,%rax,1)
  40c368:	or     $0x201,%eax
  40c36d:	jmp    40c331 <helper_lookup_tb_ptr+0x51>
  40c36f:	nop
  40c370:	or     $0xe01,%eax
  40c375:	jmp    40c331 <helper_lookup_tb_ptr+0x51>

Disassembly of section .fini:

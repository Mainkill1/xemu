
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-on/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000041b0d0 <tcg_flush_jmp_cache>:
  41b0d0:	push   %rbx
  41b0d1:	mov    0x218(%rdi),%rbx
  41b0d8:	test   %rbx,%rbx
  41b0db:	je     41b111 <tcg_flush_jmp_cache+0x41>
  41b0dd:	mov    %rbx,%rdi
  41b0e0:	call   41bdc0 <tcg_victim_cache_invalidate_begin>
  41b0e5:	lea    0x10(%rbx),%rax
  41b0e9:	lea    0x10010(%rbx),%rdx
  41b0f0:	movq   $0x0,(%rax)
  41b0f7:	add    $0x20,%rax
  41b0fb:	movq   $0x0,-0x10(%rax)
  41b103:	cmp    %rdx,%rax
  41b106:	jne    41b0f0 <tcg_flush_jmp_cache+0x20>
  41b108:	mov    %rbx,%rdi
  41b10b:	pop    %rbx
  41b10c:	jmp    41bde0 <tcg_victim_cache_invalidate_end>
  41b111:	pop    %rbx
  41b112:	xor    %eax,%eax
  41b114:	xor    %edx,%edx
  41b116:	xor    %edi,%edi
  41b118:	ret

Disassembly of section .fini:

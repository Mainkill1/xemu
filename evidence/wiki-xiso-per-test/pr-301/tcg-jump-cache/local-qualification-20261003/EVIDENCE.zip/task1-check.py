import subprocess,json
from pathlib import Path
r=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8');out=Path(__file__).parent
for b in ['build-off','build-on']:
 subprocess.run(['ninja','-C',b,'qemu-system-i386','tests/unit/test-tcg-victim-cache'],cwd=r,check=True)
 p=subprocess.run([str(r/b/'tests/unit/test-tcg-victim-cache'),'--tap'],capture_output=True,text=True,check=True)
 (out/(b+'-task1.tap')).write_text(p.stdout+p.stderr)
 assert '1..13' in p.stdout and sum(x.startswith('ok ') for x in p.stdout.splitlines())==13
 subprocess.run(['python3',str(out/'check-code-shape.py')],check=True,stdout=subprocess.DEVNULL)
mut=json.loads((out/'mutations-v2/SUMMARY.json').read_text());assert len(mut)==4 and all(x['returncode']==-6 and x['expectedAssertionFailed'] for x in mut)
print('Both emulator builds and 13 helper cases per build pass; four retained negative mutations reject; layout/code-shape evidence verified. Full unit gate remains failed on unchanged resampler math.h; native/VM qualification pending.')

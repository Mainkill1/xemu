
/home/codex/src/steamdeck-xemu/worktrees/issue167-parent-76c23c7d/build/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040c380 <helper_lookup_tb_ptr_i32>:
  40c380:	sub    $0x28,%rsp
  40c384:	add    %edx,%esi
  40c386:	mov    %ecx,%eax
  40c388:	mov    %rsi,(%rsp)
  40c38c:	mov    -0x4a8c(%rdi),%esi
  40c392:	lea    -0x4b60(%rdi),%rcx
  40c399:	mov    %eax,0x8(%rsp)
  40c39d:	mov    -0x4898(%rdi),%eax
  40c3a3:	test   %esi,%esi
  40c3a5:	jne    40c400 <helper_lookup_tb_ptr_i32+0x80>
  40c3a7:	movzbl 0x1321f1e(%rip),%esi        # 172e2cc <one_insn_per_tb>
  40c3ae:	test   %sil,%sil
  40c3b1:	jne    40c3f0 <helper_lookup_tb_ptr_i32+0x70>
  40c3b3:	mov    %eax,%esi
  40c3b5:	or     $0x200,%esi
  40c3bb:	testb  $0x20,0x133c81f(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c3c2:	cmovne %esi,%eax
  40c3c5:	mov    %eax,0xc(%rsp)
  40c3c9:	sub    $0x20,%rsp
  40c3cd:	mov    %rcx,%rdi
  40c3d0:	movdqa 0x20(%rsp),%xmm0
  40c3d6:	mov    %rdx,0x10(%rsp)
  40c3db:	movups %xmm0,(%rsp)
  40c3df:	call   40c0f0 <lookup_tb_ptr_common>
  40c3e4:	add    $0x48,%rsp
  40c3e8:	ret
  40c3e9:	nopl   0x0(%rax)
  40c3f0:	or     $0x201,%eax
  40c3f5:	jmp    40c3c5 <helper_lookup_tb_ptr_i32+0x45>
  40c3f7:	nopw   0x0(%rax,%rax,1)
  40c400:	or     $0xe01,%eax
  40c405:	jmp    40c3c5 <helper_lookup_tb_ptr_i32+0x45>

Disassembly of section .fini:

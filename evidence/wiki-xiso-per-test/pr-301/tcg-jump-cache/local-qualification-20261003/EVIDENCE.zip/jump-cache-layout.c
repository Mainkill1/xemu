#include "qemu/osdep.h"
#include "accel/tcg/tb-jmp-cache.h"
char layout_total[sizeof(CPUJumpCache)];
char layout_primary_offset[offsetof(CPUJumpCache, array)];
char layout_primary_bytes[sizeof(((CPUJumpCache *)0)->array)];

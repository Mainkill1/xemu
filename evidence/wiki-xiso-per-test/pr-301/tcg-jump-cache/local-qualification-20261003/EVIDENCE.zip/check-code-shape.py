"""Compare matched parent and candidate layout/dispatch without executing games."""
import subprocess,re,json,shlex,difflib
from pathlib import Path
root=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8')
out=Path(__file__).parent
bins={'parent':root.parent/'issue167-parent-76c23c7d/build/qemu-system-i386','disabled':root/'build-off/qemu-system-i386','enabled':root/'build-on/qemu-system-i386'}
symbols=['cpu_exec_loop','cpu_exec_step_atomic','helper_lookup_tb_ptr','helper_lookup_tb_ptr_i32','tcg_flush_jmp_cache']
allrows={};layout={};shape={}
src=out/'jump-cache-layout.c';src.write_text('#include "qemu/osdep.h"\n#include "accel/tcg/tb-jmp-cache.h"\nchar layout_total[sizeof(CPUJumpCache)];\nchar layout_primary_offset[offsetof(CPUJumpCache, array)];\nchar layout_primary_bytes[sizeof(((CPUJumpCache *)0)->array)];\n')
for name,binary in bins.items():
 build=binary.parent
 entries=json.loads((build/'compile_commands.json').read_text())
 entry=next(x for x in entries if x['file'].endswith('/cpu-exec.c') and '-Ilibsystem.a.p' in x['command'])
 cmd=shlex.split(entry['command']);obj=out/(name+'-layout.o')
 for flag,value in [('-o',str(obj)),('-c',str(src)),('-MF',str(out/(name+'-layout.d'))),('-MQ',str(obj))]:
  if flag in cmd:cmd[cmd.index(flag)+1]=value
 cmd+=['-I'+str(build.parent/'accel/tcg')];subprocess.run(cmd,cwd=build,check=True)
 nm=subprocess.check_output(['nm','-S',str(obj)],text=True)
 layout[name]={x.split()[-1]:int(x.split()[1],16) for x in nm.splitlines() if 'layout_' in x}
 nm=subprocess.check_output(['nm','-S',str(binary)],text=True)
 selected='\n'.join(x for x in nm.splitlines() if any(' '+s==x[-len(s)-1:] for s in symbols+['tb_lookup']) or 'tcg_victim_cache' in x)+'\n'
 (out/(name+'-final-dispatch-symbols.txt')).write_text(selected)
 assert not any(x.split()[-1]=='tb_lookup' for x in nm.splitlines())
 if name=='disabled':assert 'tcg_victim_cache' not in nm
 allrows[name]={}
 for sym in symbols:
  asm=subprocess.check_output(['objdump','-d','--no-show-raw-insn','--disassemble='+sym,str(binary)],text=True)
  (out/(name+'-final-'+sym+'.asm')).write_text(asm)
  rows=[]
  for x in asm.splitlines():
   if not re.match(r'^\s*[0-9a-f]+:\s',x):continue
   x=re.sub(r'^\s*[0-9a-f]+:\s*','',x)
   # Resolve linked addresses through their symbolic names, preserving offsets.
   x=re.sub(r'\b[0-9a-f]+ <([^>]+)>',r'<\1>',x)
   x=re.sub(r'-?0x[0-9a-f]+\(%rip\)',r'SYMBOL(%rip)',x)
   rows.append(x)
  allrows[name][sym]=rows
for sym in symbols:
 a,b=allrows['parent'][sym],allrows['disabled'][sym]
 d='\n'.join(difflib.unified_diff(a,b,fromfile='parent',tofile='default-off'))
 (out/('final-disabled-'+sym+'.diff')).write_text(d+'\n')
 shape[sym]={'parentInstructions':len(a),'defaultOffInstructions':len(b),'normalizedInstructionsEqual':a==b,'differenceLines':len(d.splitlines())}
assert layout['parent']==layout['disabled']
assert layout['enabled']['layout_total']-layout['parent']['layout_total']==160
assert len({x['layout_primary_offset'] for x in layout.values()})==1
assert len({x['layout_primary_bytes'] for x in layout.values()})==1
(out/'jump-cache-layout.json').write_text(json.dumps(layout,indent=2)+'\n')
(out/'final-disabled-assembly-parity.json').write_text(json.dumps(shape,indent=2)+'\n')
print(json.dumps({'layout':layout,'shape':shape},indent=2))

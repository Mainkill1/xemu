
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-on/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040c4c0 <helper_lookup_tb_ptr_i32>:
  40c4c0:	sub    $0x28,%rsp
  40c4c4:	add    %edx,%esi
  40c4c6:	mov    %ecx,%eax
  40c4c8:	mov    %rsi,(%rsp)
  40c4cc:	mov    -0x4a8c(%rdi),%esi
  40c4d2:	lea    -0x4b60(%rdi),%rcx
  40c4d9:	mov    %eax,0x8(%rsp)
  40c4dd:	mov    -0x4898(%rdi),%eax
  40c4e3:	test   %esi,%esi
  40c4e5:	jne    40c540 <helper_lookup_tb_ptr_i32+0x80>
  40c4e7:	movzbl 0x1321dde(%rip),%esi        # 172e2cc <one_insn_per_tb>
  40c4ee:	test   %sil,%sil
  40c4f1:	jne    40c530 <helper_lookup_tb_ptr_i32+0x70>
  40c4f3:	mov    %eax,%esi
  40c4f5:	or     $0x200,%esi
  40c4fb:	testb  $0x20,0x133c6df(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c502:	cmovne %esi,%eax
  40c505:	mov    %eax,0xc(%rsp)
  40c509:	sub    $0x20,%rsp
  40c50d:	mov    %rcx,%rdi
  40c510:	movdqa 0x20(%rsp),%xmm0
  40c516:	mov    %rdx,0x10(%rsp)
  40c51b:	movups %xmm0,(%rsp)
  40c51f:	call   40b360 <lookup_tb_ptr_common>
  40c524:	add    $0x48,%rsp
  40c528:	ret
  40c529:	nopl   0x0(%rax)
  40c530:	or     $0x201,%eax
  40c535:	jmp    40c505 <helper_lookup_tb_ptr_i32+0x45>
  40c537:	nopw   0x0(%rax,%rax,1)
  40c540:	or     $0xe01,%eax
  40c545:	jmp    40c505 <helper_lookup_tb_ptr_i32+0x45>

Disassembly of section .fini:

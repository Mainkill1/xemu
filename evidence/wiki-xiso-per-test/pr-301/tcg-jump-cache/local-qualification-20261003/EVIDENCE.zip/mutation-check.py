"""Compile controlled cache safety mutations; never edit production checkout.

Usage: python mutation-check.py --worktree PATH --build build-off --out PATH
Requires the retained production unit target to have been built with Meson.
"""
import argparse
import json
from pathlib import Path
import resource
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--worktree', type=Path, required=True)
parser.add_argument('--build', default='build-off')
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
root = args.worktree.resolve()
build = root / args.build
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
source = (root / 'accel/tcg/tb-victim-cache.c').read_text()
entries = json.loads((build / 'compile_commands.json').read_text())
entry = next(x for x in entries if 'test-tcg-victim-cache.p' in x['command']
             and x['file'].endswith('/tb-victim-cache.c'))
compile_command = shlex.split(entry['command'])
original_object = compile_command[compile_command.index('-o') + 1]
commands = subprocess.check_output(
    ['ninja', '-t', 'commands', 'tests/unit/test-tcg-victim-cache'], cwd=build, text=True)
link_command = shlex.split(commands.splitlines()[-1])
assert original_object in link_command

mutations = [
    ('ignore-cflags', 'tb_cflags(tb) == state.cflags', 'true',
     '/tcg/victim8/complete-key'),
    ('retain-old-generation', 'jc->victim.count = 0;', '/* discarded reset */',
     '/tcg/victim8/full-clear'),
    ('ignore-active-invalidator', 'qatomic_read(&jc->victim.invalidators) == 0', 'true',
     '/tcg/victim8/overlapping-invalidators'),
    ('allow-late-publication', 'if (!epoch_valid(jc, epoch))', 'if (false)',
     '/tcg/victim8/delayed-publication-10000'),
]
results = []
for name, old, replacement, test in mutations:
    assert old in source, name
    mutant = out / (name + '.c')
    mutant.write_text(source.replace(old, replacement, 1))
    obj = out / (name + '.o')
    binary = out / name
    command = compile_command.copy()
    command[command.index('-o') + 1] = str(obj)
    command[command.index('-c') + 1] = str(mutant)
    for flag, value in [('-MF', str(out / (name + '.d'))), ('-MQ', str(obj))]:
        if flag in command:
            command[command.index(flag) + 1] = value
    command += ['-I' + str(root / 'accel/tcg')]
    with (out / (name + '-build.log')).open('w') as log:
        subprocess.run(command, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)
        command = link_command.copy()
        command[command.index('-o') + 1] = str(binary)
        command[command.index(original_object)] = str(obj)
        subprocess.run(command, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)
    run = subprocess.run([str(binary), '--tap', '-p', test], capture_output=True, text=True)
    (out / (name + '-red.log')).write_text(run.stdout + run.stderr)
    assert run.returncode != 0 and 'ERROR:' in run.stdout + run.stderr and 'Bail out!' in run.stdout, name
    results.append({'mutation': name, 'test': test, 'returncode': run.returncode,
                    'expectedAssertionFailed': True})
    print(name + ': real retained test rejects the mutation', flush=True)
(out / 'SUMMARY.json').write_text(json.dumps(results, indent=2) + '\n')


/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-on/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040c420 <helper_lookup_tb_ptr>:
  40c420:	push   %rbp
  40c421:	lea    -0x4b60(%rdi),%rbp
  40c428:	push   %rbx
  40c429:	mov    %rdi,%rbx
  40c42c:	mov    %rbp,%rsi
  40c42f:	sub    $0x28,%rsp
  40c433:	mov    -0x4ac8(%rbx),%rax
  40c43a:	mov    %rsp,%rdi
  40c43d:	mov    0x150(%rax),%rax
  40c444:	call   *0x18(%rax)
  40c447:	mov    -0x4a8c(%rbx),%edx
  40c44d:	mov    -0x4898(%rbx),%eax
  40c453:	test   %edx,%edx
  40c455:	jne    40c4b0 <helper_lookup_tb_ptr+0x90>
  40c457:	movzbl 0x1321e6e(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40c45e:	test   %dl,%dl
  40c460:	jne    40c4a8 <helper_lookup_tb_ptr+0x88>
  40c462:	mov    %eax,%edx
  40c464:	or     $0x2,%dh
  40c467:	testb  $0x20,0x133c773(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c46e:	cmovne %edx,%eax
  40c471:	mov    %eax,0xc(%rsp)
  40c475:	sub    $0x20,%rsp
  40c479:	mov    %rbp,%rdi
  40c47c:	movdqa 0x20(%rsp),%xmm0
  40c482:	mov    0x30(%rsp),%rax
  40c487:	movups %xmm0,(%rsp)
  40c48b:	mov    %rax,0x10(%rsp)
  40c490:	call   40b360 <lookup_tb_ptr_common>
  40c495:	add    $0x48,%rsp
  40c499:	pop    %rbx
  40c49a:	pop    %rbp
  40c49b:	xor    %edx,%edx
  40c49d:	xor    %esi,%esi
  40c49f:	xor    %edi,%edi
  40c4a1:	ret
  40c4a2:	nopw   0x0(%rax,%rax,1)
  40c4a8:	or     $0x201,%eax
  40c4ad:	jmp    40c471 <helper_lookup_tb_ptr+0x51>
  40c4af:	nop
  40c4b0:	or     $0xe01,%eax
  40c4b5:	jmp    40c471 <helper_lookup_tb_ptr+0x51>

Disassembly of section .fini:

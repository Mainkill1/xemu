
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-off/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040b720 <cpu_exec_loop>:
  40b720:	push   %r15
  40b722:	mov    %rsi,%r15
  40b725:	push   %r14
  40b727:	push   %r13
  40b729:	push   %r12
  40b72b:	push   %rbp
  40b72c:	push   %rbx
  40b72d:	mov    %rdi,%rbx
  40b730:	sub    $0x88,%rsp
  40b737:	mov    0x2d0(%rdi),%ebp
  40b73d:	test   %ebp,%ebp
  40b73f:	jns    40be4e <cpu_exec_loop+0x72e>
  40b745:	data16 cs nopw 0x0(%rax,%rax,1)
  40b750:	call   3d11d0 <replay_has_exception>
  40b755:	test   %al,%al
  40b757:	je     40b770 <cpu_exec_loop+0x50>
  40b759:	movzwl 0x4b50(%rbx),%eax
  40b760:	add    0xe0(%rbx),%rax
  40b767:	je     40bfd7 <cpu_exec_loop+0x8b7>
  40b76d:	nopl   (%rax)
  40b770:	mov    0xcc(%rbx),%eax
  40b776:	movl   $0x0,0x2c(%rsp)
  40b77e:	xor    %r13d,%r13d
  40b781:	data16 cs nopw 0x0(%rax,%rax,1)
  40b78c:	nopl   0x0(%rax)
  40b790:	cmp    $0xffffffff,%eax
  40b793:	je     40b7a0 <cpu_exec_loop+0x80>
  40b795:	test   $0x10000,%eax
  40b79a:	jne    40b840 <cpu_exec_loop+0x120>
  40b7a0:	xor    %eax,%eax
  40b7a2:	xchg   %ax,0x4b52(%rbx)
  40b7a9:	mov    0xd0(%rbx),%eax
  40b7af:	test   %eax,%eax
  40b7b1:	jne    40bd60 <cpu_exec_loop+0x640>
  40b7b7:	movzbl 0xc7(%rbx),%eax
  40b7be:	test   %al,%al
  40b7c0:	jne    40b7ec <cpu_exec_loop+0xcc>
  40b7c2:	mov    0x1322bb0(%rip),%ecx        # 172e378 <use_icount>
  40b7c8:	test   %ecx,%ecx
  40b7ca:	je     40b840 <cpu_exec_loop+0x120>
  40b7cc:	mov    0xcc(%rbx),%eax
  40b7d2:	cmp    $0xffffffff,%eax
  40b7d5:	je     40b7dc <cpu_exec_loop+0xbc>
  40b7d7:	test   $0x20,%ah
  40b7da:	je     40b840 <cpu_exec_loop+0x120>
  40b7dc:	movzwl 0x4b50(%rbx),%eax
  40b7e3:	add    0xe0(%rbx),%rax
  40b7ea:	jne    40b840 <cpu_exec_loop+0x120>
  40b7ec:	mov    0x2d0(%rbx),%ebp
  40b7f2:	cmp    $0xffffffff,%ebp
  40b7f5:	jne    40b73d <cpu_exec_loop+0x1d>
  40b7fb:	movl   $0x10000,0x2d0(%rbx)
  40b805:	mov    $0x10000,%ebp
  40b80a:	movl   $0xffffffff,0x2d0(%rbx)
  40b814:	add    $0x88,%rsp
  40b81b:	mov    %ebp,%eax
  40b81d:	pop    %rbx
  40b81e:	pop    %rbp
  40b81f:	pop    %r12
  40b821:	pop    %r13
  40b823:	pop    %r14
  40b825:	pop    %r15
  40b827:	xor    %edx,%edx
  40b829:	xor    %ecx,%ecx
  40b82b:	xor    %esi,%esi
  40b82d:	xor    %edi,%edi
  40b82f:	xor    %r8d,%r8d
  40b832:	xor    %r9d,%r9d
  40b835:	xor    %r10d,%r10d
  40b838:	ret
  40b839:	nopl   0x0(%rax)
  40b840:	mov    0x98(%rbx),%rax
  40b847:	lea    0x40(%rsp),%rdi
  40b84c:	mov    %rbx,%rsi
  40b84f:	mov    0x150(%rax),%rax
  40b856:	call   *0x18(%rax)
  40b859:	mov    0xcc(%rbx),%r8d
  40b860:	mov    0x40(%rsp),%r14
  40b865:	cmp    $0xffffffff,%r8d
  40b869:	je     40bc08 <cpu_exec_loop+0x4e8>
  40b86f:	movl   $0xffffffff,0xcc(%rbx)
  40b879:	cmpq   $0x0,0x240(%rbx)
  40b881:	jne    40bc50 <cpu_exec_loop+0x530>
  40b887:	mov    0x12d72b7(%rip),%eax        # 16e2b44 <target_page+0x4>
  40b88d:	mov    0x48(%rsp),%edx
  40b891:	mov    %r14,0x40(%rsp)
  40b896:	mov    0x218(%rbx),%r9
  40b89d:	mov    0x50(%rsp),%rsi
  40b8a2:	mov    %r8d,0x4c(%rsp)
  40b8a7:	lea    -0x6(%rax),%ecx
  40b8aa:	mov    %r14,%rax
  40b8ad:	shr    %cl,%rax
  40b8b0:	xor    %r14,%rax
  40b8b3:	mov    %rax,%r12
  40b8b6:	and    $0x3f,%eax
  40b8b9:	shr    %cl,%r12
  40b8bc:	and    $0xfc0,%r12d
  40b8c3:	or     %eax,%r12d
  40b8c6:	lea    0x1(%r12),%ecx
  40b8cb:	shl    $0x4,%rcx
  40b8cf:	lea    (%r9,%rcx,1),%r10
  40b8d3:	mov    (%r10),%rbp
  40b8d6:	test   %rbp,%rbp
  40b8d9:	je     40bad0 <cpu_exec_loop+0x3b0>
  40b8df:	mov    %r12,%rax
  40b8e2:	shl    $0x4,%rax
  40b8e6:	cmp    %r14,0x18(%rax,%r9,1)
  40b8eb:	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b8f1:	cmp    %rsi,0x8(%rbp)
  40b8f5:	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b8fb:	cmp    %edx,0x10(%rbp)
  40b8fe:	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b904:	mov    0x14(%rbp),%eax
  40b907:	cmp    %eax,%r8d
  40b90a:	jne    40bad0 <cpu_exec_loop+0x3b0>
  40b910:	mov    0x14(%rbp),%eax
  40b913:	test   $0x20000,%eax
  40b918:	jne    40b924 <cpu_exec_loop+0x204>
  40b91a:	cmp    %r14,0x0(%rbp)
  40b91e:	jne    1e8434 <cpu_exec_loop.cold+0x1f>
  40b924:	cmpq   $0xffffffffffffffff,0x50(%rbp)
  40b929:	jne    40b930 <cpu_exec_loop+0x210>
  40b92b:	test   %r13,%r13
  40b92e:	jne    40b9a8 <cpu_exec_loop+0x288>
  40b930:	mov    0x133d611(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40b937:	test   %r8d,%r8d
  40b93a:	jne    40ba80 <cpu_exec_loop+0x360>
  40b940:	lea    0x2c(%rsp),%rdx
  40b945:	mov    %rbp,%rsi
  40b948:	mov    %rbx,%rdi
  40b94b:	call   40b500 <cpu_tb_exec>
  40b950:	cmpl   $0x3,0x2c(%rsp)
  40b955:	mov    %rax,%r13
  40b958:	je     40bb80 <cpu_exec_loop+0x460>
  40b95e:	cmpb   $0x0,0x1322a17(%rip)        # 172e37c <icount_align_option>
  40b965:	je     40b99a <cpu_exec_loop+0x27a>
  40b967:	mov    0x8(%r15),%rdi
  40b96b:	movzwl 0x4b50(%rbx),%ebp
  40b972:	add    0xe0(%rbx),%rbp
  40b979:	sub    %rbp,%rdi
  40b97c:	call   4286d0 <icount_to_ns>
  40b981:	add    (%r15),%rax
  40b984:	mov    %rbp,0x8(%r15)
  40b988:	mov    %rax,(%r15)
  40b98b:	mov    %rax,%rcx
  40b98e:	cmp    $0x2dc6c0,%rax
  40b994:	jg     40bce0 <cpu_exec_loop+0x5c0>
  40b99a:	mov    0xcc(%rbx),%eax
  40b9a0:	jmp    40b790 <cpu_exec_loop+0x70>
  40b9a5:	nopl   (%rax)
  40b9a8:	mov    0x2c(%rsp),%esi
  40b9ac:	cmp    $0x1,%esi
  40b9af:	ja     1e8415 <cpu_exec_loop.cold>
  40b9b5:	lea    0x58(%rbp),%r12
  40b9b9:	mov    $0x1,%edx
  40b9be:	mov    %edx,%eax
  40b9c0:	xchg   %eax,(%r12)
  40b9c4:	test   %eax,%eax
  40b9c6:	jne    40baba <cpu_exec_loop+0x39a>
  40b9cc:	testb  $0x40,0x15(%rbp)
  40b9d0:	jne    40bb70 <cpu_exec_loop+0x450>
  40b9d6:	movslq %esi,%r8
  40b9d9:	xor    %eax,%eax
  40b9db:	lea    0x12(%r8),%rdx
  40b9df:	lock cmpxchg %rbp,0x0(%r13,%rdx,8)
  40b9e6:	jne    40bb70 <cpu_exec_loop+0x450>
  40b9ec:	mov    0x28(%rbp),%rax
  40b9f0:	movzwl 0x60(%r13,%r8,2),%edx
  40b9f6:	mov    %r8,0x8(%rsp)
  40b9fb:	add    0x28(%r13),%rdx
  40b9ff:	mov    0x1308ac2(%rip),%rdi        # 17144c8 <tcg_splitwx_diff>
  40ba06:	mov    %esi,(%rsp)
  40ba09:	mov    %rax,0x68(%r13,%r8,8)
  40ba0e:	mov    %rdx,%rcx
  40ba11:	sub    %rdi,%rcx
  40ba14:	add    %r13,%rdi
  40ba17:	call   3e2720 <tb_target_set_jmp_target>
  40ba1c:	mov    0x78(%rbp),%rax
  40ba20:	mov    0x8(%rsp),%r8
  40ba25:	mov    %rax,0x80(%r13,%r8,8)
  40ba2d:	or     %r13,%r8
  40ba30:	mov    %r8,0x78(%rbp)
  40ba34:	movl   $0x0,(%r12)
  40ba3c:	testb  $0x20,0x133d19d(%rip)        # 1748be0 <qemu_loglevel>
  40ba43:	mov    (%rsp),%esi
  40ba46:	je     40b930 <cpu_exec_loop+0x210>
  40ba4c:	mov    0x28(%r13),%rax
  40ba50:	mov    0x28(%rbp),%rcx
  40ba54:	mov    %esi,%edx
  40ba56:	lea    0xccd95b(%rip),%rdi        # 10d93b8 <anon.53529a8b42b516fa44fa3e141ddff7ec.0.llvm.534248872324339782+0x2d88f>
  40ba5d:	mov    %rax,%rsi
  40ba60:	xor    %eax,%eax
  40ba62:	call   66e2f0 <qemu_log>
  40ba67:	mov    0x133d4da(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40ba6e:	test   %r8d,%r8d
  40ba71:	je     40b940 <cpu_exec_loop+0x220>
  40ba77:	nopw   0x0(%rax,%rax,1)
  40ba80:	cmpw   $0x0,0x133c78e(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40ba88:	je     40b940 <cpu_exec_loop+0x220>
  40ba8e:	testb  $0x80,0x133d14c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40ba95:	je     40b940 <cpu_exec_loop+0x220>
  40ba9b:	mov    %r14,%rdx
  40ba9e:	mov    %rbp,%rsi
  40baa1:	lea    0xc4cd01(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40baa8:	xor    %eax,%eax
  40baaa:	call   66e2f0 <qemu_log>
  40baaf:	jmp    40b940 <cpu_exec_loop+0x220>
  40bab4:	nopl   0x0(%rax)
  40bab8:	pause
  40baba:	mov    (%r12),%eax
  40babe:	test   %eax,%eax
  40bac0:	jne    40bab8 <cpu_exec_loop+0x398>
  40bac2:	jmp    40b9be <cpu_exec_loop+0x29e>
  40bac7:	nopw   0x0(%rax,%rax,1)
  40bad0:	movd   %edx,%xmm0
  40bad4:	mov    %rsi,0x70(%rsp)
  40bad9:	sub    $0x20,%rsp
  40badd:	mov    %rbx,%rdi
  40bae0:	movd   %r8d,%xmm1
  40bae5:	mov    %rcx,0x38(%rsp)
  40baea:	lea    -0xbb1(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40baf1:	punpckldq %xmm1,%xmm0
  40baf5:	mov    %r10,0x30(%rsp)
  40bafa:	mov    %r9,0x28(%rsp)
  40baff:	mov    %r14,0x80(%rsp)
  40bb07:	mov    %r8d,0x20(%rsp)
  40bb0c:	movq   %xmm0,0x88(%rsp)
  40bb15:	movdqa 0x80(%rsp),%xmm0
  40bb1e:	mov    %rsi,0x10(%rsp)
  40bb23:	lea    0x13227b6(%rip),%rsi        # 172e2e0 <tb_ctx>
  40bb2a:	movups %xmm0,(%rsp)
  40bb2e:	call   40b0e0 <tb_htable_lookup_common>
  40bb33:	add    $0x20,%rsp
  40bb37:	mov    (%rsp),%r8d
  40bb3b:	mov    0x8(%rsp),%r9
  40bb40:	test   %rax,%rax
  40bb43:	mov    %rax,%rbp
  40bb46:	mov    0x10(%rsp),%r10
  40bb4b:	mov    0x18(%rsp),%rcx
  40bb50:	je     40bc88 <cpu_exec_loop+0x568>
  40bb56:	shl    $0x4,%r12
  40bb5a:	mov    %r14,0x18(%r12,%r9,1)
  40bb5f:	mov    %rax,(%r10)
  40bb62:	jmp    40b910 <cpu_exec_loop+0x1f0>
  40bb67:	nopw   0x0(%rax,%rax,1)
  40bb70:	movl   $0x0,(%r12)
  40bb78:	jmp    40b930 <cpu_exec_loop+0x210>
  40bb7d:	nopl   (%rax)
  40bb80:	mov    0x4b50(%rbx),%eax
  40bb86:	test   %eax,%eax
  40bb88:	js     40bbfa <cpu_exec_loop+0x4da>
  40bb8a:	mov    0x13227e8(%rip),%edi        # 172e378 <use_icount>
  40bb90:	test   %edi,%edi
  40bb92:	je     1e8472 <cpu_exec_loop.cold+0x5d>
  40bb98:	mov    %rbx,%rdi
  40bb9b:	call   4285d0 <icount_update>
  40bba0:	mov    0xd8(%rbx),%rdx
  40bba7:	mov    $0xffff,%eax
  40bbac:	cmp    %rax,%rdx
  40bbaf:	cmovle %rdx,%rax
  40bbb3:	movslq %eax,%rcx
  40bbb6:	mov    %ax,0x4b50(%rbx)
  40bbbd:	sub    %rcx,%rdx
  40bbc0:	mov    %rdx,0xe0(%rbx)
  40bbc7:	test   %eax,%eax
  40bbc9:	jle    40bbfa <cpu_exec_loop+0x4da>
  40bbcb:	movzwl 0x1a(%r13),%ecx
  40bbd0:	cmp    %ecx,%eax
  40bbd2:	jge    40bbfa <cpu_exec_loop+0x4da>
  40bbd4:	cmp    $0x1ff,%eax
  40bbd9:	jg     1e8453 <cpu_exec_loop.cold+0x3e>
  40bbdf:	test   %rdx,%rdx
  40bbe2:	jne    1e8491 <cpu_exec_loop.cold+0x7c>
  40bbe8:	mov    0x14(%r13),%edx
  40bbec:	and    $0xfffffe00,%edx
  40bbf2:	or     %edx,%eax
  40bbf4:	mov    %eax,0xcc(%rbx)
  40bbfa:	xor    %r13d,%r13d
  40bbfd:	jmp    40b95e <cpu_exec_loop+0x23e>
  40bc02:	nopw   0x0(%rax,%rax,1)
  40bc08:	mov    0xd4(%rbx),%r9d
  40bc0f:	mov    0x2c8(%rbx),%r8d
  40bc16:	test   %r9d,%r9d
  40bc19:	jne    40bf10 <cpu_exec_loop+0x7f0>
  40bc1f:	movzbl 0x13226a6(%rip),%eax        # 172e2cc <one_insn_per_tb>
  40bc26:	test   %al,%al
  40bc28:	je     40bd48 <cpu_exec_loop+0x628>
  40bc2e:	or     $0x201,%r8d
  40bc35:	cmpq   $0x0,0x240(%rbx)
  40bc3d:	je     40b887 <cpu_exec_loop+0x167>
  40bc43:	data16 cs nopw 0x0(%rax,%rax,1)
  40bc4e:	xchg   %ax,%ax
  40bc50:	lea    0x4c(%rsp),%rdx
  40bc55:	mov    %r14,%rsi
  40bc58:	mov    %rbx,%rdi
  40bc5b:	mov    %r14,0x40(%rsp)
  40bc60:	mov    %r8d,0x4c(%rsp)
  40bc65:	call   40afd0 <check_for_breakpoints_slow>
  40bc6a:	test   %al,%al
  40bc6c:	jne    40be40 <cpu_exec_loop+0x720>
  40bc72:	mov    0x40(%rsp),%r14
  40bc77:	mov    0x4c(%rsp),%r8d
  40bc7c:	jmp    40b887 <cpu_exec_loop+0x167>
  40bc81:	nopl   0x0(%rax)
  40bc88:	mov    %rcx,(%rsp)
  40bc8c:	sub    $0x20,%rsp
  40bc90:	mov    %rbx,%rdi
  40bc93:	shl    $0x4,%r12
  40bc97:	mov    %r14,0x60(%rsp)
  40bc9c:	mov    %r8d,0x6c(%rsp)
  40bca1:	movdqa 0x60(%rsp),%xmm0
  40bca7:	mov    0x70(%rsp),%rax
  40bcac:	movups %xmm0,(%rsp)
  40bcb0:	mov    %rax,0x10(%rsp)
  40bcb5:	call   41a1e0 <tb_gen_code>
  40bcba:	mov    0x20(%rsp),%rcx
  40bcbf:	add    $0x20,%rsp
  40bcc3:	mov    %rax,%rbp
  40bcc6:	mov    0x218(%rbx),%rax
  40bccd:	mov    %r14,0x18(%r12,%rax,1)
  40bcd2:	mov    %rbp,(%rax,%rcx,1)
  40bcd6:	jmp    40b924 <cpu_exec_loop+0x204>
  40bcdb:	nopl   0x0(%rax,%rax,1)
  40bce0:	pxor   %xmm0,%xmm0
  40bce4:	lea    0x60(%rsp),%rsi
  40bce9:	lea    0x30(%rsp),%rdi
  40bcee:	movabs $0x112e0be826d694b3,%rax
  40bcf8:	imul   %rcx
  40bcfb:	mov    %rcx,%rax
  40bcfe:	movaps %xmm0,0x60(%rsp)
  40bd03:	sar    $0x3f,%rax
  40bd07:	sar    $0x1a,%rdx
  40bd0b:	sub    %rax,%rdx
  40bd0e:	mov    %rdx,0x30(%rsp)
  40bd13:	imul   $0x3b9aca00,%rdx,%rdx
  40bd1a:	sub    %rdx,%rcx
  40bd1d:	mov    %rcx,0x38(%rsp)
  40bd22:	call   1d66b0 <nanosleep@plt>
  40bd27:	mov    %eax,%edx
  40bd29:	xor    %eax,%eax
  40bd2b:	test   %edx,%edx
  40bd2d:	jns    40bd3d <cpu_exec_loop+0x61d>
  40bd2f:	imul   $0x3b9aca00,0x60(%rsp),%rax
  40bd38:	add    0x68(%rsp),%rax
  40bd3d:	mov    %rax,(%r15)
  40bd40:	jmp    40b99a <cpu_exec_loop+0x27a>
  40bd45:	nopl   (%rax)
  40bd48:	mov    %r8d,%eax
  40bd4b:	or     $0x2,%ah
  40bd4e:	testb  $0x20,0x133ce8c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bd55:	cmovne %eax,%r8d
  40bd59:	jmp    40b879 <cpu_exec_loop+0x159>
  40bd5e:	xchg   %ax,%ax
  40bd60:	mov    $0x365,%esi
  40bd65:	lea    0xc4c9df(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40bd6c:	call   368ff0 <bql_lock_impl>
  40bd71:	mov    0xd0(%rbx),%eax
  40bd77:	test   $0x80,%al
  40bd79:	jne    40bf58 <cpu_exec_loop+0x838>
  40bd7f:	cmpl   $0x2,0x13085a2(%rip)        # 1714328 <replay_mode>
  40bd86:	je     40bee0 <cpu_exec_loop+0x7c0>
  40bd8c:	mov    0xd0(%rbx),%eax
  40bd92:	test   $0x20,%al
  40bd94:	jne    40bf20 <cpu_exec_loop+0x800>
  40bd9a:	mov    0x98(%rbx),%rax
  40bda1:	mov    0xd0(%rbx),%ebp
  40bda7:	mov    0x150(%rax),%r12
  40bdae:	mov    0xd0(%rbx),%eax
  40bdb4:	test   $0x4,%ah
  40bdb7:	jne    40be27 <cpu_exec_loop+0x707>
  40bdb9:	mov    %ebp,%eax
  40bdbb:	mov    %rbx,%rdi
  40bdbe:	and    $0xffffeda5,%eax
  40bdc3:	testb  $0x2,0xd4(%rbx)
  40bdca:	cmovne %eax,%ebp
  40bdcd:	mov    %ebp,%esi
  40bdcf:	call   *0x58(%r12)
  40bdd4:	test   %al,%al
  40bdd6:	je     40be08 <cpu_exec_loop+0x6e8>
  40bdd8:	mov    0xb8(%r12),%rax
  40bde0:	test   %rax,%rax
  40bde3:	je     40be20 <cpu_exec_loop+0x700>
  40bde5:	mov    %ebp,%edi
  40bde7:	call   *%rax
  40bde9:	test   %al,%al
  40bdeb:	jne    40be20 <cpu_exec_loop+0x700>
  40bded:	mov    0xd4(%rbx),%esi
  40bdf3:	test   %esi,%esi
  40bdf5:	jne    40c04c <cpu_exec_loop+0x92c>
  40bdfb:	movl   $0xffffffff,0x2d0(%rbx)
  40be05:	xor    %r13d,%r13d
  40be08:	mov    0xd0(%rbx),%eax
  40be0e:	test   $0x4,%al
  40be10:	jne    40befb <cpu_exec_loop+0x7db>
  40be16:	call   369040 <bql_unlock>
  40be1b:	jmp    40b7b7 <cpu_exec_loop+0x97>
  40be20:	call   3d1210 <replay_interrupt>
  40be25:	jmp    40bded <cpu_exec_loop+0x6cd>
  40be27:	call   3d1210 <replay_interrupt>
  40be2c:	mov    %rbx,%rdi
  40be2f:	call   *0x60(%r12)
  40be34:	call   369040 <bql_unlock>
  40be39:	nopl   0x0(%rax)
  40be40:	mov    0x2d0(%rbx),%ebp
  40be46:	test   %ebp,%ebp
  40be48:	js     40b750 <cpu_exec_loop+0x30>
  40be4e:	cmp    $0xffff,%ebp
  40be54:	jg     40bf7f <cpu_exec_loop+0x85f>
  40be5a:	call   3d10e0 <replay_exception>
  40be5f:	test   %al,%al
  40be61:	je     40bfc0 <cpu_exec_loop+0x8a0>
  40be67:	mov    0x98(%rbx),%rax
  40be6e:	mov    $0x319,%esi
  40be73:	lea    0xc4c8d1(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40be7a:	mov    0x150(%rax),%rbp
  40be81:	call   368ff0 <bql_lock_impl>
  40be86:	mov    %rbx,%rdi
  40be89:	call   *0x50(%rbp)
  40be8c:	call   369040 <bql_unlock>
  40be91:	mov    0xd4(%rbx),%eax
  40be97:	movl   $0xffffffff,0x2d0(%rbx)
  40bea1:	test   %eax,%eax
  40bea3:	je     40b770 <cpu_exec_loop+0x50>
  40bea9:	mov    0x98(%rbx),%rax
  40beb0:	cmpq   $0x0,0x260(%rbx)
  40beb8:	mov    0x150(%rax),%rdx
  40bebf:	je     40c066 <cpu_exec_loop+0x946>
  40bec5:	mov    0x40(%rdx),%rax
  40bec9:	test   %rax,%rax
  40becc:	je     40bed3 <cpu_exec_loop+0x7b3>
  40bece:	mov    %rbx,%rdi
  40bed1:	call   *%rax
  40bed3:	mov    $0x10002,%ebp
  40bed8:	jmp    40b814 <cpu_exec_loop+0xf4>
  40bedd:	nopl   (%rax)
  40bee0:	call   3d1300 <replay_has_interrupt>
  40bee5:	test   %al,%al
  40bee7:	jne    40bd8c <cpu_exec_loop+0x66c>
  40beed:	mov    0xd0(%rbx),%eax
  40bef3:	test   $0x4,%al
  40bef5:	je     40be16 <cpu_exec_loop+0x6f6>
  40befb:	mov    $0x4,%esi
  40bf00:	mov    %rbx,%rdi
  40bf03:	xor    %r13d,%r13d
  40bf06:	call   248f50 <cpu_reset_interrupt>
  40bf0b:	jmp    40be16 <cpu_exec_loop+0x6f6>
  40bf10:	or     $0xe01,%r8d
  40bf17:	jmp    40b879 <cpu_exec_loop+0x159>
  40bf1c:	nopl   0x0(%rax)
  40bf20:	call   3d1210 <replay_interrupt>
  40bf25:	mov    $0x20,%esi
  40bf2a:	mov    %rbx,%rdi
  40bf2d:	call   248f50 <cpu_reset_interrupt>
  40bf32:	movabs $0x1000100000001,%rax
  40bf3c:	mov    %rax,0x2cc(%rbx)
  40bf43:	call   369040 <bql_unlock>
  40bf48:	mov    0x2d0(%rbx),%ebp
  40bf4e:	jmp    40b73d <cpu_exec_loop+0x1d>
  40bf53:	nopl   0x0(%rax,%rax,1)
  40bf58:	mov    $0x80,%esi
  40bf5d:	mov    %rbx,%rdi
  40bf60:	call   248f50 <cpu_reset_interrupt>
  40bf65:	movl   $0x10002,0x2d0(%rbx)
  40bf6f:	call   369040 <bql_unlock>
  40bf74:	mov    0x2d0(%rbx),%ebp
  40bf7a:	jmp    40b73d <cpu_exec_loop+0x1d>
  40bf7f:	cmp    $0x10002,%ebp
  40bf85:	jne    40b80a <cpu_exec_loop+0xea>
  40bf8b:	mov    0x98(%rbx),%rax
  40bf92:	cmpq   $0x0,0x260(%rbx)
  40bf9a:	mov    0x150(%rax),%rdx
  40bfa1:	je     40c01a <cpu_exec_loop+0x8fa>
  40bfa3:	mov    0x40(%rdx),%rax
  40bfa7:	test   %rax,%rax
  40bfaa:	je     40b80a <cpu_exec_loop+0xea>
  40bfb0:	mov    %rbx,%rdi
  40bfb3:	call   *%rax
  40bfb5:	jmp    40b80a <cpu_exec_loop+0xea>
  40bfba:	nopw   0x0(%rax,%rax,1)
  40bfc0:	call   3d1300 <replay_has_interrupt>
  40bfc5:	test   %al,%al
  40bfc7:	jne    40b770 <cpu_exec_loop+0x50>
  40bfcd:	mov    $0x10000,%ebp
  40bfd2:	jmp    40b814 <cpu_exec_loop+0xf4>
  40bfd7:	mov    0xd4(%rbx),%edx
  40bfdd:	mov    0x2c8(%rbx),%eax
  40bfe3:	test   %edx,%edx
  40bfe5:	jne    40c08b <cpu_exec_loop+0x96b>
  40bfeb:	movzbl 0x13222da(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40bff2:	test   %dl,%dl
  40bff4:	jne    40c045 <cpu_exec_loop+0x925>
  40bff6:	mov    %eax,%edx
  40bff8:	or     $0x2,%dh
  40bffb:	testb  $0x20,0x133cbdf(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c002:	cmovne %edx,%eax
  40c005:	and    $0xfffedffe,%eax
  40c00a:	or     $0x10001,%eax
  40c00f:	mov    %eax,0xcc(%rbx)
  40c015:	jmp    40b776 <cpu_exec_loop+0x56>
  40c01a:	mov    0x250(%rbx),%rax
  40c021:	test   %rax,%rax
  40c024:	je     40bfa3 <cpu_exec_loop+0x883>
  40c02a:	nopw   0x0(%rax,%rax,1)
  40c030:	andl   $0xffffff3f,0x20(%rax)
  40c037:	mov    0x28(%rax),%rax
  40c03b:	test   %rax,%rax
  40c03e:	jne    40c030 <cpu_exec_loop+0x910>
  40c040:	jmp    40bfa3 <cpu_exec_loop+0x883>
  40c045:	or     $0x201,%eax
  40c04a:	jmp    40c005 <cpu_exec_loop+0x8e5>
  40c04c:	movl   $0x10002,0x2d0(%rbx)
  40c056:	call   369040 <bql_unlock>
  40c05b:	mov    0x2d0(%rbx),%ebp
  40c061:	jmp    40b73d <cpu_exec_loop+0x1d>
  40c066:	mov    0x250(%rbx),%rax
  40c06d:	test   %rax,%rax
  40c070:	je     40bec5 <cpu_exec_loop+0x7a5>
  40c076:	andl   $0xffffff3f,0x20(%rax)
  40c07d:	mov    0x28(%rax),%rax
  40c081:	test   %rax,%rax
  40c084:	jne    40c076 <cpu_exec_loop+0x956>
  40c086:	jmp    40bec5 <cpu_exec_loop+0x7a5>
  40c08b:	or     $0xe01,%eax
  40c090:	jmp    40c005 <cpu_exec_loop+0x8e5>

Disassembly of section .fini:

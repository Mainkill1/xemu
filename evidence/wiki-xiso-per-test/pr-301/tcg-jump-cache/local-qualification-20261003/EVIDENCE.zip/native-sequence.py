"""Execute frozen native qualification through maintained HTTP only.

Stops on any observed correctness/evidence/transport failure. No cancellation,
replacement attempt, cache waiver, source modification or reference updates.
"""
from pathlib import Path
import json,subprocess,sys
out=Path(__file__).parent;native=out/'native';root=Path('/home/codex/src/steamdeck-xemu/worktrees/runner-standalone-process');sys.path.insert(0,str(root/'scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_xiso import follow
api=RunnerApi('http://10.0.0.123:9368');w=Workflows(api)
def call(label,script,args):
 p=subprocess.run(['python3',str(root/'scripts'/script),'--url',api.url,*args],capture_output=True)
 path=native/(label+'.json')
 assert not path.exists(), 'Existing receipt requires operator reconciliation: '+str(path)
 path.write_bytes(p.stdout);(native/(label+'.stderr.log')).write_bytes(p.stderr)
 if p.returncode:raise RuntimeError(p.stdout.decode()+p.stderr.decode())
 return json.loads(p.stdout)
def collect(case):
 subprocess.run(['python3',str(out/'collect-phase-via-http.py'),case],check=True)
def await_campaign(case):
 cid='i167-victim8-'+case+'-5679-001';r=follow(api,cid,False)
 (native/(case+'-sequence-wait.json')).write_text(json.dumps(r,indent=2)+'\n')
 assert r['terminal'] and r['failed']==0 and r['incomplete']==0 and r['passed']==8
 collect(case)
print('Following existing parent A/A campaign; no replacement attempts.',flush=True)
await_campaign('aa')
print('Parent A/A completed and collected. Uploading immutable source-bound builds while idle.',flush=True)
packages=json.loads((out/'PACKAGES.json').read_text())
for mode in ['disabled','enabled']:
 call(mode+'-uploaded','runner_tests.py',['upload',str(out/(mode+'-package')),'--exe','xemu','--id',packages[mode]['application']])
uid=packages['unit']['application'];call('unit-submitted','runner_api.py',['submit',str(out/'unit-package'),'--id',uid])
while True:
 r=w.wait(uid,30)
 if r.get('state')=='tested':break
 assert r.get('state') not in ['held','blocked','cancelled','unavailable','draft'],r
(native/'unit-result.json').write_text(json.dumps(r,indent=2)+'\n')
assert r['outcome']['correctness']=='passed' and r['outcome']['evidence']=='complete',r
receipt=w.collect(uid,native/'unit-collected',None,True);(native/'unit-collection.json').write_text(json.dumps(receipt,indent=2)+'\n')
tap=(Path(receipt['directory'])/'stdout.log').read_text();assert '1..13' in tap and sum(x.startswith('ok ') for x in tap.splitlines())==13
call('unit-saved','runner_api.py',['bake','i167-victim8-production-helper-v1','--from-job',uid,'--description','Retained actual eight-entry cache correctness: full key, invalidation, aliases, 10000 delayed fills and guarded storage reuse. Process target; does not qualify VM/game performance.','--build-file','test-tcg-victim-cache'])
print('Deck helper: 13/13 pass; retained as reusable saved test.',flush=True)
for case,mode in [('parity','disabled'),('enabled','enabled')]:
 cid='i167-victim8-'+case+'-5679-001'
 call(case+'-selected','runner_xiso.py',['select',packages[mode]['application'],'--reference','i167-76c23c7d-parent','--suite','i167-corrected-aa-v1-suite','--id',cid,'--configuration-source','suite','--test','cpu_translation_blocks.code_stable','--test','cpu_translation_blocks.code_rewrite','--mode','monolithic'])
 plan=call(case+'-plan','runner_xiso.py',['plan',cid]);assert [x['label'] for x in plan['attempts']]==['A1','B1','B2','A2','B3','A3','A4','B4'];assert len(plan['chunks'])==1
 call(case+'-start','runner_xiso.py',['start',cid]);print('Started '+case+' ABBA then BAAB; all outcomes retained.',flush=True)
 await_campaign(case);print(case+' qualification completed and collected.',flush=True)
(native/'SEQUENCE-COMPLETE.json').write_text(json.dumps({'complete':True,'campaigns':['aa','parity','enabled'],'attempts':24,'nativeHelperCases':13,'productCommit':'5679cce099eb777977e761245de47e77d05d0c05','runnerCommit':'55a360daf82a699ecd12d69d8484f32bf1cf3752'},indent=2)+'\n')
print('Frozen native sequence complete; performance decision requires reading all timings.',flush=True)

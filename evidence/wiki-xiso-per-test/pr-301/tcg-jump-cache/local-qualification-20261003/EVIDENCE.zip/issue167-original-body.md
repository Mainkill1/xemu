## Request

Determine whether the current TB jump cache loses meaningful time to conflict misses. Compare a small miss-only victim cache, a two-way organization at the same entry budget, and a separately reported larger direct map. Adopt only a measured winner.

**Priority:** bounded CPU follow-up; shares attribution with #166, but changes cache organization rather than eliminating helper calls.

**Status:** Draft [PR #299](https://github.com/Mainkill1/xemu/pull/299) implements miss/recoverability attribution, not a production cache optimization. Repair `31c083ece2e` restores the parent lookup in the compile-disabled path after the old dormant comparison exposed a compiler confound. [Fresh parent A/A and repaired default-off parity](https://github.com/Mainkill1/xemu/blob/b39357920f5de088df062ba7922341d853821c3e/evidence/wiki-xiso-per-test/pr-299/tcg-jump-cache/corrected-parent-parity-20261003/REPORT.md) complete 16 correct, eligible ABBA/BAAB runs on Deck `.123` using the updated runner `c264004` (main #93/#94/#95 included). All 16 private Mesa disk namespaces qualify without waiver. Median attempt-mean parity is -0.03% stable / -0.20% rewrite, versus identical-parent A/A variation of -0.11% / +3.35%; small effects are inconclusive. The packet retains baseline/candidate/time-saved/Improvement % tables, both orders and all 4,963 native file hashes. [Corrected dormant qualification](https://github.com/Mainkill1/xemu/blob/1da08747a91a82141f57c0221570a29012d17091/evidence/wiki-xiso-per-test/pr-299/tcg-jump-cache/corrected-observer-cost-20261003/REPORT.md) adds eight correct/eligible/Mesa-qualified runs: median attempt-mean stable -1.80% (ABBA -9.18%, BAAB -2.10%), rewrite -1.05% (ABBA -3.66%, BAAB -1.55%). Stable B1 first three samples are slow with cause unclassified; all samples remain. Combined medians do not qualify an under-5% overhead bound. All 2,482 files were collected with zero exclusions. Corrected counters adds eight correct/eligible/Mesa-qualified outcomes: stable -4.65% (ABBA -4.08%, BAAB -5.13%), rewrite -3.64% (ABBA -5.54%, BAAB -2.99%). Under-5% overhead is not consistently met. The observer packet now preserves 4,962 dormant/counters files with zero exclusions; this is combined compiler-hook/accounting cost, not same-binary activation. Conflict classification completes eight further correct/eligible/Mesa-qualified outcomes: stable -2.18% (ABBA -2.79%, BAAB -1.31%), rewrite -8.38% (ABBA -7.89%, BAAB -6.96%). The observer packet preserves all 7,443 native files with zero exclusions. All 40 corrected matrix attempts qualify Mesa, and the CPU observer matrix is complete. [Reached retail attribution](https://github.com/Mainkill1/xemu/blob/1da08747a91a82141f57c0221570a29012d17091/evidence/wiki-xiso-per-test/pr-299/tcg-jump-cache/retail-attribution-20261003/REPORT.md) completes a reviewed stationary PGR2 race window: 27,558,622 validated global hits, 5,620,784 eight-entry potential recoveries (20.40%; 5.01% of completed C lookups), 7,836,701 sixteen-entry recoveries (28.44%; 6.98%). All 871 native files are retained with zero exclusions; private Mesa qualifies. Low logged PGRAPH event cadence and a GLib stderr warning remain unclassified. No production optimization, speedup or scene reference is qualified. Counts now justify a bounded miss-only eight-entry candidate with full invalidation/lifetime and matched uninstrumented performance controls. Initial bounded diagnostic windows show potential eight-entry recoveries, not gains: 15.88% of validated global hits in stable code, 0.92% in rewrite, only 0.01271% / 0.03015% of completed C lookups. Actual uninstrumented candidate/invalidation qualification remains missing; keep HOLD/draft. Original research baseline: `82d04d84bdb3de956f20c3537e1da2cece0e8da2`; no timing comparison against it is claimed.

## Verified starting point

- [tb-jmp-cache.h](https://github.com/Mainkill1/xemu/blob/82d04d84bdb3de956f20c3537e1da2cece0e8da2/accel/tcg/tb-jmp-cache.h) defines 4,096 direct-mapped entries containing a TB pointer and guest PC.
- [cpu-exec.c](https://github.com/Mainkill1/xemu/blob/82d04d84bdb3de956f20c3537e1da2cece0e8da2/accel/tcg/cpu-exec.c), `tb_lookup()`, validates PC, CS base, target flags and cflags, then uses the global physical-code hash lookup on a miss.
- [tb-hash.h](https://github.com/Mainkill1/xemu/blob/82d04d84bdb3de956f20c3537e1da2cece0e8da2/accel/tcg/tb-hash.h) deliberately groups same-page addresses for fast invalidation.
- [cputlb.c](https://github.com/Mainkill1/xemu/blob/82d04d84bdb3de956f20c3537e1da2cece0e8da2/accel/tcg/cputlb.c) clears jump-cache entries on TLB changes, including the preceding page for potentially spanning TBs. [tb-maint.c](https://github.com/Mainkill1/xemu/blob/82d04d84bdb3de956f20c3537e1da2cece0e8da2/accel/tcg/tb-maint.c) handles physical-code invalidation and full flushes.

FEX uses a larger/adaptive L1 and additional lookup tiers: [LookupCache.h](https://github.com/FEX-Emu/FEX/blob/37d83d937586f342ca3e9131270f8ef23b61adc4/FEXCore/Source/Interface/Core/LookupCache.h). That establishes a useful design comparison, not evidence that xemu needs the same size or hash.

## First deliverable: classify misses correctly

Reuse #166's opt-in, owner-local counters and archived #54 findings where relevant. Distinguish:

```text
jump-cache hit
empty slot
occupied slot with different PC
same PC but different translation state
global TB hash hit
new translation required
cache entries cleared by mapping/code/lifecycle invalidation
```

An occupied-slot miss is only a potential conflict. Use bounded identity/eviction tracking or an offline trace to determine whether a recently displaced valid entry would actually have served the request. A high miss count caused by legitimate TLB invalidations, cflags changes or new code is not proof that associativity will help.

Record hit/miss cost, miss burstiness, cache-clear frequency/work, active PC working set and host cache pressure. Do not add a timestamp or log line to every dispatch.

## Experimental alternatives

| Variant | Question |
|---|---|
| Existing 4,096-entry direct map | Reference |
| Existing map plus 8-entry, then 16-entry victim cache consulted only after a primary miss | Do recently displaced translations account for expensive misses? |
| 2,048 sets x 2 ways = 4,096 total entries | Does associativity beat the reference at comparable entry/storage budget? |
| 8,192-entry direct map | Is extra capacity worth its separately disclosed memory/cache/clear cost? |

Keep the global TB hash table and translation path unchanged. Measure metadata/padding and actual allocated bytes; equal entry counts need not mean exactly equal allocation sizes. Do not combine all variants or add adaptive resizing before a fixed design proves useful.

```text
primary lookup -> hit: existing route
              -> miss: optional secondary/second-way validation
                         -> hit: valid TB
                         -> miss: existing global lookup/translation route
```

Coordinate generated lookup layout with #166. Compare cache variants with the same dispatch implementation, and measure any selected combination explicitly rather than adding gains from separate experiments.

## Mandatory invalidation contract

Every secondary entry must preserve the complete TB lookup key and the existing publication/lifetime rules. A still-live physical TB can become the wrong answer after virtual code remapping.

Preserve page/range/full TLB clears; account for both pages of spanning TBs; preserve physical SMC invalidation, full code-cache flush/reuse, CPU reset and snapshot restore. Initially clearing the entire tiny victim cache on an affected mapping/code invalidation is acceptable if synchronized correctly. A new hash must not silently break `tb_jmp_cache_hash_page()` clearing. Audit all cache readers, fills and clears together.

Do not turn two-way storage into an unsynchronized multi-field publication or trust stale PC/flags beside a reused TB pointer.

## Tests and acceptance

- Synthetic PCs intentionally colliding under the production hash, plus non-colliding and high-entropy controls; verify production lookup results against the reference.
- Same PC with changed CS/flags/cflags; virtual remap while old physical TB stays valid; second-page-only remap; SMC; full flush and memory reuse; debug and IRQ controls from #166/#56.
- Fixed-work CPU-heavy retail and synthetic runs, including unrelated workloads where the original cache already hits well.
- Report absolute useful-work time/CPU-seconds, guest interval tails, hit/miss breakdown, generated-code cost if affected, host cache/branch misses where available, memory and invalidation cost.
- Final performance comparison without diagnostic-only overhead; full current XISO/cross-renderer qualification only for a promising candidate.

- [ ] Evidence shows recoverable conflict misses rather than merely a high aggregate miss rate.
- [ ] One simple variant improves total useful-work cost beyond noise without unacceptable regressions.
- [ ] All mapping, SMC, publication and lifecycle controls pass.
- [ ] Rejected variants and equal-budget versus larger-budget comparisons remain visible.
- [ ] Store source/binary/settings/workload identities and per-run evidence under `evidence/wiki-xiso-per-test/pr-<number>/tcg-jump-cache/`.

Close with findings if current cache behavior is already adequate. Do not present FEX's larger cache or a theoretical miss reduction as measured xemu performance.

> Agent Declaration: Prepared with ChatGPT after source and related-work review; no emulator benchmark was run for this request.

### Runner update qualification

Deck `.123` now runs `55a360daf82a699ecd12d69d8484f32bf1cf3752`, incorporating runner #96/#97 and the backward-compatible request identity fix in [draft #98](https://github.com/Mainkill1/Xemu-Test-Runner/pull/98). All eleven managed suites pass (290 checks), plus 10 XISO client checks. All five previous campaign plans, reports and terminal statuses remain identical; the original 40 attempts retain runner `c264004`. All 1,091 backed-up metadata files are unchanged. Live HTTP controls verify the required configuration choice and per-attempt hash. No new emulator measurement ran and no speedup is claimed. [Upgrade evidence and retained failure](https://github.com/Mainkill1/xemu/blob/2b796865b4d3fdf5c4fe033538db4a57e1a7bc09/evidence/wiki-xiso-per-test/pr-299/tcg-jump-cache/runner-xiso-fixes-20261003/REPORT.md).



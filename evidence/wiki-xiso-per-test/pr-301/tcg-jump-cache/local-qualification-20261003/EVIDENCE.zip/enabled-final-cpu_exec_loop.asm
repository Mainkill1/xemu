
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-on/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040b940 <cpu_exec_loop>:
  40b940:	push   %r15
  40b942:	mov    %rsi,%r15
  40b945:	push   %r14
  40b947:	mov    %rdi,%r14
  40b94a:	push   %r13
  40b94c:	push   %r12
  40b94e:	push   %rbp
  40b94f:	push   %rbx
  40b950:	sub    $0xb8,%rsp
  40b957:	mov    0x2d0(%rdi),%ebx
  40b95d:	test   %ebx,%ebx
  40b95f:	jns    40c0cf <cpu_exec_loop+0x78f>
  40b965:	data16 cs nopw 0x0(%rax,%rax,1)
  40b970:	call   3d11d0 <replay_has_exception>
  40b975:	test   %al,%al
  40b977:	je     40b990 <cpu_exec_loop+0x50>
  40b979:	movzwl 0x4b50(%r14),%eax
  40b981:	add    0xe0(%r14),%rax
  40b988:	je     40c2df <cpu_exec_loop+0x99f>
  40b98e:	xchg   %ax,%ax
  40b990:	mov    0xcc(%r14),%eax
  40b997:	lea    0x50(%rsp),%rcx
  40b99c:	movl   $0x0,0x3c(%rsp)
  40b9a4:	xor    %r12d,%r12d
  40b9a7:	mov    %rcx,(%rsp)
  40b9ab:	nopl   0x0(%rax,%rax,1)
  40b9b0:	cmp    $0xffffffff,%eax
  40b9b3:	je     40b9c0 <cpu_exec_loop+0x80>
  40b9b5:	test   $0x10000,%eax
  40b9ba:	jne    40ba68 <cpu_exec_loop+0x128>
  40b9c0:	xor    %eax,%eax
  40b9c2:	xchg   %ax,0x4b52(%r14)
  40b9ca:	mov    0xd0(%r14),%eax
  40b9d1:	test   %eax,%eax
  40b9d3:	jne    40bfe0 <cpu_exec_loop+0x6a0>
  40b9d9:	movzbl 0xc7(%r14),%eax
  40b9e1:	test   %al,%al
  40b9e3:	jne    40ba11 <cpu_exec_loop+0xd1>
  40b9e5:	mov    0x132298d(%rip),%ecx        # 172e378 <use_icount>
  40b9eb:	test   %ecx,%ecx
  40b9ed:	je     40ba68 <cpu_exec_loop+0x128>
  40b9ef:	mov    0xcc(%r14),%eax
  40b9f6:	cmp    $0xffffffff,%eax
  40b9f9:	je     40ba00 <cpu_exec_loop+0xc0>
  40b9fb:	test   $0x20,%ah
  40b9fe:	je     40ba68 <cpu_exec_loop+0x128>
  40ba00:	movzwl 0x4b50(%r14),%eax
  40ba08:	add    0xe0(%r14),%rax
  40ba0f:	jne    40ba68 <cpu_exec_loop+0x128>
  40ba11:	mov    0x2d0(%r14),%ebx
  40ba18:	cmp    $0xffffffff,%ebx
  40ba1b:	jne    40b95d <cpu_exec_loop+0x1d>
  40ba21:	movl   $0x10000,0x2d0(%r14)
  40ba2c:	mov    $0x10000,%ebx
  40ba31:	movl   $0xffffffff,0x2d0(%r14)
  40ba3c:	add    $0xb8,%rsp
  40ba43:	mov    %ebx,%eax
  40ba45:	pop    %rbx
  40ba46:	pop    %rbp
  40ba47:	pop    %r12
  40ba49:	pop    %r13
  40ba4b:	pop    %r14
  40ba4d:	pop    %r15
  40ba4f:	xor    %edx,%edx
  40ba51:	xor    %ecx,%ecx
  40ba53:	xor    %esi,%esi
  40ba55:	xor    %edi,%edi
  40ba57:	xor    %r8d,%r8d
  40ba5a:	xor    %r9d,%r9d
  40ba5d:	xor    %r10d,%r10d
  40ba60:	xor    %r11d,%r11d
  40ba63:	ret
  40ba64:	nopl   0x0(%rax)
  40ba68:	mov    0x98(%r14),%rax
  40ba6f:	mov    (%rsp),%rdi
  40ba73:	mov    %r14,%rsi
  40ba76:	mov    0x150(%rax),%rax
  40ba7d:	call   *0x18(%rax)
  40ba80:	mov    0xcc(%r14),%r8d
  40ba87:	mov    0x50(%rsp),%r9
  40ba8c:	cmp    $0xffffffff,%r8d
  40ba90:	je     40bed0 <cpu_exec_loop+0x590>
  40ba96:	movl   $0xffffffff,0xcc(%r14)
  40baa1:	cmpq   $0x0,0x240(%r14)
  40baa9:	jne    40bf10 <cpu_exec_loop+0x5d0>
  40baaf:	mov    0x12d708f(%rip),%eax        # 16e2b44 <target_page+0x4>
  40bab5:	mov    0x218(%r14),%r10
  40babc:	mov    0x58(%rsp),%r13d
  40bac1:	mov    0x60(%rsp),%r11
  40bac6:	lea    -0x6(%rax),%ecx
  40bac9:	mov    %r9,%rax
  40bacc:	shr    %cl,%rax
  40bacf:	xor    %r9,%rax
  40bad2:	mov    %rax,%rbp
  40bad5:	and    $0x3f,%eax
  40bad8:	shr    %cl,%rbp
  40badb:	and    $0xfc0,%ebp
  40bae1:	or     %eax,%ebp
  40bae3:	lea    0x1(%rbp),%eax
  40bae6:	shl    $0x4,%rax
  40baea:	add    %r10,%rax
  40baed:	mov    (%rax),%rbx
  40baf0:	test   %rbx,%rbx
  40baf3:	je     40bcf0 <cpu_exec_loop+0x3b0>
  40baf9:	mov    %ebp,%eax
  40bafb:	shl    $0x4,%rax
  40baff:	cmp    %r9,0x18(%rax,%r10,1)
  40bb04:	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb0a:	cmp    %r11,0x8(%rbx)
  40bb0e:	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb14:	cmp    0x10(%rbx),%r13d
  40bb18:	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb1e:	mov    0x14(%rbx),%eax
  40bb21:	cmp    %r8d,%eax
  40bb24:	jne    40bcf0 <cpu_exec_loop+0x3b0>
  40bb2a:	mov    0x14(%rbx),%eax
  40bb2d:	test   $0x20000,%eax
  40bb32:	jne    40bb3d <cpu_exec_loop+0x1fd>
  40bb34:	cmp    %r9,(%rbx)
  40bb37:	jne    1e8453 <cpu_exec_loop.cold+0x1f>
  40bb3d:	cmpq   $0xffffffffffffffff,0x50(%rbx)
  40bb42:	jne    40bb49 <cpu_exec_loop+0x209>
  40bb44:	test   %r12,%r12
  40bb47:	jne    40bbc0 <cpu_exec_loop+0x280>
  40bb49:	mov    0x133d3f8(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40bb50:	test   %r8d,%r8d
  40bb53:	jne    40bca0 <cpu_exec_loop+0x360>
  40bb59:	lea    0x3c(%rsp),%rdx
  40bb5e:	mov    %rbx,%rsi
  40bb61:	mov    %r14,%rdi
  40bb64:	call   40b720 <cpu_tb_exec>
  40bb69:	cmpl   $0x3,0x3c(%rsp)
  40bb6e:	mov    %rax,%r12
  40bb71:	je     40be40 <cpu_exec_loop+0x500>
  40bb77:	cmpb   $0x0,0x13227fe(%rip)        # 172e37c <icount_align_option>
  40bb7e:	je     40bbb4 <cpu_exec_loop+0x274>
  40bb80:	mov    0x8(%r15),%rdi
  40bb84:	movzwl 0x4b50(%r14),%ebx
  40bb8c:	add    0xe0(%r14),%rbx
  40bb93:	sub    %rbx,%rdi
  40bb96:	call   428c90 <icount_to_ns>
  40bb9b:	add    (%r15),%rax
  40bb9e:	mov    %rbx,0x8(%r15)
  40bba2:	mov    %rax,(%r15)
  40bba5:	mov    %rax,%rcx
  40bba8:	cmp    $0x2dc6c0,%rax
  40bbae:	jg     40bf48 <cpu_exec_loop+0x608>
  40bbb4:	mov    0xcc(%r14),%eax
  40bbbb:	jmp    40b9b0 <cpu_exec_loop+0x70>
  40bbc0:	mov    0x3c(%rsp),%esi
  40bbc4:	cmp    $0x1,%esi
  40bbc7:	ja     1e8434 <cpu_exec_loop.cold>
  40bbcd:	lea    0x58(%rbx),%rbp
  40bbd1:	mov    $0x1,%edx
  40bbd6:	mov    %edx,%eax
  40bbd8:	xchg   %eax,0x0(%rbp)
  40bbdb:	test   %eax,%eax
  40bbdd:	jne    40bcda <cpu_exec_loop+0x39a>
  40bbe3:	testb  $0x40,0x15(%rbx)
  40bbe7:	jne    40be30 <cpu_exec_loop+0x4f0>
  40bbed:	movslq %esi,%r13
  40bbf0:	xor    %eax,%eax
  40bbf2:	lea    0x12(%r13),%rdx
  40bbf6:	lock cmpxchg %rbx,(%r12,%rdx,8)
  40bbfc:	jne    40be30 <cpu_exec_loop+0x4f0>
  40bc02:	mov    0x28(%rbx),%rax
  40bc06:	movzwl 0x60(%r12,%r13,2),%edx
  40bc0c:	mov    %r9,0x10(%rsp)
  40bc11:	add    0x28(%r12),%rdx
  40bc16:	mov    0x13088ab(%rip),%rdi        # 17144c8 <tcg_splitwx_diff>
  40bc1d:	mov    %esi,0x8(%rsp)
  40bc21:	mov    %rax,0x68(%r12,%r13,8)
  40bc26:	mov    %rdx,%rcx
  40bc29:	sub    %rdi,%rcx
  40bc2c:	add    %r12,%rdi
  40bc2f:	call   3e2720 <tb_target_set_jmp_target>
  40bc34:	mov    0x78(%rbx),%rax
  40bc38:	mov    %rax,0x80(%r12,%r13,8)
  40bc40:	or     %r12,%r13
  40bc43:	mov    %r13,0x78(%rbx)
  40bc47:	movl   $0x0,0x0(%rbp)
  40bc4e:	testb  $0x20,0x133cf8b(%rip)        # 1748be0 <qemu_loglevel>
  40bc55:	mov    0x8(%rsp),%esi
  40bc59:	mov    0x10(%rsp),%r9
  40bc5e:	je     40bb49 <cpu_exec_loop+0x209>
  40bc64:	mov    0x28(%r12),%rax
  40bc69:	mov    0x28(%rbx),%rcx
  40bc6d:	mov    %esi,%edx
  40bc6f:	mov    %r9,0x8(%rsp)
  40bc74:	lea    0xccd73d(%rip),%rdi        # 10d93b8 <anon.53529a8b42b516fa44fa3e141ddff7ec.0.llvm.534248872324339782+0x2d88f>
  40bc7b:	mov    %rax,%rsi
  40bc7e:	xor    %eax,%eax
  40bc80:	call   66e8b0 <qemu_log>
  40bc85:	mov    0x133d2bc(%rip),%r8d        # 1748f48 <trace_events_enabled_count>
  40bc8c:	mov    0x8(%rsp),%r9
  40bc91:	test   %r8d,%r8d
  40bc94:	je     40bb59 <cpu_exec_loop+0x219>
  40bc9a:	nopw   0x0(%rax,%rax,1)
  40bca0:	cmpw   $0x0,0x133c56e(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40bca8:	je     40bb59 <cpu_exec_loop+0x219>
  40bcae:	testb  $0x80,0x133cf2c(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bcb5:	je     40bb59 <cpu_exec_loop+0x219>
  40bcbb:	mov    %r9,%rdx
  40bcbe:	mov    %rbx,%rsi
  40bcc1:	lea    0xc4cae1(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40bcc8:	xor    %eax,%eax
  40bcca:	call   66e8b0 <qemu_log>
  40bccf:	jmp    40bb59 <cpu_exec_loop+0x219>
  40bcd4:	nopl   0x0(%rax)
  40bcd8:	pause
  40bcda:	mov    0x0(%rbp),%eax
  40bcdd:	test   %eax,%eax
  40bcdf:	jne    40bcd8 <cpu_exec_loop+0x398>
  40bce1:	jmp    40bbd6 <cpu_exec_loop+0x296>
  40bce6:	cs nopw 0x0(%rax,%rax,1)
  40bcf0:	movd   %r8d,%xmm2
  40bcf5:	movd   %r13d,%xmm1
  40bcfa:	mov    %r10,%rdi
  40bcfd:	mov    %r9,0x20(%rsp)
  40bd02:	punpckldq %xmm2,%xmm1
  40bd06:	mov    %r11,0x18(%rsp)
  40bd0b:	mov    %r8d,0x2c(%rsp)
  40bd10:	mov    %r10,0x10(%rsp)
  40bd15:	movq   %xmm1,0x8(%rsp)
  40bd1b:	call   41be00 <tcg_victim_cache_epoch>
  40bd20:	mov    0x20(%rsp),%r9
  40bd25:	sub    $0x20,%rsp
  40bd29:	mov    %ebp,%esi
  40bd2b:	mov    %rax,%r13
  40bd2e:	mov    0x38(%rsp),%r11
  40bd33:	mov    0x28(%rsp),%rax
  40bd38:	mov    %r9,0x90(%rsp)
  40bd40:	mov    %r13,%rdx
  40bd43:	mov    %rax,0x98(%rsp)
  40bd4b:	mov    %r11,0xa0(%rsp)
  40bd53:	mov    0x30(%rsp),%rdi
  40bd58:	movdqa 0x90(%rsp),%xmm0
  40bd61:	mov    %r11,0x10(%rsp)
  40bd66:	mov    %r11,0x38(%rsp)
  40bd6b:	movups %xmm0,(%rsp)
  40bd6f:	call   41c070 <tcg_victim_cache_lookup>
  40bd74:	add    $0x20,%rsp
  40bd78:	mov    0x10(%rsp),%r10
  40bd7d:	mov    0x18(%rsp),%r11
  40bd82:	test   %rax,%rax
  40bd85:	mov    %rax,%rbx
  40bd88:	mov    0x20(%rsp),%r9
  40bd8d:	mov    0x2c(%rsp),%r8d
  40bd92:	jne    40bb2a <cpu_exec_loop+0x1ea>
  40bd98:	mov    0x8(%rsp),%rax
  40bd9d:	mov    %r8d,0x18(%rsp)
  40bda2:	mov    %r14,%rdi
  40bda5:	sub    $0x20,%rsp
  40bda9:	mov    %r10,0x40(%rsp)
  40bdae:	lea    -0xe75(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40bdb5:	lea    0x1322524(%rip),%rsi        # 172e2e0 <tb_ctx>
  40bdbc:	mov    %r9,0xb0(%rsp)
  40bdc4:	mov    %r9,0x30(%rsp)
  40bdc9:	mov    %rax,0xb8(%rsp)
  40bdd1:	mov    %r11,0xc0(%rsp)
  40bdd9:	movdqa 0xb0(%rsp),%xmm0
  40bde2:	mov    %r11,0x10(%rsp)
  40bde7:	movups %xmm0,(%rsp)
  40bdeb:	call   40b0e0 <tb_htable_lookup_common>
  40bdf0:	add    $0x20,%rsp
  40bdf4:	mov    0x10(%rsp),%r9
  40bdf9:	mov    0x18(%rsp),%r8d
  40bdfe:	test   %rax,%rax
  40be01:	mov    %rax,%rbx
  40be04:	je     40c1a8 <cpu_exec_loop+0x868>
  40be0a:	mov    0x20(%rsp),%rdi
  40be0f:	mov    %r9,%rdx
  40be12:	mov    %r13,%r8
  40be15:	mov    %rax,%rcx
  40be18:	mov    %ebp,%esi
  40be1a:	mov    %r9,0x8(%rsp)
  40be1f:	call   41be40 <tcg_victim_cache_fill>
  40be24:	mov    0x8(%rsp),%r9
  40be29:	jmp    40bb2a <cpu_exec_loop+0x1ea>
  40be2e:	xchg   %ax,%ax
  40be30:	movl   $0x0,0x0(%rbp)
  40be37:	jmp    40bb49 <cpu_exec_loop+0x209>
  40be3c:	nopl   0x0(%rax)
  40be40:	mov    0x4b50(%r14),%eax
  40be47:	test   %eax,%eax
  40be49:	js     40bebf <cpu_exec_loop+0x57f>
  40be4b:	mov    0x1322527(%rip),%edi        # 172e378 <use_icount>
  40be51:	test   %edi,%edi
  40be53:	je     1e8491 <cpu_exec_loop.cold+0x5d>
  40be59:	mov    %r14,%rdi
  40be5c:	call   428b90 <icount_update>
  40be61:	mov    0xd8(%r14),%rdx
  40be68:	mov    $0xffff,%eax
  40be6d:	cmp    %rax,%rdx
  40be70:	cmovle %rdx,%rax
  40be74:	movslq %eax,%rcx
  40be77:	mov    %ax,0x4b50(%r14)
  40be7f:	sub    %rcx,%rdx
  40be82:	mov    %rdx,0xe0(%r14)
  40be89:	test   %eax,%eax
  40be8b:	jle    40bebf <cpu_exec_loop+0x57f>
  40be8d:	movzwl 0x1a(%r12),%ecx
  40be93:	cmp    %ecx,%eax
  40be95:	jge    40bebf <cpu_exec_loop+0x57f>
  40be97:	cmp    $0x1ff,%eax
  40be9c:	jg     1e8472 <cpu_exec_loop.cold+0x3e>
  40bea2:	test   %rdx,%rdx
  40bea5:	jne    1e84b0 <cpu_exec_loop.cold+0x7c>
  40beab:	mov    0x14(%r12),%edx
  40beb0:	and    $0xfffffe00,%edx
  40beb6:	or     %edx,%eax
  40beb8:	mov    %eax,0xcc(%r14)
  40bebf:	xor    %r12d,%r12d
  40bec2:	jmp    40bb77 <cpu_exec_loop+0x237>
  40bec7:	nopw   0x0(%rax,%rax,1)
  40bed0:	mov    0xd4(%r14),%r10d
  40bed7:	mov    0x2c8(%r14),%r8d
  40bede:	test   %r10d,%r10d
  40bee1:	jne    40c198 <cpu_exec_loop+0x858>
  40bee7:	movzbl 0x13223de(%rip),%eax        # 172e2cc <one_insn_per_tb>
  40beee:	test   %al,%al
  40bef0:	je     40bfc0 <cpu_exec_loop+0x680>
  40bef6:	or     $0x201,%r8d
  40befd:	cmpq   $0x0,0x240(%r14)
  40bf05:	je     40baaf <cpu_exec_loop+0x16f>
  40bf0b:	nopl   0x0(%rax,%rax,1)
  40bf10:	lea    0x5c(%rsp),%rdx
  40bf15:	mov    %r9,%rsi
  40bf18:	mov    %r14,%rdi
  40bf1b:	mov    %r9,0x50(%rsp)
  40bf20:	mov    %r8d,0x5c(%rsp)
  40bf25:	call   40afd0 <check_for_breakpoints_slow>
  40bf2a:	test   %al,%al
  40bf2c:	jne    40c0c0 <cpu_exec_loop+0x780>
  40bf32:	mov    0x50(%rsp),%r9
  40bf37:	mov    0x5c(%rsp),%r8d
  40bf3c:	jmp    40baaf <cpu_exec_loop+0x16f>
  40bf41:	nopl   0x0(%rax)
  40bf48:	movabs $0x112e0be826d694b3,%rax
  40bf52:	pxor   %xmm0,%xmm0
  40bf56:	lea    0x40(%rsp),%rdi
  40bf5b:	imul   %rcx
  40bf5e:	mov    %rcx,%rax
  40bf61:	lea    0x90(%rsp),%rsi
  40bf69:	movaps %xmm0,0x90(%rsp)
  40bf71:	sar    $0x3f,%rax
  40bf75:	sar    $0x1a,%rdx
  40bf79:	sub    %rax,%rdx
  40bf7c:	mov    %rdx,0x40(%rsp)
  40bf81:	imul   $0x3b9aca00,%rdx,%rdx
  40bf88:	sub    %rdx,%rcx
  40bf8b:	mov    %rcx,0x48(%rsp)
  40bf90:	call   1d66b0 <nanosleep@plt>
  40bf95:	mov    %eax,%edx
  40bf97:	xor    %eax,%eax
  40bf99:	test   %edx,%edx
  40bf9b:	jns    40bfb1 <cpu_exec_loop+0x671>
  40bf9d:	imul   $0x3b9aca00,0x90(%rsp),%rax
  40bfa9:	add    0x98(%rsp),%rax
  40bfb1:	mov    %rax,(%r15)
  40bfb4:	jmp    40bbb4 <cpu_exec_loop+0x274>
  40bfb9:	nopl   0x0(%rax)
  40bfc0:	mov    %r8d,%eax
  40bfc3:	or     $0x2,%ah
  40bfc6:	testb  $0x20,0x133cc14(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40bfcd:	cmovne %eax,%r8d
  40bfd1:	jmp    40baa1 <cpu_exec_loop+0x161>
  40bfd6:	cs nopw 0x0(%rax,%rax,1)
  40bfe0:	mov    $0x365,%esi
  40bfe5:	lea    0xc4c75f(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40bfec:	call   368ff0 <bql_lock_impl>
  40bff1:	mov    0xd0(%r14),%eax
  40bff8:	test   $0x80,%al
  40bffa:	jne    40c260 <cpu_exec_loop+0x920>
  40c000:	cmpl   $0x2,0x1308321(%rip)        # 1714328 <replay_mode>
  40c007:	je     40c160 <cpu_exec_loop+0x820>
  40c00d:	mov    0xd0(%r14),%eax
  40c014:	test   $0x20,%al
  40c016:	jne    40c228 <cpu_exec_loop+0x8e8>
  40c01c:	mov    0x98(%r14),%rax
  40c023:	mov    0xd0(%r14),%ebx
  40c02a:	mov    0x150(%rax),%rbp
  40c031:	mov    0xd0(%r14),%eax
  40c038:	test   $0x4,%ah
  40c03b:	jne    40c0ac <cpu_exec_loop+0x76c>
  40c03d:	mov    %ebx,%eax
  40c03f:	mov    %r14,%rdi
  40c042:	and    $0xffffeda5,%eax
  40c047:	testb  $0x2,0xd4(%r14)
  40c04f:	cmovne %eax,%ebx
  40c052:	mov    %ebx,%esi
  40c054:	call   *0x58(%rbp)
  40c057:	test   %al,%al
  40c059:	je     40c08c <cpu_exec_loop+0x74c>
  40c05b:	mov    0xb8(%rbp),%rax
  40c062:	test   %rax,%rax
  40c065:	je     40c0a5 <cpu_exec_loop+0x765>
  40c067:	mov    %ebx,%edi
  40c069:	call   *%rax
  40c06b:	test   %al,%al
  40c06d:	jne    40c0a5 <cpu_exec_loop+0x765>
  40c06f:	mov    0xd4(%r14),%esi
  40c076:	test   %esi,%esi
  40c078:	jne    40c35c <cpu_exec_loop+0xa1c>
  40c07e:	movl   $0xffffffff,0x2d0(%r14)
  40c089:	xor    %r12d,%r12d
  40c08c:	mov    0xd0(%r14),%eax
  40c093:	test   $0x4,%al
  40c095:	jne    40c17c <cpu_exec_loop+0x83c>
  40c09b:	call   369040 <bql_unlock>
  40c0a0:	jmp    40b9d9 <cpu_exec_loop+0x99>
  40c0a5:	call   3d1210 <replay_interrupt>
  40c0aa:	jmp    40c06f <cpu_exec_loop+0x72f>
  40c0ac:	call   3d1210 <replay_interrupt>
  40c0b1:	mov    %r14,%rdi
  40c0b4:	call   *0x60(%rbp)
  40c0b7:	call   369040 <bql_unlock>
  40c0bc:	nopl   0x0(%rax)
  40c0c0:	mov    0x2d0(%r14),%ebx
  40c0c7:	test   %ebx,%ebx
  40c0c9:	js     40b970 <cpu_exec_loop+0x30>
  40c0cf:	cmp    $0xffff,%ebx
  40c0d5:	jg     40c289 <cpu_exec_loop+0x949>
  40c0db:	call   3d10e0 <replay_exception>
  40c0e0:	test   %al,%al
  40c0e2:	je     40c2c8 <cpu_exec_loop+0x988>
  40c0e8:	mov    0x98(%r14),%rax
  40c0ef:	mov    $0x319,%esi
  40c0f4:	lea    0xc4c650(%rip),%rdi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c0fb:	mov    0x150(%rax),%rbx
  40c102:	call   368ff0 <bql_lock_impl>
  40c107:	mov    %r14,%rdi
  40c10a:	call   *0x50(%rbx)
  40c10d:	call   369040 <bql_unlock>
  40c112:	mov    0xd4(%r14),%eax
  40c119:	movl   $0xffffffff,0x2d0(%r14)
  40c124:	test   %eax,%eax
  40c126:	je     40b990 <cpu_exec_loop+0x50>
  40c12c:	mov    0x98(%r14),%rax
  40c133:	cmpq   $0x0,0x260(%r14)
  40c13b:	mov    0x150(%rax),%rdx
  40c142:	je     40c378 <cpu_exec_loop+0xa38>
  40c148:	mov    0x40(%rdx),%rax
  40c14c:	test   %rax,%rax
  40c14f:	je     40c156 <cpu_exec_loop+0x816>
  40c151:	mov    %r14,%rdi
  40c154:	call   *%rax
  40c156:	mov    $0x10002,%ebx
  40c15b:	jmp    40ba3c <cpu_exec_loop+0xfc>
  40c160:	call   3d1300 <replay_has_interrupt>
  40c165:	test   %al,%al
  40c167:	jne    40c00d <cpu_exec_loop+0x6cd>
  40c16d:	mov    0xd0(%r14),%eax
  40c174:	test   $0x4,%al
  40c176:	je     40c09b <cpu_exec_loop+0x75b>
  40c17c:	mov    $0x4,%esi
  40c181:	mov    %r14,%rdi
  40c184:	xor    %r12d,%r12d
  40c187:	call   248f50 <cpu_reset_interrupt>
  40c18c:	jmp    40c09b <cpu_exec_loop+0x75b>
  40c191:	nopl   0x0(%rax)
  40c198:	or     $0xe01,%r8d
  40c19f:	jmp    40baa1 <cpu_exec_loop+0x161>
  40c1a4:	nopl   0x0(%rax)
  40c1a8:	mov    0x218(%r14),%rdi
  40c1af:	mov    %r9,0x8(%rsp)
  40c1b4:	mov    %r8d,0x10(%rsp)
  40c1b9:	call   41be00 <tcg_victim_cache_epoch>
  40c1be:	mov    0x8(%rsp),%r9
  40c1c3:	mov    0x10(%rsp),%r8d
  40c1c8:	mov    %r14,%rdi
  40c1cb:	sub    $0x20,%rsp
  40c1cf:	mov    %rax,%r13
  40c1d2:	mov    %r9,0x70(%rsp)
  40c1d7:	mov    %r8d,0x7c(%rsp)
  40c1dc:	movdqa 0x70(%rsp),%xmm0
  40c1e2:	mov    0x80(%rsp),%rax
  40c1ea:	movups %xmm0,(%rsp)
  40c1ee:	mov    %rax,0x10(%rsp)
  40c1f3:	call   41a3c0 <tb_gen_code>
  40c1f8:	mov    0x28(%rsp),%rdx
  40c1fd:	add    $0x20,%rsp
  40c201:	mov    %ebp,%esi
  40c203:	mov    0x218(%r14),%rdi
  40c20a:	mov    %r13,%r8
  40c20d:	mov    %rax,%rcx
  40c210:	mov    %rax,%rbx
  40c213:	call   41be40 <tcg_victim_cache_fill>
  40c218:	mov    0x8(%rsp),%r9
  40c21d:	jmp    40bb3d <cpu_exec_loop+0x1fd>
  40c222:	nopw   0x0(%rax,%rax,1)
  40c228:	call   3d1210 <replay_interrupt>
  40c22d:	mov    $0x20,%esi
  40c232:	mov    %r14,%rdi
  40c235:	call   248f50 <cpu_reset_interrupt>
  40c23a:	movabs $0x1000100000001,%rax
  40c244:	mov    %rax,0x2cc(%r14)
  40c24b:	call   369040 <bql_unlock>
  40c250:	mov    0x2d0(%r14),%ebx
  40c257:	jmp    40b95d <cpu_exec_loop+0x1d>
  40c25c:	nopl   0x0(%rax)
  40c260:	mov    $0x80,%esi
  40c265:	mov    %r14,%rdi
  40c268:	call   248f50 <cpu_reset_interrupt>
  40c26d:	movl   $0x10002,0x2d0(%r14)
  40c278:	call   369040 <bql_unlock>
  40c27d:	mov    0x2d0(%r14),%ebx
  40c284:	jmp    40b95d <cpu_exec_loop+0x1d>
  40c289:	cmp    $0x10002,%ebx
  40c28f:	jne    40ba31 <cpu_exec_loop+0xf1>
  40c295:	mov    0x98(%r14),%rax
  40c29c:	cmpq   $0x0,0x260(%r14)
  40c2a4:	mov    0x150(%rax),%rdx
  40c2ab:	je     40c325 <cpu_exec_loop+0x9e5>
  40c2ad:	mov    0x40(%rdx),%rax
  40c2b1:	test   %rax,%rax
  40c2b4:	je     40ba31 <cpu_exec_loop+0xf1>
  40c2ba:	mov    %r14,%rdi
  40c2bd:	call   *%rax
  40c2bf:	jmp    40ba31 <cpu_exec_loop+0xf1>
  40c2c4:	nopl   0x0(%rax)
  40c2c8:	call   3d1300 <replay_has_interrupt>
  40c2cd:	test   %al,%al
  40c2cf:	jne    40b990 <cpu_exec_loop+0x50>
  40c2d5:	mov    $0x10000,%ebx
  40c2da:	jmp    40ba3c <cpu_exec_loop+0xfc>
  40c2df:	mov    0xd4(%r14),%edx
  40c2e6:	mov    0x2c8(%r14),%eax
  40c2ed:	test   %edx,%edx
  40c2ef:	jne    40c39d <cpu_exec_loop+0xa5d>
  40c2f5:	movzbl 0x1321fd0(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40c2fc:	test   %dl,%dl
  40c2fe:	jne    40c355 <cpu_exec_loop+0xa15>
  40c300:	mov    %eax,%edx
  40c302:	or     $0x2,%dh
  40c305:	testb  $0x20,0x133c8d5(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c30c:	cmovne %edx,%eax
  40c30f:	and    $0xfffedffe,%eax
  40c314:	or     $0x10001,%eax
  40c319:	mov    %eax,0xcc(%r14)
  40c320:	jmp    40b997 <cpu_exec_loop+0x57>
  40c325:	mov    0x250(%r14),%rax
  40c32c:	test   %rax,%rax
  40c32f:	je     40c2ad <cpu_exec_loop+0x96d>
  40c335:	data16 cs nopw 0x0(%rax,%rax,1)
  40c340:	andl   $0xffffff3f,0x20(%rax)
  40c347:	mov    0x28(%rax),%rax
  40c34b:	test   %rax,%rax
  40c34e:	jne    40c340 <cpu_exec_loop+0xa00>
  40c350:	jmp    40c2ad <cpu_exec_loop+0x96d>
  40c355:	or     $0x201,%eax
  40c35a:	jmp    40c30f <cpu_exec_loop+0x9cf>
  40c35c:	movl   $0x10002,0x2d0(%r14)
  40c367:	call   369040 <bql_unlock>
  40c36c:	mov    0x2d0(%r14),%ebx
  40c373:	jmp    40b95d <cpu_exec_loop+0x1d>
  40c378:	mov    0x250(%r14),%rax
  40c37f:	test   %rax,%rax
  40c382:	je     40c148 <cpu_exec_loop+0x808>
  40c388:	andl   $0xffffff3f,0x20(%rax)
  40c38f:	mov    0x28(%rax),%rax
  40c393:	test   %rax,%rax
  40c396:	jne    40c388 <cpu_exec_loop+0xa48>
  40c398:	jmp    40c148 <cpu_exec_loop+0x808>
  40c39d:	or     $0xe01,%eax
  40c3a2:	jmp    40c30f <cpu_exec_loop+0x9cf>

Disassembly of section .fini:

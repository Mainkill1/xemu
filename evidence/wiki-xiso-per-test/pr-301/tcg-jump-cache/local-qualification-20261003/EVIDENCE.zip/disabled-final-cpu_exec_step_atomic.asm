
/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/build-off/qemu-system-i386:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000040c410 <cpu_exec_step_atomic>:
  40c410:	push   %r14
  40c412:	xor    %esi,%esi
  40c414:	push   %r13
  40c416:	push   %r12
  40c418:	push   %rbp
  40c419:	push   %rbx
  40c41a:	sub    $0x60,%rsp
  40c41e:	mov    %rdi,0x8(%rsp)
  40c423:	add    $0xf0,%rdi
  40c42a:	movl   $0x0,0x1c(%rsp)
  40c432:	call   1d7ed0 <__sigsetjmp@plt>
  40c437:	test   %eax,%eax
  40c439:	jne    40c600 <cpu_exec_step_atomic+0x1f0>
  40c43f:	call   24a650 <start_exclusive>
  40c444:	mov    $0xfffffffffffff938,%rax
  40c44b:	mov    0x8(%rsp),%rcx
  40c450:	cmp    %rcx,%fs:(%rax)
  40c454:	jne    40c6be <cpu_exec_step_atomic+0x2ae>
  40c45a:	mov    0x8(%rsp),%rbx
  40c45f:	cmpb   $0x0,0xb4(%rbx)
  40c466:	jne    40c745 <cpu_exec_step_atomic+0x335>
  40c46c:	mov    0x98(%rbx),%rax
  40c473:	movb   $0x1,0xb4(%rbx)
  40c47a:	mov    %rbx,%rsi
  40c47d:	lea    0x20(%rsp),%rdi
  40c482:	mov    0x150(%rax),%rax
  40c489:	call   *0x18(%rax)
  40c48c:	mov    0xd4(%rbx),%esi
  40c492:	mov    0x2c8(%rbx),%eax
  40c498:	test   %esi,%esi
  40c49a:	jne    40c6e0 <cpu_exec_step_atomic+0x2d0>
  40c4a0:	movzbl 0x1321e25(%rip),%edx        # 172e2cc <one_insn_per_tb>
  40c4a7:	test   %dl,%dl
  40c4a9:	je     40c610 <cpu_exec_step_atomic+0x200>
  40c4af:	or     $0x201,%eax
  40c4b4:	and    $0x7f,%ah
  40c4b7:	mov    0x20(%rsp),%r13
  40c4bc:	mov    0x28(%rsp),%esi
  40c4c0:	or     $0x601,%eax
  40c4c5:	mov    0x30(%rsp),%rdi
  40c4ca:	mov    %eax,0x2c(%rsp)
  40c4ce:	mov    %eax,%edx
  40c4d0:	mov    0x12d666e(%rip),%eax        # 16e2b44 <target_page+0x4>
  40c4d6:	lea    -0x6(%rax),%ecx
  40c4d9:	mov    %r13,%rax
  40c4dc:	shr    %cl,%rax
  40c4df:	xor    %r13,%rax
  40c4e2:	mov    %rax,%rbp
  40c4e5:	and    $0x3f,%eax
  40c4e8:	shr    %cl,%rbp
  40c4eb:	and    $0xfc0,%ebp
  40c4f1:	or     %eax,%ebp
  40c4f3:	mov    0x8(%rsp),%rax
  40c4f8:	lea    0x1(%rbp),%r12d
  40c4fc:	mov    0x218(%rax),%r14
  40c503:	shl    $0x4,%r12
  40c507:	add    %r14,%r12
  40c50a:	mov    (%r12),%rbx
  40c50e:	test   %rbx,%rbx
  40c511:	je     40c628 <cpu_exec_step_atomic+0x218>
  40c517:	mov    %ebp,%eax
  40c519:	shl    $0x4,%rax
  40c51d:	cmp    %r13,0x18(%rax,%r14,1)
  40c522:	jne    40c628 <cpu_exec_step_atomic+0x218>
  40c528:	cmp    %rdi,0x8(%rbx)
  40c52c:	jne    40c628 <cpu_exec_step_atomic+0x218>
  40c532:	cmp    %esi,0x10(%rbx)
  40c535:	jne    40c628 <cpu_exec_step_atomic+0x218>
  40c53b:	mov    0x14(%rbx),%eax
  40c53e:	cmp    %eax,%edx
  40c540:	jne    40c628 <cpu_exec_step_atomic+0x218>
  40c546:	mov    0x14(%rbx),%eax
  40c549:	test   $0x20000,%eax
  40c54e:	jne    40c559 <cpu_exec_step_atomic+0x149>
  40c550:	cmp    (%rbx),%r13
  40c553:	jne    1e84cf <cpu_exec_step_atomic.cold>
  40c559:	mov    0x8(%rsp),%rax
  40c55e:	mov    0x98(%rax),%rax
  40c565:	mov    0x150(%rax),%rax
  40c56c:	mov    0x30(%rax),%rax
  40c570:	test   %rax,%rax
  40c573:	je     40c57c <cpu_exec_step_atomic+0x16c>
  40c575:	mov    0x8(%rsp),%rdi
  40c57a:	call   *%rax
  40c57c:	mov    0x133c9c6(%rip),%ecx        # 1748f48 <trace_events_enabled_count>
  40c582:	test   %ecx,%ecx
  40c584:	jne    40c6f0 <cpu_exec_step_atomic+0x2e0>
  40c58a:	mov    %rbx,%rsi
  40c58d:	mov    0x8(%rsp),%rbx
  40c592:	lea    0x1c(%rsp),%rdx
  40c597:	mov    %rbx,%rdi
  40c59a:	call   40b500 <cpu_tb_exec>
  40c59f:	mov    0x98(%rbx),%rax
  40c5a6:	mov    0x150(%rax),%rax
  40c5ad:	mov    0x38(%rax),%rax
  40c5b1:	test   %rax,%rax
  40c5b4:	je     40c5bd <cpu_exec_step_atomic+0x1ad>
  40c5b6:	mov    0x8(%rsp),%rdi
  40c5bb:	call   *%rax
  40c5bd:	mov    0x8(%rsp),%rax
  40c5c2:	mov    0xc8(%rax),%edx
  40c5c8:	test   %edx,%edx
  40c5ca:	je     40c724 <cpu_exec_step_atomic+0x314>
  40c5d0:	movb   $0x0,0xb4(%rax)
  40c5d7:	call   24a810 <end_exclusive>
  40c5dc:	add    $0x60,%rsp
  40c5e0:	pop    %rbx
  40c5e1:	pop    %rbp
  40c5e2:	pop    %r12
  40c5e4:	pop    %r13
  40c5e6:	pop    %r14
  40c5e8:	xor    %eax,%eax
  40c5ea:	xor    %edx,%edx
  40c5ec:	xor    %ecx,%ecx
  40c5ee:	xor    %esi,%esi
  40c5f0:	xor    %edi,%edi
  40c5f2:	xor    %r8d,%r8d
  40c5f5:	ret
  40c5f6:	cs nopw 0x0(%rax,%rax,1)
  40c600:	mov    0x8(%rsp),%rdi
  40c605:	call   40b360 <cpu_exec_longjmp_cleanup>
  40c60a:	jmp    40c5bd <cpu_exec_step_atomic+0x1ad>
  40c60c:	nopl   0x0(%rax)
  40c610:	mov    %eax,%edx
  40c612:	or     $0x2,%dh
  40c615:	testb  $0x20,0x133c5c5(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c61c:	cmovne %edx,%eax
  40c61f:	jmp    40c4b4 <cpu_exec_step_atomic+0xa4>
  40c624:	nopl   0x0(%rax)
  40c628:	movd   %edx,%xmm1
  40c62c:	movd   %esi,%xmm0
  40c630:	mov    %r13,0x40(%rsp)
  40c635:	sub    $0x20,%rsp
  40c639:	punpckldq %xmm1,%xmm0
  40c63d:	mov    %rdi,0x70(%rsp)
  40c642:	lea    -0x1709(%rip),%rdx        # 40af40 <tb_lookup_cmp>
  40c649:	lea    0x1321c90(%rip),%rsi        # 172e2e0 <tb_ctx>
  40c650:	movq   %xmm0,0x68(%rsp)
  40c656:	movdqa 0x60(%rsp),%xmm0
  40c65c:	mov    %rdi,0x10(%rsp)
  40c661:	mov    0x28(%rsp),%rdi
  40c666:	movups %xmm0,(%rsp)
  40c66a:	call   40b0e0 <tb_htable_lookup_common>
  40c66f:	add    $0x20,%rsp
  40c673:	mov    %rax,%rbx
  40c676:	test   %rax,%rax
  40c679:	je     40c690 <cpu_exec_step_atomic+0x280>
  40c67b:	shl    $0x4,%rbp
  40c67f:	mov    %r13,0x18(%rbp,%r14,1)
  40c684:	mov    %rax,(%r12)
  40c688:	jmp    40c546 <cpu_exec_step_atomic+0x136>
  40c68d:	nopl   (%rax)
  40c690:	sub    $0x20,%rsp
  40c694:	movdqa 0x40(%rsp),%xmm0
  40c69a:	mov    0x50(%rsp),%rax
  40c69f:	mov    0x28(%rsp),%rdi
  40c6a4:	mov    %rax,0x10(%rsp)
  40c6a9:	movups %xmm0,(%rsp)
  40c6ad:	call   41a1e0 <tb_gen_code>
  40c6b2:	add    $0x20,%rsp
  40c6b6:	mov    %rax,%rbx
  40c6b9:	jmp    40c559 <cpu_exec_step_atomic+0x149>
  40c6be:	lea    0xc4c09e(%rip),%r8        # 1058763 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e23>
  40c6c5:	lea    0xdd8324(%rip),%rcx        # 11e49f0 <__func__.10>
  40c6cc:	mov    $0x26e,%edx
  40c6d1:	xor    %edi,%edi
  40c6d3:	lea    0xc4c071(%rip),%rsi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c6da:	call   1d54e0 <g_assertion_message_expr@plt>
  40c6df:	nop
  40c6e0:	or     $0xe01,%eax
  40c6e5:	jmp    40c4b4 <cpu_exec_step_atomic+0xa4>
  40c6ea:	nopw   0x0(%rax,%rax,1)
  40c6f0:	cmpw   $0x0,0x133bb1e(%rip)        # 1748216 <_TRACE_EXEC_TB_DSTATE>
  40c6f8:	je     40c58a <cpu_exec_step_atomic+0x17a>
  40c6fe:	testb  $0x80,0x133c4dc(%rip)        # 1748be1 <qemu_loglevel+0x1>
  40c705:	je     40c58a <cpu_exec_step_atomic+0x17a>
  40c70b:	mov    %r13,%rdx
  40c70e:	mov    %rbx,%rsi
  40c711:	lea    0xc4c091(%rip),%rdi        # 10587a9 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e69>
  40c718:	xor    %eax,%eax
  40c71a:	call   66e2f0 <qemu_log>
  40c71f:	jmp    40c58a <cpu_exec_step_atomic+0x17a>
  40c724:	lea    0xc4c0d7(%rip),%r8        # 1058802 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13ec2>
  40c72b:	lea    0xdd82be(%rip),%rcx        # 11e49f0 <__func__.10>
  40c732:	mov    $0x295,%edx
  40c737:	xor    %edi,%edi
  40c739:	lea    0xc4c00b(%rip),%rsi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c740:	call   1d54e0 <g_assertion_message_expr@plt>
  40c745:	lea    0xc4c0a8(%rip),%r8        # 10587f4 <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13eb4>
  40c74c:	lea    0xdd829d(%rip),%rcx        # 11e49f0 <__func__.10>
  40c753:	mov    $0x26f,%edx
  40c758:	xor    %edi,%edi
  40c75a:	lea    0xc4bfea(%rip),%rsi        # 105874b <anon.b6099f712a5ecfc5bdf9f49747300252.66.llvm.11930075988074840444+0x13e0b>
  40c761:	call   1d54e0 <g_assertion_message_expr@plt>

Disassembly of section .fini:

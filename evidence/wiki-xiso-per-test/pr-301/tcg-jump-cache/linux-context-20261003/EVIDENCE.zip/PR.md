## Recommendation: HOLD

**Summary:** Add a retained, opt-in Linux collector for the existing external diagnostic adapter. It records clocks/policies, thread placement and mappings to investigate unexplained timing variation; it changes no emulator or host policy. Source checks pass; native Deck use and diagnostic cost still need qualification.
**Remaining:** Native diagnostic use/cost evidence, current-head CI and human review.

### Problem

Whole-run utilization alone cannot explain timing variation when the run lacks frequency/policy, thread affinity and layout evidence. The owning performance investigation is [xemu #167](https://github.com/Mainkill1/xemu/issues/167).

### What this PR changes

- `tools/linux_performance_context.py`: standard-library Python tool reads procfs/sysfs and writes JSON Lines. Header identifies PID/start time and units. Samples record thread ticks, most recently executed CPU, allowed CPUs and context switches; CPU governor/driver/reported frequencies; raw DRM/hwmon readings; first process mappings and ASLR policy.
- Collection is bounded by sample count and interval. PID and thread identity checks discard snapshots crossing reuse. Missing/denied readings and malformed parsed proc fields remain explicit. Each sample reports collection duration.
- Eleven retained tests cover parsing, read-only behavior, missing data, process/thread reuse, real CLI collection and argument bounds.
- `DIAGNOSTICS.md` documents a package-pinned external recipe with all pause/resume flags false, artifact format and interpretation boundaries.

### Why this approach

Reuse the existing supervised external adapter and its command/stdout/stderr archival. The tool remains optional and adds no service, API, implicit sampler, dependency or host policy change. Package it with the application so its bytes are hashed. Instrumented runs remain diagnostic intervention and are separate from clean comparisons.

### Validation

| Source/tool check | Result |
|---|---|
| Existing Python suite before change | 89 passed |
| Final targeted / full Python suite | 11 / 100 passed, zero failures |
| Missing-feature and thread-reuse regressions | Observed RED then GREEN |
| Disabled final process-identity check | Negative control rejected, implementation restored |
| Diff check | Clean |

Local HTTP fixtures clear inherited SSH markers only in the fixture process; normal test operation retains the LAN-only policy. No C# runtime code changes or runner redeployment are required.

### Results

**Performance: N/A**—source verification does not establish an emulator gain. Native diagnostic records and emulator interpretation belong in [xemu draft #301](https://github.com/Mainkill1/xemu/pull/301); this PR contains the reusable tool and its tests.

### Risks and remaining questions

Host counters are read sequentially. CPUFreq values may represent requested rather than measured frequencies; lastProcessor does not count migrations. Sysfs readings remain raw strings. Missing permissions/support remain explicit, not zero. Collection has observer cost and must not be pooled with clean timing evidence. Linux/Python 3.9+ only; no root is required.

### Related work

Addresses the instrumentation gap in the ongoing xemu #167 investigation. Keep draft; no merge authorized.

> **Agent Declaration**: Created with assistance from Codex (GPT-6), with read-only review.

"""Summarize archived diagnostic records, never execution or benchmark selection."""
from pathlib import Path
import json,statistics,hashlib
p=Path(__file__).parent
summaries=[]
for run in sorted((p/'native').iterdir()):
 fs=list(run.glob('diagnostics/*linux-context/external.stdout.txt'));assert len(fs)==1
 records=[json.loads(x) for x in fs[0].read_text().splitlines()];samples=[r for r in records if r['type']=='sample']
 assert len(samples)==64 and records[-1]['type']=='finish' and records[-1]['status']=='sample_limit'
 assert all(s['status']=='captured' for s in samples)
 cpu=[];allowed=set();involuntary=[];clock=[];temps=[];power=[];gpu=[]
 for s in samples:
  v=[t for t in s['threads'] if t['name']=='CPU 0/TCG'];assert len(v)==1
  t=v[0];cpu.append(t['lastProcessor']);allowed.add(t['allowedCpus']);involuntary.append(t['involuntaryContextSwitches'])
  cpus=t['allowedCpus']
  for pol in s['cpuPolicies'].values():
   if pol['scaling_cur_freq'] is not None:clock.append(int(pol['scaling_cur_freq']))
  for card in s['gpu'].values():
   if card['gpu_busy_percent'] is not None:gpu.append(int(card['gpu_busy_percent']))
   for monitor in card['hwmon'].values():
    if monitor.get('temp1_input') is not None:temps.append(int(monitor['temp1_input']))
    if monitor.get('power1_average') is not None:power.append(int(monitor['power1_average']))
 duration=[s['captureDurationNs']/1e6 for s in samples];events=[json.loads(x) for x in (run/'operator-events.jsonl').read_text().splitlines()];activity=json.loads((run/'result.json').read_text())
 leaves=json.loads((run/'guest/results.txt').read_text());mapped=samples[0]['maps'];text=[line for line in mapped.splitlines() if 'r-xp' in line and line.endswith('/xemu')]
 detail={'runId':run.name,'samples':len(samples),'captureMedianMs':statistics.median(duration),'captureP95Ms':sorted(duration)[60],'captureMaxMs':max(duration),'captureTotalMs':sum(duration),'spanSeconds':(samples[-1]['monotonicNs']-samples[0]['monotonicNs'])/1e9,'vcpuLastObservedCpus':sorted(set(cpu)),'vcpuObservedCpuChanges':sum(a!=b for a,b in zip(cpu,cpu[1:])),'vcpuAllowedCpus':sorted(allowed),'vcpuInvoluntarySwitchDelta':involuntary[-1]-involuntary[0],'reportedFrequencyKhzMin':min(clock),'reportedFrequencyKhzMax':max(clock),'reportedFrequencyKhzMedian':statistics.median(clock),'hardwareFrequencyAvailable':all(pol['cpuinfo_cur_freq'] is not None for s in samples for pol in s['cpuPolicies'].values()),'driver':sorted(set(pol['scaling_driver'] for s in samples for pol in s['cpuPolicies'].values())),'governor':sorted(set(pol['scaling_governor'] for s in samples for pol in s['cpuPolicies'].values())),'gpuBusyMedian':statistics.median(gpu) if gpu else None,'temp1InputMin':min(temps) if temps else None,'temp1InputMax':max(temps) if temps else None,'power1AverageMin':min(power) if power else None,'power1AverageMax':max(power) if power else None,'randomizeVaSpace':samples[0]['randomizeVaSpace'],'mapsSha256':hashlib.sha256(mapped.encode()).hexdigest(),'xemuTextMappings':text,'sampleErrorMessages':sorted(set(e for s in samples for e in s['errors'])),'leafWorkSeconds':{l['id']:l['total_us']/1e6/l['sample_count'] for l in leaves},'operatorEventTypes':sorted(set(e['kind'] for e in events)), 'operatorActivity':activity['operatorActivity']}
 summaries.append(detail)
 print(run.name,'capture median/max ms',round(detail['captureMedianMs'],3),round(detail['captureMaxMs'],3),'observed CPU changes',detail['vcpuObservedCpuChanges'],'cpus',detail['vcpuLastObservedCpus'],'freq GHz',round(detail['reportedFrequencyKhzMin']/1e6,4),round(detail['reportedFrequencyKhzMax']/1e6,4),'guestwork',*[round(x,4) for x in detail['leafWorkSeconds'].values()])
(p/'context-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')

"""Four predeclared diagnostic attempts through maintained HTTP, never retry."""
import sys,json,subprocess,hashlib
from pathlib import Path
p=Path(__file__).parent;client=Path('/home/codex/src/steamdeck-xemu/worktrees/runner-standalone-process');sys.path.insert(0,str(client/'scripts'))
from runner_transport import RunnerApi
from runner_xiso import follow,read_report
from runner_workflows import Workflows
api=RunnerApi('http://10.0.0.123:9368');source=Path('/home/codex/src/steamdeck-xemu/worktrees/runner-linux-performance-context/tools/linux_performance_context.py')
assert source.read_bytes()==(p/'context-package/tools/linux_performance_context.py').read_bytes()
leaves=['cpu_translation_blocks.jump_cache_collision2','cpu_translation_blocks.jump_cache_collision8','cpu_translation_blocks.jump_cache_collision10','cpu_translation_blocks.jump_cache_noncollision8']
def save(name,value):(p/name).write_text(json.dumps(value,indent=2)+'\n')
def call(name,args):
 f=p/(name+'.json');assert not f.exists(),f
 r=subprocess.run(['python3',str(client/'scripts/runner_xiso.py'),'--url',api.url,*args],capture_output=True,text=True);f.write_text(r.stdout);(p/(name+'.stderr.log')).write_text(r.stderr);assert r.returncode==0,r.stdout+r.stderr;return json.loads(r.stdout)
ids=['i167-linux-context-20261003-'+str(i).zfill(3) for i in range(1,5)]
save('sequence-contract.json',{'campaigns':ids,'diagnosticOnly':True,'cleanBenchmark':False,'sameExecutableSha256':'51cd99ef27b7212ba75029c489b31b36b44f732302cee27276c2c62756357c24','scriptSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'settings':{'warmup_iterations':0,'measurement_iterations_multiplier':1,'gpu_completion_mode':'per_iteration'},'samples':64,'intervalMs':500,'pauseBefore':False,'resumeDuring':False,'pauseAfter':False})
for cid in ids:
 args=['select','i167-5679-linux-context-ef8-v1','--suite','i167-linux-context-v1-suite','--id',cid,'--mode','monolithic','--configuration-source','suite']
 for leaf in leaves:args+=['--test',leaf]
 call(cid+'-selected',args);plan=call(cid+'-plan',['plan',cid]);assert len(plan['attempts'])==1 and set(plan['tests'])==set(leaves)
 print('Frozen '+cid,flush=True)
for cid in ids:
 s=api.json('/api/v1/status');assert s['Phase']=='idle' and s['Queue']['Pending']==s['Queue']['Testing']==0,s
 call(cid+'-start',['start',cid]);print('Started diagnostic '+cid,flush=True)
 result=follow(api,cid,False);save(cid+'-wait.json',result);assert result['terminal']
 attempts=api.json('/api/v1/xiso-campaigns/'+cid+'/attempts');save(cid+'-attempts.json',attempts);assert len(attempts['items'])==1
 for a in attempts['items']:
  receipt=Workflows(api).collect(a['id'],p/'native',None,True);save(cid+'-collection.json',receipt)
  print(cid,a['runId'],a['execution'],a['correctness'],a['evidence'],a['comparison'],'files',receipt['fileCount'],flush=True)
 save(cid+'-report.json',read_report(api,cid,'json'))
save('sequence-complete.json',{'campaigns':ids,'completed':True})
print('All four diagnostic attempts archived; no clean performance comparison.',flush=True)

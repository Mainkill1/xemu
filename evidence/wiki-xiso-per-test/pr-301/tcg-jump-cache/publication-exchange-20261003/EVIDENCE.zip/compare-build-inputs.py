from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent;old=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8');new=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-publication-exchange')
# Compare exact frozen third-party source trees; exclude local git metadata.
old_names={d.name for d in (old/'subprojects').iterdir() if d.is_dir() and d.name!='packagecache'}
new_names={d.name for d in (new/'subprojects').iterdir() if d.is_dir() and d.name!='packagecache'}
records=[]
for name in sorted(old_names | new_names):
 a=old/'subprojects'/name;b=new/'subprojects'/name
 def digest(root):
  h=hashlib.sha256();count=0
  for f in sorted(root.rglob('*')):
   if f.is_file() and '.git' not in f.relative_to(root).parts:
    h.update(f.relative_to(root).as_posix().encode());h.update(b'\0');h.update(f.read_bytes());count+=1
  return {'sha256':h.hexdigest(),'files':count}
 x,y=digest(a),digest(b);assert x==y,(name,x,y);records.append({'dependency':name,'old':x,'candidate':y,'identical':True})
(p/'dependency-source-proof.json').write_text(json.dumps(records,indent=2)+'\n');print('All',len(records),'dependency source trees identical.')
# Compare source/config changes at the declared runtime boundaries.
for f in ('accel/tcg/cpu-exec.c','accel/tcg/tb-jmp-cache.h','accel/tcg/tb-victim-cache.h','include/qemu/atomic.h','meson.build','accel/tcg/meson.build'):
 assert (old/f).read_bytes()==(new/f).read_bytes(),f
print('Caller, layout, atomic definitions and build configuration sources unchanged.')

"""Observe/collect one maintained campaign. Never starts, cancels or retries."""
import sys,json
from pathlib import Path
p=Path(__file__).parent;client=Path('/home/codex/src/steamdeck-xemu/worktrees/runner-standalone-process');sys.path.insert(0,str(client/'scripts'))
from runner_transport import RunnerApi
from runner_xiso import follow,read_report
from runner_workflows import Workflows
label,cid=sys.argv[1:];api=RunnerApi('http://10.0.0.123:9368')
def save(name,data):(p/name).write_text(json.dumps(data,indent=2)+'\n')
result=follow(api,cid,False);save(label+'-wait.json',result);assert result['terminal']
rows=api.json('/api/v1/xiso-campaigns/'+cid+'/attempts');save(label+'-attempts.json',rows);assert len(rows['items'])==8 and rows['nextOffset'] is None
for row in rows['items']:
 r=Workflows(api).collect(row['id'],p/(label+'-collected'),None,True);save(label+'-'+row['label']+'-collection.json',r)
 print(row['label'],row['runId'],row['execution'],row['correctness'],row['evidence'],row['comparison'],r['fileCount'],'files',flush=True)
for f in ('json','markdown','csv'):
 r=read_report(api,cid,f);path=p/(label+'-report.'+('md' if f=='markdown' else f));save(path.name,r) if f=='json' else path.write_text(r)
print('Terminal '+cid+'; all outcomes and artifacts preserved.',flush=True)

## XISO campaign i167-publish-aa-20261003-001 — inconclusive

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 12 metric rows. Opposite ABBA/BAAB outcomes: 1.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 2 | 0 | +0.49% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 548094.25 | 552395.75 | -0.78% | -0.92% | +2.10% | max_us +1.61%, p95_us +1.61% |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 606364.75 | 594262.25 | +2.00% | -0.15% | +24.86% | max_us +2.11%, mean_us +1.74%, median_us +2.00%, min_us +1.14%, p95_us +2.11% (orders disagree) |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 1255793.50 | 1266804.25 | -0.88% | -0.97% | -5.71% | — |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 374171.00 | 367596.50 | +1.76% | -0.43% | +25.26% | max_us +3.48%, mean_us +2.10%, median_us +1.76%, min_us +1.57%, p95_us +3.48% |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

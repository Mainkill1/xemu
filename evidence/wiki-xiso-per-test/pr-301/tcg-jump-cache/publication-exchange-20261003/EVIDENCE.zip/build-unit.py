"""Build exact publication-exchange-worktree helper/unit sources with pinned existing generated headers.

Read frozen old-build compile/link commands; all new outputs go to this artifact
folder. No old binary/object or build definition is overwritten.
"""
import subprocess,shlex,json
from pathlib import Path
p=Path(__file__).parent;old=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8');new=Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-publication-exchange');build=old/'build-on'
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','tests/unit/test-tcg-victim-cache'],text=True).splitlines();sources=['tests/unit/test-tcg-victim-cache.c','accel/tcg/tb-victim-cache.c'];outputs=[];records=[]
for source in sources:
 raw=next(x for x in commands if ' -c ' in x and x.endswith(source));args=shlex.split(raw);clean=[];i=0;out=p/(Path(source).name+'.o')
 while i<len(args):
  if args[i] in ['-MD']:i+=1;continue
  if args[i] in ['-MQ','-MF']:i+=2;continue
  if args[i]=='-o':clean+=['-o',str(out)];i+=2;continue
  if args[i]=='-c':clean+=['-c',str(new/source)];i+=2;continue
  clean.append(args[i].replace(str(old),str(new)) if str(old) in args[i] else args[i]);i+=1
 subprocess.run(clean,cwd=build,check=True);outputs.append(out);records.append(clean)
args=shlex.split(commands[-1]);result=[];i=0
while i<len(args):
 if args[i]=='-o':result+=['-o',str(p/'test-tcg-victim-cache')];i+=2;continue
 if args[i].startswith('tests/unit/test-tcg-victim-cache.p/'):
  result.append(str(outputs[0] if args[i].endswith('/test-tcg-victim-cache.c.o') else outputs[1]));i+=1;continue
 result.append(args[i]);i+=1
subprocess.run(result,cwd=build,check=True);records.append(result);(p/'unit-command-receipt.json').write_text(json.dumps({'generatedHeadersFromFrozenBuild':str(build),'newSource':str(new),'commands':records},indent=2)+'\n')

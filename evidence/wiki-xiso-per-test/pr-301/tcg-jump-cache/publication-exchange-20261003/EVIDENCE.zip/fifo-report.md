## XISO campaign i167-publish-vs-fifo-20261003-001 — inconclusive

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 11 metric rows. Opposite ABBA/BAAB outcomes: 1.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 1 | 1 | -0.81% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 546275.25 | 552148.25 | -1.08% | +0.56% | -1.88% | max_us +2.06%, median_us -1.08%, p95_us +2.06% |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 588997.75 | 594511.00 | -0.94% | -1.47% | +0.42% | max_us -1.98%, mean_us -1.03%, p95_us -1.98% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 1258790.00 | 1158394.00 | +7.98% | +6.86% | +2.72% | max_us +5.50%, mean_us +7.32%, median_us +7.98%, min_us +7.30%, p95_us +5.50% |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 364945.50 | 367467.25 | -0.69% | -1.98% | +1.10% | — (orders disagree) |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

# Read-only source review

Reviewer found no code blocker in base587a832b3d0 → candidate1beff07a535acf153bf774ec578d5146b0143d23. Local QEMU docs/devel/atomics.rst defines qatomic_set_mb as the optimized qatomic_set+smp_mb shortcut. X86/s390 uses sequentially consistent exchange plus after-RMW compiler/signal barrier. Sanitizer/other-host fallback retains release-store + full fence. This orders preceding PC/victim metadata writes and pointer publication before epoch validation. Failed publication clearing, owner-only metadata, foreign invalidator ordering and storage lifetime remain unchanged. The discarded old exchange value is not dereferenced.

Disassembly confirms original relaxed pointer store + locked stack operation versus candidate memory xchg. Fresh changed-source14 helpers pass; these do not qualify real VM/lifecycle behavior or speedup. Full build target initially used wrong name xemu and failed; subsequent qemu-system-i386 build exits0 with14 fresh helper passes. Existing VMA/fpng warnings remain in the full build log. Native helper14 passes through immutable saved definition, all21 artifacts retained.

Default-OFF build source excludes tb-victim-cache.c (accel/tcg/meson.build option guard). No new source/layout/config flags affect that route. A fresh OFF executable was not built for this single-helper substitution; earlier OFF qualification remains historical.

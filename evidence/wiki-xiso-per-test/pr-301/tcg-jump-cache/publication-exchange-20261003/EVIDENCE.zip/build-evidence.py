from pathlib import Path
import hashlib
import json
import statistics
import zipfile

ROOT = Path(__file__).resolve().parent
DEST = Path('/home/codex/src/steamdeck-xemu/worktrees/issue167-victim8/evidence/wiki-xiso-per-test/pr-301/tcg-jump-cache/publication-exchange-20261003')
DEST.mkdir(exist_ok=False)
OLD = '51cd99ef27b7212ba75029c489b31b36b44f732302cee27276c2c62756357c24'
NEW = '0c856d3a4c82c7b049a52bb7b3bec0079799d038d5983be97ced449d9e899fcc'
LEAVES = ['jump_cache_collision2', 'jump_cache_collision8', 'jump_cache_collision10', 'jump_cache_noncollision8']
NAMES = ['2 colliding targets', '8 colliding targets', '10 colliding targets (above capacity)', '8 noncolliding targets (control)']


def load(path):
    return json.loads(path.read_text())


def rows(prefix):
    return [next(r for r in load(ROOT / f'{prefix}-report.json')['rows']
                 if r['testId'] == 'cpu_translation_blocks.' + leaf and r['metric'] == 'mean_us')
            for leaf in LEAVES]


def table(prefix):
    lines = ['| Workload | Backend | Before | After | Time saved | Improvement % | ABBA / BAAB | CPU correctness |',
             '|---|---|---:|---:|---:|---:|---:|---|']
    for name, r in zip(NAMES, rows(prefix)):
        a, b = r['a']['median'] / 1e6, r['b']['median'] / 1e6
        improvement = 100 * (a - b) / a
        assert abs(improvement - r['improvementPercent']) < 1e-5
        lines.append(f"| {name} | Vulkan | {a:.6f} s | {b:.6f} s | {a-b:+.6f} s | **{improvement:+.2f}%** | {r['abbaImprovementPercent']:+.2f}% / {r['baabImprovementPercent']:+.2f}% | 8/8 PASS |")
    return '\n'.join(lines)


attempts = []
artifacts = 0
for prefix in ('aa', 'fifo'):
    report = load(ROOT / f'{prefix}-report.json')
    assert report['status'] == 'inconclusive' and report['indexedAttempts'] == 8 and not report['blockers']
    plan = load(ROOT / f'{prefix}-plan.json')
    assert plan['settings'] == {'warmup_iterations': 0, 'measurement_iterations_multiplier': 1, 'gpu_completion_mode': 'per_iteration'}
    items = load(ROOT / f'{prefix}-attempts.json')['items']
    assert [x['label'] for x in items] == ['A1', 'B1', 'B2', 'A2', 'B3', 'A3', 'A4', 'B4']
    for item in items:
        assert item['execution'] == 'completed' and item['correctness'] == 'passed' and item['evidence'] == 'complete' and item['comparison'] == 'eligible'
        receipt = load(ROOT / f"{prefix}-{item['label']}-collection.json")
        assert receipt['complete'] and receipt['excluded'] == 0 and receipt['fileCount'] == 310
        artifacts += receipt['fileCount']
        run = ROOT / f'{prefix}-collected' / item['runId']
        assessment = load(run / 'assessment.json')
        assert assessment['Execution'] == 'completed' and assessment['Correctness'] == 'passed' and assessment['Evidence'] == 'complete' and assessment['Comparison'] == 'eligible'
        assert all(c['Passed'] for c in assessment['Checks'])
        result = load(run / 'result.json')
        expected = NEW if prefix == 'fifo' and item['label'].startswith('B') else OLD
        assert result['executableSha256'] == expected
        assert result['host']['runnerVersion'] == '0.2.0+e17919c849b840d43171a615b288f559fbec9e4c'
        activity = result['operatorActivity']
        assert not activity['Intervened'] and not any(v for k, v in activity.items() if k != 'Intervened')
        state = load(run / 'diagnostics/run-state/report.json')
        assert state['DriverNamespaceVerified'] and state['ComparisonReady'] and not state['AllowUncontrolledDriverCache'] and not state['Issues']
        assert state['DriverQualification'] == 'mesa_private_disk_writes_observed'
        assert state['DriverBefore']['Complete'] and state['DriverBefore']['Bytes'] == 0
        assert state['DriverAfter']['Complete'] and state['DriverAfter']['Bytes'] > 0
        guest = load(run / 'guest/normalized-results.json')['records']
        assert len(guest) == 4 and all(g['Correct'] and g['Samples'] == 10 for g in guest)
        by_id = {g['Id']: g['MeanUs'] for g in guest}
        ordinal = int(item['label'][1:]) - 1
        for row in rows(prefix):
            assert by_id[row['testId']] == row[item['label'][0].lower() + 'Samples'][ordinal]
        attempts.append({'campaign': prefix, **item, 'executableSha256': expected,
                         'driverQualification': state['DriverQualification'], 'operatorActivity': activity,
                         'workSeconds': {k: v / 1e6 for k, v in by_id.items()}})

unit = load(ROOT / 'unit-collection.json')
assert unit['complete'] and unit['excluded'] == 0 and unit['fileCount'] == 21
unit_run = ROOT / 'native-unit' / unit['runId']
unit_assessment = load(unit_run / 'assessment.json')
assert unit_assessment['Execution'] == 'completed' and unit_assessment['Correctness'] == 'passed' and unit_assessment['Evidence'] == 'complete' and unit_assessment['Comparison'] == 'eligible'
assert sum(line.startswith('ok ') for line in (unit_run / 'stdout.log').read_text().splitlines()) == 14
assert sum(line.startswith('ok ') for line in (ROOT / 'fresh-unit.log').read_text().splitlines()) == 14
assert all(r['identical'] for r in load(ROOT / 'caller-proof.json').values())
deps = load(ROOT / 'dependency-source-proof.json')
assert len(deps) == 18 and all(r['identical'] for r in deps)
assert all(load(ROOT / 'generated-config-proof.json').values())
assert load(ROOT / 'runtime-scope.json')['runtimeChangesFromOriginalFIFO'] == ['accel/tcg/tb-victim-cache.c']
assert artifacts == 4960

dist = ['| Workload | A1 | A2 | A3 | A4 | B1 | B2 | B3 | B4 |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for name, r in zip(NAMES, rows('fifo')):
    dist.append('| ' + name + ' | ' + ' | '.join(f'{v/1e6:.6f}' for v in r['aSamples'] + r['bSamples']) + ' |')

report = '''# #167 publication exchange: controlled comparisons remain inconclusive

## Decision

**HOLD for owning xemu PR #301; do not integrate this experiment.** The original eight-entry runtime remains unchanged. A two-line publication change preserves the required full barrier and passes the retained helper contracts, but clean Deck measurements do not demonstrate a dependable incremental performance gain. Stop this publication-only tuning pass; preserve the source, packages, maintained fixtures and complete evidence. The broader issue remains open because earlier fit-case benefit and above-capacity regression remain unresolved.

## What changed and why

Experimental source [1beff07a535acf153bf774ec578d5146b0143d23](https://github.com/Mainkill1/xemu/commit/1beff07a535acf153bf774ec578d5146b0143d23), based on owning branch head `587a832b3d0`, changes only `tcg_victim_cache_fill()` in `accel/tcg/tb-victim-cache.c` relative to original runtime `5679cce099eb777977e761245de47e77d05d0c05`:

```text
BEFORE: store primary TB pointer → full barrier → recheck epoch → clear if stale
AFTER:  atomic store with full barrier → recheck epoch → clear if stale
```

`qatomic_set()` plus `smp_mb()` becomes QEMU's documented `qatomic_set_mb()` primitive. On this x86 build, the separate pointer store and locked stack operation become one `xchg` pointer publication. No barrier is removed; the returned old pointer is discarded. Lookup keys, owner-local FIFO metadata, foreign invalidation protocol, active-writer/epoch checks, storage lifetime and default-off guards remain unchanged. This hypothesized lower publication cost; disassembly is mechanism evidence, not a speedup.

## Quick comparison: original FIFO → publication exchange

''' + table('fifo') + '''

Time is **fixed guest work**, seconds per 8,000,000 calls, not frame time or FPS. Each before/after value is the median of four attempt-level means; each attempt mean contains all ten guest samples. Each order has two A/two B attempts. Improvement %=100*(before-after)/before; positive is faster. All rows are the maintained `cpu_translation_blocks.` leaves; suffixes are `jump_cache_collision2`, `jump_cache_collision8`, `jump_cache_collision10`, `jump_cache_noncollision8`, respectively. Two/eight/ten deliberate same-slot targets and eight distinct-slot targets execute the same arithmetic per call. Eight is the victim capacity; ten attacks capacity overflow. Targets use byte offsets within one 4 KiB page, not separate pages.

The ten-target aggregate is favorable in both orders, **but not established as a patch benefit**. A ranges 1.051–1.300 s and B ranges 1.040–1.276 s. A4 is faster than B4; A2 is faster than B2. Both binaries exhibit overlapping fast/slow observations, and the sample mixture differs. No confidence bound or causal explanation is inferred from four attempts per binary. Smaller cases/control give opposing order signs. Both canonical campaign reports classify their outcome `inconclusive`.

### All candidate-comparison attempt means (seconds)

''' + '\n'.join(dist) + '''

The table labels logical attempts; physical order is **A1 B1 B2 A2 B3 A3 A4 B4**. Full raw ten-sample guest results, mean/median/min/max/p95 metrics, all run IDs and canonical JSON/Markdown/CSV comparisons are preserved in the ZIP. No sample was removed or rerun.

## Fresh A/A qualification

Both A and B use the exact original FIFO executable and identical frozen inputs. This campaign preceded the candidate comparison.

''' + table('aa') + '''

These are observed apparent differences between identical binaries, **not improvements**. A4 eight-target/control means are 0.908/0.600 s; all remain included. ABBA/BAAB discrepancies and earlier diagnostic variation prevent declaring a stable noise floor. Passing correctness and comparison eligibility do not resolve that variation.

## Validation and cache state

- Fresh GCC 14/O2 i386-softmmu enabled build succeeds with the actual `qemu-system-i386` and helper targets. Fourteen helper cases pass locally and on Deck through the existing saved standalone definition, including 20,000-operation FIFO oracle, 10,000 delayed publications and guarded storage reuse. Read-only review reports no memory-ordering blocker. These checks do not prove arbitrary VM remapping or concurrent reclamation.
- Generated host/target/device configs, 18 dependency source trees and configure options match original FIFO build inputs. CPU dispatch object's `.text`, `.text.unlikely`, `.rodata`, `.rodata.str1.1` bytes match exactly. Whole executable layouts differ; this does not eliminate host-layout effects. No fresh disabled build is claimed for this experiment; changed code remains inside the existing default-off source guard.
- **16/16 clean measurement attempts** finish, pass all four independent arithmetic/page contracts, complete evidence and remain comparison-eligible. **4,960 measurement artifacts plus 21 helper artifacts collected**, no exclusions. All private Mesa disk namespaces begin empty, show driver writes and qualify with `mesa_private_disk_writes_observed`; no uncontrolled-cache waiver, purge or policy intervention. All operator-activity counters are zero.
- Native measurements use Deck `10.0.0.123`, Vulkan/RADV, 128 MiB; updated maintained runner `e17919c849b840d43171a615b288f559fbec9e4c`. Routine testing used LAN HTTP, no SSH. Deck returns idle. OS page cache, driver memory cache, power/delivered CPU frequency and scheduling remain limitations.
- Rendering/physical Xbox, other 159 XISO leaves, OpenGL, reached-game >=300-second PGR2, resources and actual VM lifecycle are **not qualified**. No new production-parent comparison was run after the inconclusive direct comparison. Do not subtract these percentages from earlier campaigns or claim net game gains.

## Immutable workload and product identities

- A runtime `5679cce099eb777977e761245de47e77d05d0c05`; application `i167-5679cce0-enabled`; executable SHA-256 `51cd99ef27b7212ba75029c489b31b36b44f732302cee27276c2c62756357c24`.
- B runtime `1beff07a535acf153bf774ec578d5146b0143d23`; application `i167-1beff07a-publish-mb`; executable SHA-256 `0c856d3a4c82c7b049a52bb7b3bec0079799d038d5983be97ced449d9e899fcc`. Original companions/config/EEPROM/library bytes unchanged; package manifests retained.
- Native helper application `i167-publish-helper-1bef-001`; executable SHA-256 `14c9a50da1d759fca5fe4f3c5222ed37540532ab154f0ce652710779502d6eef`; saved definition `i167-compact-fifo-reference-v1` @ `353c488b6c2ee752c550b32e30a68b561bf9b32ed72579c14346d3038c8a9136`.
- Retained genuine fixture [source draft #54](https://github.com/Mainkill1/xemu-perf-tests/pull/54), compiled source `19f252d79aed0c3614ec43fab1d468f09ff6296e`; ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f`; catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012`.
- Suite `i167-collision-arithmetic-v1-suite` @ `a7cbe7d53b011dae8b9d7efd189cf62407fcd4414c72aabc27bdf0b5bc361171`; source-derived CPU reference `db086d21eb0e600f30246c1a8bc129290dcce0f16f4308ead9765f35cd49876b`. Suite remains administratively `unverified`; passing selected arithmetic contracts does not promote it to a full renderer baseline. No observed framebuffer/timing self-reference.
- Same explicit suite configuration: zero warmups, multiplier one, per_iteration. Campaigns `i167-publish-aa-20261003-001` and `i167-publish-vs-fifo-20261003-001`. Plans, selected requests and immutable revisions retained.

## Preserved failures and bounded handoff

Initial build command named nonexistent `xemu` target and failed before compilation; `build.log` preserves it. Correct target build log is separate. A headless `--version` query actually initialized GUI and failed due to unavailable local display; this is **not** a passed launch test. Existing third-party build warnings remain visible; no warning-free full-build claim. No emulator measurement attempt failed, was waived, retried or filtered.

The original FIFO and source draft #54 stay available. Keep #301 draft/HOLD; publication source is archived, excluded from owning product runtime. Future work must address above-capacity admission/search cost and characterize between-process variation before claiming a useful change. This pass adds no publication-only optimization to the product and does not close broader #167.

[All raw measurements and logs](EVIDENCE.zip) · [Artifact identities and public-byte exclusions](INDEX.json) · [Summary and every attempt](SUMMARY.json). No emulator results are stored in runner/test-source PRs. Executables, firmware/private state and duplicate diagnostics archives remain local with hashes recorded.
'''
(DEST / 'REPORT.md').write_text(report)

files = []
for directory in ('aa-collected', 'fifo-collected', 'native-unit', 'candidate-package', 'unit-package'):
    files.extend(f for f in (ROOT / directory).rglob('*') if f.is_file())
files.extend(f for f in ROOT.iterdir() if f.is_file())
index = []
with zipfile.ZipFile(DEST / 'EVIDENCE.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in sorted(set(files)):
        name = f.relative_to(ROOT).as_posix()
        data = f.read_bytes()
        # Preserve hashes for private/binary payloads while publishing all raw
        # measurements, canonical reports, source scripts and build/review logs.
        include = '/state/' not in name and f.name != 'diagnostics.zip'
        include &= f.suffix in ('.json', '.jsonl', '.log', '.md', '.csv', '.txt', '.py', '.toml')
        index.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'publicBytesIncluded': bool(include)})
        if include:
            z.writestr(name, data)
(DEST / 'INDEX.json').write_text(json.dumps(index, indent=2) + '\n')
summary = {'recommendation': 'HOLD', 'integrated': False, 'directComparison': 'inconclusive',
           'nativeMeasurementAttempts': 16, 'measurementArtifacts': artifacts, 'helperArtifacts': 21,
           'guestSamples': 640, 'candidateRows': rows('fifo'), 'aaRows': rows('aa'), 'attempts': attempts,
           'unit': unit, 'zipSha256': hashlib.sha256((DEST / 'EVIDENCE.zip').read_bytes()).hexdigest()}
(DEST / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
with zipfile.ZipFile(DEST / 'EVIDENCE.zip') as z:
    assert z.testzip() is None
    for item in index:
        if item['publicBytesIncluded']:
            assert hashlib.sha256(z.read(item['path'])).hexdigest() == item['sha256']
print('Verified:', artifacts, '+ 21 artifacts; 16 qualified measurement attempts; 640 guest samples;', (DEST / 'EVIDENCE.zip').stat().st_size, 'ZIP bytes')

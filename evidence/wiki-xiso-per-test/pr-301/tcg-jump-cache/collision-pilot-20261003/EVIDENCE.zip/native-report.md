## XISO campaign i167-collision-native-19f252d-001 — ineligible

Suite `i167-collision-19f252d-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 0/1. Changes above 1%: 0 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Comparison blockers
- The campaign does not contain eight attempts per chunk.
- Chunk 1: ABBA/BAAB schedule is missing or out of order.

No numeric gains are published until every planned attempt is indexed and eligible.

## Recommendation: HOLD

**Summary:** Add four retained generated-code CPU workloads for xemu #167: two/eight/ten deliberately colliding targets and an equal-work eight-target noncollision control. The production emitter passes independent IA-32 execution/checksum and geometry checks; the Release XISO builds. This draft delivers reusable test source, not a performance claim or an approved framebuffer baseline.
**Remaining:** Native guest execution, applicable reference qualification and balanced emulator comparisons before considering merge.

### Problem

[xemu #301](https://github.com/Mainkill1/xemu/pull/301) initially improved stable-code work by 3.23%, but compiler attribution later found inline-only improves that fixture too. Existing CPU workloads do not deliberately force the collisions the proposed victim cache is meant to recover.

### What this PR changes

- `cpu_jump_cache_workload.h`: immutable 18-byte cdecl IA-32 routines within one allocated 4 KiB page; 65-byte target strides collide under xemu `76c23c7d`'s 4096-slot softmmu hash, while 64-byte strides give distinct slots.
- `cpu_translation_block_tests.*`: register four leaves, each executing 8M round-robin indirect calls per iteration and ten existing profile samples. Assert geometry, every iteration's independent recurrence checksum, unchanged bytes and successful release. Emit operation count, target count, collision mode, work/result/expected checksums.
- Catalog generator, generated descriptors/docs and shared plans: add four IDs; 163 leaves plus five structural groups. Existing 164 descriptors remain unchanged; 29 shared plans change only catalog/plan identities.
- Retain host checks and workload/acceptance documentation. Historical qualification images and expected framebuffer output are not replaced.

### Why this approach

```text
BEFORE: incidental compiler-chosen indirect target locations
AFTER:  generate immutable IA-32 targets → assert deliberate hash geometry
        → fixed indirect-call recurrence → check independent checksum
```

Two targets attack minimal eviction; eight target the bounded history; ten exceed eight victims plus one primary. The equal-work eight-target control has the same instructions and expected result. Loop/return PCs, interrupts and real dispatch paths can affect recovery, so target count does not predict benefit. The test remains executable on physical Xbox; hash geometry describes xemu's software cache.

### Validation

| Completed check | Result |
|---|---|
| Catalog freshness / host contracts | 145/145 pass |
| Actual production-emitted ELF32 execution | Short KATs and full 8M budgets pass |
| Initial missing initialization | Valid-input tests fail, then pass after implementation |
| Deliberate incorrect arithmetic / geometry | Both mutations rejected; restored checks pass |
| Committed Release XISO | Builds; embedded catalog bytes verified by maintained packager |
| Read-only source / NXDK object review | No Critical/Important defect; native qualification permitted |
| Native / framebuffer / physical Xbox | Pending; no new approved reference |

Compiled source `19f252d`; current head adds documentation only. NXDK `73c95900`, matched pinned dependencies. ISO SHA-256 `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f`; catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012`. Unchanged-source compiler warnings remain in fill-rate/primitive array designators, menu/composite code, NXDK `NULL`, and linker section merging; modified code has no emitted warning.

### Results

**Performance: Not yet measured.** Host checks establish emitter behavior and known answers, not xemu timings. The ELF32 harness uses its own dispatch loop; NXDK object inspection verifies the production indirect call, cdecl cleanup, exact operation bound and sticky mismatch. Allocation, generation, geometry, hashing and output are outside timing; pointer-table initialization and one checksum compare per whole work iteration remain inside it.

### Risks and remaining questions

Native assertions, paired reference admission, actual C-dispatch recovery rate, interrupt/capacity effects, and physical Xbox remain unqualified. This synthetic does not qualify VM remapping, stale storage, reset/load or retail performance. Use fresh A/A then ABBA/BAAB, and keep every failure. Emulator results/raw evidence belong to owning xemu #301; this repository receives actual test source only.

### Related work

Addresses [xemu #167](https://github.com/Mainkill1/xemu/issues/167); supports [xemu #301](https://github.com/Mainkill1/xemu/pull/301). Separate source draft retained for later merge as requested. No merge authorized.

> **Agent Declaration:** Created with assistance from Codex / GPT-6; read-only review by Codex / GPT-6.

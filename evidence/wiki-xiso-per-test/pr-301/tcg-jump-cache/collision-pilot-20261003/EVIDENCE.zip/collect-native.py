import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/home/codex/src/steamdeck-xemu/worktrees/runner-standalone-process/scripts')
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_xiso import read_report
p=Path(__file__).parent;api=RunnerApi('http://10.0.0.123:9368');cid='i167-collision-native-19f252d-001'
status=api.json('/api/v1/xiso-campaigns/'+cid);assert status['terminal']
(p/'native-terminal.json').write_text(json.dumps(status,indent=2)+'\n')
a=api.json('/api/v1/xiso-campaigns/'+cid+'/attempts');assert len(a['items'])==1
row=a['items'][0];r=Workflows(api).collect(row['id'],p/'native-collected',None,True)
(p/'native-collection.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
for fmt in ['json','markdown','csv']:
 d=read_report(api,cid,fmt);(p/('native-report.'+('md' if fmt=='markdown' else fmt))).write_text(json.dumps(d,indent=2)+'\n' if fmt=='json' else d)
base=p/'native-collected'/row['runId'];ex=json.loads((base/'guest/extraction.json').read_text());assert hashlib.sha256((base/'guest/results.txt').read_bytes()).hexdigest()==ex['sha256']
print((base/'guest/results.txt').read_text(),flush=True)

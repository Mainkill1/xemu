import sys,json,hashlib
from pathlib import Path
ROOT=Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0,str(ROOT/'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_xiso import read_report
case=sys.argv[1]
assert case in ['aa','parity','enabled']
api=RunnerApi('http://10.0.0.123:9368'); w=Workflows(api)
p=ROOT/'artifacts/issue167-victim8-20261003/native'; campaign='i167-victim8-'+case+'-5679-001'
status=api.json('/api/v1/xiso-campaigns/'+campaign)
assert status['terminal'] and api.json('/api/v1/status')['Phase']=='idle'
(p/(case+'-terminal-status.json')).write_text(json.dumps(status,indent=2)+'\n')
attempts=api.json('/api/v1/xiso-campaigns/'+campaign+'/attempts')
assert len(attempts['items'])==8 and attempts['nextOffset'] is None
(p/(case+'-attempts.json')).write_text(json.dumps(attempts,indent=2)+'\n')
cache=[]
for a in attempts['items']:
 r=w.collect(a['id'],p/(case+'-collected'),None,True)
 (p/(case+'-'+a['label']+'-collection.json')).write_text(json.dumps(r,indent=2)+'\n')
 base=p/(case+'-collected')/a['runId']; d=json.loads((base/'diagnostics/run-state/report.json').read_text())
 extraction=json.loads((base/'guest/extraction.json').read_text())
 assert hashlib.sha256((base/'guest/results.txt').read_bytes()).hexdigest()==extraction['sha256']
 row={k:d.get(k) for k in ['Status','CacheMode','DriverNamespaceVerified','DriverQualification','ComparisonReady','AllowUncontrolledDriverCache','Issues']}
 row.update(label=a['label'],runId=a['runId'],driverBeforeFiles=len(d['DriverBefore']['Files']),driverAfterFiles=len(d['DriverAfter']['Files']),driverAfterBytes=d['DriverAfter']['Bytes'])
 cache.append(row)
 print(case,a['label'],a['correctness'],a['comparison'],'files',r['fileCount'],'exclusions',r['excluded'],flush=True)
(p/(case+'-cache-qualification.json')).write_text(json.dumps(cache,indent=2)+'\n')
print(json.dumps({'case':case,'outcome':status,'allCacheNamespacesQualify':all(r['ComparisonReady'] and r['DriverNamespaceVerified'] and not r['Issues'] and not r['AllowUncontrolledDriverCache'] for r in cache)}))

assert status['passed']==8 and status['failed']==0 and status['incomplete']==0
for fmt in ['json','markdown','csv']:
 report=read_report(api,campaign,fmt)
 (p/(case+'-report.'+('md' if fmt=='markdown' else fmt))).write_text(json.dumps(report,indent=2)+'\n' if fmt=='json' else report)
assert all(r['ComparisonReady'] and r['DriverNamespaceVerified'] and not r['Issues'] and not r['AllowUncontrolledDriverCache'] for r in cache)
report=json.loads((p/(case+'-report.json')).read_text());assert report['status']=='eligible' and not report['blockers']
rows=[x for x in report['rows'] if x['metric']=='mean_us'];assert len(rows)==2
summary=[{'testId':x['testId'],'baselineSeconds':x['a']['median']/1e6,'candidateSeconds':x['b']['median']/1e6,'timeSavedSeconds':(x['a']['median']-x['b']['median'])/1e6,'improvementPercent':x['improvementPercent'],'abbaImprovementPercent':x['abbaImprovementPercent'],'baabImprovementPercent':x['baabImprovementPercent'],'aSamplesSeconds':[v/1e6 for v in x['aSamples']],'bSamplesSeconds':[v/1e6 for v in x['bSamples']]} for x in rows]
(p/(case+'-SUMMARY.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)

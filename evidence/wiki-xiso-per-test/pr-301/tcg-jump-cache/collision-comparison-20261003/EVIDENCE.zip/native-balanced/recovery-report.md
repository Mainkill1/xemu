## XISO campaign i167-collision-recovery-20261003-001 — inconclusive

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 20 metric rows. Opposite ABBA/BAAB outcomes: 5.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 3 | 1 | +29.28% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 914643.50 | 566338.50 | +38.08% | +22.48% | +37.79% | max_us +38.68%, mean_us +38.32%, median_us +38.08%, min_us +38.42%, p95_us +38.68% |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 1089391.00 | 599286.50 | +44.99% | +50.24% | +39.89% | max_us +39.35%, mean_us +42.47%, median_us +44.99%, min_us +38.47%, p95_us +39.35% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 1016479.00 | 1267440.75 | -24.69% | -17.99% | -24.94% | max_us -24.06%, mean_us -24.63%, median_us -24.69%, min_us -25.56%, p95_us -24.06% |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 478255.50 | 380314.75 | +20.48% | +17.91% | -2.93% | max_us +19.69%, mean_us +20.42%, median_us +20.48%, min_us +20.55%, p95_us +19.69% (orders disagree) |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

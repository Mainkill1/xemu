## XISO campaign i167-collision-aa-20261003-001 — inconclusive

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 4 metric rows. Opposite ABBA/BAAB outcomes: 1.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 0 | 0 | -0.76% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 833467.75 | 841681.50 | -0.99% | +1.11% | -1.71% | max_us +4.48%, p95_us +4.48% (orders disagree) |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 877521.75 | 883217.00 | -0.65% | +1.00% | -0.58% | max_us +1.04%, p95_us +1.04% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 883894.25 | 891565.50 | -0.87% | -1.02% | -0.12% | — |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 376298.50 | 373937.75 | +0.63% | +0.38% | +0.56% | — |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

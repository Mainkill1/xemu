## XISO campaign i167-collision-parent-20261003-001 — eligible

Suite `i167-collision-arithmetic-v1-suite` · ISO `87296b1b35e9f3ade67661ed53d42e9d11ff786bf9ecb07182149c9924c7767f` · catalog `sha256:5f579ca71a19d22c66ffa213aaa665983125bacb9c962bfd690798b7e3770012` · suite qualification `unverified`
Indexed attempts: 8/8. Changes above 1%: 20 metric rows. Opposite ABBA/BAAB outcomes: 0.
Improvement is positive when the candidate is faster. Each order uses two A and two B attempts; the combined value uses four of each. These are guest timings, not whole-game FPS. Attempt eligibility does not qualify a candidate suite as an approved baseline.

### Category summary
| Category | Leaves | >1% faster | >1% slower | Median leaf change |
|---|---:|---:|---:|---:|
| cpu | 4 | 3 | 1 | +13.22% |
Category median is the median of leaf percentage changes; it is not an additive runtime or GPU cost.

### Per-leaf results
| Category | Test | A median (µs) | B median (µs) | Improvement | ABBA | BAAB | Changes above 1% |
|---|---|---:|---:|---:|---:|---:|---|
| cpu | cpu_translation_blocks.jump_cache_collision2 | 728698.25 | 545602.75 | +25.13% | +25.18% | +33.11% | max_us +26.88%, mean_us +25.06%, median_us +25.13%, min_us +23.79%, p95_us +26.88% |
| cpu | cpu_translation_blocks.jump_cache_collision8 | 789510.00 | 586461.00 | +25.72% | +24.57% | +32.69% | max_us +24.73%, mean_us +25.76%, median_us +25.72%, min_us +25.07%, p95_us +24.73% |
| cpu | cpu_translation_blocks.jump_cache_collision10 | 803216.50 | 1257965.25 | -56.62% | -57.84% | -40.51% | max_us -54.94%, mean_us -56.15%, median_us -56.62%, min_us -56.58%, p95_us -54.94% |
| cpu | cpu_translation_blocks.jump_cache_noncollision8 | 371660.00 | 366788.25 | +1.31% | +1.40% | +0.65% | max_us +1.82%, mean_us +1.48%, median_us +1.31%, min_us +1.22%, p95_us +1.82% |

The full CSV includes each leaf's mean, median, min, max and p95 guest metrics, plus the four-attempt A/B distributions. A changed pixel or guest timing needs separate correctness and gameplay review.

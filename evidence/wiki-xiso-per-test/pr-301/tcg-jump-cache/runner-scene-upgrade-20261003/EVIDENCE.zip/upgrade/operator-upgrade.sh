#!/usr/bin/env bash
set -euo pipefail
root=/home/deck/xemu-research
revision=e17919c849b840d43171a615b288f559fbec9e4c
archive="$root/runner-e17919c.tar.gz"
app="$root/runner-e17919c"
old_app="$root/runner-0e05af4"
old_unit=xemu-research-runner-20261003-0e05af4.service
new_unit=xemu-research-runner-20261003-e17919c
config="$root/runner.json"
expected_archive=678eded451277d40be1dc061e06740b458f05fa9fb7c7fbb0c403bd5f4e94465
actual_archive=$(sha256sum "$archive")
test "${actual_archive%% *}" = "$expected_archive"
test ! -e "$app"
test -r /run/user/1000/xauth_IUEWSd
mkdir "$app"
tar -xzf "$archive" -C "$app" --strip-components=1
python3 - "$app" "$revision" <<'VERIFY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);manifest=json.loads((root/'release.json').read_text())
assert manifest['sourceCommit']==sys.argv[2]
for name,e in manifest['files'].items():
 p=root/name
 with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 assert p.stat().st_size==e['bytes'] and actual==e['sha256'],name
print(json.dumps({'sourceCommit':manifest['sourceCommit'],'verifiedFiles':len(manifest['files'])}))
VERIFY
test "$("$app/XemuTestRunner" --version)" = "0.2.0+$revision"
config_hash=$(sha256sum "$config")
launch_runner() {
 systemd-run --user --unit="$1" --working-directory="$root" \
 --setenv=DISPLAY=:0 --setenv=XAUTHORITY=/run/user/1000/xauth_IUEWSd \
 --setenv=XDG_RUNTIME_DIR=/run/user/1000 \
 --setenv=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus \
 "$2/XemuTestRunner" run -c "$config" --non-interactive
}
recover() {
 systemctl --user stop "$new_unit.service" 2>/dev/null || true
 launch_runner xemu-research-runner-20261003-0e05af4-recovery "$old_app"
}
# Operator upgrade only: fail closed if work arrived since the agent preflight.
python3 - <<'IDLE'
import json,urllib.request
with urllib.request.urlopen('http://10.0.0.123:9368/api/v1/status',timeout=10) as r:s=json.load(r)
assert s['Phase']=='idle' and s['CurrentJob'] is None and s['Queue']['Pending']==0 and s['Queue']['Testing']==0,s
IDLE
trap recover ERR
systemctl --user stop "$old_unit"
python3 - "$root" <<'BACKUP'
from pathlib import Path
import hashlib,json,tarfile
root=Path(__import__('sys').argv[1]);dest=root/'upgrade-e17919c'
dest.mkdir(exist_ok=False)
files=[root/'runner.json']
pending=root/'workspace/Queue/Pending'
files.extend(sorted(pending.rglob('*.json')))
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(dest/'metadata-before.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
(dest/'hashes-before.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps({'independentMetadataBackupFiles':len(files),'backup':str(dest)}))
BACKUP
launch_runner "$new_unit" "$app"
systemctl --user is-active "$new_unit.service"
test "$(sha256sum "$config")" = "$config_hash"
python3 - "$root" <<'AFTER'
from pathlib import Path
import hashlib,json,urllib.request,time,sys
root=Path(sys.argv[1]);dest=root/'upgrade-e17919c'
for attempt in range(20):
 try:
  with urllib.request.urlopen('http://10.0.0.123:9368/api/v1/agent?view=summary',timeout=2) as r:d=json.load(r)
  assert d['version']=='0.2.0+e17919c849b840d43171a615b288f559fbec9e4c',d
  break
 except (OSError,ValueError):time.sleep(0.5)
else:raise RuntimeError('Updated runner did not become reachable')
before=json.loads((dest/'hashes-before.json').read_text())
after={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in before}
assert before==after,'Managed metadata changed during upgrade'
(dest/'hashes-after.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({'unchangedMetadataFiles':len(before),'version':d['version']}))
AFTER
trap - ERR
printf '%s\n' 'Updated runner started; config, original application and metadata backup retained.'

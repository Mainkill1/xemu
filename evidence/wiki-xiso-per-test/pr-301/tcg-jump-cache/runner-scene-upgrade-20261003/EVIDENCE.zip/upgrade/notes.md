# Runner update scope and failures

Four user-merged main fixes #100–103 are cherry-picked onto maintained standalone-process draft89. No PR merge performed. Standalone compose check previously matched older measurement-start wording; new production validator rejects with wait_for_scene. The local test-only change updates that assertion and checks accepted bounded live gate for default and explicit xemu. No production guard is loosened.

First local Python invocation inherited SSH_CONNECTION/SSH_CLIENT/SSH_TTY and therefore correctly failed51assertions/two errors on fake localhost endpoints. Original output retained. Local fixture rerun unsets these inherited markers; tests still exercise explicit SSH-loopback refusal. Normal Deck operation remains LAN HTTP. This is not a runner or native correctness failure, cache waiver, or measurement rerun.

Fresh checks: baseline49RunnerChecks, updated51RunnerChecks,142AgentChecks,26XisoChecks,92client tests. Old gameplay definitions with post-run-only scene checks are intentionally incompatible with stricter upstream runtime live gates; their JSON/evidence will be preserved, not rewritten or self-approved. New gameplay definitions require already qualified scene references and live wait directly before measurement.

No performance result is inferred from this update. It does not add clock/power/affinity telemetry or resolve identical-executable A/A variation. Upgrade remains separate operator action; normal upload/start/wait/collect stays maintained HTTP.

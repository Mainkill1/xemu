"""Freeze reusable MCPX guest-fixture inputs on Deck .123; never start xemu.

Uses maintained HTTP clients. Keeps historical missing references explicit;
does not create or approve new framebuffer oracles.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi, job_url
from runner_workflows import Workflows
from runner_tests import upload_application

BASE = ROOT / 'artifacts/issue197-sample-memory/remaining-gates'
version = sys.argv[1] if len(sys.argv) == 2 else 'v1'
assert version in ['v1', 'v2', 'v3', 'v4']
suffix = '' if version == 'v1' else '-' + version
out = BASE / ('mcpx-voice-native' + suffix)
out.mkdir(exist_ok=True)
api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api)

def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')
    return value

status = save('host-status-before-preparation.json', api.json('/api/v1/status'))
assert status['Phase'] == 'idle' and status['Queue']['Pending'] == 0 and status['Queue']['Testing'] == 0, status
source = json.loads((ROOT / 'artifacts/issue229-dsp-multiply/xiso-preparation/qualified-cpu-reference-definition.json').read_text())['definition']
identity = json.loads((BASE / 'matched-runtime-builds/identity.json').read_text())
suite_package = json.loads((BASE / ('mcpx-voice-suite' + suffix) / 'suite.json').read_text())
assert identity['runtimeLibrariesIdentical']
assert suite_package['isoSha256'] == dict(v1='4bc1fec5f070a695699d57c78ef19183c1f43631e853bd20ed749d55f4eb056a',
    v2='62a20d29bc73ef4fe6ae8c37976d72ed520c0ff808d455ef99e57cd122916720',
    v3='2fb92d1441fef790b7abd32e75abe61a0bf2ea971ffc9581e9cf04e310f57831',
    v4='182013b490ac64d3dcee08cc77cc149e7f76bbacf2a182a928ef2509b11b37b7')[version]
iso = BASE / ('mcpx-voice-suite' + suffix) / 'suite.iso'
assert hashlib.sha256(iso.read_bytes()).hexdigest() == suite_package['isoSha256']
asset = 'issue197-mcpx-voice-iso-' + suite_package['isoSha256'][:12]
save('iso-asset-created.json', api.json('/api/v1/disk-assets', 'POST', dict(id=asset, kind='readonly-input', length=iso.stat().st_size,
    sha256=suite_package['isoSha256'], description='Retained MCPX guest voice fixture ' + suite_package['sourceCommit'] + '; exact 164-leaf embedded catalog.')))
api.upload_path('/api/v1/disk-assets/' + asset + '/content', iso, iso.stat().st_size, suite_package['isoSha256'])
save('iso-asset-ready.json', api.json('/api/v1/disk-assets/' + asset))

build = BASE / 'matched-runtime-builds/reference'
test = 'issue197-deck-mcpx-voice-full-' + version
seed = test + '-seed'
job = copy.deepcopy(source['job'])
job.update(id=seed, expectedExecutableSha256=None, tags=['issue197', 'mcpx-voice', 'correctness', 'vulkan', 'full-dsp'],
    operations=dict(mode='benchmark', allowPreview=False, allowManualInput=False, allowPauseResume=False,
                    allowDiagnostics=False, allowBulkTransfers=False))
job['arguments'] = ['-config_path', '{packageDir}/xemu.toml', '-name', 'xemu-issue197-mcpx,debug-threads=on', '-msg', 'timestamp=on']
job['experiment'] = dict(id='issue197-guest-mcpx-voice', variant='build', reference='ee5ce48b48784f999af374c1452003f8b2b1230f',
    variedFactors=['bounded ADPCM sample-memory implementation'], controlledFactors=['exact generated input and 164-leaf ISO/catalog',
    'matching 38 libraries', 'full DSP', 'private guest state', 'cold private Mesa disk cache', 'warmup0 multiplier1 per_iteration'],
    requireCorrectnessPass=True, requireCompleteEvidence=True, allowOperatorIntervention=False, allowDiagnostics=False)
for shared in job['runtimeState']['isolation']['readOnlyAssets']:
    if shared['field'] == 'dvd_path':
        shared.update(assetId=asset, expectedSha256=suite_package['isoSha256'])
config = (ROOT / 'artifacts/issue229-dsp-multiply/xiso-preparation/issue229-deck-xiso-cpu-vulkan-v1/xemu.toml').read_text()
assert 'use_dsp = false' in config
config = config.replace('use_dsp = false', 'use_dsp = true')
(out / 'xemu.toml').write_text(config)
local = {'xemu.toml': out / 'xemu.toml'}
for name in identity['buildFiles']:
    local[name] = build / name
files = [f for f in copy.deepcopy(source['files']) if not f['path'].startswith('lib/') and f['path'] not in ['xemu.toml', 'xemu']]
for name, path in local.items():
    files.append(dict(path=name, length=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest(), executable=name=='xemu'))
files.sort(key=lambda x: x['path'])
job['requiredFiles'] = [f['path'] for f in files]
job['inputs'] = [dict(path=f['path'], role='guest-fixture-input', hash=True,
                     expectedSha256=None if f['path']=='xemu' else f['sha256']) for f in files]
request = save('seed-manifest.json', dict(id=seed, job=job, files=files))
save('seed-created.json', api.json('/api/v1/jobs', 'POST', request))
if wf.status(seed)['state'] == 'busy':
    wf.operation(seed)
api.json(job_url(seed) + '/reuse', 'POST', dict(sourceJobId=source['sourceJobId']))
save('reuse-operation.json', wf.operation(seed))
for name, path in local.items():
    row = next(f for f in files if f['path']==name)
    api.upload_path(job_url(seed) + '/files/' + name, path, row['length'], row['sha256'])
save('seed-files-ready.json', api.json(job_url(seed) + '/files'))
baked = save('baked.json', api.json('/api/v1/tests/' + test + '/bake', 'POST', dict(sourceJobId=seed,
    description='Retained experimental MCPX voice output correctness; full DSP; polling waits NOT COMPARABLE; missing historical references preserved.',
    buildFiles=identity['buildFiles'])))
registered = save('suite.json', api.json('/api/v1/xiso-suites', 'POST', dict(id=test+'-suite', testId=test, revision=baked['revision'],
    settings=dict(warmup_iterations=0, measurement_iterations_multiplier=1, gpu_completion_mode='per_iteration'))))
for variant in ['reference', 'candidate']:
    application = 'issue197-matched-' + variant + '-linux-v1'
    sha = upload_application(api, BASE / 'matched-runtime-builds' / variant, 'xemu', application)
    save('application-' + variant + '.json', dict(id=application, sha256=sha, started=False))
save('qualification.json', dict(sourceCommit=suite_package['sourceCommit'], isoSha256=suite_package['isoSha256'],
    catalogId=suite_package['catalogId'], test=test, revision=baked['revision'], suite=registered['id'],
    qualification=registered['qualification'], started=False,
    referencePolicy='Historical reference has no new MCPX leaves. Unpaired diagnostics may report guest PASS with canonical missing-oracle failures; no oracle replacement or performance inference.'))
print(json.dumps(dict(test=test, revision=baked['revision'], suite=registered['id'], started=False)), flush=True)

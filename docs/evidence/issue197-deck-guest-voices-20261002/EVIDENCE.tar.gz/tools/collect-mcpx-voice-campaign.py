"""Collect one terminal retained MCPX campaign, preserving original outcomes.

Usage: python3 collect-mcpx-voice-campaign.py CAMPAIGN OUTPUT_DIRECTORY LABEL
No starts, retries, reference updates or interpretation of polling as throughput.
"""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows

campaign, directory, label = sys.argv[1:]
out = Path(directory)
api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api)

def save(name, value):
    with (out / (label + '-' + name + '.json')).open('x') as target:
        json.dump(value, target, indent=2)
        target.write('\n')
    return value

status = save('campaign', api.json('/api/v1/xiso-campaigns/' + campaign))
assert status['terminal']
page = save('attempts', api.json('/api/v1/xiso-campaigns/' + campaign + '/attempts?limit=100'))
assert page['nextOffset'] is None and len(page['items']) == 1
job = page['items'][0]['id']
result = save('result', wf.result(job))
assert result['outcome']['execution'] == 'completed' and result['outcome']['evidence'] == 'complete'
collection = save('collection', wf.collect(job, out / (label + '-collected'), None, True))
assert collection['complete'] and collection['excluded'] == 0
run = Path(collection['directory'])
rows = json.loads((run / 'guest/results.txt').read_text())
assert len(rows) == status['selectedLeaves']
summary = dict(campaign=campaign, jobId=job, runId=result['runId'], outcome=result['outcome'],
    collectedFiles=collection['fileCount'], excluded=collection['excluded'],
    guestResultsSha256=hashlib.sha256((run / 'guest/results.txt').read_bytes()).hexdigest(), leaves=[])
for row in rows:
    meta = row['metadata']
    item = dict(id=row['id'], guestOutcome=row['outcome'], averagePollingWaitUs=row['average_us'],
                sampleCount=row['sample_count'], metadata=meta, performanceComparable=False)
    if 'mix_words' in meta:
        words = meta['mix_words']
        assert len(words) == 64
        expected = [4096 * 256] * 32 + [(-4096 if 'stereo' in row['id'] else 4096) * 256] * 32
        signed = [w - (1 << 24) if w & (1 << 23) else w for w in words]
        item['independentUnityMixMatches'] = all(w >> 24 == 0 and abs(actual - target) <= 32
            for w, actual, target in zip(words, signed, expected))
        item['maximumUnityMixError'] = max(abs(actual-target) for actual,target in zip(signed,expected))
        item['allMixWordsZero'] = all(w == 0 for w in words)
    summary['leaves'].append(item)
save('summary', summary)
print(json.dumps({k:v for k,v in summary.items() if k!='leaves'}))
print(json.dumps([{k:v for k,v in row.items() if k!='metadata'} for row in summary['leaves']]))

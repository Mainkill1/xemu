"""Freeze the VP-monitor silent-output negative control; never launch a run."""
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi, job_url
from runner_workflows import Workflows

base = ROOT / 'artifacts/issue197-sample-memory/remaining-gates/mcpx-voice-native-v4'
out = base / 'negative-preparation'
out.mkdir(exist_ok=False)
api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api)

def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')
    return value

status = save('host-status-before-preparation.json', api.json('/api/v1/status'))
assert status['Phase']=='idle' and status['Queue']['Pending']==0 and status['Queue']['Testing']==0
source = json.loads((base / 'seed-manifest.json').read_text())
request = copy.deepcopy(source)
test, seed = 'issue197-deck-mcpx-vp-negative-v4', 'issue197-deck-mcpx-vp-negative-v4-seed'
request['id'] = request['job']['id'] = seed
request['job']['tags'] = ['issue197', 'mcpx-voice', 'expected-negative', 'vp-monitor']
request['job']['experiment'].update(id='issue197-mcpx-silent-negative', variant='expected-negative',
    variedFactors=['full DSP disabled; VP monitor clears GP mix observation'], reference=None)
config = (base / 'xemu.toml').read_text()
assert 'use_dsp = true' in config
path = out / 'xemu.toml'
path.write_text(config.replace('use_dsp = true', 'use_dsp = false'))
sha = hashlib.sha256(path.read_bytes()).hexdigest()
for row in request['files']:
    if row['path']=='xemu.toml':
        row.update(length=path.stat().st_size, sha256=sha)
for row in request['job']['inputs']:
    if row['path']=='xemu.toml':
        row['expectedSha256'] = sha
save('seed-manifest.json', request)
save('created.json', api.json('/api/v1/jobs', 'POST', request))
if wf.status(seed)['state']=='busy':
    wf.operation(seed)
api.json(job_url(seed) + '/reuse', 'POST', dict(sourceJobId=source['id']))
save('reuse-operation.json', wf.operation(seed))
api.upload_path(job_url(seed) + '/files/xemu.toml', path, path.stat().st_size, sha)
save('files-ready.json', api.json(job_url(seed) + '/files'))
build_files = json.loads((base.parent / 'matched-runtime-builds/identity.json').read_text())['buildFiles']
baked = save('baked.json', api.json('/api/v1/tests/' + test + '/bake', 'POST', dict(sourceJobId=seed,
    description='Deliberate silent GP-mix negative control; expected output assertion failures with valid engine progress and safe cleanup; no speedup measurement.',
    buildFiles=build_files)))
suite = save('suite.json', api.json('/api/v1/xiso-suites', 'POST', dict(id=test+'-suite', testId=test, revision=baked['revision'],
    settings=dict(warmup_iterations=0, measurement_iterations_multiplier=1, gpu_completion_mode='per_iteration'))))
print(json.dumps(dict(test=test, suite=suite['id'], revision=baked['revision'], started=False)))

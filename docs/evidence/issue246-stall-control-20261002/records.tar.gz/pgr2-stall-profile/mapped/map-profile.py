"""Map a retained native profile to the exact binary and pinned dependencies.

Do not attribute anonymous JIT samples to CPU or DSP, or infer speedups from
sample shares. Full leaf records and command/hash identities are preserved.
"""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import subprocess

root = Path('/home/codex/src/steamdeck-xemu')
base = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-stall-profile-v1'
run = next((base / 'collected').iterdir())
out = base / 'mapped'
out.mkdir(exist_ok=False)
native = root / 'artifacts/issue246-texture-allocation/native-builds/candidate-linux-v2'
binary = native / 'squashfs-root/usr/bin/xemu'
debug = native / 'debug-root/usr/lib/debug/.build-id/d5/84912b97c1e515f9348cb57e99747196005e65.debug'
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == '1b52adf0dea0823a95c37ae79d447af01bf8a904d6385037908b2ca57d44bba2'
data = next(run.glob('diagnostics/*/late-stall-profile.data'))
environment = dict(os.environ, DEBUGINFOD_URLS='', PERF_BUILDID_DIR=str(out / 'buildid-cache'))
commands = []

def execute(name, arguments):
    commands.append(arguments)
    with (out / (name + '.txt')).open('x') as stdout, (out / (name + '-stderr.txt')).open('x') as stderr:
        subprocess.run(arguments, stdout=stdout, stderr=stderr, env=environment, check=True, timeout=60)
    return (out / (name + '.txt')).read_text()

ids = execute('buildids', ['perf', 'buildid-list', '-i', str(data)])
matches = [line for line in ids.splitlines() if line.endswith('/xemu')]
assert len(matches) == 1 and matches[0].split()[0] == 'd584912b97c1e515f9348cb57e99747196005e65'
remote = matches[0].split(maxsplit=1)[1]
target = out / 'symfs' / remote.lstrip('/')
target.parent.mkdir(parents=True)
target.symlink_to(binary)
(target.parent / debug.name).symlink_to(debug)
libraries = root / 'artifacts/issue229-dsp-multiply/native-builds/parent-linux/squashfs-root/usr/lib'
for file in libraries.iterdir():
    if file.is_file():
        destination = target.parent / 'lib' / file.name
        destination.parent.mkdir(exist_ok=True)
        destination.symlink_to(file)
execute('events', ['perf', 'evlist', '-i', str(data)])
execute('leaf', ['perf', 'script', '-G', '-i', str(data), '--symfs', str(out / 'symfs'),
                 '-F', 'pid,tid,event,ip,sym,symoff,dso,period'])
(out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
histogram = collections.defaultdict(lambda: [0, 0])
threads = collections.defaultdict(lambda: [0, 0])
total = samples = 0
for line in (out / 'leaf.txt').read_text().splitlines():
    match = re.match(r'\s*(\d+)/(\d+)\s+(\d+)\s+cycles:Pu:\s+\S+\s+(.+?)\s+\((.+)\)$', line)
    if not match:
        raise ValueError(line)
    pid, tid, period = map(int, match.group(1, 2, 3))
    symbol, dso = match.group(4).split('+')[0], match.group(5)
    total += period
    samples += 1
    histogram[(symbol, dso)][0] += 1
    histogram[(symbol, dso)][1] += period
    threads[(pid, tid)][0] += 1
    threads[(pid, tid)][1] += period
rows = [{'symbol': symbol, 'dso': dso, 'samples': counts[0], 'period': counts[1],
         'sampledUserspaceCyclesPercent': 100 * counts[1] / total}
        for (symbol, dso), counts in sorted(histogram.items(), key=lambda row: -row[1][1])]
summary = {'samples': samples, 'period': total,
           'meaning': 'Process sampled userspace cycle shares, not wall-time CPU utilization or speedup. Five-second FP diagnostic; anonymous JIT and unmapped host symbols remain unresolved.',
           'binarySha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
           'debugSha256': hashlib.file_digest(debug.open('rb'), 'sha256').hexdigest(),
           'elfBuildId': matches[0].split()[0],
           'perfDataSha256': hashlib.file_digest(data.open('rb'), 'sha256').hexdigest(),
           'allLeaves': rows,
           'threads': [{'pid': key[0], 'tid': key[1], 'samples': value[0],
                        'period': value[1], 'sampledUserspaceCyclesPercent': 100 * value[1] / total}
                       for key, value in sorted(threads.items(), key=lambda row: -row[1][1])]}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'map-profile.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'samples': samples, 'period': total, 'topLeaves': rows[:12], 'threads': summary['threads'][:6]}, indent=2))

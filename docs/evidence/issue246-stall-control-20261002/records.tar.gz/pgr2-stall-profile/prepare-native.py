"""Reusable short owner profile after the frozen collector-OFF throttle plan.

Profile and thread-name observations are declared diagnostics, not acceptance
timings. No guest clock/config/timeout changes or manual intervention.
"""
from pathlib import Path
import copy
import json
import sys

root = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(root / 'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi, job_url
from runner_workflows import Workflows

source = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-throttle-off-v1'
name = 'issue246-deck-pgr2-stall-profile-v1'
out = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-stall-profile-v1'
manifest = copy.deepcopy(json.loads((source / 'manifest.json').read_text()))
previous = manifest['id']
manifest['id'] = name
job = manifest['job']
job['id'] = name
job['experiment'].update(id=name, variant='collector-off-stall-owner-diagnostic',
    variedFactors=['After frozen OFF throttle/captures, add 5s 99Hz frame-pointer perf and before/after OS thread names; diagnostic ownership, not performance acceptance'])
for suffix in ['before', 'after']:
    job['diagnostics'].append({'id': 'threads-' + suffix, 'type': 'external',
        'toolExecutable': 'ps', 'toolArguments': ['-T', '-p', '{pid}', '-o', 'pid,tid,comm,pcpu'],
        'toolWorkingDirectory': 'result', 'durationMs': 10000,
        'pauseBefore': False, 'resumeDuring': True, 'pauseAfter': False})
job['diagnostics'].append({'id': 'late-stall-profile', 'type': 'perf',
    'durationMs': 5000, 'frequency': 99, 'callGraph': 'fp',
    'pauseBefore': False, 'resumeDuring': True, 'pauseAfter': False,
    'outputName': 'late-stall-profile.data'})
index = len(job['plan']) - 1
assert job['plan'][index]['type'] == 'quit'
job['plan'][index:index] = [
    {'type': 'diagnostic', 'diagnosticId': 'threads-before'},
    {'type': 'diagnostic', 'diagnosticId': 'late-stall-profile'},
    {'type': 'diagnostic', 'diagnosticId': 'threads-after'},
    {'type': 'screenshot', 'name': 'after-profile'},
]
job['workload']['evidenceRequirements'].append({'name': 'after-profile-capture',
    'scope': 'result', 'path': 'screenshots/after-profile.png',
    'mustExist': True, 'minimumBytes': 1000})
api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api, progress=True)
status = api.json('/api/v1/status')
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
assert not status['Queue']['Pending'] and not status['Queue']['Testing']
out.mkdir(parents=True, exist_ok=False)

def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

save('deck-before.json', status)
save('manifest.json', manifest)
for file in ['xemu.toml', 'build-identity.json']:
    (out / file).write_bytes((source / file).read_bytes())
(out / 'prepare-native.py').write_bytes(Path(__file__).read_bytes())
save('created.json', api.json('/api/v1/jobs', 'POST', manifest))
if wf.status(name)['state'] == 'busy':
    wf.operation(name)
api.json(job_url(name) + '/reuse', 'POST', {'sourceJobId': previous})
wf.operation(name)
save('files-ready.json', api.json(job_url(name) + '/files'))
save('baked.json', api.json('/api/v1/tests/' + name + '/bake', 'POST', {
    'sourceJobId': name, 'buildFiles': ['xemu'],
    'description': 'Issue246 PGR2 stall ownership: frozen collector-OFF throttle procedure then 5s 99Hz FP perf and ps thread names; same binary/state/private Mesa; original failures retained, no performance claim',
}))
save('submitted.json', wf.submit_draft(name))
print(json.dumps(wf.status(name)))

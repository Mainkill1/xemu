"""One same-executable OFF diagnostic; preserve the existing ON attempt.

Only allocation collection and its validation/output contract are removed.
Navigation, throttle, telemetry, assets, runtime libraries and isolation remain.
"""
from pathlib import Path
import copy
import json
import sys

root = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(root / 'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi, job_url
from runner_workflows import Workflows

source = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-throttle-v1'
name = 'issue246-deck-collector-pgr2-throttle-off-v1'
out = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-throttle-off-v1'
manifest = copy.deepcopy(json.loads((source / 'manifest.json').read_text()))
previous = manifest['id']
manifest['id'] = name
job = manifest['job']
job['id'] = name
del job['environment']['XEMU_VK_TEXTURE_ALLOCATION_LOG']
job['diagnostics'] = [r for r in job['diagnostics'] if r['id'] != 'allocation-schema']
job['plan'] = [r for r in job['plan'] if r.get('diagnosticId') != 'allocation-schema']
job['workload']['evidenceRequirements'] = [r for r in job['workload']['evidenceRequirements']
    if r['path'] not in ['vk-texture-allocations.jsonl', 'vk-allocation-schema-check.json']]
job['experiment'].update(id=name, variant='collector-off-throttle-diagnostic',
    variedFactors=['Same executable allocation collector OFF versus original throttle ON; one diagnostic control, not balanced performance qualification'])
job['experiment']['controlledFactors'].append('Guest input, waits, captures, schema8 telemetry and state/cache isolation unchanged from throttle ON')

# Check all execution fields other than the declared collection contract and labels.
original = json.loads((source / 'manifest.json').read_text())['job']
for field in ['executable', 'expectedExecutableSha256', 'arguments', 'workingDirectory',
              'runtimeState', 'operations', 'launchMode', 'requiredFiles', 'inputs']:
    assert job[field] == original[field], field
assert job['plan'] == [r for r in original['plan'] if r.get('diagnosticId') != 'allocation-schema']
assert manifest['files'] == json.loads((source / 'manifest.json').read_text())['files']
api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api, progress=True)
status = api.json('/api/v1/status')
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
assert not status['Queue']['Pending'] and not status['Queue']['Testing']
out.mkdir(parents=True, exist_ok=False)

def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

save('deck-before.json', status)
save('manifest.json', manifest)
save('control-contract.json', {'sourceJob': previous, 'sameExecutableAndFiles': True,
    'unchangedGuestInputAndSettings': True, 'removed': ['Allocation log environment',
    'Allocation schema diagnostic after gameplay', 'Allocation output requirements'],
    'retained': 'Inactive allocation reader payload and input identity retained to keep package bytes identical',
    'comparison': 'One diagnostic control; no A/A, ABBA/BAAB or improvement claim'})
for file in ['xemu.toml', 'build-identity.json']:
    (out / file).write_bytes((source / file).read_bytes())
(out / 'prepare-native.py').write_bytes(Path(__file__).read_bytes())
save('created.json', api.json('/api/v1/jobs', 'POST', manifest))
if wf.status(name)['state'] == 'busy':
    wf.operation(name)
api.json(job_url(name) + '/reuse', 'POST', {'sourceJobId': previous})
wf.operation(name)
save('files-ready.json', api.json(job_url(name) + '/files'))
save('baked.json', api.json('/api/v1/tests/' + name + '/bake', 'POST', {
    'sourceJobId': name, 'buildFiles': ['xemu'],
    'description': 'Issue246 same-executable collector-OFF PGR2 throttle diagnostic: unchanged guest input, assets, schema8 telemetry and cold private Mesa; isolates stalled scene progress, not ABBA/BAAB performance proof',
}))
save('submitted.json', wf.submit_draft(name))
print(json.dumps(wf.status(name)))

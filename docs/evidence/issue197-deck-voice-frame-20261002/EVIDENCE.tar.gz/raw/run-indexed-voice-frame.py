"""Corrected saved-test campaign with every native build slot explicit.

The first direct-job campaign remains diagnostic evidence: default indexing
classified the unused companion executable as fixed input, splitting A/B keys.
No production, binary, settings, frame count or oracle changes here.
"""
from pathlib import Path
from types import SimpleNamespace
import json
import sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
OUT = Path(__file__).resolve().parent
OLD = OUT / 'deck-native'
NEW = OUT / 'deck-indexed'
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_wait import execute as completion_wait

api = RunnerApi('http://10.0.0.123:9368')
work = Workflows(api)

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

plan = json.loads((OLD / 'matrix-plan.json').read_text())
plan['order'] = [r for r in plan['order'] if not r['correctness']]
plan['provenance'] = 'saved test revision, all forty explicit build slots; source/default-index classification error preserved separately'
if (NEW / 'matrix-plan.json').exists():
    assert json.loads((NEW / 'matrix-plan.json').read_text()) == plan
else:
    status = api.json('/api/v1/status')
    assert status['Phase'] == 'idle' and status['CurrentJob'] is None
    save(NEW / 'preflight.json', status)
    save(NEW / 'matrix-plan.json', plan)
rows = []
for item in plan['order']:
    test = 'mcpx-production-vp-' + item['profile'] + '-w' + str(item['workers']) + '-' + item['variant'] + '-v1'
    baked = json.loads((OLD / 'saved-tests' / (test + '.json')).read_text())
    job = 'issue197-indexed-vp-' + item['label'] + '-20261002'
    folder = NEW / item['label']
    marker = folder / 'submission.json'
    request = {'testId': test, 'revision': baked['revision'], 'jobId': job}
    if marker.exists():
        assert json.loads(marker.read_text()) == request
        assert work.status(job)['state'] in ('testing', 'tested', 'queued'), 'Inspect the same handle before resuming.'
    else:
        save(marker, request)
        # Use the retained immutable saved bundle; no build replacement, hidden
        # runtime change, or upload is needed for these exact two binaries.
        receipt = work.run_test(test, baked['revision'], job, None, {}, 8 * 1024 * 1024)
        save(folder / 'submit.json', receipt)
    wait = completion_wait(api, SimpleNamespace(id=job, job=True, updates=False))
    save(folder / 'wait.json', wait)
    result = work.result(job)
    save(folder / 'result-summary.json', result)
    collection = work.collect(job, folder / 'collected', None, True)
    save(folder / 'collection.json', collection)
    assert wait['terminal'] and collection['complete'] and collection['excluded'] == 0
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}, result
    run = folder / 'collected' / result['runId']
    assert json.loads((run / 'result.json').read_text())['exitCode'] == 0
    raw = json.loads((run / 'stdout.log').read_text())
    assert raw['frames'] == 20000 and raw['voices'] == 45
    assert raw['profile'] == item['profile'] and raw['workers'] == item['workers']
    assert raw['checksum'] == raw['expected_checksum'] == 3686400000
    assert raw['maximum_error_24bit_units'] <= 32
    rows.append({**item, **raw, 'jobId': job, 'runId': result['runId']})
    save(NEW / 'observations.json', rows)
    print(json.dumps({'label': item['label'], 'runId': result['runId'], 'elapsed_us': raw['elapsed_us']}), flush=True)
status = api.json('/api/v1/status')
save(NEW / 'post-status.json', status)
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
print('COMPLETE', len(rows), flush=True)

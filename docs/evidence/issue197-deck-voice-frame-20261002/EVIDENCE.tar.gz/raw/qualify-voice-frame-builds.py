"""Bind retained CI source, compiler settings, exes and all runtime libraries."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path('/home/codex/src/steamdeck-xemu')
OUT = ROOT / 'artifacts/issue197-sample-memory/remaining-gates/voice-frame'
BUILDS = ROOT / 'artifacts/issue197-sample-memory/native-builds'
EXE = 'test-xbox-mcpx-apu-voice-frame'
variants = {
    'reference': ('3bc242754a6100b71495bb9dfcd241f3f10b24b9', 37028671968, BUILDS / '3bc24275-voice-frame-reference-ci'),
    'candidate': ('fa3146586c6ca242ec707ba00a012c4b0e0fbee5', 37028558983, BUILDS / 'fa314658-voice-frame-ci')}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def settings(path):
    text = re.sub(r'\x1b\[[0-9;]*m', '', path.read_text())
    markers = ['XEMU_BUILD_OPTIONS: ', 'C compiler for the host machine: ',
               'C linker for the host machine: ', 'C++ compiler for the host machine: ']
    result = {m.rstrip(': '): next(line.split(m, 1)[1] for line in text.splitlines() if m in line) for m in markers}
    assert 'clang 21.1.8' in result['C compiler for the host machine']
    assert 'ld.lld 21.1.8' in result['C linker for the host machine']
    assert all(flag in result['XEMU_BUILD_OPTIONS'] for flag in ('-Db_lto=true', '-Db_lto_mode=thin', '-Dx86_version=3'))
    assert any('test-xbox-mcpx-apu-voice-frame OK' in line and '6 subtests passed' in line for line in text.splitlines())
    return result

compiler = settings(OUT / 'reference-release-ci.log')
assert compiler == settings(OUT / 'candidate-release-ci.log')
tracked = ['tests/xbox/mcpx-apu/test-voice-frame.c', 'tests/xbox/mcpx-apu/VOICE-FRAME.md',
           'meson.build', '.github/workflows/build-linux.yml',
           'hw/xbox/mcpx/apu/vp/vp.c', 'hw/xbox/mcpx/apu/vp/vp.h',
           'hw/xbox/mcpx/apu/vp/adpcm.h', 'hw/xbox/mcpx/apu/vp/resample.h',
           'hw/xbox/mcpx/apu/vp/svf.h', 'hw/xbox/mcpx/apu/vp/hrtf.h',
           'hw/xbox/mcpx/apu/apu.c', 'hw/xbox/mcpx/apu/apu.h']
source = {}
files = []
libraries = None
for variant, (commit, ci, build) in variants.items():
    archive = next((build / 'source').glob('*.tar.zst'))
    selected = tracked + (['hw/xbox/mcpx/apu/vp/sample-memory.h'] if variant == 'candidate' else [])
    checks = {}
    prefix = None
    proc = subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE)
    with tarfile.open(fileobj=proc.stdout, mode='r|') as tar:
        for member in tar:
            parts = member.name.removeprefix('./').split('/', 1)
            if len(parts) != 2 or parts[1] not in selected:
                continue
            name = parts[1]
            data = tar.extractfile(member).read()
            expected = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=ROOT / 'worktrees/issue197-sample-memory')
            assert data == expected, name
            checks[name] = hashlib.sha256(data).hexdigest()
            dest = OUT / 'source' / variant / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
    assert proc.wait() == 0 and set(checks) == set(selected), set(selected) - set(checks)
    source[variant] = {'commit': commit, 'ciRun': ci, 'archiveSha256': sha(archive), 'sourceSha256': checks,
                       'elfNotes': subprocess.check_output(['readelf', '-n', str(build / EXE)], text=True)}
    exe = build / EXE
    files.append({'path': variant + '/' + EXE, 'source': str(exe), 'sha256': sha(exe), 'bytes': exe.stat().st_size})
    library = build / 'squashfs-root/usr/lib'
    current = {p.name: sha(p) for p in library.iterdir()}
    assert len(current) == 38
    if libraries is None:
        libraries = current
        for name in sorted(current):
            p = library / name
            files.append({'path': 'lib/' + name, 'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
    else:
        assert current == libraries, 'Corresponding libraries differ.'
for name in tracked[:2]:
    assert source['reference']['sourceSha256'][name] == source['candidate']['sourceSha256'][name]
receipt = {'qualified': True, 'fixedOriginal': 'ee5ce48b48784f999af374c1452003f8b2b1230f',
           'source': source, 'compilerSettings': compiler, 'runtimeLibrariesIdentical': True,
           'runtimeLibraryCount': 38, 'files': files,
           'scope': 'Matched actual production VP fixed-work fixture; no guest, DSP, renderer or audible output.'}
(OUT / 'matched-build-qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'qualified': True, 'files': len(files), 'libraries': 38, 'compilerSettings': compiler}))

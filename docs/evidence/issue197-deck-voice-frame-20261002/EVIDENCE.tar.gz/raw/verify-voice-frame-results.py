"""Independently reparse all raw native evidence; never launch measurements."""
from pathlib import Path
import json
import statistics
import sys
import csv

ROOT = Path(__file__).resolve().parent
corrected = '--indexed' in sys.argv
NATIVE = ROOT / ('deck-indexed' if corrected else 'deck-native')
plan = json.loads((NATIVE / 'matrix-plan.json').read_text())
identity = json.loads((ROOT / 'matched-build-qualification.json').read_text())
indexed = {}
server_comparison = json.loads((ROOT / 'server-comparison.json').read_text())
with (ROOT / 'server-comparison.csv').open(newline='') as stream:
    complete_server_rows = list(csv.DictReader(stream))
for variant in ('reference', 'candidate'):
    records = json.loads((ROOT / ('server-' + variant + '-runs.json')).read_text())
    indexed.update({r['runId']: r for r in records['items']})
rows = []
attempts = []
for item in plan['order']:
    folder = NATIVE / item['label']
    result = json.loads((folder / 'result-summary.json').read_text())
    collection = json.loads((folder / 'collection.json').read_text())
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}
    assert collection['complete'] and collection['excluded'] == 0
    run = folder / 'collected' / result['runId']
    job = json.loads((run / 'job.json').read_text())
    exe = next(f for f in identity['files'] if f['path'] == job['Executable'])
    assert job['ExpectedExecutableSha256'] == exe['sha256']
    assert json.loads((run / 'result.json').read_text())['exitCode'] == 0
    raw = (run / 'stdout.log').read_text()
    if item['correctness']:
        assert '1..6' in raw and sum(line.startswith('ok ') for line in raw.splitlines()) == 6
        assert not any(line.startswith('not ok') for line in raw.splitlines())
    else:
        value = json.loads(raw)
        assert value['profile'] == item['profile'] and value['workers'] == item['workers']
        assert value['frames'] == plan['frames'] and value['voices'] == 45
        assert value['warmup_frames'] == 256 and value['samples_per_voice_frame'] == 32
        assert value['checksum'] == value['expected_checksum'] == plan['frames'] * 184320
        assert value['correctness'] == 'PASS' and 0 <= value['maximum_error_24bit_units'] <= 32
        assert value['elapsed_us'] > 0
        # Index metrics are another independent transport of the raw value.
        index = indexed[result['runId']]
        assert index['eligible'] and not index['issues'] and index['sha256'] == exe['sha256']
        metric = next(m for m in index['metrics'] if m['name'] == 'validated-vp-frame-time')
        assert metric['value'] == value['elapsed_us'] and metric['unit'] == 'us' and metric['direction'] == 'lower'
        rows.append({**item, **value, 'runId': result['runId']})
    attempts.append({'label': item['label'], 'runId': result['runId'], 'fileCount': collection['fileCount'], 'outcome': result['outcome']})

assert len(rows) == 72 and len(attempts) == (72 if corrected else 74)
assert rows == [{k: v for k, v in r.items() if k != 'jobId'} for r in json.loads((NATIVE / 'observations.json').read_text())]

def span(values):
    return 100 * (max(values) - min(values)) / statistics.median(values)

def improvement(a, b):
    return 100 * (a - b) / a

results = []
for workers in (1, 8):
    for profile in ('mono-adpcm', 'stereo-adpcm', 'mono-pcm'):
        group = [r for r in rows if r['profile'] == profile and r['workers'] == workers]
        if corrected:
            assert len({indexed[r['runId']]['testKey'] for r in group}) == 1, 'A/B workload identity does not match.'
            assert len({indexed[r['runId']]['environmentKey'] for r in group}) == 1
            for variant in ('reference', 'candidate'):
                assert len({indexed[r['runId']]['buildKey'] for r in group if r['variant'] == variant}) == 1
            key = indexed[group[0]['runId']]['testKey'][:12]
            context = indexed[group[0]['runId']]['environmentKey'][:12]
            matched = [r for r in complete_server_rows if r['test_key'] == key and r['context'] == context and r['metric'] == 'validated-vp-frame-time']
            assert len(matched) == 1, 'Retrieve all server comparison rows before qualification.'
            saved = matched[0]
            assert saved['improvement_percent'], 'The server has not produced a comparable percentage.'
            sr = {'testKey': key, 'context': context, 'na': int(saved['n_a']), 'nb': int(saved['n_b']),
                  'a': float(saved['a']), 'b': float(saved['b']), 'verdict': saved['verdict'],
                  'improvementPercent': float(saved['improvement_percent'])}
            assert sr['na'] == 8 and sr['nb'] == 4 and sr['improvementPercent'] is not None
            all_a = statistics.median(r['elapsed_us'] for r in group if r['variant'] == 'reference')
            all_b = statistics.median(r['elapsed_us'] for r in group if r['variant'] == 'candidate')
            assert sr['a'] == all_a and sr['b'] == all_b
        control = [r['elapsed_us'] for r in group if r['phase'] == 'aaaa']
        balanced = [r for r in group if r['phase'] != 'aaaa']
        a = [r['elapsed_us'] for r in balanced if r['variant'] == 'reference']
        b = [r['elapsed_us'] for r in balanced if r['variant'] == 'candidate']
        assert len(a) == len(b) == len(control) == 4
        assert len({r['final_cbo'] for r in group}) == 1
        ma, mb = statistics.median(a), statistics.median(b)
        phases = {}
        pairs = []
        for phase in ('abba', 'baab'):
            ordered = [r for r in group if r['phase'] == phase]
            pa = statistics.median(r['elapsed_us'] for r in ordered if r['variant'] == 'reference')
            pb = statistics.median(r['elapsed_us'] for r in ordered if r['variant'] == 'candidate')
            phases[phase] = improvement(pa, pb)
            for chunk in (ordered[:2], ordered[2:]):
                ra = next(r['elapsed_us'] for r in chunk if r['variant'] == 'reference')
                rb = next(r['elapsed_us'] for r in chunk if r['variant'] == 'candidate')
                pairs.append(improvement(ra, rb))
        results.append({'profile': profile, 'workers': workers, 'baseline_us': ma,
                        'candidate_us': mb, 'saved_us': ma - mb, 'improvement_percent': improvement(ma, mb),
                        'baselineRange_us': [min(a), max(a)], 'candidateRange_us': [min(b), max(b)],
                        'originalControlRange_us': [min(control), max(control)],
                        'originalControlSpread_percent': span(control),
                        'balancedOriginalSpread_percent': span(a), 'balancedCandidateSpread_percent': span(b),
                        'orders': phases, 'adjacentPairs_percent': pairs,
                        'serverIncludingControls': sr if corrected else None,
                        'correctness': 'PASS', 'allPairsBetter': min(pairs) > 0})
summary = {'scope': 'Fixed 20000 production VP frames including output validation; no game FPS, DSP, pacing or audible claim.',
           'formula': '100*(median original_us - median candidate_us)/median original_us; positive is better',
           'results': results, 'attempts': attempts, 'correctnessProcesses': 0 if corrected else 2, 'timingProcesses': 72,
           'completeCollection': True, 'excludedFiles': 0, 'allExitZero': True,
           'controlledHostPowerOrAffinity': False,
           'canonicalCohortKeysMatch': corrected,
           'recommendation': 'HOLD: evaluate synthetic results separately; prior game gain inconclusive and other declared PR gates remain.'}
(ROOT / ('INDEXED-VERIFIED-SUMMARY.json' if corrected else 'VERIFIED-SUMMARY.json')).write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(results, indent=2))

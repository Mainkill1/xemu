"""Retained matched production-VP campaign; execution/collection via HTTP only.

Build identities must be qualified before invocation. Every attempt uses a
fresh process. Resume reads the existing authoritative job; it never reruns it.
"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import shutil
import sys
import urllib.parse

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_wait import execute as completion_wait

OUT = ROOT / 'artifacts/issue197-sample-memory/remaining-gates/voice-frame'
NATIVE = OUT / 'deck-native'
PACKAGE = NATIVE / 'package'
EXE = 'test-xbox-mcpx-apu-voice-frame'
FRAMES = 20000
api = RunnerApi('http://10.0.0.123:9368')
work = Workflows(api)

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

identity = json.loads((OUT / 'matched-build-qualification.json').read_text())
assert identity['qualified'] is True
files = []
for item in identity['files']:
    source = Path(item['source'])
    assert digest(source) == item['sha256']
    target = PACKAGE / item['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    if item['path'].endswith(EXE):
        target.chmod(0o755)
    files.append({key: item[key] for key in ('path', 'bytes', 'sha256')})
save(NATIVE / 'payload-manifest.json', {'files': files, 'qualification': identity})
job = json.loads((ROOT / 'artifacts/issue197-sample-memory/remaining-gates/memory-lifetime/deck-native/candidate/definition.json').read_text())
job['TimeoutSeconds'] = 180
job['Experiment']['Id'] = 'issue197-production-voice-frame-20261002'
job['RequiredFiles'] = [item['path'] for item in files]
schedule = []
for variant in ('reference', 'candidate'):
    schedule.append({'label': variant + '-correctness', 'variant': variant, 'correctness': True})
for workers in (1, 8):
    for profile in ('mono-adpcm', 'stereo-adpcm', 'mono-pcm'):
        for phase, order in (('aaaa', 'AAAA'), ('abba', 'ABBA'), ('baab', 'BAAB')):
            for ordinal, letter in enumerate(order, 1):
                schedule.append({'label': f'{profile}-w{workers}-{phase}-{ordinal}-{letter.lower()}',
                    'variant': 'reference' if letter == 'A' else 'candidate',
                    'correctness': False, 'workers': workers, 'profile': profile,
                    'phase': phase, 'ordinal': ordinal})
plan = {'host': '10.0.0.123', 'runner': 'f5b3e58', 'frames': FRAMES,
        'voices': 45, 'warmupFrames': 256, 'timedValidationIncluded': True,
        'order': schedule, 'interventions': 'none; no affinity/power changes, no renderer/Mesa, new process per attempt'}
plan_path = NATIVE / 'matrix-plan.json'
if plan_path.exists():
    assert json.loads(plan_path.read_text()) == plan
else:
    preflight = api.json('/api/v1/status')
    assert preflight['Phase'] == 'idle' and preflight['CurrentJob'] is None
    assert preflight['Queue']['Pending'] == preflight['Queue']['Testing'] == 0
    save(NATIVE / 'preflight.json', preflight)
    save(plan_path, plan)

rows = []
reuse = None
correctness = []
for item in schedule:
    variant = item['variant']
    job['Id'] = 'issue197-vp-' + item['label'] + '-20261002'
    job['Executable'] = variant + '/' + EXE
    job['ExpectedExecutableSha256'] = next(f['sha256'] for f in files if f['path'] == job['Executable'])
    job['Experiment']['Variant'] = variant
    if item['correctness']:
        job['Arguments'] = ['--tap']
        job['Workload'] = {'CorrectnessChecks': [
            {'Name': 'six-case-plan', 'Path': 'stdout.log', 'ContainsText': '1..6'},
            {'Name': 'last-case', 'Path': 'stdout.log', 'ContainsText': 'ok 6 /mcpx-apu/voice-frame/mono-pcm-worker8'}],
            'EvidenceRequirements': [{'Name': 'full-TAP', 'Path': 'stdout.log', 'MinimumBytes': 200}]}
    else:
        job['Arguments'] = ['--benchmark', item['profile'], str(FRAMES), str(item['workers'])]
        job['Workload'] = {'CorrectnessChecks': [
            {'Name': 'fixed-checksum', 'Path': 'stdout.log', 'ContainsText': f'"checksum":{FRAMES * 184320},"expected_checksum":{FRAMES * 184320}'},
            {'Name': 'oracle-pass', 'Path': 'stdout.log', 'ContainsText': '"correctness":"PASS"'}],
            'EvidenceRequirements': [{'Name': 'fixed-work-output', 'Path': 'stdout.log', 'MinimumBytes': 200}],
            'ReportedMetrics': [{'Name': 'validated-vp-frame-time', 'Path': 'stdout.log', 'JsonProperty': 'elapsed_us', 'Unit': 'us', 'Direction': 'lower'}]}
    directory = NATIVE / item['label']
    marker = directory / 'definition.json'
    if marker.exists():
        assert json.loads(marker.read_text()) == job
        # An existing definition is never permission to launch a replacement.
        current = work.status(job['Id'])
        assert current['state'] in ('tested', 'testing', 'queued', 'submitted'), current
    else:
        save(marker, job)
        save(PACKAGE / 'job.json', job)
        save(directory / 'submit.json', work.submit(PACKAGE, job['Id'], reuse, 8 * 1024 * 1024))
    waited = completion_wait(api, SimpleNamespace(id=job['Id'], job=True, updates=False))
    save(directory / 'wait.json', waited)
    result = work.result(job['Id'])
    save(directory / 'result-summary.json', result)
    collected = work.collect(job['Id'], directory / 'collected', None, True)
    save(directory / 'collection.json', collected)
    assert waited['terminal'] and collected['complete'] and collected['excluded'] == 0
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}, result
    run = directory / 'collected' / result['runId']
    assert json.loads((run / 'result.json').read_text())['exitCode'] == 0
    text = (run / 'stdout.log').read_text()
    if item['correctness']:
        assert len([line for line in text.splitlines() if line.startswith('ok ')]) == 6
        assert not any(line.startswith('not ok') for line in text.splitlines())
        correctness.append({**item, 'runId': result['runId'], 'passed': 6})
    else:
        raw = json.loads(text)
        assert raw['profile'] == item['profile'] and raw['workers'] == item['workers']
        assert raw['frames'] == FRAMES and raw['voices'] == 45 and raw['warmup_frames'] == 256
        assert raw['checksum'] == raw['expected_checksum'] == FRAMES * 184320
        assert raw['maximum_error_24bit_units'] <= 32 and raw['elapsed_us'] > 0
        rows.append({**item, **raw, 'jobId': job['Id'], 'runId': result['runId']})
        save(NATIVE / 'observations.json', rows)
    print(json.dumps({'label': item['label'], 'runId': result['runId'], 'elapsed_us': rows[-1]['elapsed_us'] if not item['correctness'] else None, 'outcome': result['outcome']}), flush=True)
    reuse = job['Id']
save(NATIVE / 'correctness-summary.json', correctness)
post = api.json('/api/v1/status')
save(NATIVE / 'post-status.json', post)
assert post['Phase'] == 'idle' and post['CurrentJob'] is None
# Retain reusable benchmark templates and all build slots, including both exes.
for item in schedule:
    if item['correctness'] or item['phase'] != 'abba' or item['ordinal'] not in (1, 2):
        continue
    test = 'mcpx-production-vp-' + item['profile'] + '-w' + str(item['workers']) + '-' + item['variant'] + '-v1'
    receipt = api.json('/api/v1/tests/' + urllib.parse.quote(test, safe='') + '/bake', 'POST', {
        'sourceJobId': 'issue197-vp-' + item['label'] + '-20261002',
        'description': 'Fixed 20000 production VP frames, 45 voices, 256 warmup; independent mix/checksum oracle. Host elapsed includes validation. No game/FPS or DSP claim.',
        'buildFiles': [f['path'] for f in files]})
    save(NATIVE / 'saved-tests' / (test + '.json'), receipt)
print('COMPLETE', len(rows), flush=True)

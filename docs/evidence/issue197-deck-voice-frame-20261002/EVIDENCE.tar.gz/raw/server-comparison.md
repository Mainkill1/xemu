A f6b1e664fda3 -> B e9b055f095ea | partial
Attempts 97/49; blocked 2. Reference: explicit A.

### mcpx-production-vp-stereo-adpcm-w8-candidate-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 6621037.00 | 6365266.00 | 6620789.25 [6606211.00,6643059.00] | 6365521.25 [6352475.00,6379078.00] | 8/4 | improved | +3.86% |

### --tap / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| (none) () | N/A | N/A | N/A | N/A | 1/0 | missingB | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 8/0 | missingB | N/A |

### mcpx-production-vp-mono-adpcm-w1-candidate-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 5407760.00 | 5359669.50 | 5413888.75 [5373316.00,5482181.00] | 5357570.50 [5255290.00,5455653.00] | 8/4 | improved | +0.89% |

### mcpx-production-vp-mono-pcm-w8-candidate-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 6147662.00 | 6165290.50 | 6165222.13 [6139925.00,6287105.00] | 6168156.75 [6153898.00,6188148.00] | 8/4 | regressed | -0.29% |

### --tap / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| (none) () | N/A | N/A | N/A | N/A | 0/1 | missingA | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 8/0 | missingB | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 0/4 | missingA | N/A |
12 additional rows omitted; use comparison CSV.
Improvement: positive is better; lower=(A-B)/A, higher=(B-A)/A. Medians and distributions are across attempts, not pooled guest samples. Descriptive, not a significance test.

"""Publish every attempt with a verified archive and readable bounded report."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue197-sample-memory')
OUT = REPO / 'docs/evidence/issue197-deck-voice-frame-20261002'
OUT.mkdir(parents=True, exist_ok=True)
summary = json.loads((RAW / 'INDEXED-VERIFIED-SUMMARY.json').read_text())
initial = json.loads((RAW / 'VERIFIED-SUMMARY.json').read_text())
identity = json.loads((RAW / 'matched-build-qualification.json').read_text())
ci = {v: json.loads((RAW / (v + '-ci.json')).read_text()) for v in ('reference', 'candidate')}
assert all(c['conclusion'] == 'success' for c in ci.values())
for value in ci.values():
    required = [j for j in value['jobs'] if j['name'] in ('Build / Linux / Build for Ubuntu (x86_64, release)', 'Build / Unit tests / Run unit tests')]
    assert len(required) == 2 and all(j['conclusion'] == 'success' for j in required)
ci_counts = '; '.join(v + ': ' + str(sum(j['conclusion'] == 'success' for j in c['jobs'])) + '/' + str(len(c['jobs'])) + ' jobs reported success' for v, c in ci.items())
assert len(summary['attempts']) == 72 and summary['canonicalCohortKeysMatch'] is True
assert len(initial['attempts']) == 74
assert len(list((RAW / 'deck-native/saved-tests').glob('*.json'))) == 12
payloads, omissions = {}, []
for path in sorted(RAW.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.name == 'package.log':
        continue
    name = path.relative_to(RAW).as_posix()
    if 'deck-native/package/' in name:
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        omissions.append({'path': name, 'bytes': path.stat().st_size, 'sha256': digest,
                          'reason': 'immutable native binary/library bundle retained locally and on runner; exact CI identities and source retained'})
    else:
        payloads['raw/' + name] = path.read_bytes()
for name in ('voice-frame-focused.txt', 'voice-frame-focused.json'):
    payloads['local-meson/' + name] = (REPO / 'build-sample-memory/meson-logs' / name).read_bytes()
payloads['source/harness.patch'] = subprocess.check_output(['git', 'diff', '90fa3139f38250383f794ac9ccfffc2dedb4a530', 'fa3146586c6ca242ec707ba00a012c4b0e0fbee5'], cwd=REPO)
payloads['SUMMARY.json'] = (json.dumps(summary, indent=2) + '\n').encode()
entries = []
archive = OUT / 'EVIDENCE.tar.gz'
with archive.open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
                entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries)
    for entry in entries:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
with archive.open('rb') as stream:
    archive_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
(OUT / 'INDEX.json').write_text(json.dumps({'archive': archive.name, 'bytes': archive.stat().st_size,
    'sha256': archive_hash, 'payloads': entries, 'omissions': omissions}, indent=2) + '\n')
(OUT / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'INITIAL-DIAGNOSTIC-SUMMARY.json').write_text(json.dumps(initial, indent=2) + '\n')

def table():
    lines = ['| Profile | Workers | Original s | Candidate s | Saved s | Improvement % | Correctness |',
             '| --- | ---: | ---: | ---: | ---: | ---: | --- |']
    for row in summary['results']:
        lines.append(f"| {row['profile']} | {row['workers']} | {row['baseline_us']/1e6:.6f} | {row['candidate_us']/1e6:.6f} | {row['saved_us']/1e6:+.6f} | {row['improvement_percent']:+.2f}% | PASS |")
    return '\n'.join(lines)

variation = ['| Profile | Workers | A/A spread | ABBA improvement | BAAB improvement | Four adjacent-pair improvements |',
             '| --- | ---: | ---: | ---: | ---: | --- |']
for row in summary['results']:
    pairs = ', '.join(f'{p:+.2f}%' for p in row['adjacentPairs_percent'])
    variation.append(f"| {row['profile']} | {row['workers']} | {row['originalControlSpread_percent']:.2f}% | {row['orders']['abba']:+.2f}% | {row['orders']['baab']:+.2f}% | {pairs} |")
hashes = {v: next(f['sha256'] for f in identity['files'] if f['path'].startswith(v + '/')) for v in ('reference', 'candidate')}
report = f'''# Matched production voice-frame comparison on Steam Deck

**Decision: HOLD.** This packet tests the performance scope of
[xemu draft PR275](https://github.com/Mainkill1/xemu/pull/275), issue #197.
It measures actual production voice processing, decoding, sinc SRC, mixing
and worker dispatch plus identical output validation. It is synthetic fixed
work, not game FPS, full DSP, audio pacing or audible playback.

## Baseline versus candidate

Each number is host monotonic time for **20,000 frames of 45 voices**,
32 samples per voice per frame. Each process excludes 256 startup frames
and one verified frame. Primary medians use **four original and four candidate
processes**, physical **ABBA then BAAB** through pinned saved tests with
all forty build slots explicit. The preceding four original A/A
controls are separate and not pooled into these medians.
Positive Improvement % means less time: `100*(original-candidate)/original`.

{table()}

Mono/stereo ADPCM exercise the changed reader; mono PCM is the unaffected
control. This directly extends the earlier **48.04% / 54.35% encoded-reader
component reductions** to a larger processing boundary. The earlier component
did not include this decoder/SRC/mixer/worker work and cannot predict these
percentages or game FPS. See the existing component and inconclusive parked
PGR2 packets linked in PR275. All sixteen ADPCM adjacent pairs use less time,
but mono with one worker varies between +2.45% and +0.38% by order. Both PCM
medians are slower: one-worker orders reverse sign, and all four eight-worker
pairs are slightly slower. The small PCM differences are near or below A/A
variation; they remain disclosed costs, not automatically dismissed as noise.
Keep the small/mixed results descriptive; this
campaign provides no confidence interval or general game-speedup proof.

## Variation and order

{chr(10).join(variation)}

A/A spread is `(maximum-minimum)/median`; individual ranges and within-build
balanced spreads are in [SUMMARY.json](SUMMARY.json). Four pairs are the
adjacent A/B or B/A processes in ABBA and BAAB. No host power policy or
CPU affinity was pinned. All repetitions, controls and regressions remain
visible; none was dropped or replaced. The included per-frame oracle checks
1,024 output samples and calculates 64 checksum contributions, so its common
cost can dilute the percentage of the production work itself.

## Source, builds and execution

- Fixed original production: `ee5ce48b48784f999af374c1452003f8b2b1230f`.
- Reference harness input: `3bc242754a6100b71495bb9dfcd241f3f10b24b9`;
  only the identical fixture, documentation and build/CI registration were added.
- Candidate input: `fa3146586c6ca242ec707ba00a012c4b0e0fbee5`.
  Production reader/caller remain identical to the prior measured `e25b0ba`.
- CI [reference 37028671968](https://github.com/Mainkill1/xemu/actions/runs/37028671968)
  and [candidate 37028558983](https://github.com/Mainkill1/xemu/actions/runs/37028558983)
  report workflow success ({ci_counts}). The earlier pending Windows PDB
  snapshot is retained. Both release builds pass all six retained VP cases. Candidate
  production original/candidate memory modes each pass thirteen cases.
- Identical Clang/LLD **21.1.8**, release ThinLTO, x86 version 3 and all
  **38 corresponding runtime libraries**. Source archives match the exact
  fixture, VP/decoder/SRC and build inputs. Qualification receipts, compiler
  logs and source copies are inside the archive.
- Executable SHA-256 original `{hashes['reference']}`;
  candidate `{hashes['candidate']}`.
- Deck **10.0.0.123**, maintained HTTP runner **f5b3e58**, port 9368.
  All upload, execution and collection use HTTP. No Windows or SSH measurement.
  One immutable forty-file bundle contains both builds and shared libraries.
  No renderer, Mesa cache, QMP, input replay, timer throttle or guest clock is used.

## Correctness and retained tooling

Both native correctness processes pass **6/6**; all **72 corrected timing processes**
exit zero and report completed/passed/complete/eligible. Every timed run
checks checksum **3,686,400,000**, every output bin against the independently
expected `45/512` signed mix, error at most 32 signed-24-bit units, exact
45-voice dispatch, active voice states, common final buffer offset, and poisoned
physical SGE gaps. Worker and SRC finalization complete. Original/candidate
final offsets agree within every profile/worker cohort.

Local six-case checks and the four focused Meson targets pass. Deliberate
VP-monitor silence aborts with checksum zero instead of 184320. Invalid CLI
frames/profile/worker arguments exit two. This constant-signal oracle does
not prove sample ordering; the separate ramp/remap/lifetime tests provide
that coverage. Previously published broader local failures remain unresolved
and are retained in the lifetime packet; this focused run does not erase them.

The executable and usage contract remain in `tests/xbox/mcpx-apu`; Meson and
Linux CI retain it. Twelve reusable profile/worker/build tests are installed
on the Deck, each declaring all forty replacement build slots. Scripts,
frozen plans, indexed server measurements, comparisons, native launch/host
records and all **146 complete collections** are in [EVIDENCE.tar.gz](EVIDENCE.tar.gz).
[INDEX.json](INDEX.json) lists every payload hash and large-binary omission;
omitted binaries are retained locally and by CI/runner identities. Archive
SHA-256: `{archive_hash}`.

## Preserved initial campaign and reporting correction

The initial two correctness and 72 timing processes all completed and passed;
their measured values are in
[INITIAL-DIAGNOSTIC-SUMMARY.json](INITIAL-DIAGNOSTIC-SUMMARY.json).
Direct jobs declared no explicit build replacement slots. Default hash
indexing excluded only the running executable, treating the unused companion
executable as fixed workload data. A/B therefore had distinct canonical
workload keys: the server correctly reported missing A/B rows,
**NOT COMPARABLE**. Those values do not establish an eligible server comparison.

The corrected campaign uses the twelve retained saved tests, each declaring
both executables and all 38 libraries as build slots. No product, binary,
clock, oracle, frame count, worker count or settings changed. It runs a fresh,
explicitly preserved A/A + ABBA + BAAB campaign; no failed or incomparable
attempt was overwritten. Independent verification requires identical A/B
canonical workload/environment keys in each corrected cohort and matches every
raw time to its indexed reported metric. The server's combined history still
includes incomparable initial rows and untimed TAP controls. Its matched
corrected cohorts pool eight original processes (including four controls)
against four candidate processes; the primary table keeps the balanced
four/four subset separate. Full server output is retained.

An earlier source-qualification script used the wrong Meson path; its failed
preflight and correction are retained. This happened before native execution
and required no build or measurement rerun.

## Remaining limits

Required guest XISO timings remain **NOT COMPARABLE**: their sample-progress
polling is timer paced, and newly added framebuffer references are not yet
approved. Passing guest mix checks are correctness evidence. Audible playback
parity and repeatable whole-game/resource qualification remain open. The
previous PGR2 balanced result was inconclusive. This packet does not make
PR275 ready or authorize a merge.
'''
(OUT / 'REPORT.md').write_text(report)
print(json.dumps({'payloads': len(entries), 'omissions': len(omissions), 'archiveBytes': archive.stat().st_size, 'archiveSha256': archive_hash}))

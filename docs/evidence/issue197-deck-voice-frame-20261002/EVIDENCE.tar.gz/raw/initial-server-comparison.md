A f6b1e664fda3 -> B e9b055f095ea | incomparable
Attempts 49/25; blocked 2. Reference: explicit A.

### --tap / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| (none) () | N/A | N/A | N/A | N/A | 1/0 | missingB | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 8/0 | missingB | N/A |

### --tap / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| (none) () | N/A | N/A | N/A | N/A | 0/1 | missingA | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 8/0 | missingB | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 0/4 | missingA | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 0/4 | missingA | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 8/0 | missingB | N/A |

### --benchmark / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | N/A | N/A | N/A | N/A | 0/4 | missingA | N/A |
6 additional rows omitted; use comparison CSV.
Improvement: positive is better; lower=(A-B)/A, higher=(B-A)/A. Medians and distributions are across attempts, not pooled guest samples. Descriptive, not a significance test.

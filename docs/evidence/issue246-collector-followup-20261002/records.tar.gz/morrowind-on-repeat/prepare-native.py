"""One declared reproduction attempt, preserving the original failed procedure.

Clone the immutable unprofiled collector-ON procedure through maintained HTTP;
no plan/config/build/cache changes, retries, thresholds or outcome repairs.
"""
from pathlib import Path
import json
import sys

root = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(root / 'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows

api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api, progress=True)
source = 'issue246-deck-collector-morrowind-newgame-v3'
name = 'issue246-deck-collector-morrowind-on-repro-v1'
out = root / 'artifacts/issue246-texture-allocation/native-collector/morrowind-on-repro-v1'
out.mkdir(parents=True, exist_ok=False)

def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

status = api.json('/api/v1/status')
save('deck-before.json', status)
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
assert not status['Queue']['Pending'] and not status['Queue']['Testing']
(out / 'prepare-native.py').write_bytes(Path(__file__).read_bytes())
save('reproduction-contract.json', {
    'sourceJob': source, 'newJob': name,
    'hypothesis': 'Determine whether the PFIFO abort reproduces with the exact collector-ON procedure; no causal claim from a single repeat.',
    'changedFactors': ['Attempt identity only'],
    'runtimeCommit': '8079502ae25a602e1395fa9ee87ec1ef8b57c9d6',
    'performanceComparison': 'Not measured',
})
save('cloned.json', wf.clone(source, name, False))
save('baked.json', api.json('/api/v1/tests/' + name + '/bake', 'POST', {
    'sourceJobId': name, 'buildFiles': ['xemu'],
    'description': 'Issue246 explicit unchanged collector-ON Morrowind reproduction of PFIFO abort: identical binary, plan, state assets and private Mesa; original failure preserved; no performance claim',
}))
save('submitted.json', wf.submit_draft(name))
print(json.dumps(wf.status(name)))

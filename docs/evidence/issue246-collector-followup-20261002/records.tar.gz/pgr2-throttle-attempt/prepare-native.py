"""Extend the existing frozen PGR2 allocation procedure with a bounded throttle.

Keep native assets/build/settings and early navigation unchanged. Preserve this
as a saved test and inspect actual captures before claiming guest movement/churn.
"""
from pathlib import Path
import copy
import json
import sys

root = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(root / 'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi, job_url
from runner_workflows import Workflows

source = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-v1'
name = 'issue246-deck-collector-pgr2-throttle-v1'
out = root / 'artifacts/issue246-texture-allocation/native-collector/pgr2-throttle-v1'
manifest = copy.deepcopy(json.loads((source / 'manifest.json').read_text()))
previous = manifest['id']
manifest['id'] = name
job = manifest['job']
job['id'] = name
plan = job['plan']
index = next(i for i, step in enumerate(plan) if step.get('diagnosticId') == 'allocation-schema')
extra = [{'type': 'segment_start', 'name': 'throttle-observation'}]
for seconds in [15, 30, 45]:
    extra.extend([{'type': 'button', 'button': 'RTrigger', 'durationMs': 15000},
                  {'type': 'screenshot', 'name': f'throttle-{seconds}s'}])
extra.extend([{'type': 'segment_end', 'name': 'throttle-observation'},
              {'type': 'button', 'button': 'Start', 'durationMs': 100},
              {'type': 'wait', 'delayMs': 2000},
              {'type': 'screenshot', 'name': 'pause-menu-observation'}])
plan[index:index] = extra
job['tags'].append('bounded-throttle-observation')
job['experiment'].update(id=name, variant='collector-on-throttle-diagnostic',
    variedFactors=['Extend frozen PGR2 loading/grid procedure with 45 seconds of scripted throttle and pause-menu capture; no performance comparison'])
job['experiment']['controlledFactors'].append('Same B binary, readers, pinned parent libraries, early plan and cold private state as original PGR2 collector procedure')
for label in ['throttle-15s', 'throttle-30s', 'throttle-45s', 'pause-menu-observation']:
    job['workload']['evidenceRequirements'].append({
        'name': label + '-capture', 'scope': 'result',
        'path': 'screenshots/' + label + '.png', 'mustExist': True, 'minimumBytes': 1000})
api = RunnerApi('http://10.0.0.123:9368')
wf = Workflows(api, progress=True)
status = api.json('/api/v1/status')
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
assert not status['Queue']['Pending'] and not status['Queue']['Testing']
out.mkdir(parents=True, exist_ok=False)

def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

save('deck-before.json', status)
save('manifest.json', manifest)
for file in ['xemu.toml', 'build-identity.json']:
    (out / file).write_bytes((source / file).read_bytes())
(out / 'prepare-native.py').write_bytes(Path(__file__).read_bytes())
save('created.json', api.json('/api/v1/jobs', 'POST', manifest))
if wf.status(name)['state'] == 'busy':
    wf.operation(name)
api.json(job_url(name) + '/reuse', 'POST', {'sourceJobId': previous})
wf.operation(name)
save('files-ready.json', api.json(job_url(name) + '/files'))
save('baked.json', api.json('/api/v1/tests/' + name + '/bake', 'POST', {
    'sourceJobId': name, 'buildFiles': ['xemu'],
    'description': 'Issue246 Vulkan PGR2 allocation observation: unchanged loading/grid recipe then three 15s throttle holds and pause-menu capture; private Mesa, full DSP/JIT; actual movement/churn reviewed after exit, no speedup scored',
}))
save('submitted.json', wf.submit_draft(name))
print(json.dumps(wf.status(name)))

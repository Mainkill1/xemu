"""Retained immutable PGR2 A/A or ABBA/BAAB cohort via maintained HTTP clients.

Requires complete reference/candidate build directories and a verified identity
ledger. Existing attempt directories are never overwritten; runs are not retried.
"""
from pathlib import Path
import argparse, hashlib, json, statistics, sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows

TEST = 'issue197-deck-pgr2-parked-warm60-300-v3'
REVISION = '3e72921bec480a32d141fe3b8c3894b6a64a864de037cee803d8fde52d7ef919'
EXPECTED = dict(execution='completed', correctness='passed', evidence='complete', comparison='eligible')

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=['controls', 'balanced'], required=True)
    parser.add_argument('--identity', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--prefix', required=True)
    parser.add_argument('--controls', type=Path, help='Completed matched controls SUMMARY.json; required for balanced phase.')
    args = parser.parse_args()
    identity = json.loads(args.identity.read_text())
    builds = {key: Path(identity[key]['directory']) for key in ['reference', 'candidate']}
    assert identity['reference']['sourceCommit'] == 'ee5ce48b48784f999af374c1452003f8b2b1230f'
    assert identity['runtimeLibrariesIdentical'] and len(identity['buildFiles']) == 39
    for key, directory in builds.items():
        for name in identity['buildFiles']:
            assert sha(directory / name) == identity[key]['files'][name]['sha256'], (key, name)
    for name in identity['buildFiles']:
        if name != 'xemu':
            assert identity['reference']['files'][name]['sha256'] == identity['candidate']['files'][name]['sha256'], name
    if args.phase == 'balanced':
        assert args.controls is not None, 'Balanced phase requires completed matched controls.'
        controls = json.loads(args.controls.read_text())
        assert controls['identitySha256'] == sha(args.identity)
        assert controls['phase'] == 'controls' and len(controls['runs']) == 2
        assert controls['controlsQualified']
        order = 'ABBABAAB'
    else:
        assert args.controls is None
        order = 'AA'
    args.output.mkdir(parents=True, exist_ok=False)
    api = RunnerApi('http://10.0.0.123:9368')
    work = Workflows(api)
    detail = api.json('/api/v1/tests/' + TEST + '/' + REVISION)
    assert sorted(detail['buildFiles']) == sorted(identity['buildFiles'])
    before = api.json('/api/v1/status')
    assert before['Phase'] == 'idle' and before['CurrentJob'] is None and before['Queue']['Pending'] == 0
    save(args.output / 'deck-before.json', before)
    frozen = dict(phase=args.phase, physicalOrder=order, testId=TEST, revision=REVISION,
                  identitySha256=sha(args.identity), identity=identity,
                  controls= str(args.controls) if args.controls else None,
                  controlsGate='Both original runs eligible with qualified private Mesa; mean guest-interval range/median <=5%. Preliminary n=2 repeatability only; reassess variation in balanced pairs.',
                  retries='none', nativeHost='Steam Deck 10.0.0.123')
    save(args.output / 'frozen-plan.json', frozen)
    summary = dict(phase=args.phase, identitySha256=frozen['identitySha256'], physicalOrder=order, runs=[])
    save(args.output / 'SUMMARY.json', summary)
    for ordinal, letter in enumerate(order, 1):
        key = 'reference' if letter == 'A' else 'candidate'
        directory = args.output / f'{ordinal:02d}-{letter}'
        directory.mkdir()
        job_id = f'{args.prefix}-{ordinal:02d}-{letter.lower()}'
        current = api.json('/api/v1/status')
        assert current['Phase'] == 'idle' and current['CurrentJob'] is None and current['Queue']['Pending'] == 0
        submitted = work.run_test(TEST, REVISION, job_id, builds[key],
                                  dict(experimentId=args.prefix, variant=key, reference='ee5ce48b48784f999af374c1452003f8b2b1230f'),
                                  8 * 1024 * 1024)
        save(directory / 'submitted.json', submitted)
        print('SUBMITTED', job_id, flush=True)
        terminal = work.wait(job_id, 660)
        save(directory / 'terminal.json', terminal)
        assert terminal['state'] == 'tested', terminal
        result = work.result(job_id)
        save(directory / 'result-summary.json', result)
        collection = work.collect(job_id, directory / 'collected', None, True)
        save(directory / 'collection.json', collection)
        assert collection['complete'] and collection['excluded'] == 0, collection
        run = Path(collection['directory'])
        performance = json.loads((run / 'performance.json').read_text())
        cache = json.loads((run / 'diagnostics/run-state/report.json').read_text())
        row = dict(jobId=job_id, runId=result['runId'], mode=letter, outcome=result['outcome'],
                   collection=collection, performance=performance,
                   mesa={k:cache[k] for k in ['DriverNamespaceVerified','DriverQualification','ComparisonReady','AllowUncontrolledDriverCache']})
        summary['runs'].append(row)
        save(args.output / 'SUMMARY.json', summary)
        print(json.dumps(dict(jobId=job_id, outcome=result['outcome'], meanIntervalMs=performance['Frames']['IntervalsMs']['Mean'])), flush=True)
        assert result['outcome'] == EXPECTED, result
        assert row['mesa'] == dict(DriverNamespaceVerified=True, DriverQualification='mesa_private_disk_writes_observed', ComparisonReady=True, AllowUncontrolledDriverCache=False), row['mesa']
    if args.phase == 'controls':
        means = [r['performance']['Frames']['IntervalsMs']['Mean'] for r in summary['runs']]
        spread = 100 * (max(means) - min(means)) / statistics.median(means)
        summary['originalMeanIntervalSpreadPercentOfMedian'] = spread
        summary['controlsQualified'] = spread <= 5
    else:
        summary['statistics'] = {}
        for label, getter in {
            'meanGuestFrameIntervalMs': lambda p:p['Frames']['IntervalsMs']['Mean'],
            'p95GuestFrameIntervalMs': lambda p:p['Frames']['IntervalsMs']['P95'],
            'p99GuestFrameIntervalMs': lambda p:p['Frames']['IntervalsMs']['P99'],
            'meanProcessCpuPercent': lambda p:p['Monitoring']['Cpu']['Mean'],
        }.items():
            a = statistics.median(getter(r['performance']) for r in summary['runs'] if r['mode'] == 'A')
            b = statistics.median(getter(r['performance']) for r in summary['runs'] if r['mode'] == 'B')
            summary['statistics'][label] = dict(referenceMedian=a, candidateMedian=b, saved=a-b, improvementPercent=100*(a-b)/a, nReference=4, nCandidate=4)
        summary['interpretation'] = 'Descriptive game measures only; inspect scenes, paired order and variation before claiming a gain. Does not qualify audio or affected XISO parity.'
    save(args.output / 'SUMMARY.json', summary)
    save(args.output / 'deck-after.json', api.json('/api/v1/status'))
    print('COHORT COMPLETE', json.dumps({k:v for k,v in summary.items() if k!='runs'}), flush=True)

if __name__ == '__main__':
    main()

"""Start only the already-frozen next campaign after confirmed prior terminal.
No uploads, diagnostic actions, retries or artifact transfers during benchmark.
"""
import json,subprocess,sys
from pathlib import Path
R=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(R/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi
api=RunnerApi('http://10.0.0.123:9368');P=R/'artifacts/issue263-pvideo-reuse/native-preparation/issue263-deck-pvideo-benchmark-v1';client=R/'worktrees/runner-plan-timeout/scripts/runner_xiso.py'
for previous,current in [('aaaa','abba'),('abba','baab')]:
 status=api.json('/api/v1/xiso-campaigns/i263-deck-vk-'+previous+'-v1')
 if not status['terminal']:
  with (P/(previous+'-continue-wait.log')).open('w') as out:subprocess.run(['python3',str(client),'--url',api.url,'--pretty','wait','i263-deck-vk-'+previous+'-v1','--updates'],stdout=out,check=True)
  status=api.json('/api/v1/xiso-campaigns/i263-deck-vk-'+previous+'-v1')
 assert status['terminal'] and status['remaining']==0 and status['finished']==status['attemptCount'],status
 (P/(previous+'-terminal.json')).write_text(json.dumps(status,indent=2)+'\n')
 started=api.json('/api/v1/xiso-campaigns/i263-deck-vk-'+current+'-v1/start','POST',{});(P/(current+'-started.json')).write_text(json.dumps(started,indent=2)+'\n')
 with (P/(current+'-wait.log')).open('w') as out:subprocess.run(['python3',str(client),'--url',api.url,'--pretty','wait','i263-deck-vk-'+current+'-v1','--updates'],stdout=out,check=True)

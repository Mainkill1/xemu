from pathlib import Path
import json,sys,subprocess
R=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(R/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi
api=RunnerApi('http://10.0.0.123:9368');A=R/'artifacts/issue263-pvideo-reuse';P=A/'native-preparation/issue263-deck-pvideo-benchmark-v1'
for phase in ['aaaa','abba','baab']:
 id='i263-deck-vk-'+phase+'-v1';status=api.json('/api/v1/xiso-campaigns/'+id)
 assert status['terminal'] and status['remaining']==0 and status['finished']==status['attemptCount'],status
 (P/(phase+'-terminal.json')).write_text(json.dumps(status,indent=2)+'\n')
 attempts=api.json('/api/v1/xiso-campaigns/'+id+'/attempts?offset=0&limit=100');assert attempts['nextOffset'] is None
 (P/(phase+'-attempts.json')).write_text(json.dumps(attempts,indent=2)+'\n')
 for row in attempts['items']:
  out=A/('native-deck-balanced-v1/'+phase);out.mkdir(parents=True,exist_ok=True)
  with (P/(row['id']+'-collect.log')).open('w') as log:
   subprocess.run(['python3',str(R/'worktrees/runner-plan-timeout/scripts/runner_api.py'),'--url',api.url,'collect',row['id'],str(out),'--all'],stdout=log,stderr=subprocess.STDOUT,check=True)
  print(row['id'],row['runId'],flush=True)
for variant,sha in [('parent','d406d6072238c81ebed3b144257fcfb23a5fd12b5215769f853d9365d33d5471'),('candidate','5dd8d5453574fdad00e2acd9d0dc4aacb1e32ca142334ce87a05226f99e46e5b')]:
 offset=0;records=[]
 while offset is not None:
  page=api.json(f'/api/v1/build-results/{sha}/runs?offset={offset}&limit=100');records.extend(page['items']);offset=page['nextOffset']
 (P/(variant+'-indexed-records.json')).write_text(json.dumps(records,indent=2)+'\n')
path='/api/v1/compare?A=d406d6072238c81ebed3b144257fcfb23a5fd12b5215769f853d9365d33d5471&B=5dd8d5453574fdad00e2acd9d0dc4aacb1e32ca142334ce87a05226f99e46e5b'
for format in ['json','csv','markdown']:
 with api.open(path+'&format='+format) as response: (P/('server-comparison.'+('md' if format=='markdown' else format))).write_bytes(response.read())
print('Collected full comparison and indexed records',flush=True)

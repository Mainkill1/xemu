"""Freeze an image diagnostic; uses the maintained runner only, no native launch."""
from pathlib import Path
import copy,json,sys
R=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(R/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi,job_url
from runner_workflows import Workflows
A=R/'artifacts/issue263-pvideo-reuse/native-preparation';api=RunnerApi('http://10.0.0.123:9368');wf=Workflows(api)
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
plan=json.loads((A/'candidate-path-plan-v2.json').read_text());chunk=plan['chunks'][0]
source=api.json('/api/v1/test-configs/'+chunk['testId']+'/'+chunk['revision'])['definition']
test='issue263-deck-pvideo-overlay-shots-v2';seed=test+'-seed';P=A/test;P.mkdir(exist_ok=True);dump(P/'source-definition.json',source)
job=copy.deepcopy(source['job']);job['id']=seed;job['tags']=['issue263','pvideo','host-overlay-image-diagnostic','fixture-v2','not-performance-proof']
job['plan']=[{'type':'wait','delayMs':11000}]+[{'type':'screenshot','name':f'overlay-{i:02d}','delayMs':250} for i in range(50)]
job['workload']['evidenceRequirements']+=[{'name':f'overlay-capture-{i:02d}','scope':'result','path':f'screenshots/overlay-{i:02d}.png','mustExist':True,'minimumBytes':1} for i in range(50)]
job['experiment']['id']='issue263-overlay-shots-v2';job['experiment']['allowOperatorIntervention']=True;job['experiment']['allowDiagnostics']=True
job['operations']={'mode':'diagnostic'};files=copy.deepcopy(source['files']);request={'id':seed,'job':job,'files':files};dump(P/'manifest.json',request)
dump(P/'created.json',api.json('/api/v1/jobs','POST',request))
if wf.status(seed)['state']=='busy':wf.operation(seed)
api.json(job_url(seed)+'/reuse','POST',{'sourceJobId':source['sourceJobId']});wf.operation(seed)
baked=api.json('/api/v1/tests/'+test+'/bake','POST',{'sourceJobId':seed,'description':'PVIDEO rev2 synthetic resize/toggle image diagnostic: 50 planned live screenshots, private Mesa cache; all shots required; no performance claim','buildFiles':['xemu']});dump(P/'baked.json',baked)
print(json.dumps({'test':test,'revision':baked['revision'],'started':False}),flush=True)

from pathlib import Path
import copy,hashlib,json,sys,subprocess
R=Path('/home/codex/src/steamdeck-xemu');A=R/'artifacts/issue263-pvideo-reuse/native-preparation';sys.path.insert(0,str(R/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi,job_url
from runner_workflows import Workflows
api=RunnerApi('http://10.0.7.1:9368');wf=Workflows(api)
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((A/'windows-source-definition.json').read_text())['definition'];job=copy.deepcopy(source['job']);test='issue263-windows-pvideo-source-v2';seed=test+'-seed';P=A/test;P.mkdir(exist_ok=True)
config=(A/'issue263-deck-pvideo-source-pilot-v2/xemu.toml').read_text();(P/'xemu.toml').write_text(config)
local={'xemu.exe':A/'windows-candidate-ci/xemu.exe','xemu.toml':P/'xemu.toml','pvideo-source-reference-v2.json':A/'pvideo-source-reference-v2.json'}
files=[copy.deepcopy(f) for f in source['files'] if f['path']=='state/seed-eeprom.bin']
for name,p in local.items():files.append({'path':name,'length':p.stat().st_size,'sha256':sha(p),'executable':name=='xemu.exe'})
job.update(id=seed,executable='xemu.exe',expectedExecutableSha256=None,requiredFiles=[f['path'] for f in files],arguments=['-config_path','{packageDir}/xemu.toml'],plan=[],tags=['issue263','pvideo','Windows','correctness-only','unqualified-driver-cache'],operations={'mode':'diagnostic'})
job['environment']={k:v for k,v in job['environment'].items() if k in ('XEMU_FRAME_LOG','XEMU_FLIP_LOG')}
job['inputs']=[{'path':f['path'],'role':'candidate-or-reference' if f['path']=='xemu.exe' else 'fixed-pvideo-input','hash':True,'expectedSha256':None if f['path']=='xemu.exe' else f['sha256']} for f in files]
isolation=job['runtimeState']['isolation'];isolation.update(cacheMode='cold',cacheShaders=False,driverCache='uncontrolled',allowUncontrolledDriverCache=False,requirePrivateGuestState=True)
dvd=next(x for x in isolation['readOnlyAssets'] if x['field']=='dvd_path');dvd.update(assetId='issue263-pvideo-iso-a1006c77',expectedSha256='a1006c77017ab8cb91ec6165ca01fbcebb6636e8eaee27f1deac75c14c70a11d')
job['workload'].update(correctnessChecks=[],evidenceRequirements=[],reportedMetrics=[],minimumMetricSamples=0,requirePlanCompletion=True)
job['workload']['guestHddResults'].update(expectedResults='pvideo-source-reference-v2.json',expectedResultsSha256=sha(local['pvideo-source-reference-v2.json']))
job['experiment']={'id':'issue263-windows-source-v2','variant':'candidate-correctness','reference':'ee5ce48b48784f999af374c1452003f8b2b1230f','variedFactors':['Vulkan PVIDEO resource reuse'],'controlledFactors':['same generated fixturec1e81de','64MiB','Vulkan','independent source/background known answers','private HDD/EEPROM'],'requireCorrectnessPass':True,'requireCompleteEvidence':True,'allowOperatorIntervention':False,'allowDiagnostics':False}
request={'id':seed,'job':job,'files':files};dump(P/'manifest.json',request);dump(P/'created.json',api.json('/api/v1/jobs','POST',request))
if wf.status(seed)['state']=='busy':wf.operation(seed)
api.json(job_url(seed)+'/reuse','POST',{'sourceJobId':source['sourceJobId']});wf.operation(seed)
for name,p in local.items():
 row=next(f for f in files if f['path']==name);api.upload_path(job_url(seed)+'/files/'+name,p,row['length'],row['sha256'])
baked=api.json('/api/v1/tests/'+test+'/bake','POST',{'sourceJobId':seed,'description':'Windows correctness-only PVIDEO fixturev2, private guest state and explicit unqualified driver cache; no performance claim','buildFiles':['xemu.exe']});dump(P/'baked.json',baked)
suite=api.json('/api/v1/xiso-suites','POST',{'id':test+'-suite','testId':test,'revision':baked['revision'],'settings':{'warmup_iterations':0,'measurement_iterations_multiplier':1,'gpu_completion_mode':'per_iteration'}});dump(P/'suite.json',suite)
from runner_tests import upload_application
app='issue263-candidate-ci-win-v1';directory=A/'windows-candidate-ci/build-only';directory.mkdir(exist_ok=True);target=directory/'xemu.exe'
if not target.exists():target.hardlink_to(local['xemu.exe'])
value=upload_application(api,directory,'xemu.exe',app);dump(P/'application.json',{'id':app,'sha256':value,'sourceCommit':'aeeb9554a87f5e4cb706ff6c58b3825b16f320f1','ciRun':36930561902,'artifactId':11197065429,'performanceQualified':False})
identity='i263-windows-pvideo-source-v2';dump(P/'created-campaign.json',api.json('/api/v1/xiso-campaigns','POST',{'id':identity,'application':app,'suite':suite['id'],'tests':['pvideo.resize_toggle']}));dump(P/'plan.json',api.json('/api/v1/xiso-campaigns/'+identity+'?view=plan'))
print(json.dumps({'campaign':identity,'started':False,'performanceQualified':False}),flush=True)

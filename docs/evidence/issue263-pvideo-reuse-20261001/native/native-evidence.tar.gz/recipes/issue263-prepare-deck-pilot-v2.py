"""Prepare a reproducible PVIDEO diagnostic through maintained HTTP clients.
Does not start any test. Emulator evidence stays in owning xemu PR280.
"""
from pathlib import Path
import copy,hashlib,json,shutil,subprocess,sys
R=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(R/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi,job_url
from runner_workflows import Workflows
from runner_tests import upload_application
A=R/'artifacts/issue263-pvideo-reuse/native-preparation';api=RunnerApi('http://10.0.0.123:9368');wf=Workflows(api)
def dump(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((A/'source-definition.json').read_text())['definition'];job=copy.deepcopy(source['job'])
test='issue263-deck-pvideo-source-pilot-v2';seed=test+'-seed';P=A/test;P.mkdir(exist_ok=True)
config='''[general]
show_welcome = false
[input]
background_input_capture = true
[input.virtual_ports]
port1_connected = 1
[input.bindings]
port1_driver = "usb-xbox-gamepad"
port1 = "keyboard"
[display]
renderer = "VULKAN"
[display.window]
vsync = false
fullscreen_on_startup = true
fullscreen_exclusive = false
[audio]
use_dsp = false
use_dsp_jit = true
[sys]
mem_limit = "64"
[sys.files]
hdd_path = "{runtimeDir}/hdd.qcow2"
eeprom_path = "{runtimeDir}/eeprom.bin"
'''
(P/'xemu.toml').write_text(config)
local={'xemu.toml':P/'xemu.toml','pvideo-source-reference-v2.json':A/'pvideo-source-reference-v2.json','xemu':R/'worktrees/issue263-pvideo-reuse/build-profile/qemu-system-i386','lib/libslirp.so.0':Path('/lib/x86_64-linux-gnu/libslirp.so.0').resolve(),'lib/libpcap.so.0.8':Path('/lib/x86_64-linux-gnu/libpcap.so.0.8').resolve()}
files=[copy.deepcopy(f) for f in source['files'] if f['path']=='state/seed-eeprom.bin']
for name,p in local.items():files.append({'path':name,'length':p.stat().st_size,'sha256':sha(p),'executable':name=='xemu'})
job.update(id=seed,expectedExecutableSha256=None,requiredFiles=[f['path'] for f in files],tags=['issue263','pvideo','generated-xiso','source-pilot','diagnostic-not-performance-proof'],operations={'mode':'diagnostic'})
job['arguments']=['-config_path','{packageDir}/xemu.toml','-name','xemu-issue263-pvideo,debug-threads=on','-msg','timestamp=on']
job['environment']['XEMU_VK_PERF_LOG']='{resultDir}/vk-perf.log'
job['inputs']=[{'path':f['path'],'role':'candidate-or-reference' if f['path']=='xemu' else 'fixed-pvideo-input','hash':True,'expectedSha256':None if f['path']=='xemu' else f['sha256']} for f in files]
isolation=job['runtimeState']['isolation'];isolation.update(cacheMode='cold',cacheShaders=False,driverCache='mesa',allowUncontrolledDriverCache=False,requirePrivateGuestState=True,deadlineSeconds=30)
dvd=next(x for x in isolation['readOnlyAssets'] if x['field']=='dvd_path');dvd.update(assetId='issue263-pvideo-iso-a1006c77',expectedSha256='a1006c77017ab8cb91ec6165ca01fbcebb6636e8eaee27f1deac75c14c70a11d')
job['plan']=[];job['workload']['analysis']=None;job['workload'].update(correctnessChecks=[],evidenceRequirements=[{'name':'production-vk-upload-diagnostic','scope':'result','path':'vk-perf.log','mustExist':True,'minimumBytes':1,'containsText':'pvideo_upload'}],reportedMetrics=[],minimumMetricSamples=0,requirePlanCompletion=True)
job['workload']['guestHddResults'].update(expectedResults='pvideo-source-reference-v2.json',expectedResultsSha256=sha(A/'pvideo-source-reference-v2.json'))
job['experiment']={'id':'issue263-source-pilot','variant':'build','reference':'ee5ce48b48784f999af374c1452003f8b2b1230f','variedFactors':['Vulkan PVIDEO allocation reuse'],'controlledFactors':['fixturec1e81dee','independent source/background oracle','64MiB guest','private HDD and EEPROM','qualified cold Mesa requested','same local O2 debug build toolchain','same pcap/slirp libraries'],'requireCorrectnessPass':True,'requireCompleteEvidence':True,'allowOperatorIntervention':False,'allowDiagnostics':True}
request={'id':seed,'job':job,'files':files};dump(P/'manifest.json',request)
dump(P/'created.json',api.json('/api/v1/jobs','POST',request))
if wf.status(seed)['state']=='busy':wf.operation(seed)
api.json(job_url(seed)+'/reuse','POST',{'sourceJobId':source['sourceJobId']});wf.operation(seed)
for name,p in local.items():
 row=next(f for f in files if f['path']==name);api.upload_path(job_url(seed)+'/files/'+name,p,row['length'],row['sha256'])
dump(P/'files-ready.json',api.json(job_url(seed)+'/files'))
baked=api.json('/api/v1/tests/'+test+'/bake','POST',{'sourceJobId':seed,'description':'Issue263 source/path diagnostic only: independent source/background known answers, actual PVIDEO upload diagnostics, no host-overlay or performance qualification','buildFiles':['xemu']});dump(P/'baked.json',baked)
suite=api.json('/api/v1/xiso-suites','POST',{'id':test+'-suite','testId':test,'revision':baked['revision'],'settings':{'warmup_iterations':0,'measurement_iterations_multiplier':1,'gpu_completion_mode':'per_iteration'}});dump(P/'suite.json',suite)
for variant,path in [('parent',R/'artifacts/issue263-pvideo-reuse/xemu-parent'),('candidate',local['xemu'])]:
 identity='issue263-'+variant+'-local-linux-v1';directory=A/identity;directory.mkdir(exist_ok=True);target=directory/'xemu'
 if not target.exists():shutil.copyfile(path,target)
 assert sha(target)==sha(path)
 value=json.loads((directory/'receipt.json').read_text())['sha256'];assert value==sha(path);dump(directory/'receipt-v2-reuse.json',{'id':identity,'sha256':value,'source':str(path),'productCommit':'ee5ce48b48784f999af374c1452003f8b2b1230f' if variant=='parent' else 'aeeb9554a87f5e4cb706ff6c58b3825b16f320f1','fixture':'c1e81dee18c0a3e3c9778d4746df53ba47152fd2','started':False})
 print(json.dumps({'application':identity,'sha256':value}),flush=True)
print(json.dumps({'test':test,'revision':baked['revision'],'suite':suite['id'],'qualified':suite['qualification'],'started':False}),flush=True)

"""Freeze a second PVIDEO benchmark with built-in host CPU analysis.
Uses retained HTTP-owned inputs, never launches xemu outside the runner.
Preparation does not start work; all three campaign plans are frozen together.
"""
from pathlib import Path
import copy,json,sys
R=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(R/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi,job_url
from runner_workflows import Workflows
A=R/'artifacts/issue263-pvideo-reuse/native-preparation';P=A/'issue263-deck-pvideo-benchmark-v2';P.mkdir(exist_ok=True)
api=RunnerApi('http://10.0.0.123:9368');wf=Workflows(api)
def dump(name,d): (P/name).write_text(json.dumps(d,indent=2)+'\n')
before=api.json('/api/v1/status'); assert before['Phase']=='idle',before['Phase']
baked=json.loads((A/'issue263-deck-pvideo-benchmark-v1/baked.json').read_text());source=api.json('/api/v1/test-configs/'+baked['id']+'/'+baked['revision'])['definition'];dump('source-definition.json',source)
test='issue263-deck-pvideo-benchmark-v2';seed=test+'-seed';job=copy.deepcopy(source['job']);job['id']=seed
job['plan']=[{'type':'wait_for_artifact','timeoutMs':60000,'pollIntervalMs':100,'condition':{'scope':'result','path':'guest-frames.log','containsText':'frame=600 '}},{'type':'segment_start','name':'pvideo-frame600-window'},{'type':'wait','delayMs':16000},{'type':'segment_end','name':'pvideo-frame600-window'}]
job['workload']['analysis']={'segment':'pvideo-frame600-window','metricsPath':'metrics.csv','minimumCpuSamples':24}
job['tags']=['issue263','pvideo','benchmark','host-CPU-fixed-window','fixture-v2']
job['experiment']['id']='issue263-pvideo-benchmark-v2';job['experiment']['controlledFactors']+=['readiness guest frame600, then fixed16s host CPU window; no exact guest workload-boundary claim','minimum24 CPU samples at existing500ms sampler','same frame/flip logs, no verbose Vulkan trace']
request={'id':seed,'job':job,'files':copy.deepcopy(source['files'])};dump('manifest.json',request);dump('created.json',api.json('/api/v1/jobs','POST',request))
if wf.status(seed)['state']=='busy':wf.operation(seed)
api.json(job_url(seed)+'/reuse','POST',{'sourceJobId':source['sourceJobId']});wf.operation(seed)
baked=api.json('/api/v1/tests/'+test+'/bake','POST',{'sourceJobId':seed,'description':'PVIDEO fixturev2: built-in CPU mean/median during fixed16s after guestframe600 readiness, 24 minimumCPU samples; no verbose Vulkan trace or manual actions; guest source/background hard oracles','buildFiles':['xemu']});dump('baked.json',baked)
suite=api.json('/api/v1/xiso-suites','POST',{'id':test+'-suite','testId':test,'revision':baked['revision'],'settings':{'warmup_iterations':0,'measurement_iterations_multiplier':1,'gpu_completion_mode':'per_iteration'}});dump('suite.json',suite)
parent='issue263-parent-local-linux-v1';candidate='issue263-candidate-local-linux-v1'
for phase,reference,application in [('aaaa',parent,parent),('abba',parent,candidate),('baab',candidate,parent)]:
 identity='i263-deck-vk-'+phase+'-v2';body={'id':identity,'suite':suite['id'],'referenceApplication':reference,'application':application,'tests':['pvideo.steady_upload','pvideo.resize_toggle']}
 dump(phase+'-request.json',body);dump(phase+'-created.json',api.json('/api/v1/xiso-campaigns','POST',body));dump(phase+'-plan.json',api.json('/api/v1/xiso-campaigns/'+identity+'?view=plan'))
print(json.dumps({'prepared':True,'started':False,'campaigns':3,'attempts':12,'workloads':2}),flush=True)

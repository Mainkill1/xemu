"""Audit canonical input/state identities and reproduce per-order guest tables.
Full maintained-server comparison remains authoritative; this reports the frozen
ABBA/BAAB order because the hash comparison API has no campaign filter.
"""
import argparse,csv,hashlib,json,statistics
from pathlib import Path
R=Path('/home/codex/src/steamdeck-xemu');A=R/'artifacts/issue263-pvideo-reuse'
args=argparse.ArgumentParser();args.add_argument('--version',choices=['1','2'],required=True);version=args.parse_args().version
P=A/('native-preparation/issue263-deck-pvideo-benchmark-v'+version)
parent='d406d6072238c81ebed3b144257fcfb23a5fd12b5215769f853d9365d33d5471';candidate='5dd8d5453574fdad00e2acd9d0dc4aacb1e32ca142334ce87a05226f99e46e5b';raw=[];identities=[];metrics=[]
for phase in ['aaaa','abba','baab']:
 for p in sorted((A/('native-deck-balanced-v'+version)/phase).iterdir()):
  r=json.loads((p/'result.json').read_text());m=json.loads((p/'input-manifest.json').read_text());j=json.loads((p/'job.json').read_text());a=json.loads((p/'assessment.json').read_text());s=json.loads((p/'diagnostics/run-state/report.json').read_text());n=json.loads((p/'guest/normalized-results.json').read_text())
  assert r['executableSha256'] in [parent,candidate]
  variant='parent' if r['executableSha256']==parent else 'candidate'
  assert m['ExecutableSha256']==r['executableSha256'] and m['JobManifestSha256']==hashlib.sha256((p/'job.json').read_bytes()).hexdigest()
  assert all(x['Verified'] for x in m['Inputs'])
  fixed=[(x['Path'],x['Bytes'],x['Sha256']) for x in m['Inputs'] if x['Path']!='xemu']
  x=j['RuntimeState']['Xiso'];assert set(x['Tests'])=={'pvideo.steady_upload','pvideo.resize_toggle'}
  assert x['IsoSha256']=='a1006c77017ab8cb91ec6165ca01fbcebb6636e8eaee27f1deac75c14c70a11d'
  assert x['Settings']=={'warmup_iterations':0,'measurement_iterations_multiplier':1,'gpu_completion_mode':'per_iteration'}
  assert a['Execution']=='completed' and a['Correctness']=='passed' and a['Evidence']=='complete' and a['Comparison']=='eligible'
  assert s['ComparisonReady'] and s['DriverNamespaceVerified'] and not s['AllowUncontrolledDriverCache']
  assert {v['Id'] for v in n['records']}=={'pvideo.steady_upload','pvideo.resize_toggle'} and all(v['Samples']==8 for v in n['records'])
  identities.append({'runId':r['runId'],'binarySha256':r['executableSha256'],'fixedInputs':fixed,'runnerVersion':r['host']['runnerVersion'],'xiso':x})
  for v in n['records']:raw.append({'order':phase,'job':r['job'],'runId':r['runId'],'binary':variant,'sha256':r['executableSha256'],**v})
  if version=='2':
   analysis=json.loads((p/'performance.json').read_text());assert analysis['Complete'],analysis['Errors'];monitor=analysis['Monitoring'];assert monitor['Cpu']['Count']>=24
   for v in r['workload']['Measurements']:metrics.append({'order':phase,'runId':r['runId'],'binary':variant,**v})
assert len(identities)==12 and len({json.dumps(r['fixedInputs']) for r in identities})==1 and len({r['runnerVersion'] for r in identities})==1
(P/'identity-audit.json').write_text(json.dumps({'checked':identities,'matchingFixedInputs':True,'matchingRunner':True,'exactGuestSettings':True},indent=2)+'\n')
rows=[]
for phase in ['abba','baab']:
 for id in ['pvideo.steady_upload','pvideo.resize_toggle']:
  for metric in ['MeanUs','MedianUs','MinUs','MaxUs','P95Us']:
   a=statistics.median([r[metric] for r in raw if r['order']==phase and r['Id']==id and r['binary']=='parent']);b=statistics.median([r[metric] for r in raw if r['order']==phase and r['Id']==id and r['binary']=='candidate']);rows.append({'order':phase,'test':id,'metric':metric,'unit':'us/128-frame-submission-batch','parent':a,'candidate':b,'saved':a-b,'improvementPercent':100*(a-b)/a,'parentRuns':2,'candidateRuns':2,'sourceCorrectness':'passed'})
(P/'per-order-summary.json').write_text(json.dumps(rows,indent=2)+'\n');(P/'per-run-values.json').write_text(json.dumps(raw,indent=2)+'\n')
with (P/'per-order-summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
if metrics:
 (P/'per-run-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');cost=[]
 for phase in ['abba','baab']:
  values={variant:[v['Value'] for v in metrics if v['order']==phase and v['binary']==variant and v['Name']=='monitor/cpu_mean'] for variant in ['parent','candidate']}
  assert all(len(v)==2 for v in values.values());a,b=[statistics.median(values[v]) for v in ['parent','candidate']];cost.append({'order':phase,'metric':'median of per-run CPU means','unit':'core_pct','parent':a,'candidate':b,'savedPercentagePoints':a-b,'improvementPercent':100*(a-b)/a})
 (P/'per-order-cpu-summary.json').write_text(json.dumps(cost,indent=2)+'\n');print(json.dumps(cost,indent=2))
print('PASS:12 attempts,24 leaf records,eight samples each,exact binary/input/guest settings,cache/correctness;20 guest order rows')

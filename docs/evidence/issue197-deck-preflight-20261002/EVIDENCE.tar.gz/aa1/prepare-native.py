"""Frozen parent A/A preflight for PR275, via maintained Deck HTTP client."""
from pathlib import Path
import copy,hashlib,json,sys
root=Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0,str(root/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi,job_url
from runner_workflows import Workflows
name='issue197-deck-pgr2-parked-300-v1-aa1'
source=root/'artifacts/issue246-texture-allocation/native-collector/pgr2-throttle-off-v1'
exe=root/'artifacts/issue229-dsp-multiply/native-builds/parent-linux/squashfs-root/usr/bin/xemu'
out=root/'artifacts/issue197-sample-memory/native/aa1'
h=hashlib.sha256(exe.read_bytes()).hexdigest()
assert h=='4a6e0dae0a83a870aebde726ca40687f35c9293f3da1147a6d7d14e8c4e8e01a'
m=copy.deepcopy(json.loads((source/'manifest.json').read_text()));m['id']=name;j=m['job'];j['id']=name;j['expectedExecutableSha256']=h
for f in m['files']:
 if f['path']=='xemu':f.update(length=exe.stat().st_size,sha256=h)
for f in j['inputs']:
 if f['path']=='xemu':f.update(role='fixed-main-parent',expectedSha256=h)
j['environment'].pop('XEMU_VK_PERF_LOG')
j['diagnostics']=[]
end=next(i for i,x in enumerate(j['plan']) if x.get('type')=='segment_end' and x.get('name')=='stationary')
j['plan']=j['plan'][:end+1]+[{'type':'quit'}]
start=next(i for i,x in enumerate(j['plan']) if x.get('type')=='segment_start' and x.get('name')=='stationary')
assert j['plan'][start+2]['type']=='wait' and j['plan'][start+2]['delayMs']==30000
j['plan'][start+2]['delayMs']=300000
assert sum(x.get('delayMs',0)+x.get('durationMs',0) for x in j['plan']) < 600000
j['workload']['evidenceRequirements']=[x for x in j['workload']['evidenceRequirements'] if x['path'] in ['segments.jsonl','guest-frames.log']]
j['experiment'].update(id='issue197-deck-pgr2-parked-300-v1',variant='parent-aa1',reference='ee5ce48b48784f999af374c1452003f8b2b1230f',variedFactors=['None: parent A/A preflight before candidate ABBA/BAAB'],controlledFactors=['Exact main parent release binary and pinned parent runtime-library bundle','300-second parked PGR2 segment, full DSP JIT, Vulkan, 128 MiB guest','Frozen menu route; no manual input, throttle, profiler, allocation collector, or Vulkan performance log','Private guest HDD/EEPROM and qualified private cold Mesa/application cache state','Guest-frame/flip and normal process/host telemetry identical for planned A/B'])
api=RunnerApi('http://10.0.0.123:9368');wf=Workflows(api,progress=True)
status=api.json('/api/v1/status');assert status['Phase']=='idle' and status['CurrentJob'] is None
assert status['Queue']['Pending']==status['Queue']['Testing']==0
out.mkdir(parents=True,exist_ok=False)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
save('deck-before.json',status);save('manifest.json',m)
(out/'prepare-native.py').write_bytes(Path(__file__).read_bytes());(out/'xemu.toml').write_bytes((source/'xemu.toml').read_bytes())
save('build-identity.json',{'commit':'ee5ce48b48784f999af374c1452003f8b2b1230f','sha256':h,'reference':'../issue229-dsp-multiply/native-builds/parent-linux','candidateForFutureComparison':'95f889090c8e8a16343c85382115330e86f7a9b9','compiler':'Clang/LLD21.1.8','scope':'Parent A/A preflight; not affected audio correctness'})
save('created.json',api.json('/api/v1/jobs','POST',m))
if wf.status(name)['state']=='busy':wf.operation(name)
api.json(job_url(name)+'/reuse','POST',{'sourceJobId':json.loads((source/'manifest.json').read_text())['id']});wf.operation(name)
api.upload_path(job_url(name)+'/files/xemu',exe,exe.stat().st_size,h)
save('files-ready.json',api.json(job_url(name)+'/files'))
save('baked.json',api.json('/api/v1/tests/'+name+'/bake','POST',{'sourceJobId':name,'buildFiles':['xemu'],'description':'PR275 parent A/A preflight: 300-second parked PGR2, exact main, qualified private cold Mesa, same pinned runtime libraries, no profiler or allocation/Vulkan perf collection; generic scene checks are not audio parity.'}))
save('submitted.json',wf.submit_draft(name));print(json.dumps(wf.status(name)))

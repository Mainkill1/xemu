from pathlib import Path
import importlib.util
import tempfile
import unittest

ROOT = Path('/home/codex/src/steamdeck-xemu/worktrees/issue250-finish-attribution')
spec = importlib.util.spec_from_file_location('reader_tests', ROOT / 'tests/unit/test-vk-perf-summary.py')
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
source = (ROOT / 'scripts/performance/vk-perf-summary.py').read_text()
for name, begin, end, old, new, check in [
    ('invent_durations', 'def finish_totals', 'def summarize_finish',
     'stats[key] /= 1000', 'stats[key] /= 500',
     'test_finish_partial_samples_are_not_scaled_to_total_wait'),
    ('credit_straddler', 'def summarize_finish', 'def main',
     "bucket['startTimestampUs'] >= start", "bucket['endTimestampUs'] >= start",
     'test_finish_tail_keeps_crossing_bucket_separate')]:
    first, last = source.index(begin), source.index(end)
    section = source[first:last]
    assert section.count(old) == 1
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / 'mutant.py'
        path.write_text(source[:first] + section.replace(old, new) + source[last:])
        tests.SCRIPT = path
        result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([tests.SummaryTests(check)]))
        assert not result.wasSuccessful() and len(result.failures) == 1 and not result.errors
        print(name, 'rejected by expected behavioral assertion')

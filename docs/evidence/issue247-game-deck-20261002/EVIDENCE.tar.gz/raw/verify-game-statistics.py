"""Recalculate collected game statistics without contacting the native host.

Usage: python3 verify-game-statistics.py COHORT_DIRECTORY OUTPUT_JSON
The output is a new receipt; existing evidence is never overwritten.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys


def distribution(values):
    ordered = sorted(values)
    def percentile(p):
        rank = (len(ordered) - 1) * p
        low, high = math.floor(rank), math.ceil(rank)
        return ordered[low] + (ordered[high] - ordered[low]) * (rank - low)
    return dict(Count=len(values), Mean=math.fsum(values) / len(values),
                Median=statistics.median(values), Min=ordered[0], Max=ordered[-1],
                P95=percentile(.95), P99=percentile(.99))


def check(actual, expected):
    for key, value in actual.items():
        assert math.isclose(value, expected[key], rel_tol=1e-11, abs_tol=1e-9), (
            key, value, expected[key])


def main():
    cohort, output = map(Path, sys.argv[1:])
    summary = json.loads((cohort / 'SUMMARY.json').read_text())
    receipt = dict(method='Independent source hash verification and Python fsum/linear-percentile recalculation',
                   cohort=str(cohort), runs=[])
    frame_pattern = re.compile(r'timestamp_us=(\d+) frame=(\d+) delta_us=(\d+)')
    for row in summary['runs']:
        run = Path(row['collection']['directory'])
        report = json.loads((run / 'performance.json').read_text())
        assert report == row['performance']
        for source in report['Sources']:
            payload = (run / source['Path']).read_bytes()
            assert len(payload) == source['Bytes']
            assert hashlib.sha256(payload).hexdigest() == source['Sha256']
        frames = []
        previous_time, previous_frame = -1, -1
        for line in (run / report['Profile']['GuestFramesPath']).read_text().splitlines():
            match = frame_pattern.fullmatch(line)
            assert match is not None, line
            time, number, delta = map(int, match.groups())
            assert time >= previous_time and number > previous_frame
            previous_time, previous_frame = time, number
            frames.append((time, delta))
        start = previous_time - report['Profile']['FrameTailSeconds'] * 1000000
        assert start == report['Frames']['WindowStartUs']
        assert previous_time == report['Frames']['WindowEndUs']
        intervals = [delta / 1000 for time, delta in frames if time >= start and delta > 0]
        cpu = []
        with (run / report['Profile']['MetricsPath']).open(newline='') as stream:
            for sample in csv.DictReader(stream):
                if sample['segment'] == report['Profile']['Segment']:
                    cpu.append(float(sample['process_cpu_core_pct']))
        actual_frames, actual_cpu = distribution(intervals), distribution(cpu)
        check(actual_frames, report['Frames']['IntervalsMs'])
        check(actual_cpu, report['Monitoring']['Cpu'])
        receipt['runs'].append(dict(jobId=row['jobId'], runId=row['runId'], mode=row['mode'],
                                    sourceHashesVerified=True, frames=actual_frames, cpu=actual_cpu))
    receipt['verifiedRuns'] = len(receipt['runs'])
    receipt['scope'] = 'Recalculation only; no statistical significance, audio parity, displayed FPS, or candidate speedup inferred. PGRAPH_INCREMENT control events are not display presentation.'
    with output.open('x') as target:
        json.dump(receipt, target, indent=2)
        target.write('\n')
    print(json.dumps(dict(verifiedRuns=receipt['verifiedRuns'], output=str(output))))


if __name__ == '__main__':
    main()

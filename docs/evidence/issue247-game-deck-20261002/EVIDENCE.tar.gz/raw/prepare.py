"""Prepare matched native builds and one immutable parked-game definition."""
from pathlib import Path
import copy,hashlib,json,shutil,subprocess,sys
ROOT=Path('/home/codex/src/steamdeck-xemu');OUT=Path(__file__).resolve().parent
REPO=ROOT/'worktrees/issue247-equal-store'
PRIOR=ROOT/'artifacts/issue247-equal-store-deck-20261002'
sys.path.insert(0,str(ROOT/'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi,job_url,encode_path
from runner_workflows import Workflows
from runner_tests import upload_application
from gameplay_procedure import assess,load_contract
api=RunnerApi('http://10.0.0.123:9368');work=Workflows(api)
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
matched=json.loads((PRIOR/'matched-build-qualification.json').read_text());assert matched['qualified']
assert subprocess.check_output(['git','diff','c4d36ecfa3111b60744225e966c0d12bc44cf007','--','hw'],cwd=REPO)==b''
identity={'originalProduction':'ee5ce48b48784f999af374c1452003f8b2b1230f','qualificationSha256':sha(PRIOR/'matched-build-qualification.json'),'compilerSettings':matched['compilerSettings'],'runtimeLibrariesIdentical':True,'buildFiles':['xemu']+[r['path'] for r in matched['files'] if r['path'].startswith('lib/')],'variants':{}}
assert len(identity['buildFiles'])==39
for variant in ('reference','candidate'):
 source=PRIOR/'native-builds'/variant/'squashfs-root/usr';destination=OUT/'builds'/variant
 files={}
 for name in identity['buildFiles']:
  p=source/('bin/xemu' if name=='xemu' else name)
  dst=destination/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
  files[name]={'path':name,'bytes':dst.stat().st_size,'sha256':sha(dst)}
  if name.startswith('lib/'):
   assert files[name]['sha256']==next(f['sha256'] for f in matched['files'] if f['path']==name)
 (destination/'xemu').chmod(0o755)
 identity['variants'][variant]={'directory':str(destination),'sourceCommit':matched['source'][variant]['commit'],'ciRun':matched['source'][variant]['ciRun'],'files':files}
for name in identity['buildFiles'][1:]:assert identity['variants']['reference']['files'][name]==identity['variants']['candidate']['files'][name]
save(OUT/'identity.json',identity)
base=json.loads((OUT/'profile-source.json').read_text())['definition'];j=copy.deepcopy(base['job'])
contract=load_contract(ROOT/'worktrees/runner-standalone-process/procedures/pgr2-parked-v1.json')
original_input=copy.deepcopy(contract['planPrefix'][:-1])
contract['id']='pgr2-parked-warm60-300-v1';contract['measurementMs']=300000
contract['planPrefix']=original_input+[{'type':'wait','delayMs':60000},copy.deepcopy(contract['planPrefix'][-1])]
save(OUT/'procedure.json',contract)
j['id']='issue247-deck-pgr2-parked-warm60-300-v1';j['executable']='xemu';j['expectedExecutableSha256']=identity['variants']['reference']['files']['xemu']['sha256']
j['plan']=[{'type':'require_input'}]+copy.deepcopy(contract['planPrefix'])+[{'type':'screenshot','name':'recording-start'},{'type':'wait','delayMs':300000},{'type':'screenshot','name':'recording-end'},{'type':'segment_end','name':'stationary-start'},{'type':'quit'}]
j['timeoutSeconds']=600;j['tags']=['issue247','deck','pgr2','matched-production-game']
j['requiredFiles']=identity['buildFiles']+['xemu.toml','state/seed-eeprom.bin']
j['workload']['analysis'].update(segment='stationary-start',frameTailSeconds=300,minimumCpuSamples=540,minimumFrameSamples=160)
for i,check in enumerate(j['workload']['correctnessChecks']):
 check['name']='parked-'+('start' if i==0 else 'end')+'-visible';check['path']='screenshots/recording-'+('start' if i==0 else 'end')+'.png'
j['workload']['evidenceRequirements'][0]['name']='measurement-boundaries'
j['operations']={'mode':'benchmark','allowPreview':False,'allowManualInput':False,'allowPauseResume':False,'allowDiagnostics':False,'allowBulkTransfers':False}
j['diagnostics']=[]
j['experiment'].update(id='issue247-pgr2-production-20261002',variant='reference',reference='ee5ce48b48784f999af374c1452003f8b2b1230f',allowOperatorIntervention=False,allowDiagnostics=False)
j['experiment']['controlledFactors']=['Same canonical parked input course, with 60s excluded warmup and300s measurement','Full DSP with default JIT, VP workers0, 128MiB guest, Vulkan, vsync off','Identical38 runtime libraries and private EEPROM/HDD seeds','Private cold application/Mesa disk namespaces; no driver/OS RAM reset claim','No profiler or allocation probe; existing PGRAPH control logs are common to both builds']
fixed=OUT/'fixed';(fixed/'state').mkdir(parents=True,exist_ok=True)
config=fixed/'xemu.toml';shutil.copyfile(ROOT/'artifacts/issue197-sample-memory/native/v2-aa1/xemu.toml',config)
assert sha(config)=='d097766f036ca1cf3d2b59fa2d752d36b0c747b546dcb350b07811103f779058'
eeprom=fixed/'state/seed-eeprom.bin'
if not eeprom.exists():api.download(job_url(base['sourceJobId'])+'/files/'+encode_path('state/seed-eeprom.bin'),eeprom,256)
assert eeprom.stat().st_size==256 and sha(eeprom)=='a076678d81b90d638fd4fc21d7f580b133efb634b990f497363ad3cb1a572eb3'
j['inputs']=[{'path':'xemu','role':'replaceable-native-build','hash':True,'expectedSha256':None}]+[{'path':name,'role':'fixed-private-guest-seed' if name.startswith('state/') else 'fixed-full-DSP-JIT','hash':True,'expectedSha256':sha(fixed/name)} for name in ('xemu.toml','state/seed-eeprom.bin')]
assert j['runtimeState']['isolation']['allowUncontrolledDriverCache'] is False
assessment=assess(j,contract);assert assessment['ok'],assessment;save(OUT/'procedure-check-before-save.json',assessment)
assets='issue247-pgr2-assets-20261002';package=OUT/'package'
for name in identity['buildFiles']:
 src=OUT/'builds/reference'/name;dst=package/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for name in ('xemu.toml','state/seed-eeprom.bin'):
 dst=package/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(fixed/name,dst)
if not (OUT/'assets-uploaded.json').exists():
 state=api.json('/api/v1/status');assert state['Phase']=='idle' and state['CurrentJob'] is None and state['Queue']['Pending']==state['Queue']['Testing']==0
 save(OUT/'preflight.json',state)
 digest=upload_application(api,package,'xemu',assets);assert digest==identity['variants']['reference']['files']['xemu']['sha256']
 save(OUT/'assets-uploaded.json',{'id':assets,'sha256':digest,'state':work.status(assets)})
request={'sourceJobId':assets,'job':j,'description':'Issue247: canonical parked course;60s excluded warmup,300s Vulkan/default-JIT measurement. Same39 build slots/private Mesa and guest state. Scene review required; no audio parity claim.','buildFiles':identity['buildFiles']}
marker=OUT/'saved-test-request.json';receipt=OUT/'saved-test.json'
if receipt.exists():
 assert json.loads(marker.read_text())==request
 config_result=json.loads(receipt.read_text())
else:
 save(marker,request);config_result=api.json('/api/v1/test-configs/'+j['id'],'POST',request);save(receipt,config_result)
assert config_result['buildFileCount']==39
saved=api.json('/api/v1/tests/'+config_result['id']+'/'+config_result['revision']+'?view=definition');save(OUT/'saved-definition.json',saved)
assert saved['definition']['job']['plan']==j['plan'] or assess(saved['definition']['job'],contract)['ok']
check=assess(saved['definition']['job'],contract);assert check['ok'];save(OUT/'procedure-check-after-save.json',check)
save(OUT/'frozen-plan.json',{'controls':'AA','balanced':'ABBABAAB','sourceProfile':base['id'],'sourceRevision':json.loads((OUT/'profile-source.json').read_text())['revision'],'test':config_result,'identitySha256':sha(OUT/'identity.json'),'procedureSha256':check['procedureSha256'],'minimumCpuSamples':540,'minimumFrameSamples':160,'controlsGate':'Two passed scene-reviewed original runs; original mean control-interval and CPU spread/median each<=5%. Preliminary n2 repeatability only; reassess all balanced pairs.','primaryMetric':'Mean process CPU in host stationary segment; common PGRAPH_INCREMENT control intervals from final300s log tail separately. Not presented/displayed FPS.','retries':'None; resume authoritative job only.'})
print(json.dumps({'prepared':True,'test':config_result['id'],'revision':config_result['revision'],'buildSlots':39,'sceneTransport':check['transport'],'executableHashes':{v:identity['variants'][v]['files']['xemu']['sha256'] for v in identity['variants']}}))

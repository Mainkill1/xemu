"""Record a post-exit scene judgment with hashes; never changes an oracle.

View both retained screenshots before invoking. This records an agent judgment,
not hardware parity or automatic recognition. Unqualified scenes gate later slots.
"""
from pathlib import Path
import argparse,hashlib,json
OUT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=['controls','balanced'],required=True);p.add_argument('--ordinal',type=int,required=True);p.add_argument('--qualified',choices=['yes','no'],required=True);p.add_argument('--observation',required=True);args=p.parse_args()
phase=OUT/args.phase;summary=json.loads((phase/'SUMMARY.json').read_text())
row=next(r for r in summary['runs'] if r['ordinal']==args.ordinal);run=Path(row['collection']['directory']);folder=phase/row['label'];receipt=folder/'scene-review.json'
assert not receipt.exists(),'Scene reviews are immutable; preserve a correction separately.'
hashes={}
for name in ('screenshots/recording-start.png','screenshots/recording-end.png'):
 data=(run/name).read_bytes();hashes[name]=hashlib.sha256(data).hexdigest()
review={'qualified':args.qualified=='yes','observation':args.observation,'sha256':hashes,'runId':row['runId'],'reviewer':'Codex / GPT-6','scope':'Visual parked-scene admission only; no audio parity, guest-input counter proof, hardware reference, or displayed-FPS claim.'}
receipt.write_text(json.dumps(review,indent=2)+'\n')
if args.phase=='controls' and len(summary['runs'])==2:
 all_reviews=[]
 for r in summary['runs']:
  path=phase/r['label']/'scene-review.json'
  if not path.exists():break
  all_reviews.append(json.loads(path.read_text()))
 summary['controlsQualified']=summary.get('numericControlsQualified',False) and len(all_reviews)==2 and all(r['qualified'] for r in all_reviews)
 (phase/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(review))

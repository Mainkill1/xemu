"""Update the canonical xemu PR/issue; default is a local preview.

--apply PATCHes only the previously read bodies and verifies exact readback.
Never merges, changes readiness, posts comments, or updates the tool repo.
"""
from pathlib import Path
import argparse
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store')


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    analysis = json.loads((ROOT / 'ANALYSIS.json').read_text())
    controls = analysis['phases']['controls']
    assert controls['submitted'] == 2 and controls['allRunsQualified']
    assert controls['controlsQualified'] is False and analysis['phases']['balanced']['submitted'] == 0
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    evidence = f'https://github.com/Mainkill1/xemu/blob/{head}/docs/evidence/issue247-game-deck-20261002'
    before = json.loads((ROOT / 'pr-before.json').read_text())
    body = before['body']
    body = replace(body, 'Roughly 88% of sampled APU voice-state stores in #270 wrote unchanged words. This branch validates equal, aligned direct-RAM words with a same-value atomic compare-exchange and preserves the original physical-store fallback.',
                   'After #270 observed roughly 88% unchanged APU voice-state stores, this branch validates equal aligned RAM words with a same-value atomic compare-exchange while preserving the original physical-store fallback.')
    body = replace(body, 'Keep this draft: guest-writer ordering, affected audio and reset/save-load qualification remain incomplete.',
                   'New five-minute Deck PGR2 controls qualify Mesa disk caches and the race scene, but mean control-event intervals vary 9.92%, above the frozen 5% gate; no candidate game run is launched. Keep this draft: writer ordering, audio/lifecycle/XISO qualification and game repeatability remain incomplete.')
    body = replace(body, "qualify any further game comparison's start procedure and Mesa cache state.",
                   'stabilize the admitted PGR2 control recipe before a separately frozen ABBA/BAAB game campaign.')
    gate_table = '''**Deck PGR2 game gate:** two original-build A/A controls, each with 60 s excluded warmup and 300 s measurement. No candidate comparison or game speedup is established. Core % measures process CPU; intervals measure PGRAPH_INCREMENT control events, not displayed FPS.

| Metric | Baseline control 1 | Baseline control 2 | A/A spread | Gate |
| --- | ---: | ---: | ---: | --- |
| Mean process CPU (core %) | 244.767 | 246.230 | 0.60% | Pass ≤5% |
| Mean PGRAPH control interval (ms) | 1578.067 | 1428.946 | 9.92% | Fail ≤5% |
| Private Mesa files before → after | 0 → 830 | 0 → 833 | N/A | Qualified, no waiver |

'''
    body = replace(body, '### Problem\n', gate_table + '### Problem\n')
    old = '- The earlier Deck PGR2 A/B/B attempts were comparison-ineligible due uncontrolled Mesa cache; the next baseline tested Event Select rather than the race start and failed correctness. [Runner issue81](https://github.com/Mainkill1/Xemu-Test-Runner/issues/81) preserves that input failure. This headless VP campaign does not qualify those game attempts or resolve their Mesa cache gate.'
    new = '- Historical Deck PGR2 A/B/B attempts remain cache-ineligible; the later Event Select baseline remains a correctness failure ([runner issue81](https://github.com/Mainkill1/Xemu-Test-Runner/issues/81)). The new game controls use the maintained canonical input course and deployed [Mesa fix PR80](https://github.com/Mainkill1/Xemu-Test-Runner/pull/80). They do not retroactively qualify historical failures.'
    body = replace(body, old, new)
    validation = f'''- **New native game gate:** two original full-xemu runs on **Deck .123**, Vulkan/default JIT, complete 39 build slots, identical 38 libraries and private guest seeds. Both are completed/passed/complete/eligible with zero exit, complete collection and no intervention. Empty private Mesa disk namespaces receive actual recognized writes with no waiver. The post-exit captures show the parked race; control 1 has GO at the start, control 2 does not, so identical guest phase is unproven. Independent raw CSV/control-log recalculation and all indexed reference records agree; test/environment/build keys match. A/A control-interval spread fails the frozen gate; **zero of eight planned ABBA/BAAB slots is submitted**. [Game report]({evidence}/REPORT.md), [packet]({evidence}/EVIDENCE.tar.gz), [hash index]({evidence}/INDEX.json). Deck power/affinity and RAM caches remain uncontrolled.\n\n'''
    body = replace(body, '### Results\n', validation + '### Results\n')
    body = replace(body, 'Further game comparisons still need controlled Mesa cache and consumed start inputs. Keep this PR draft and HOLD until these bounded gates close.',
                   'New game controls establish private Mesa disk qualification and the parked race scene. The 9.92% A/A mean-interval spread leaves game repeatability unresolved; it is not a candidate regression because neither run uses the candidate. Keep this PR draft and HOLD until these bounded gates close.')
    issue_before = json.loads((ROOT / 'issue-before.json').read_text())
    status, original = issue_before['body'].split('\n---\n', 1)
    status += f'''\n\n## Native game qualification\n\nSteam Deck **10.0.0.123** runs two original-build PGR2 controls with 60 seconds excluded warmup and 300 seconds measurement. Both pass runner checks, post-exit race-scene admission and private Mesa disk qualification (empty before, 830/833 files after, no waiver). Mean process CPU is **244.767 / 246.230 core %**, a **0.60%** A/A spread; mean PGRAPH control interval is **1578.067 / 1428.946 ms**, a **9.92%** spread against the frozen **5%** gate. Thus no candidate/ABBA/BAAB slot is launched and no game improvement is inferred. The GO overlay differs at the start boundaries; identical guest phase is unproven. [Report]({evidence}/REPORT.md), [complete packet]({evidence}/EVIDENCE.tar.gz). Prior production VP gains remain separate; PR276 remains draft/HOLD. Historical failures are preserved.\n'''
    issue_body = status + '\n---\n' + original
    for name, text in (('pr', body), ('issue', issue_body)):
        (ROOT / f'{name}-final-body.md').write_text(text)
        (ROOT / f'{name}-request.json').write_text(json.dumps({'body': text}) + '\n')
    if not args.apply:
        print('Local preview only', head)
        return
    for name, endpoint, expected, text in (
        ('pr', 'repos/Mainkill1/xemu/pulls/276', before, body),
        ('issue', 'repos/Mainkill1/xemu/issues/247', issue_before, issue_body)):
        current = json.loads(subprocess.check_output(['gh', 'api', endpoint], text=True))
        assert current['body'] == expected['body'], 'Canonical body changed externally; reconcile before PATCH.'
        assert current['state'] == 'open'
        if name == 'pr':
            assert current['draft'] and not current['merged'] and current['head']['sha'] == head
        with (ROOT / f'{name}-response.json').open('w') as stream:
            subprocess.run(['gh', 'api', endpoint, '--method', 'PATCH', '--input', str(ROOT / f'{name}-request.json')], stdout=stream, check=True)
        readback = json.loads(subprocess.check_output(['gh', 'api', endpoint], text=True))
        assert readback['body'] == text and readback['state'] == 'open'
        if name == 'pr':
            assert readback['draft'] and not readback['merged'] and readback['head']['sha'] == head
        (ROOT / f'{name}-readback.json').write_text(json.dumps(readback, indent=2) + '\n')
    print('Verified canonical draft PR276 and open issue247', head)


if __name__ == '__main__':
    main()

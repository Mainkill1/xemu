"""Package the frozen game campaign in its owning xemu PR.

Run after all submitted jobs are terminal, collected, and scene reviewed.
No native execution, reference replacement, cache waiver, or hidden retry.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store')
OUT = REPO / 'docs/evidence/issue247-game-deck-20261002'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    subprocess.run(['python3', str(RAW / 'summarize.py')], check=True)
    analysis = json.loads((RAW / 'ANALYSIS.json').read_text())
    identity = json.loads((RAW / 'identity.json').read_text())
    controls = analysis['phases']['controls']
    balanced = analysis['phases']['balanced']
    assert controls['submitted'] == 2
    for phase in ('controls', 'balanced'):
        for row in analysis['phases'][phase].get('runs', []):
            assert row['sceneReview'] is not None, row
    if controls['controlsQualified']:
        assert balanced['submitted'] == 8, 'Finish every frozen slot or explicitly preserve a failed gate before packaging.'
    else:
        assert balanced['submitted'] == 0
    prior = RAW.parent / 'issue247-equal-store-deck-20261002/matched-build-qualification.json'
    assert sha(prior) == identity['qualificationSha256']
    (RAW / 'matched-build-qualification.json').write_bytes(prior.read_bytes())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    diff = subprocess.check_output(['git', 'diff', identity['variants']['candidate']['sourceCommit'], head, '--', 'hw'], cwd=REPO)
    assert diff == b'', 'Evidence is stale for the current production source.'
    (RAW / 'source-equivalence.json').write_text(json.dumps({'currentSourceHead': head,
        'measuredCandidate': identity['variants']['candidate']['sourceCommit'],
        'hardwareDiffBytes': len(diff), 'productionHardwareIdentical': True,
        'scope': 'Production hw sources unchanged; later publication contains evidence only.'}, indent=2) + '\n')
    OUT.mkdir(parents=True, exist_ok=True)
    payloads, omissions = {}, []
    for path in sorted(RAW.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        name = path.relative_to(RAW).as_posix()
        if name == 'package.log':
            continue
        reason = None
        if name in ('pr-final-body.md', 'issue-final-body.md', 'pr-request.json', 'issue-request.json'):
            reason = 'Pre-publication local preview; canonical PR276/issue247 bodies are updated after the evidence commit exists.'
        elif name.startswith(('builds/', 'package/')):
            reason = 'Large executable/libraries and private input copy retained locally; identity and matched-build qualification are published.'
        elif path.name.endswith('.bin') and 'eeprom' in path.name.lower():
            reason = 'Private EEPROM input/output retained locally; exact hash and size published.'
        elif '/state/driver-cache/' in name or '/state/application-cache/' in name:
            reason = 'Generated cache bytes retained locally; complete before/after hash ledger is published.'
        if reason:
            omissions.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path), 'reason': reason})
        else:
            payloads['raw/' + name] = path.read_bytes()
    entries = []
    archive = OUT / 'EVIDENCE.tar.gz'
    with archive.open('wb') as stream:
        with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as target:
                for name, data in sorted(payloads.items()):
                    item = tarfile.TarInfo(name)
                    item.size, item.mode, item.mtime = len(data), 0o644, 0
                    target.addfile(item, io.BytesIO(data))
                    entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    with tarfile.open(archive, 'r:gz') as target:
        assert len(target.getmembers()) == len(entries)
        for item in entries:
            assert hashlib.sha256(target.extractfile(item['path']).read()).hexdigest() == item['sha256']
    digest = sha(archive)
    (OUT / 'INDEX.json').write_text(json.dumps({'archive': archive.name, 'bytes': archive.stat().st_size,
        'sha256': digest, 'payloads': entries, 'omissions': omissions}, indent=2) + '\n')
    (OUT / 'SUMMARY.json').write_text(json.dumps(analysis, indent=2) + '\n')
    intro = ('Both baseline controls pass the frozen repeatability gate; the complete physical ABBA/BAAB comparison follows below.'
             if controls['controlsQualified'] else
             'The two baseline controls fail the frozen repeatability gate. No candidate run or ABBA/BAAB slot was launched; this workload cannot establish a candidate game gain.')
    lines = ['# Equal voice store game qualification on Steam Deck', '',
             '**Decision: HOLD / draft [PR276](https://github.com/Mainkill1/xemu/pull/276).** ' + intro,
             'The matched production VP fixture still establishes its separate fixed-work gains. This game campaign does not qualify audio, guest-writer concurrency or affected XISO references/timings.', '',
             '## Results at a glance', '',
             'A means original physical stores; B means the existing equal-RAM-store candidate. Both builds use the same compiler, libraries, game inputs and Vulkan settings. Process CPU is the sampled mean in the stationary segment, expressed as core percent (100% = one core). The control-event statistics measure PGRAPH_INCREMENT intervals, not display presentation or game FPS.', '',
             '| Baseline control | Mean CPU core % | Mean control interval ms | p95 ms | p99 ms | Positive intervals | Mesa cache | Scene |',
             '| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |']
    for row in controls['runs']:
        m = row['metrics']
        if m:
            lines.append(f"| {row['label']} | {m['processCpuCorePercent']:.3f} | {m['controlMeanMs']:.3f} | {m['controlP95Ms']:.3f} | {m['controlP99Ms']:.3f} | {row['controlIntervals']} | {row['mesa']['DriverQualification']} | {'admitted' if row['sceneReview']['qualified'] else 'rejected'} |")
        else:
            lines.append(f"| {row['label']} | N/A | N/A | N/A | N/A | N/A | {row['mesa']['DriverQualification']} | rejected |")
    lines += ['', 'The two-run A/A spreads use `100*(maximum-minimum)/median`; both mean CPU and mean control interval must be at most 5%. This is a preliminary repeatability check, not a population confidence bound.', '',
              '| Gate | Observed spread | Frozen limit |', '| --- | ---: | ---: |']
    gate_names = {'meanControlInterval': 'Mean PGRAPH control interval', 'meanProcessCpu': 'Mean process CPU'}
    for key, value in (controls.get('spreadsPercentOfMedian') or {}).items():
        lines.append(f'| {gate_names[key]} | {value:.3f}% | 5% |')
    lines += ['', f"Controls qualified: **{controls.get('controlsQualified', False)}**. Candidate slots submitted: **{balanced['submitted']} / 8**. No failed attempt is discarded and the gate is not relaxed.", '']
    if balanced.get('metrics'):
        lines += ['| Metric | Baseline median | Candidate median | Saved | Improvement % |', '| --- | ---: | ---: | ---: | ---: |']
        for key, m in balanced['metrics'].items():
            lines.append(f"| {key} ({m['unit']}) | {m['baselineMedian']:.3f} | {m['candidateMedian']:.3f} | {m['saved']:+.3f} | {m['improvementPercent']:+.3f}% |")
        lines += ['', 'These are medians of four original and four candidate runs. Saved CPU is core percentage points; saved intervals are milliseconds. Positive Improvement % means lower cost/interval. Each adjacent pair and all tails are retained in SUMMARY.json; variation and guest progress must be considered together before calling a small CPU change useful.', '']
    lines += ['## Frozen workload and cache conditions', '',
              'The maintained parked PGR2 course uses keyboard input with the canonical LStickRight selection and ten A presses. It excludes 60 seconds of warmup after the final input and then records 300 seconds with no acceleration/braking. Start and end captures are inspected after exit. Image admission only confirms the parked race scene; the runner’s coarse nonblack image checks alone cannot establish the scene.', '',
              'Control 1 shows a GO overlay at the start boundary; control 2 does not. Both show the intended parked race and the same track, but fixed host-clock warmup does not prove identical guest progress. The cause of the 9.92% mean-interval variation is unclassified; these observations do not isolate power, rendering, startup phase or any individual subsystem.', '',
              'Full DSP, default JIT, VP worker setting 0, Vulkan, vsync off, 128 MiB guest RAM, private EEPROM and HDD seed, identical BIOS/bootrom/disc assets. All 39 executable/library slots are declared before launch. The saved test, definition, input manifest, procedure checks, settings hashes, and physical order are retained. No game asset or private EEPROM bytes are published.', '',
              'Mesa cache qualification is enforced with no waiver: empty private disk namespace before launch, actual recognized writes afterward, full bounded file ledger, schema 2. OS/driver RAM caches and Deck power/affinity remain uncontrolled. Older cache-ineligible or wrong-scene attempts remain historical failures and are not qualified retroactively.', '',
              '## Source and build identity', '',
              f"- Original production: `{identity['originalProduction']}`.",
              f"- Matched reference input: `{identity['variants']['reference']['sourceCommit']}`.",
              f"- Matched candidate input: `{identity['variants']['candidate']['sourceCommit']}`.",
              f"- Full xemu A SHA256: `{identity['variants']['reference']['files']['xemu']['sha256']}`.",
              f"- Full xemu B SHA256: `{identity['variants']['candidate']['files']['xemu']['sha256']}`.",
              '- Clang/LLD 21.1.8, release ThinLTO, x86 version 3; all 38 runtime libraries match.',
              '- Native host: Steam Deck **10.0.0.123**, maintained HTTP runner **f5b3e58**, port 9368. No Windows or SSH native execution.', '',
              'Production hardware sources at publication remain byte-identical to the measured candidate. The #197 reader patch is in neither build. Prior CI source/build qualification is copied into this packet; these are the matched full xemu binaries from that qualification, not the standalone VP executables.', '',
              '## Every native attempt', '',
              '| Phase | Slot | Run ID | Outcome | Collected files | Mesa files before and after |',
              '| --- | --- | --- | --- | ---: | ---: |']
    for phase in ('controls', 'balanced'):
        source_path = RAW / phase / 'SUMMARY.json'
        if not source_path.exists():
            continue
        for row in json.loads(source_path.read_text())['runs']:
            outcome = '/'.join(row['outcome'].values())
            lines.append(f"| {phase} | {row['label']} | {row['runId']} | {outcome} | {row['collection']['fileCount']} | {row['driverFiles']['before']} → {row['driverFiles']['after']} |")
    lines += ['', 'Jobs are submitted once and observed through their original handles. Full paged collection happens after confirmed exit; no live previews, diagnostic probes, manual inputs or bulk transfers are allowed. Independent Python recalculation verifies raw source hashes, CPU statistics and control-event mean/p95/p99 against the runner report. Both control records are index-eligible and their test, environment and build keys match. The full reference index has two records and no further page. No baseline pin is changed. A/A controls are not pooled into candidate medians.', '',
              'The existing frame log is emitted by NV_PGRAPH_INCREMENT. Its label and the runner’s cadence_fps field do not establish displayed FPS. The CPU window is the declared host segment; control intervals use the final 300 seconds of the timestamped log, as specified by the immutable analysis profile. Tail-window and segment boundaries are distinct.', '',
              '## Remaining qualification', '',
              'Keep PR276 draft. Complete guest-writer/observer ordering, sample ordering, audible affected audio and live reset/save-load coverage, plus approved affected XISO references and usable per-leaf timings. If game repeatability fails, investigate the measured workload before a new separately frozen campaign; do not hide this gate failure with replacement runs.', '',
              '[Complete packet](EVIDENCE.tar.gz), [payload and omission index](INDEX.json), [all attempts and adjacent-pair calculations](SUMMARY.json).', '',
              f'Archive SHA256: `{digest}`. Raw cache binaries, large builds and private EEPROM are retained locally with hashes and explicit omission reasons; complete raw metrics, control logs, ledgers, screenshots, requests, receipts and reusable scripts are included.', '']
    (OUT / 'REPORT.md').write_text('\n'.join(lines))
    print(json.dumps({'archiveBytes': archive.stat().st_size, 'payloads': len(entries), 'omissions': len(omissions), 'sha256': digest}))


if __name__ == '__main__':
    main()

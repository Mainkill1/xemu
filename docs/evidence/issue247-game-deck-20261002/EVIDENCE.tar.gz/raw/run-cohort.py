"""Run one frozen AA/ABBA/BAAB slot; resume only its authoritative job.

Usage: run-cohort.py --phase controls|balanced --ordinal N
Post-exit scene reviews gate subsequent slots. No observer timeout restarts a job.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse,hashlib,json,statistics,sys
ROOT=Path('/home/codex/src/steamdeck-xemu');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_wait import execute as completion_wait
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=['controls','balanced'],required=True);p.add_argument('--ordinal',type=int,required=True);args=p.parse_args()
api=RunnerApi('http://10.0.0.123:9368');work=Workflows(api)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=json.loads((OUT/'identity.json').read_text());test=json.loads((OUT/'saved-test.json').read_text());plan=json.loads((OUT/'frozen-plan.json').read_text())
assert sha(OUT/'identity.json')==plan['identitySha256']
order=plan[args.phase];assert 1<=args.ordinal<=len(order)
phase=OUT/args.phase;phase.mkdir(exist_ok=True)
summary_path=phase/'SUMMARY.json'
if summary_path.exists():summary=json.loads(summary_path.read_text())
else:summary={'phase':args.phase,'identitySha256':plan['identitySha256'],'physicalOrder':order,'runs':[]}
if args.phase=='balanced':
 controls=json.loads((OUT/'controls/SUMMARY.json').read_text());assert controls['controlsQualified'] and controls['identitySha256']==plan['identitySha256']
 assert len(controls['runs'])==2
for row in summary['runs']:
 if row['ordinal']>=args.ordinal:continue
 review=json.loads((phase/row['label']/'scene-review.json').read_text());assert review['qualified'] is True
 for name,digest in review['sha256'].items():assert sha(Path(row['collection']['directory'])/name)==digest
letter=order[args.ordinal-1];variant='reference' if letter=='A' else 'candidate';label=f'{args.ordinal:02d}-{letter}'
folder=phase/label;folder.mkdir(exist_ok=True);handle=f'issue247-game-{args.phase}-{args.ordinal:02d}-{letter.lower()}-20261002'
build=Path(identity['variants'][variant]['directory'])
for name in identity['buildFiles']:assert sha(build/name)==identity['variants'][variant]['files'][name]['sha256']
request={'testId':test['id'],'revision':test['revision'],'jobId':handle,'buildSha256':{name:identity['variants'][variant]['files'][name]['sha256'] for name in identity['buildFiles']},'labels':{'experimentId':'issue247-pgr2-production-20261002','variant':variant,'reference':identity['originalProduction']}}
marker=folder/'submission.json'
if marker.exists():
 assert json.loads(marker.read_text())==request
 state=work.status(handle)
 if state['state'] in ('busy','draft'):
  if state['state']=='busy':work.operation(handle)
  save(folder/'resumed-submit.json',work.run_test(test['id'],test['revision'],handle,build,request['labels'],8*1024*1024))
 else:assert state['state'] in ('testing','tested','queued'),state
else:
 status=api.json('/api/v1/status');assert status['Phase']=='idle' and status['CurrentJob'] is None and status['Queue']['Pending']==status['Queue']['Testing']==0
 save(folder/'preflight.json',status);save(marker,request)
 save(folder/'submitted.json',work.run_test(test['id'],test['revision'],handle,build,request['labels'],8*1024*1024))
print('Observing',handle,flush=True)
wait=completion_wait(api,SimpleNamespace(id=handle,job=True,updates=False));save(folder/'wait.json',wait)
result=work.result(handle);save(folder/'result-summary.json',result)
collection=work.collect(handle,folder/'collected',None,True);save(folder/'collection.json',collection)
assert wait['terminal'] and collection['complete'] and collection['excluded']==0
run=Path(collection['directory']);raw=json.loads((run/'result.json').read_text());cache=json.loads((run/'diagnostics/run-state/report.json').read_text()) if (run/'diagnostics/run-state/report.json').exists() else {}
assert raw['executableSha256']==request['buildSha256']['xemu'] and raw['host']['machine']=='steamdeck'
performance=json.loads((run/'performance.json').read_text()) if (run/'performance.json').exists() else None
row={'ordinal':args.ordinal,'label':label,'jobId':handle,'runId':result['runId'],'mode':letter,'outcome':result['outcome'],'exitCode':raw['exitCode'],'collection':collection,'performance':performance,'mesa':{k:cache.get(k) for k in ('DriverNamespaceVerified','DriverQualification','ComparisonReady','AllowUncontrolledDriverCache')},'driverFiles':{'before':len((cache.get('DriverBefore') or {}).get('Files',[])),'after':len((cache.get('DriverAfter') or {}).get('Files',[])),'afterBytes':(cache.get('DriverAfter') or {}).get('Bytes')}}
prior=[r for r in summary['runs'] if r['ordinal']==args.ordinal]
if prior:assert len(prior)==1 and prior[0]==row
else:summary['runs'].append(row)
summary['runs'].sort(key=lambda r:r['ordinal']);save(summary_path,summary)
print(json.dumps(row),flush=True)
assert result['outcome']=={'execution':'completed','correctness':'passed','evidence':'complete','comparison':'eligible'},result
assert row['mesa']=={'DriverNamespaceVerified':True,'DriverQualification':'mesa_private_disk_writes_observed','ComparisonReady':True,'AllowUncontrolledDriverCache':False},row['mesa']
assert raw['exitCode']==0 and performance is not None
if args.phase=='controls' and len(summary['runs'])==2:
 spreads={}
 for label,get in {'meanControlInterval':lambda p:p['Frames']['IntervalsMs']['Mean'],'meanProcessCpu':lambda p:p['Monitoring']['Cpu']['Mean']}.items():
  values=[get(r['performance']) for r in summary['runs']];spreads[label]=100*(max(values)-min(values))/statistics.median(values)
 summary['spreadsPercentOfMedian']=spreads;summary['numericControlsQualified']=all(v<=5 for v in spreads.values())
 summary['controlsQualified']=False
 save(summary_path,summary)
save(folder/'post-status.json',api.json('/api/v1/status'))
print('Finished same job; post-exit scene review required before next slot',flush=True)

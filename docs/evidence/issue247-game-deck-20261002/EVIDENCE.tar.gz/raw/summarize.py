"""Summarize all frozen campaign attempts, including failed or gated runs.

No native requests. No confidence interval or displayed-FPS inference.
Run only after the current native attempt has completed and been collected.
"""
from pathlib import Path
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parent
METRICS = {
    'processCpuCorePercent': ('core %', lambda p: p['Monitoring']['Cpu']['Mean']),
    'controlMeanMs': ('ms', lambda p: p['Frames']['IntervalsMs']['Mean']),
    'controlP95Ms': ('ms', lambda p: p['Frames']['IntervalsMs']['P95']),
    'controlP99Ms': ('ms', lambda p: p['Frames']['IntervalsMs']['P99']),
    'controlMaximumMs': ('ms', lambda p: p['Frames']['IntervalsMs']['Max']),
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    plan = json.loads((ROOT / 'frozen-plan.json').read_text())
    assert sha(ROOT / 'identity.json') == plan['identitySha256']
    answer = {'identitySha256': plan['identitySha256'], 'phases': {},
              'scope': 'Mean process CPU and PGRAPH_INCREMENT control intervals; not displayed FPS, audio parity, or XISO qualification.',
              'improvementFormula': '100 * (baseline - candidate) / baseline; positive is better for cost/interval.',
              'statisticalScope': 'Descriptive medians and adjacent pairs. No population confidence bound; two A/A controls are preliminary repeatability only.'}
    for phase in ('controls', 'balanced'):
        path = ROOT / phase / 'SUMMARY.json'
        if not path.exists():
            answer['phases'][phase] = {'submitted': 0, 'plannedOrder': plan[phase]}
            continue
        source = json.loads(path.read_text())
        assert source['identitySha256'] == plan['identitySha256']
        rows = source['runs']
        result = {'submitted': len(rows), 'plannedOrder': plan[phase],
                  'observedOrder': ''.join(r['mode'] for r in rows), 'runs': []}
        for row in rows:
            assert row['mode'] == plan[phase][row['ordinal'] - 1]
            review_path = ROOT / phase / row['label'] / 'scene-review.json'
            review = json.loads(review_path.read_text()) if review_path.exists() else None
            if review:
                assert review['runId'] == row['runId']
                for name, digest in review['sha256'].items():
                    assert sha(Path(row['collection']['directory']) / name) == digest
            perf = row['performance']
            qualified = (row['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}
                         and row['exitCode'] == 0 and row['collection']['complete']
                         and row['collection']['excluded'] == 0 and perf is not None
                         and row['mesa'] == {'DriverNamespaceVerified': True, 'DriverQualification': 'mesa_private_disk_writes_observed', 'ComparisonReady': True, 'AllowUncontrolledDriverCache': False}
                         and review is not None and review['qualified'] is True)
            item = {k: row[k] for k in ('ordinal', 'label', 'jobId', 'runId', 'mode', 'outcome', 'exitCode', 'mesa', 'driverFiles')}
            item.update(sceneReview=review, qualified=qualified,
                        metrics={k: getter(perf) for k, (_, getter) in METRICS.items()} if perf else None,
                        cpuSamples=perf['Monitoring']['Cpu']['Count'] if perf else None,
                        controlIntervals=perf['Frames']['IntervalsMs']['Count'] if perf else None,
                        flipTailCadence=perf['Flips']['CadenceFps'] if perf else None)
            result['runs'].append(item)
        result['allRunsQualified'] = len(rows) == len(plan[phase]) and all(r['qualified'] for r in result['runs'])
        if phase == 'controls':
            result.update({k: source.get(k) for k in ('spreadsPercentOfMedian', 'numericControlsQualified', 'controlsQualified')})
        if phase == 'balanced' and result['allRunsQualified']:
            assert answer['phases']['controls']['controlsQualified'] is True
            result['metrics'] = {}
            for key, (unit, _) in METRICS.items():
                baseline = statistics.median(r['metrics'][key] for r in result['runs'] if r['mode'] == 'A')
                candidate = statistics.median(r['metrics'][key] for r in result['runs'] if r['mode'] == 'B')
                pairs = []
                for i in range(0, len(rows), 2):
                    pair = result['runs'][i:i + 2]
                    assert {r['mode'] for r in pair} == {'A', 'B'}
                    a = next(r for r in pair if r['mode'] == 'A')
                    b = next(r for r in pair if r['mode'] == 'B')
                    pairs.append({'baselineRun': a['runId'], 'candidateRun': b['runId'],
                                  'baseline': a['metrics'][key], 'candidate': b['metrics'][key],
                                  'improvementPercent': 100 * (a['metrics'][key] - b['metrics'][key]) / a['metrics'][key]})
                result['metrics'][key] = {'unit': unit, 'baselineMedian': baseline, 'candidateMedian': candidate,
                                          'saved': baseline - candidate, 'improvementPercent': 100 * (baseline - candidate) / baseline,
                                          'adjacentPairs': pairs}
        answer['phases'][phase] = result
    (ROOT / 'ANALYSIS.json').write_text(json.dumps(answer, indent=2) + '\n')
    print(json.dumps({k: {p: v for p, v in value.items() if p not in ('runs',)} for k, value in answer['phases'].items()}, indent=2))


if __name__ == '__main__':
    main()

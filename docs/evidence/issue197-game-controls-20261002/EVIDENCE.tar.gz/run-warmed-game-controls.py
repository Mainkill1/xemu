"""Frozen PGR2 controls using maintained HTTP submission, wait and collection."""
from pathlib import Path
from types import SimpleNamespace
import copy, json, sys

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi, job_url
from runner_workflows import Workflows
from runner_wait import execute as completion_wait

OUT = ROOT / 'artifacts/issue197-sample-memory/remaining-gates/warmed-game-controls'
OUT.mkdir(parents=True, exist_ok=True)
api = RunnerApi('http://10.0.0.123:9368')
work = Workflows(api)
source = ROOT / 'artifacts/issue197-sample-memory/native/v2-aa1'
manifest = copy.deepcopy(json.loads((source / 'manifest.json').read_text()))
job = manifest['job']
id1 = 'issue197-deck-pgr2-parked-warm60-300-v3-aa1'
manifest['id'] = job['id'] = id1
job['experiment']['id'] = 'issue197-deck-pgr2-parked-warm60-300-v3'
job['experiment']['variant'] = 'original-aa1'
job['experiment']['controlledFactors'].append('New immutable v3 workload: excluded 60-second warmup after existing race-loading route; earlier v2 controls remain unchanged.')
plan = job['plan']
index = next(i for i, step in enumerate(plan) if step['type'] == 'segment_start' and step.get('name') == 'stationary')
plan[index:index] = [
    {'type': 'segment_start', 'name': 'excluded-warmup'},
    {'type': 'wait', 'delayMs': 60000},
    {'type': 'segment_end', 'name': 'excluded-warmup'},
]
original = json.loads((source / 'manifest.json').read_text())
assert manifest['files'] == original['files']
for field in ['executable', 'expectedExecutableSha256', 'arguments', 'workingDirectory', 'runtimeState', 'operations', 'launchMode', 'requiredFiles', 'inputs', 'environment', 'diagnostics', 'workload', 'timeoutSeconds']:
    assert job[field] == original['job'][field], field
stripped = [step for step in plan if step not in plan[index:index+3]]
assert stripped == original['job']['plan']

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

save(OUT / 'frozen-manifest.json', manifest)
save(OUT / 'hypothesis.json', {
    'question': 'Does excluding an additional 60-second race warmup reduce the earlier phase mismatch and 40.76% same-parent interval variation?',
    'scope': 'Two original-only controls; no candidate or speedup claim',
    'changedRuntimeFactor': 'One excluded 60000ms warmup before unchanged 300000ms stationary segment',
    'originalControlsRetained': True,
    'retries': 'none',
    'comparisonGate': 'Inspect canonical eligibility, qualified private Mesa, screenshots and original indexed metrics. Treat under-5% A/A spread only as preliminary repeatability; assess variation again in balanced pairs before small-gain claims.',
})
state = api.json('/api/v1/status')
save(OUT / 'deck-before.json', state)
assert state['Phase'] == 'idle' and state['CurrentJob'] is None and state['Queue']['Pending'] == 0
save(OUT / 'created.json', api.json('/api/v1/jobs', 'POST', manifest))
if work.status(id1)['state'] == 'busy':
    work.operation(id1)
api.json(job_url(id1) + '/reuse', 'POST', {'sourceJobId': original['id']})
save(OUT / 'reused.json', work.operation(id1))
save(OUT / 'files-ready.json', api.json(job_url(id1) + '/files'))
build_slots = [item['path'] for item in manifest['files'] if item['path'] == 'xemu' or item['path'].startswith('lib/')]
baked = api.json('/api/v1/tests/issue197-deck-pgr2-parked-warm60-300-v3/bake', 'POST', {
    'sourceJobId': id1, 'buildFiles': build_slots,
    'description': 'Uninstrumented PGR2 Vulkan: frozen input route, excluded 60s race warmup, 300s parked measurement. Private cold Mesa and guest state, full DSP/JIT, 128 MiB guest. All executable/library slots pinned. Earlier v2 attempts unchanged.',
})
save(OUT / 'saved-test.json', baked)
for ordinal in [1, 2]:
    identity = id1 if ordinal == 1 else 'issue197-deck-pgr2-parked-warm60-300-v3-aa2'
    directory = OUT / ('aa' + str(ordinal))
    directory.mkdir(exist_ok=True)
    submitted = work.submit_draft(identity) if ordinal == 1 else work.run_test(baked['id'], baked['revision'], identity, None, {'experimentId': job['experiment']['id'], 'variant': 'original-aa2', 'reference': job['experiment']['reference']}, 8 * 1024 * 1024)
    save(directory / 'submitted.json', submitted)
    print('SUBMITTED', identity, flush=True)
    waited = completion_wait(api, SimpleNamespace(id=identity, job=True, updates=False))
    save(directory / 'wait.json', waited)
    result = work.result(identity)
    save(directory / 'result-summary.json', result)
    collection = work.collect(identity, directory / 'collected', None, True)
    save(directory / 'collection.json', collection)
    print(json.dumps({'jobId': identity, 'runId': result.get('runId'), 'outcome': result.get('outcome'), 'collection': collection}), flush=True)
    assert waited['terminal'] and collection['complete'] and collection['excluded'] == 0
    # Preserve any first failure and stop this bounded campaign; never rerun it.
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}, result
print('BOTH CONTROLS COMPLETE', flush=True)

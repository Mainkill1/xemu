from pathlib import Path
import sys,json
root=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(root/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
source=root/'artifacts/issue197-sample-memory/native/v2-aa1';out=root/'artifacts/issue197-sample-memory/native/v2-aa2';name='issue197-deck-pgr2-parked-300-v2-aa2';b=json.loads((source/'baked.json').read_text())
api=RunnerApi('http://10.0.0.123:9368');wf=Workflows(api);s=api.json('/api/v1/status');assert s['Phase']=='idle' and not s['CurrentJob'];assert s['Queue']['Pending']==s['Queue']['Testing']==0
prior=json.loads((source/'result-summary.json').read_text());assert prior['outcome']=={'execution':'completed','correctness':'passed','evidence':'complete','comparison':'eligible'}
p=json.loads((source/'performance.json').read_text());assert p['available'] and p['analysis']['complete']
state=json.loads((source/'state-final.json').read_text());assert state['comparisonReady'] and state['driver']['verified'] and not state['driver']['explicitlyAccepted']
(source/'scene-audit.json').write_text(json.dumps({'inspected':['screenshots/stationary-start.png','screenshots/stationary-end.png'],'start':'Red car at 0 MPH on starting grid; other cars ahead','end':'Same car and position, 0 MPH; opponents departed','sceneMatchesParkedProcedure':True,'nativeAudioChecked':False,'source':'Direct inspection of original collected captures'},indent=2)+'\n')
out.mkdir(parents=True,exist_ok=False)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
save('deck-before.json',s);save('from-test-request.json',{'id':name,'testId':b['id'],'revision':b['revision'],'experimentId':'issue197-deck-pgr2-parked-300-v2','variant':'parent-aa2','reference':'ee5ce48b48784f999af374c1452003f8b2b1230f'})
(out/'run-native.py').write_bytes(Path(__file__).read_bytes());r=wf.run_test(b['id'],b['revision'],name,None,{'experimentId':'issue197-deck-pgr2-parked-300-v2','variant':'parent-aa2','reference':'ee5ce48b48784f999af374c1452003f8b2b1230f'},8*1024*1024);save('submitted.json',r);print(r)

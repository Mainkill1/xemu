"""Freeze built-in measurement windows before the first comparative run."""
from pathlib import Path
import copy,json,sys
root=Path('/home/codex/src/steamdeck-xemu');sys.path.insert(0,str(root/'worktrees/runner-plan-timeout/scripts'))
from runner_transport import RunnerApi,job_url
from runner_workflows import Workflows
source=root/'artifacts/issue197-sample-memory/native/aa1';name='issue197-deck-pgr2-parked-300-v2-aa1';out=root/'artifacts/issue197-sample-memory/native/v2-aa1'
m=copy.deepcopy(json.loads((source/'manifest.json').read_text()));previous=m['id'];m['id']=name;j=m['job'];j['id']=name
j['workload']['analysis']={'segment':'stationary','metricsPath':'metrics.csv','guestFlipsPath':'guest-flips.log','guestFramesPath':'guest-frames.log','flipTailSamples':6,'frameTailSeconds':300,'minimumCpuSamples':100,'minimumFrameSamples':100}
j['experiment'].update(id='issue197-deck-pgr2-parked-300-v2',variant='parent-aa1')
j['experiment']['controlledFactors'].append('Frozen built-in CPU segment and guest log tail windows; guest windows are not display presentation or exact host-segment alignment')
# The first attempt is preserved. Only post-exit analysis and identity differ.
original=json.loads((source/'manifest.json').read_text())['job']
for field in ['executable','expectedExecutableSha256','arguments','workingDirectory','runtimeState','operations','launchMode','requiredFiles','inputs','plan','environment','diagnostics']:
 assert j[field]==original[field],field
assert m['files']==json.loads((source/'manifest.json').read_text())['files']
api=RunnerApi('http://10.0.0.123:9368');wf=Workflows(api,progress=True);status=api.json('/api/v1/status');assert status['Phase']=='idle' and not status['CurrentJob'];assert status['Queue']['Pending']==status['Queue']['Testing']==0
out.mkdir(parents=True,exist_ok=False)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
save('manifest.json',m);save('deck-before.json',status);(out/'prepare-native.py').write_bytes(Path(__file__).read_bytes());(out/'xemu.toml').write_bytes((source/'xemu.toml').read_bytes());(out/'build-identity.json').write_bytes((source/'build-identity.json').read_bytes());save('changed-contract.json',{'originalAttempt':previous,'runtimePlanSettingsAndFilesIdentical':True,'changed':'Declare saved post-exit performance windows before future A/A and balanced runs','originalNotRepaired':True})
save('created.json',api.json('/api/v1/jobs','POST',m))
if wf.status(name)['state']=='busy':wf.operation(name)
api.json(job_url(name)+'/reuse','POST',{'sourceJobId':previous});wf.operation(name)
save('files-ready.json',api.json(job_url(name)+'/files'))
save('baked.json',api.json('/api/v1/tests/'+name+'/bake','POST',{'sourceJobId':name,'buildFiles':['xemu'],'description':'PR275 measured parent/candidate procedure: 300-second parked PGR2; qualified private cold Mesa; exact pinned runtime libs and private guest state; no profiler or allocation/Vulkan perf probe; CPU stationary segment, final300s guest frame intervals, final6 flip records; not native audio parity.'}))
save('submitted.json',wf.submit_draft(name));print(json.dumps(wf.status(name)))

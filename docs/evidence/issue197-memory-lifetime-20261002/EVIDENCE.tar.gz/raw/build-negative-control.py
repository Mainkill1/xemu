"""Compile the retained fixture against a guard-deleted reader, without editing production."""
from pathlib import Path
import json,os,shlex,subprocess
root=Path('/home/codex/src/steamdeck-xemu/worktrees/issue197-sample-memory');build=root/'build-sample-memory';out=Path(__file__).resolve().parent
source=(root/'tests/xbox/mcpx-apu/test-sample-memory.c').read_text().replace('"hw/xbox/mcpx/apu/vp/sample-memory.h"','"unguarded-reader.h"');(out/'negative-test-memory.c').write_text(source)
header=(root/'hw/xbox/mcpx/apu/vp/sample-memory.h').read_text();needle='                address_space_to_flatview(&address_space_memory) == cache.fv &&\n';assert needle in header;(out/'unguarded-reader.h').write_text(header.replace(needle,''))
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if e['file'].endswith('/tests/xbox/mcpx-apu/test-sample-memory.c'))
cc=shlex.split(entry['command']);cc[cc.index('-o')+1]=str(out/'negative-test-memory.o');cc[-1]=str(out/'negative-test-memory.c')
lines=(build/'build.ninja').read_text().splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('build test-xbox-mcpx-apu-real-memory: cpp_LINKER_RSP '));inputs=shlex.split(lines[i].split('cpp_LINKER_RSP ',1)[1].split(' | ',1)[0]);inputs=[str(out/'negative-test-memory.o') if x=='test-xbox-mcpx-apu-real-memory.p/tests_xbox_mcpx-apu_test-sample-memory.c.o' else x for x in inputs];args=[];links=[]
for line in lines[i+1:]:
 if line and not line.startswith(' '):break
 if line.startswith(' ARGS = '):args=shlex.split(line[len(' ARGS = '):])
 if line.startswith(' LINK_ARGS = '):links=shlex.split(line[len(' LINK_ARGS = '):])
link=['c++']+args+['-o',str(out/'test-negative-memory')]+inputs+links
(out/'negative-build-commands.json').write_text(json.dumps({'compile':cc,'link':link,'cwd':str(build),'change':'delete exactly the FlatView identity eligibility clause; same real-memory fixture and emulator objects'},indent=2)+'\n')
env=dict(os.environ,TMPDIR='/home/codex/src/steamdeck-xemu/scratch/compiler-tmp')
for kind,cmd in [('compile',cc),('link',link)]:
 r=subprocess.run(cmd,cwd=build,env=env,capture_output=True,text=True);(out/('negative-'+kind+'.log')).write_text(r.stdout+r.stderr);r.check_returncode()
for test in ['owned-ram-retirement', 'owned-ram-resize']:
 for mode,args,expected in [('original',['--baseline'],0),('unguarded',[],-6)]:
  cmd=[str(out/'test-negative-memory')]+args+['--tap','-p','/mcpx-apu/sample-memory/'+test]
  r=subprocess.run(cmd,cwd=build,capture_output=True,text=True,timeout=60)
  (out/(test+'-'+mode+'.log')).write_text(r.stdout+r.stderr)
  (out/(test+'-'+mode+'-exit.json')).write_text(json.dumps({'argv':cmd,'exitCode':r.returncode,'expectedExitCode':expected})+'\n')
  print(test,mode,r.returncode,flush=True)
  assert r.returncode==expected

"""Retained component controls; native execution and collection use HTTP only."""
from pathlib import Path
from types import SimpleNamespace
import hashlib, json, shutil, subprocess, sys, urllib.parse

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_wait import execute as completion_wait

OUT = ROOT / 'artifacts/issue197-sample-memory/remaining-gates/memory-lifetime/deck-native'
BUILD = ROOT / 'artifacts/issue197-sample-memory/native-builds/0024d134-real-memory-ci'
OUT.mkdir(parents=True, exist_ok=True)
PACKAGE = OUT / 'package'
PACKAGE.mkdir(exist_ok=True)
api = RunnerApi('http://10.0.0.123:9368')
work = Workflows(api)
preflight = api.json('/api/v1/status')
assert preflight['Phase'] == 'idle' and preflight['CurrentJob'] is None
assert preflight['Queue']['Pending'] == preflight['Queue']['Testing'] == 0
(OUT / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

exe = BUILD / 'test-xbox-mcpx-apu-real-memory'
assert exe.is_file(), 'Download the retained x86 release CI artifact first.'
app = BUILD / 'squashfs-root/usr/lib'
assert app.is_dir(), 'Extract the corresponding AppImage first.'
old_manifest = json.loads((ROOT / 'artifacts/issue197-sample-memory/deck-component/payload-manifest.json').read_text())
files = []
for old in old_manifest['files']:
    relative = old['path']
    source = exe if relative == exe.name else app / Path(relative).name
    assert source.is_file(), source
    target = PACKAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    if relative == exe.name:
        target.chmod(0o755)
    files.append({'path': relative, 'bytes': target.stat().st_size, 'sha256': hashlib.file_digest(target.open('rb'), 'sha256').hexdigest(), 'source': str(source)})
digest = next(item['sha256'] for item in files if item['path'] == exe.name)
save(OUT / 'payload-manifest.json', {'sourceCI': 37024778087, 'files': files, 'note': 'All library files come from this executable artifact\'s corresponding AppImage; no old libraries are reused.'})
(OUT / 'elf-notes.txt').write_text(subprocess.check_output(['readelf', '-n', str(exe)], text=True))
job = json.loads((ROOT / 'artifacts/issue197-sample-memory/deck-component/controls/20261002-102803214-96f43736fd4f4a05847769520e18b3e4/job.json').read_text())
job['ExpectedExecutableSha256'] = digest
job['Experiment']['Id'] = 'issue197-lifetime-correctness-20261002'
job['Workload']['CorrectnessChecks'] = [
    {'Name': 'thirteen-case-plan', 'Path': 'stdout.log', 'ContainsText': '1..13'},
    {'Name': 'last-lifetime-case', 'Path': 'stdout.log', 'ContainsText': 'ok 13 /mcpx-apu/sample-memory/owned-ram-resize'},
]
job['Workload']['EvidenceRequirements'] = [{'Name': 'full-TAP-output', 'Path': 'stdout.log', 'MinimumBytes': 500}]
summary = []
reuse = None
for mode, args in [('candidate', ['--tap']), ('original', ['--baseline', '--tap'])]:
    job['Id'] = f'issue197-lifetime-{mode}-controls-20261002'
    job['Arguments'] = args
    job['Experiment']['Variant'] = mode + '-correctness'
    directory = OUT / mode
    directory.mkdir(exist_ok=True)
    save(directory / 'definition.json', job)
    save(PACKAGE / 'job.json', job)
    save(directory / 'submit.json', work.submit(PACKAGE, job['Id'], reuse, 8 * 1024 * 1024))
    waited = completion_wait(api, SimpleNamespace(id=job['Id'], job=True, updates=False))
    save(directory / 'wait.json', waited)
    result = work.result(job['Id'])
    save(directory / 'result-summary.json', result)
    collected = work.collect(job['Id'], directory / 'collected', None, True)
    save(directory / 'collection.json', collected)
    assert waited['terminal'] and collected['complete'] and collected['excluded'] == 0
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}, result
    run = directory / 'collected' / result['runId']
    raw = (run / 'stdout.log').read_text()
    assert len([line for line in raw.splitlines() if line.startswith('ok ')]) == 13
    assert not any(line.startswith('not ok') for line in raw.splitlines())
    assert json.loads((run / 'result.json').read_text())['exitCode'] == 0
    summary.append({'mode': mode, 'jobId': job['Id'], 'runId': result['runId'], 'passed': 13, 'outcome': result['outcome'], 'completeCollection': True})
    print(json.dumps(summary[-1]), flush=True)
    reuse = job['Id']
save(OUT / 'SUMMARY.json', {'host': '10.0.0.123', 'sourceCI': 37024778087, 'prHead': '0024d1343d28340638f0f4455c16f42b5b3e6912', 'executableSha256': digest, 'attempts': summary, 'scope': 'component correctness only; no new performance measurement'})
status = api.json('/api/v1/status')
save(OUT / 'post-controls-status.json', status)
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
for item in summary:
    test = f'mcpx-adpcm-real-memory-{item["mode"]}-correctness-v3'
    baked = api.json('/api/v1/tests/' + urllib.parse.quote(test, safe='') + '/bake', 'POST', {
        'sourceJobId': item['jobId'],
        'description': '13 real-memory checks: decoded mono/stereo, SGE crossing, MMIO order, 768 mapping/register changes, 64 owned RAM retirements and 64 resizes with owner finalization. Correctness only.',
        'buildFiles': [entry['path'] for entry in files],
    })
    save(OUT / (test + '.json'), baked)
    print(json.dumps({'savedTest': test, 'receipt': baked}), flush=True)

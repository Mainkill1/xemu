## Recommendation: HOLD

**Summary:** This branch batches nonstreaming ADPCM encoded-word reads in bounded RAM caches while rechecking translation and memory-view identity per word. Steam Deck component ABBA/BAAB reduces mono/stereo read time by **48.04% / 54.35%**, and expanded original/candidate memory tests pass. Final guest ADPCM/PCM mix checks also pass five leaves per build, with a deliberate silent-output failure. Matched PGR2 game ABBA/BAAB is complete: the apparent combined 7.61% interval reduction is **inconclusive**, with 25–27% within-build variation and opposite signs in adjacent pairs. Keep draft pending audible output, approved XISO references/timing contracts and remaining lifetime coverage.
**Remaining:** Audible output parity and approved XISO framebuffer references; valid affected/control XISO timing contracts; repeatable representative game evidence; arbitrary backing destruction/resize coverage.

### Problem

`voice_get_samples()` performs nine or eighteen physical descriptor/payload reads per nonstreaming ADPCM block. Issue #197 investigates this cost. The collector-OFF profile in [#293](https://github.com/Mainkill1/xemu/pull/293) attributes 9.31% of process userspace cycles to voice-worker physical longword reads, without distinguishing ADPCM/PCM or descriptor/payload. It does not predict FPS savings.

### What this PR changes

- `hw/xbox/mcpx/apu/vp/vp.c` uses the private `sample-memory.h` reader. Each logical SGE-page chunk owns a temporary `MemoryRegionCache`, destroyed afterward.
- Every word reloads table base and descriptor. Cached loads require matching physical offset, a complete four-byte RAM word, and current FlatView identity equal to the retained view. Changed mappings/descriptors, failed/short maps, non-RAM and crossing words use ordinary physical loads. Descriptor arithmetic retains `hwaddr` width.
- `tests/xbox/mcpx-apu/test-sample-memory.c` adds nine API-double and thirteen actual-memory cases: decoded mono/stereo ramps, SGE crossing, actual MMIO order/count, and 256 event-ordered foreign-thread generations each for RAM mapping, table-base and descriptor changes. Two new cases perform 64 event-controlled owned-RAM retirements and 64 actual resizes exposing MMIO, with reader/writer RCU drains and owner-finalization checks. Production Linux XBOX CI runs original/candidate modes and retains the fixed-work benchmark.
- The branch preserves failed controls, repairs, CI outcomes and complete native evidence. Maintained HTTP process execution is a genuine separate [runner draft #89](https://github.com/Mainkill1/Xemu-Test-Runner/pull/89).

### Why this approach

```text
BEFORE: word -> current SGE translation -> physical payload read
AFTER: map bounded chunk
       word -> current SGE translation -> same view/address + whole RAM word?
          yes: cached read; no: original physical read
       destroy cache
```

Retaining the old view prevents address reuse during identity comparison; the comparison dereferences no current-view pointer. PCM, streaming ADPCM, decode, resampling and scheduling are unchanged. This does not synchronize every possible concurrent backing lifetime change.

### Validation

Reference `ee5ce48b48784f999af374c1452003f8b2b1230f`; component product/test `e25b0ba239c8146d2d661f26ec5ad29e82a14853`; expanded/native game candidate `c4cdef6cad3dd22d516e16ec2cb1aa9c06ec11f6`; guest evidence head `b51d7d96f28` adds documentation only; `0024d1343d2` adds lifetime tests without changing production code. Production reader/caller are byte-identical to the component-tested revision.

- [CI36999719003](https://github.com/Mainkill1/xemu/actions/runs/36999719003): all 20 jobs successful; 137 ordinary units pass; production original/candidate memory modes 11/11 each. Local API-double 9/9 and actual-memory 11/11 each pass. Removing only the view guard reproduces stale reads; the guarded candidate passes. [Source, red/green and limits](https://github.com/Mainkill1/xemu/tree/3c6b9fd8d5cfefc62a916754cd351e568f04895b/docs/evidence/issue197-expanded-correctness-20261002).
- Deck `.123` original/candidate expanded memory tests: **11/11 each**, exit zero, full collection, zero exclusions; 768 controlled changes per run. These are correctness results.
- Component: 24 separate processes including four A/A controls per workload, physical ABBA then BAAB, 4,096 warmup and 10M timed blocks/process. All independently calculated checksums match, collection complete. [Raw component evidence](https://github.com/Mainkill1/xemu/tree/cc39ba8afb4d090073703fcc4e131545794a2a0f/docs/evidence/issue197-deck-component-20261002).
- Matched game builds: exact reference rebuilt by [CI37004023200](https://github.com/Mainkill1/xemu/actions/runs/37004023200), attempt 3, all 20 jobs successful. **38/38 libraries**, Clang/LLD 21.1.8 and recorded release options match. Failed/canceled attempts preserved. [Build identities](https://github.com/Mainkill1/xemu/tree/8e199a0ef32372ac044bf9df393eeb00daf297d1/docs/evidence/issue197-matched-runtime-20261002).
- Guest fixture on Deck `.123`: final original/candidate each pass all **five** generated-input ADPCM/PCM mix assertions and cleanup checks; exact 64-word parity per leaf, maximum one-unit error. Deliberate VP-monitor mono silence fails the unchanged oracle despite ≥1024 engine sample periods and passing cleanup. All six attempts—including setup and headroom failures—exit zero and fully collect with zero exclusions; Mesa private cold disk writes qualify without waiver. Canonical outcomes remain **failed/ineligible** because these new leaves lack pinned framebuffer references. [Complete outcomes, raw assertions and fixture identities](https://github.com/Mainkill1/xemu/tree/b51d7d96f28/docs/evidence/issue197-deck-guest-voices-20261002).
- Game: Deck `10.0.0.123`, HTTP runner `f5b3e58`, Vulkan/full DSP/JIT/128 MiB, surface 1, VP workers 0, no vsync. Same immutable v3 test: excluded 60-second warmup, then ≥300 seconds parked. Two preceding matched A/A controls show 0.90% range/median; subsequent physical **ABBABAAB** is materially more variable. All eight exit zero, pass declared checks, qualify private cold Mesa disk writes without waiver, and fully collect 868 files each, zero exclusions. All scenes inspected; all statistics independently recalculated from source-hashed raw logs. [Complete game report and archive](https://github.com/Mainkill1/xemu/tree/45fc9193672/docs/evidence/issue197-game-balanced-20261002).

- Lifetime extension at `0024d1343d2`: local original/candidate **13/13** each; removing only the view guard makes both new cases fail on stale `0xdeadbeef` while original controls pass. Native extension and current CI are pending. The broader local unit build retains the unchanged GCC14 resampler `sinf`/`cosf` compile failure.

### Results

Positive Improvement % = less time; medians across four observations per build.

| Component workload | Original (s / 10M blocks) | Candidate | Saved (s) | Improvement % |
| --- | ---: | ---: | ---: | ---: |
| Mono: 9 words / 36 bytes | 5.020 | 2.609 | 2.412 | +48.04% |
| Stereo: 18 words / 72 bytes | 9.686 | 4.422 | 5.264 | +54.35% |

Order results agree: mono ABBA/BAAB +48.05/+48.04%; stereo +54.30/+54.33%. Original component spreads: 0.49/0.47%. Same-executable isolated reads; **not game FPS or end-to-end audio savings**.

| PGR2 descriptive metric | Original | Candidate | Saved | Improvement % |
| --- | ---: | ---: | ---: | ---: |
| Mean guest progress interval | 1,799.41 ms | 1,662.47 ms | 136.94 ms | +7.61% |
| p95 guest progress interval | 2,542.73 ms | 2,312.68 ms | 230.05 ms | +9.05% |
| p99 guest progress interval | 2,757.69 ms | 2,463.72 ms | 293.97 ms | +10.66% |
| Mean process CPU | 244.66% | 245.05% | −0.39 percentage points | −0.16% |

These are guest-progress observations, **not host presentation frame times or FPS**. CPU 100%=one logical core. ABBA/BAAB mean-interval medians appear +15.24/+10.06% better, but combined A/B range/median is **25.45/26.95%**. Adjacent pairs are **−4.90%, +32.21%, −4.85%, +22.05%**. No reliable game gain is established; favorable aggregate numbers do not qualify readiness.

### Risks and remaining questions

Earlier event-ordered tests retain RAM banks. New local tests retire QOM-owned RAM and shrink resizable RAM; native qualification is pending. Direct backing destruction that violates QEMU ownership is outside the cache contract; arbitrary same-map RAM-pointer replacement and native audible output remain unqualified. Host power/affinity were not pinned. Every matched game run preserves an unclassified `GLib: g_source_destroy` assertion warning also present in reference controls, despite exit zero. No significance claim from four processes per build.

Earlier unstable game controls, paused diagnostic observer timeout/ineligible performance, and CI failures remain preserved. The original voice snapshot identifies **45 affected mono ADPCM voices**, not fetch frequency or audio parity. [Historical controls](https://github.com/Mainkill1/xemu/tree/3a0f9ff/docs/evidence/issue197-game-controls-20261002), [voice snapshot](https://github.com/Mainkill1/xemu/tree/47d4810ac45facc9a1a80f3ae69d34256428f949/docs/evidence/issue197-pgr2-voice-snapshot-20261002).

Final affected ADPCM/PCM guest-mix checks pass; **audible output and affected/control XISO performance are not yet qualified**. The five-leaf retained guest MCPX fixture is in [test-suite draft #52](https://github.com/Mainkill1/xemu-perf-tests/pull/52), with 177 host contracts and pinned-NXDK Release build passing; native generated-mix qualification and silent-output rejection are complete on `.123`. Its host-paced progress polling will be explicitly **NOT COMPARABLE** for throughput. Missing framebuffer references, valid throughput timing and audible-output coverage keep this draft/HOLD.

### Related work

Addresses #197. #190 owns descriptor caching; #293 supplies attribution; #187 remains deferred. Runner #89 remains draft. Native testing stays on Deck `.123`; no merge.

> **Agent Declaration**: This pull request was created with assistance from Codex / GPT-6.

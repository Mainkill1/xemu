"""Prove the exact-boundary oracle rejects losing a complete frame bucket."""
from pathlib import Path
import importlib.util
import tempfile
import unittest

REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue246-allocation-attribution')
OUT = Path(__file__).resolve().parent
reader = REPO / 'scripts/performance/vk-perf-summary.py'
test = REPO / 'tests/unit/test-vk-perf-summary.py'
source = reader.read_text()
assert source.count("bucket['startTimestampUs'] >= start") == 1
assert source.count("bucket['startTimestampUs'] < start") == 1
mutant = source.replace("bucket['startTimestampUs'] >= start", "bucket['startTimestampUs'] > start")
mutant = mutant.replace("bucket['startTimestampUs'] < start", "bucket['startTimestampUs'] <= start")
with tempfile.TemporaryDirectory() as temporary:
    path = Path(temporary) / 'reader.py'
    path.write_text(mutant)
    spec = importlib.util.spec_from_file_location('boundary_tests', test)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SCRIPT = path
    suite = unittest.TestSuite([module.SummaryTests('test_auxiliary_exact_boundary_excludes_previous_bucket')])
    with (OUT / 'boundary-mutant.log').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    assert len(result.failures) == 1 and not result.errors
    assert '1 != 2' in result.failures[0][1]
print('Defective exact-boundary partition rejected by the retained test.')

"""Update PR293/#170 canonical bodies after the owning evidence commit exists."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue246-allocation-attribution')


def replace(body, old, new):
    assert body.count(old) == 1, old
    return body.replace(old, new, 1)


def main():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    evidence = f'https://github.com/Mainkill1/xemu/blob/{head}/docs/evidence/issue170-aux-analysis-20261002'
    before = json.loads((ROOT / 'pr-before.json').read_text())
    body = before['body']
    body = replace(body, '- Maintained allocation/schema-8 readers, collector tests, usage documentation, reusable native procedures and raw evidence. No retained images.',
                   '- Maintained allocation/schema-8 readers, collector tests, usage documentation, reusable native procedures and raw evidence. The schema-8 reader now adds `--auxiliary --tail-seconds`: validate seven caller arrays and separate complete trailing-window buckets from an uncertain boundary bucket. Both readers are registered in Meson/CI. No retained images or deferred submissions.')
    body = replace(body, 'Current head `f693ff713a` publishes documentation/evidence only; product/scripts/tests are unchanged from B.',
                   'Production hardware sources remain unchanged from B; this head extends the offline reader, its tests and Meson registration. The new evidence does not rerun or qualify the existing runtime collector.')
    body = replace(body, '### Results\n', '- New offline verification: registered telemetry 15/15 and allocation-reader 11/11 pass. A defective exact-boundary partition is rejected. Independent source-field recalculation and read-only review reproduce both reports. Full local unit rebuild still fails in unchanged resampler `sinf`/`cosf` declarations; a discovery invocation collects zero Python tests, so it is not claimed green. No new native attempt or new CI result is asserted by this packet.\n\n### Results\n')
    table = f'''**Related #170 auxiliary-upload gate:** existing diagnostic logs, not matched A/B performance. Both complete recorded 60-second windows and their separate straddling buckets contain zero surface-create/upload, texture-upload, PVIDEO or dummy-create calls.

| Recorded scene | Eligible auxiliary calls in tail | Readback calls, complete + boundary | Presentation calls, complete + boundary |
| --- | ---: | ---: | ---: |
| PGR2 parked starting grid | 0 | 486 + 6 | 81 + 1 |
| Morrowind name-entry modal | 0 | 0 | 2995 + 2 |

[Auxiliary report]({evidence}/REPORT.md), [raw traces and reader checks]({evidence}/EVIDENCE.tar.gz), [source/hash manifest]({evidence}/INDEX.json). The underlying short captures span 163.876 / 231.078 seconds and do not satisfy current five-minute PGR2 performance acceptance. Queue-wait durations are host elapsed diagnostics, not CPU time or predicted savings. Driving/streaming/transitions remain unqualified, so #170 stays open and no ring is implemented.

'''
    body = replace(body, '### Risks and remaining questions\n', table + '### Risks and remaining questions\n')
    body = replace(body, 'Addresses #246, still open. #197/draft #275 remain separate sample-memory research.',
                   'Addresses #246, still open. Provides bounded caller attribution for #170, which stays open; #90 owns presentation and required readback is preserved. #197/draft #275 remain separate sample-memory research.')
    issue_before = json.loads((ROOT / 'issue-before.json').read_text())
    issue = issue_before['body']
    old_status = '**Status:** the synchronous helper is source-confirmed; the frequency, avoidable critical-path cost and performance gain for remaining upload callers are unmeasured. Reviewed `main` at `82d04d84bdb3de956f20c3537e1da2cece0e8da2`.'
    issue = replace(issue, old_status,
        '**Status:** the synchronous helper remains source-confirmed at current main `ee5ce48b48784f999af374c1452003f8b2b1230f`. Two retained Deck diagnostics now classify its callers. Neither identifies a warm upload opportunity in the admitted recorded windows; broader frequency, avoidable critical-path cost and performance gain remain unqualified.')
    finding = f'''## Current Deck caller attribution

Draft [PR293](https://github.com/Mainkill1/xemu/pull/293) retains the schema-8 reader extension and evidence. Existing **Steam Deck 10.0.0.123** PGR2 grid/Morrowind name-entry traces have zero eligible create/upload auxiliary calls in their final recorded 60-second complete buckets **and** separate boundary buckets. PGR2 still records **486 + 6 boundary** CPU-readback calls and **81 + 1 boundary** presentation calls; Morrowind records **2995 + 2 boundary** presentation calls. Those paths retain their existing completion rules and are outside this issue's upload-retirement scope.

Whole-log surface-create/upload counts are **88/93** for PGR2 and **24/28** for Morrowind. The caller paths `command.c`, `perf.c`, `surface.c`, `display.c` match current main byte-for-byte. This is diagnostic attribution from short historical captures, **not** baseline/candidate timings, a speedup, or current five-minute PGR2 acceptance. Driving/streaming/transitions remain missing; keep this issue open and do not implement a speculative ring. The retained reader passes **15 checks**, allocation-reader **11**, with Meson registration, exact-boundary negative control and independent recalculation. Existing local full-unit resampler declaration failure stays disclosed.

[Readable table and scope]({evidence}/REPORT.md), [complete selected traces/checks]({evidence}/EVIDENCE.tar.gz), [hash index]({evidence}/INDEX.json). No new native attempt, report/readback deferral, timeout tolerance or cache waiver is introduced.

'''
    issue = replace(issue, '## Verified behavior and important counterevidence\n', finding + '## Verified behavior and important counterevidence\n')
    for name, endpoint, expected, text in (
        ('pr', 'repos/Mainkill1/xemu/pulls/293', before, body),
        ('issue', 'repos/Mainkill1/xemu/issues/170', issue_before, issue)):
        current = json.loads(subprocess.check_output(['gh', 'api', endpoint], text=True))
        assert current['body'] == expected['body'] and current['state'] == 'open'
        if name == 'pr':
            assert current['draft'] and not current['merged'] and current['head']['sha'] == head
        request = ROOT / (name + '-request.json')
        request.write_text(json.dumps({'body': text}) + '\n')
        (ROOT / (name + '-final-body.md')).write_text(text)
        with (ROOT / (name + '-response.json')).open('w') as stream:
            subprocess.run(['gh', 'api', endpoint, '--method', 'PATCH', '--input', str(request)], stdout=stream, check=True)
        readback = json.loads(subprocess.check_output(['gh', 'api', endpoint], text=True))
        assert readback['body'] == text and readback['state'] == 'open'
        if name == 'pr':
            assert readback['draft'] and not readback['merged'] and readback['head']['sha'] == head
        (ROOT / (name + '-readback.json')).write_text(json.dumps(readback, indent=2) + '\n')
    print('Verified canonical draft PR293 and open issue170', head)


if __name__ == '__main__':
    main()

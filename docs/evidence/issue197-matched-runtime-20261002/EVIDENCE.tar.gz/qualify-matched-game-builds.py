"""Verify corresponding CI bundles and retain complete 39-slot game builds."""
from pathlib import Path
import argparse, hashlib, json, re, shutil, subprocess

ROOT = Path('/home/codex/src/steamdeck-xemu')
REFERENCE = 'ee5ce48b48784f999af374c1452003f8b2b1230f'
CANDIDATE = 'c4cdef6cad3dd22d516e16ec2cb1aa9c06ec11f6'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def compiler_settings(path):
    raw = re.sub(r'\x1b\[[0-9;]*m', '', path.read_text())
    markers = ['XEMU_BUILD_OPTIONS: ', 'C compiler for the host machine: ',
               'C linker for the host machine: ', 'C++ compiler for the host machine: ']
    result = {marker.rstrip(': '): next(line.split(marker, 1)[1] for line in raw.splitlines() if marker in line)
              for marker in markers}
    assert 'clang 21.1.8' in result['C compiler for the host machine']
    assert 'ld.lld 21.1.8' in result['C linker for the host machine']
    for flag in ['-Db_lto=true', '-Db_lto_mode=thin', '-Dx86_version=3']:
        assert flag in result['XEMU_BUILD_OPTIONS'], flag
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-artifact', type=Path, required=True)
    parser.add_argument('--reference-log', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    candidate_artifact = ROOT / 'artifacts/issue197-sample-memory/native-builds/c4cdef-real-memory-ci'
    reference_source = ROOT / 'artifacts/issue197-sample-memory/native-builds/ee5-reference-current-source-ci/source-equivalence.json'
    candidate_source = ROOT / 'artifacts/issue197-sample-memory/native-builds/c4cdef-source-ci/source-equivalence.json'
    a, b = json.loads(reference_source.read_text()), json.loads(candidate_source.read_text())
    assert a['referenceCommit'] == REFERENCE and all(row['matchesReference'] for row in a['sourceChecks'])
    assert b['prHead'] == CANDIDATE and all(row['matchesHead'] for row in b['sourceFiles'])
    candidate_log = ROOT / 'scratch/issue197-ci-c4cdef-x86-release-rest.log'
    settings = compiler_settings(args.reference_log)
    assert settings == compiler_settings(candidate_log), 'Compiler or release options differ.'
    artifacts = {'reference': args.reference_artifact, 'candidate': candidate_artifact}
    names = sorted(p.name for p in (candidate_artifact / 'squashfs-root/usr/lib').iterdir())
    assert len(names) == 38
    expected = json.loads((ROOT / 'artifacts/issue197-sample-memory/remaining-gates/warmed-game-controls/frozen-manifest.json').read_text())
    build_slots = {row['path'] for row in expected['files'] if row['path'] == 'xemu' or row['path'].startswith('lib/')}
    assert build_slots == {'xemu', *('lib/' + n for n in names)}
    sources = {}
    for key, artifact in artifacts.items():
        library = artifact / 'squashfs-root/usr/lib'
        assert sorted(p.name for p in library.iterdir()) == names
        sources[key] = {'xemu': artifact / 'squashfs-root/usr/bin/xemu', **{'lib/' + n: library / n for n in names}}
    differences = [name for name in names if sha(sources['reference']['lib/' + name]) != sha(sources['candidate']['lib/' + name])]
    assert not differences, 'Corresponding runtime libraries differ: ' + ', '.join(differences)
    args.output.mkdir(parents=True, exist_ok=False)
    identity = dict(referenceCiRun=37004023200, candidateCiRun=36999719003,
                    compilerSettings=settings, runtimeLibrariesIdentical=True,
                    buildFiles=['xemu'] + ['lib/' + n for n in names],
                    referenceSource=a, candidateSource=b,
                    referenceCompilerLogSha256=sha(args.reference_log), candidateCompilerLogSha256=sha(candidate_log))
    for key, artifact in artifacts.items():
        directory = args.output / key
        (directory / 'lib').mkdir(parents=True)
        files = {}
        for name, source in sources[key].items():
            destination = directory / name
            shutil.copy2(source, destination)
            files[name] = dict(bytes=destination.stat().st_size, sha256=sha(destination))
            assert files[name]['sha256'] == sha(source)
        (directory / 'xemu').chmod(0o755)
        appimage = next(artifact.glob('*.AppImage'))
        identity[key] = dict(directory=str(directory.resolve()), sourceCommit=REFERENCE if key=='reference' else CANDIDATE,
                             correspondingAppImage=str(appimage), appImageSha256=sha(appimage), files=files,
                             executableElfNotes=subprocess.check_output(['readelf', '-n', str(directory/'xemu')], text=True))
    (args.output / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps(dict(runtimeLibrariesIdentical=True, buildSlots=39, reference=identity['reference']['files']['xemu'], candidate=identity['candidate']['files']['xemu']), indent=2))

if __name__ == '__main__':
    main()

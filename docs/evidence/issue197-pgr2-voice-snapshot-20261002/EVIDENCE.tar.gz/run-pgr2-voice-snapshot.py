"""Retained HTTP-only PGR2 diagnostic procedure; never clean performance evidence."""
from pathlib import Path
import argparse, copy, json, re, struct, sys, time, urllib.parse

ROOT = Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi, job_url, encode_path
from runner_workflows import Workflows
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--id', required=True, help='Fresh attempt ID, or existing ID with --observe.')
parser.add_argument('--observe', action='store_true', help='Observe a submitted saved diagnostic test without creating or restarting it.')
parser.add_argument('--output', required=True, type=Path, help='Output directory dedicated to this attempt.')
args = parser.parse_args()
OUT = args.output.resolve()
OUT.mkdir(parents=True, exist_ok=True)
api = RunnerApi('http://10.0.0.123:9368')
work = Workflows(api)
job_id = args.id
source_id = 'issue197-deck-pgr2-parked-300-v2-aa1'

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

recipe_flags = {'pauseBefore': True, 'resumeDuring': False, 'pauseAfter': True}
if not args.observe:
    manifest = copy.deepcopy(json.loads((ROOT / 'artifacts/issue197-sample-memory/native/v2-aa1/manifest.json').read_text()))
    manifest['id'] = job_id
    job = manifest['job']
    job['id'] = job_id
    job['timeoutSeconds'] = 900
    job['experiment']['id'] = 'issue197-pgr2-path-identification'
    job['experiment']['variant'] = 'original-diagnostic'
    job['experiment']['allowDiagnostics'] = True
    job['experiment']['allowOperatorIntervention'] = True
    job['experiment']['controlledFactors'].append('Diagnostic-only paused postlude; no clean performance claim.')
    job['operations'].update(mode='smoke', allowDiagnostics=True, allowPauseResume=True, allowBulkTransfers=True)
    recipe_flags = {'pauseBefore': True, 'resumeDuring': False, 'pauseAfter': True}
    # This diagnostic contract has no performance-analysis window. Original v1
    # and its ineligible frame-analysis outcome remain unchanged.
    job['workload'].pop('analysis', None)
    job['diagnostics'] = [
        {'id': 'pci-map', 'type': 'monitor', 'monitorCommand': 'info pci', **recipe_flags},
        {'id': 'apu-voice-base', 'type': 'monitor', 'monitorCommand': 'xp /1wx 0xfe80202c', **recipe_flags},
    ]
    assert job['plan'][-1]['type'] == 'quit'
    job['plan'][-1:] = [
        {'type': 'pause'},
        {'type': 'diagnostic', 'diagnosticId': 'pci-map'},
        {'type': 'diagnostic', 'diagnosticId': 'apu-voice-base'},
        {'type': 'wait', 'delayMs': 120000},
        {'type': 'quit'},
    ]
    assert next(step['delayMs'] for step in job['plan'] if step['type']=='wait' and step['delayMs']==300000)==300000
    save('manifest.json', manifest)
    save('purpose.json', {'scope': 'Identify active/nonpaused nonstreaming ADPCM voices; diagnostic run, not a speedup comparison', 'reference': source_id, 'changes': 'unchanged runtime payload and 300-second parked procedure, followed by pause, PCI/voice-base queries and bounded RAM snapshot', 'noGuestWrites': True})
    status = api.json('/api/v1/status')
    save('deck-before.json', status)
    assert status['Phase'] == 'idle' and status['CurrentJob'] is None
    save('created.json', api.json('/api/v1/jobs', 'POST', manifest))
    if work.status(job_id)['state'] == 'busy':
        work.operation(job_id)
    api.json(job_url(job_id) + '/reuse', 'POST', {'sourceJobId': source_id})
    save('reused.json', work.operation(job_id))
    save('files-ready.json', api.json(job_url(job_id) + '/files'))
    build_slots = [item['path'] for item in manifest['files'] if item['path']=='xemu' or item['path'].startswith('lib/')]
    save('saved-test.json', api.json('/api/v1/tests/issue197-pgr2-voice-snapshot-v2/bake', 'POST', {
        'sourceJobId': job_id,
        'buildFiles': build_slots,
        'description': 'PGR2 300-second parked diagnostic, then paused PCI/APU voice-base queries and a bounded voice-table read using the retained HTTP helper. Diagnostics allowed; no clean performance claim.',
    }))
    save('submitted.json', work.submit_draft(job_id))
deadline = time.monotonic() + 900
while time.monotonic() < deadline:
    state = work.status(job_id)
    if state['state'] == 'tested':
        raise RuntimeError('Run terminated before the diagnostic postlude: ' + json.dumps(state))
    diagnostics = api.json('/api/v1/diagnostics')
    completed = {item['Id']: item for item in diagnostics['Completed']}
    if diagnostics['Active'] and 'apu-voice-base' in completed and 'pci-map' in completed:
        break
    print(json.dumps({'state': state['state'], 'runId': state.get('runId'), 'phase': api.json('/api/v1/status')['Phase']}), flush=True)
    time.sleep(20)
else:
    raise RuntimeError('Timed out observing the existing run; inspect the same job ID, do not restart.')
save('postlude-diagnostics.json', diagnostics)
run_id = state['runId']

def get_diagnostic(result, artifact):
    assert result['Status'] == 'completed', result
    relative = 'diagnostics/' + result['Directory'].replace('\\', '/').split('/diagnostics/', 1)[1] + '/' + artifact
    href = '/api/v1/runs/' + urllib.parse.quote(run_id, safe='') + '/artifacts/' + encode_path(relative)
    with api.open(href) as response:
        data = response.read(65537)
    assert len(data) <= 65536
    (OUT / artifact).write_bytes(data)
    return data

pci = get_diagnostic(completed['pci-map'], 'monitor.txt').decode()
(OUT / 'pci-map.txt').write_text(pci)
apu = re.search(r'PCI device 10de:01b0.*?(?=\n\s*Bus\s|\Z)', pci, re.S | re.I)
assert apu is not None, pci
assert re.search(r'BAR0:.*?0xfe800000', apu.group(), re.I), apu.group()
base_text = get_diagnostic(completed['apu-voice-base'], 'monitor.txt').decode()
(OUT / 'apu-voice-base.txt').write_text(base_text)
match = re.search(r'(?:0x)?fe80202c:\s*(0x[0-9a-f]+)', base_text, re.I)
assert match, base_text
base = int(match.group(1), 16)
assert 0 < base <= 128 * 1024 * 1024 - 256 * 128 and base % 128 == 0, base
request = {'Recipe': {'Id': 'apu-voice-table', 'Type': 'memory_dump', 'Address': base, 'Size': 256 * 128, 'OutputName': 'voice-table.bin', 'PauseBefore': True, 'ResumeDuring': False, 'PauseAfter': True, 'Reason': 'Read-only identification of affected ADPCM voice formats; not clean benchmark evidence.'}}
save('voice-table-request.json', request)
result = api.json('/api/v1/diagnostics/run', 'POST', request)
save('voice-table-receipt.json', result)
raw = get_diagnostic(result, 'voice-table.bin')
assert len(raw) == 256 * 128
voices = []
for voice in range(256):
    fmt = struct.unpack_from('<I', raw, voice * 128 + 4)[0]
    state_word = struct.unpack_from('<I', raw, voice * 128 + 0x54)[0]
    voices.append({'voice': voice, 'format': f'{fmt:08x}', 'state': f'{state_word:08x}', 'active': bool(state_word & (1 << 21)), 'paused': bool(state_word & (1 << 18)), 'streaming': bool(fmt & (1 << 24)), 'multipass': bool(fmt & (1 << 21)), 'stereo': bool(fmt & (1 << 27)), 'container': ['B8','B16','ADPCM','B32'][fmt >> 30], 'samplesPerBlock': 1 + ((fmt >> 16) & 31)})
active = [v for v in voices if v['active'] and not v['paused'] and not v['multipass']]
affected = [v for v in active if v['container']=='ADPCM' and not v['streaming']]
summary = {'jobId': job_id, 'runId': run_id, 'guestVoiceBase': f'{base:#x}', 'scope': 'one paused guest voice-format snapshot; neither throughput nor audio parity', 'activeNonpausedNonmultipassVoices': len(active), 'affectedNonstreamingADPCMVoices': len(affected), 'activeVoices': active, 'allVoices': voices}
save('voice-summary.json', summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['allVoices','activeVoices']}), flush=True)
# Scripted waits freeze while the VM is paused. Release the diagnostic
# handoff so the bounded postlude wait and existing quit step can complete.
save('postlude-resume.json', api.json('/api/v1/xemu/resume', 'POST', {}))
terminal = work.wait(job_id, 300)
save('terminal.json', terminal)
assert terminal['state'] == 'tested', terminal
save('result-summary.json', work.result(job_id))
save('collection.json', work.collect(job_id, OUT / 'collected', None, True))
print('COLLECTED', flush=True)

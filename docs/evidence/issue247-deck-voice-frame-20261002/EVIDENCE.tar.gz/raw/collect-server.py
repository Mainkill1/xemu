"""Collect server comparison and every indexed record after native testing."""
from pathlib import Path
import json
import sys
import urllib.parse

ROOT = Path('/home/codex/src/steamdeck-xemu')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi

api = RunnerApi('http://10.0.0.123:9368')
status = api.json('/api/v1/status')
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
identity = json.loads((OUT / 'matched-build-qualification.json').read_text())
hashes = {v: next(f['sha256'] for f in identity['files'] if f['path'] == v + '/test-xbox-mcpx-apu-voice-frame') for v in ('reference', 'candidate')}
all_hashes = {v + '-' + kind: next(f['sha256'] for f in identity['files'] if f['path'] == v + '/test-xbox-mcpx-apu-voice-frame' + suffix) for v in ('reference', 'candidate') for kind, suffix in (('ordinary', ''), ('diagnostic', '-stores'))}
for variant, digest in all_hashes.items():
    pages, items, offset = [], [], 0
    while True:
        page = api.json('/api/v1/build-results/' + digest + '/runs?offset=' + str(offset) + '&limit=20')
        pages.append(page)
        current = page['items']
        items.extend(current)
        if len(current) < 20:
            break
        offset += len(current)
    (OUT / ('server-' + variant + '-runs.json')).write_text(json.dumps({'items': items, 'pages': pages}, indent=2) + '\n')
query = urllib.parse.urlencode({'A': hashes['reference'], 'B': hashes['candidate']})
for format_name in ('json', 'markdown', 'csv'):
    with api.open('/api/v1/compare?' + query + '&format=' + format_name) as response:
        data = response.read()
    suffix = {'json': 'json', 'markdown': 'md', 'csv': 'csv'}[format_name]
    (OUT / ('server-comparison.' + suffix)).write_bytes(data)
print(json.dumps({'hashes': hashes, 'referenceRuns': len(json.loads((OUT / 'server-reference-ordinary-runs.json').read_text())['items']),
                  'candidateRuns': len(json.loads((OUT / 'server-candidate-ordinary-runs.json').read_text())['items'])}))

## Recommendation: HOLD

**Triage:** The atomic candidate measured 2.19% lower Windows process CPU in an eligible balanced campaign, but guest-writer ordering and audio/save-load parity remain unproven. Resolve those correctness gates and run an affected audio XISO before merge.

**Summary:** Issue #247 and the opt-in counters in #270 show that about 88% of sampled APU voice-state stores wrote unchanged words in PGR2. This draft validates equal direct-RAM words with a same-value atomic compare-exchange; a changed word falls back to the original physical store. A new, balanced Windows PGR2 campaign on the atomic implementation observed **2.19% lower sampled process CPU** at the same 30 FPS cap, with frame p95/p99 slightly worse. This is not yet a safe merge: a complete ordering contract with guest direct-memory writers, affected audio correctness, and save/load qualification are still missing.
**Remaining:** Establish the guest-writer/mapping ordering contract; compare PCM and reset/save-load behavior; run a pinned affected APU/audio XISO case with oracle; complete the Deck fixed-work ABBA/BAAB comparison; qualify the game start procedure and cache state; obtain new-head CI.

### Problem

`voice_set_mask()` performs a physical store after every voice-state read/modify/write, including unchanged values. #270 measured 88.19–88.23% unchanged stores in three Windows PGR2 runs and 88.62% in one admitted Deck run. That count identifies work exposure, not speedup.

### What this PR changes

- `hw/xbox/mcpx/apu/vp/vp.c` delegates to the production store helper in `voice-store.c`. For equal values in direct, aligned Xbox RAM, it compares/exchanges the expected little-endian word with itself. A validation mismatch performs the original physical store. Xen and unsupported mappings also use the physical store.
- `voice-store.h` provides overflow-safe range/equality admission. Changed values, low-memory overlays, out-of-range addresses, non-direct RAM, and partial mappings retain the original physical-memory path.
- The policy test and production-path `AddressSpace` test cover direct RAM, VGA dirty logging, MMIO overlays, a two-byte overlay, and a synchronized writer that changes the RAM word after the APU read but before validation. The test invokes the same helper called by `voice_set_mask()`.
- A retained Linux production VP fixture and a separate physical-store diagnostic link the actual VP, decoder, libsamplerate and QEMU RAM. Both use 45 voices with mono ADPCM, stereo ADPCM and PCM, one/eight workers, independent mix and offset oracles, and NV2A dirty clients. The ordinary timing executable contains no store counter. Linux CI verifies and retains both targets.
- [Atomic revision evidence](https://github.com/Mainkill1/xemu/blob/c4d36ecfa3/evidence/wiki-xiso-per-test/pr-276-issue247/ATOMIC-REVISION.md) provides every new Windows/Deck run, avg/p95/p99/max values, run IDs, executable identities, and exclusions. [Earlier evidence](https://github.com/Mainkill1/xemu/blob/c4d36ecfa3/evidence/wiki-xiso-per-test/pr-276-issue247/REPORT.md) applies only to the pre-review implementation.

No shadow cache, APU scheduling change, or graphics/shader change is included. The idea was informed by [izzy2lost's equal-write prototype](https://github.com/izzy2lost/xemu/commit/a7765290d17750e10a2bfc2d94cd85279f3b591e); this branch adds a resolved-mapping and direct-access guard.

### Why this approach

The existing physical read supplies the comparison value. The resolved `MemoryRegion` check and direct-access predicate prevent overlays and special RAM from being treated as ordinary writable RAM. The sequentially consistent compare-exchange validates the aligned host word in little-endian representation. If another writer changes the word **before validation**, the original physical-store path executes. QEMU guest direct writes can use ordinary non-atomic RAM accesses, however, so the test and atomic operation do **not** establish a complete cross-writer ordering proof. The real-`AddressSpace` test shows that equal direct-RAM contents stay clean under VGA dirty logging, while changed writes mark dirty.

```text
Previous: read -> compute -> RAM mapping check -> return on equality
Revised:  read -> compute -> direct RAM check -> atomic equal-word check
                                                   | match: return
                                                   | mismatch/unsupported: physical store
```

The inline helper and implementation use `LGPL-2.1-or-later`, one of QEMU checkpatch's permitted identifiers. The including `vp.c` allows LGPL version 2 or later. Checkpatch rejects `LGPL-2.0-or-later` for new files despite its use in an adjacent older header. The temporary callback-guard commit and immediate revert have been removed from branch history.

### Validation

- Parent A source: `ee5ce48b48784f999af374c1452003f8b2b1230f`. Atomic B executable source: `d3ccb5420cdcaebf73ac9553d32f73c09c899d61`. Current PR head `c4d36ecfa3` adds report, clearer comments, and the synchronized-writer test without changing the compiled fast-path algorithm; the binary runs below are attributable to `d3ccb5420c`, not claimed as a fresh `c4d36ecfa3` executable.
- On current source, local Linux `qemu-system-i386` and both focused unit binaries built with `-DXBOX=1`; policy cases passed 3/3 and real-`AddressSpace` case passed 1/1. `git diff --check` passed. Checkpatch for the follow-up commit reported zero errors and two documentation-file warnings. The previous atomic source head had 39/40 exact-head GitHub checks successful; one unit-test job was still installing dependencies, while the separate PR-run unit job passed. Both CI workflows for the prior `c4d36ecfa3` head completed successfully. New fixture head `5d832c02c3e` has CI pending.
- Vulkan PGR2 Windows: same pinned procedure for A and B, ordered **A/B/B/A then B/A/A/B**. Eight runs completed with correctness passed, evidence complete, and comparison eligible. Start/end screenshots show the same parked car and track; hashes are recorded in the machine-readable evidence, images remain private. Windows A executable SHA-256: `a89521cb6ff76916e248b002f253df0c2d5aafb3867d13384d96a498c36622e2`; B: `5d7f2cba9a30de4708a494536770864410454cb8690cdc7e1b38706daec31787`.
- Steam Deck A/B/B passed correctness but were comparison-ineligible due uncontrolled Mesa driver-cache state. The next baseline A run measured **PGR2 Event Select rather than the race start**, failing correctness and ending the balanced sequence. Its OS controller receipts were present, which does not prove guest consumption. [Runner issue #81](https://github.com/Mainkill1/Xemu-Test-Runner/issues/81) preserves that failure. No Deck A/B comparison is claimed for this revision.
- Earlier Windows attempts remain excluded and recorded: a diagnostic transfer made B1 comparison-ineligible, and a later request failed before launch when the legacy 2.62 GB HDD copy filled the disk. The full eight-run campaign followed authorized cleanup of finalized duplicate seed copies. [Runner issue #47](https://github.com/Mainkill1/Xemu-Test-Runner/issues/47) tracks the fixture and preflight defect.
- The maintained [APU XISO fixture draft #52](https://github.com/Mainkill1/xemu-perf-tests/pull/52) now contains five affected audio leaves, but its pinned framebuffer references and timer-paced measurement qualification remain incomplete; it has not yet qualified this candidate. Reset/save-load and controlled game/Deck-cache coverage remain pending.
- New local fixture qualification at `5d832c02c3e`: policy 3/3, real-memory 1/1, ordinary VP 6/6 and diagnostic VP 6/6 pass. Twelve 1,000-frame runs match independent output and offset expectations. Candidate diagnostics record 45,000 changed physical stores and zero unchanged fallback stores in each workload. A mutated helper omitting changed stores aborts the ordinary frame oracle (offset 0 versus independently expected 3392). The silence negative also aborts. No Deck performance result is claimed from these local checks.
- The attempted full local unit build fails in unchanged `test-xbox-mcpx-apu-resampler.c` because GCC 14 rejects missing `sinf`/`cosf` declarations. This remains a recorded failure; the full local suite is not claimed green.

### Results

**New atomic B executable (`d3ccb5420c`) versus parent A, Windows PGR2.** These are arithmetic means of four per-run values for each variant; the [atomic revision report](https://github.com/Mainkill1/xemu/blob/c4d36ecfa3/evidence/wiki-xiso-per-test/pr-276-issue247/ATOMIC-REVISION.md) retains every run and the CPU/frame avg, p95, p99 and max values.

| Metric | A | B | B − A | Interpretation |
| --- | ---: | ---: | ---: | --- |
| Process CPU mean | 318.428 core % | 311.444 core % | −6.984 core % | **2.19% lower sampled CPU** |
| Guest cadence | 30.000 fps | 30.000 fps | ~0 | Capped |
| Frame average | 33.333 ms | 33.333 ms | ~0 | No observed change |
| Frame p95 | 33.597 ms | 33.651 ms | +0.053 ms | Slightly worse |
| Frame p99 | 33.977 ms | 34.097 ms | +0.120 ms | Slightly worse |
| Mean per-run frame maximum | 34.500 ms | 34.338 ms | −0.161 ms | Slightly better |

The pre-review B source `93b4226360` had a separate 1.98% Windows CPU reduction in the earlier report. Those numbers are historical and are not pooled with this revision. Windows B4's high 326.73 core % remains included here; no outlier was silently dropped.

### Risks and remaining questions

The compare-exchange rejects the tested stale-read interleaving, but guest direct RAM stores may be non-atomic and are not serialized by the APU voice lock. Full writer/mapping ordering, observers beyond tested dirty logging, native PCM comparison, and save/load remain unqualified. A compare-exchange also writes at the host-memory level and could have different cost on other architectures. The Windows observation is workload-specific; its p95/p99 did not improve. The Deck sequence is incomplete and cache-ineligible. The unaffected XISO control cannot substitute for an audio case with a pinned oracle. Keep this PR draft and marked HOLD until these gates are closed.

### Related work

Addresses #247. #270 provided opt-in attribution data and is closed as a diagnostic-only PR. #200 studied APU worker count and is not duplicated here.

> **Agent Declaration**: This pull request was created with assistance from Codex (GPT-6).

"""Verify CI source, fixture, build settings and complete runtime libraries."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path('/home/codex/src/steamdeck-xemu')
OUT = Path(__file__).resolve().parent
REPO = ROOT / 'worktrees/issue247-equal-store'
EXES = ['test-xbox-mcpx-apu-voice-frame', 'test-xbox-mcpx-apu-voice-frame-stores']
VARIANTS = {
    'reference': ('dd1a8f48690803975d9e97b8e1139dcc4164fc83', 37038506712),
    'candidate': ('5d832c02c3ed6e1f56ef1b808fe74d8f3ea565ee', 37038440974),
}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def settings(path):
    text = re.sub(r'\x1b\[[0-9;]*m', '', path.read_text())
    markers = ['XEMU_BUILD_OPTIONS: ', 'C compiler for the host machine: ',
               'C linker for the host machine: ', 'C++ compiler for the host machine: ']
    result = {m.rstrip(': '): next(line.split(m, 1)[1] for line in text.splitlines() if m in line) for m in markers}
    assert 'clang 21.1.8' in result['C compiler for the host machine']
    assert 'ld.lld 21.1.8' in result['C linker for the host machine']
    assert all(flag in result['XEMU_BUILD_OPTIONS'] for flag in ('-Db_lto=true', '-Db_lto_mode=thin', '-Dx86_version=3'))
    for exe in EXES:
        assert any(re.search(re.escape(exe) + r'\s+OK\b', line) and '6 subtests passed' in line for line in text.splitlines()), exe
    return result

compiler = settings(OUT / 'reference-release-ci.log')
assert compiler == settings(OUT / 'candidate-release-ci.log')
tracked = ['tests/xbox/mcpx-apu/test-voice-frame.c', 'tests/xbox/mcpx-apu/VOICE-FRAME.md',
           'meson.build', '.github/workflows/build-linux.yml',
           'hw/xbox/mcpx/apu/vp/vp.c', 'hw/xbox/mcpx/apu/vp/vp.h',
           'hw/xbox/mcpx/apu/vp/adpcm.h', 'hw/xbox/mcpx/apu/vp/resample.h',
           'hw/xbox/mcpx/apu/apu.c', 'hw/xbox/mcpx/apu/apu_int.h']
source, files, libraries = {}, [], None
for variant, (commit, ci) in VARIANTS.items():
    build = OUT / 'native-builds' / variant
    archive = next((build / 'source').glob('*.tar.zst'))
    selected = tracked + (['hw/xbox/mcpx/apu/vp/voice-store.c', 'hw/xbox/mcpx/apu/vp/voice-store.h'] if variant == 'candidate' else [])
    checks = {}
    proc = subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE)
    with tarfile.open(fileobj=proc.stdout, mode='r|') as tar:
        for member in tar:
            parts = member.name.removeprefix('./').split('/', 1)
            if len(parts) != 2 or parts[1] not in selected:
                continue
            name = parts[1]
            data = tar.extractfile(member).read()
            expected = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=REPO)
            assert data == expected, name
            checks[name] = hashlib.sha256(data).hexdigest()
            dest = OUT / 'source' / variant / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
    assert proc.wait() == 0 and set(checks) == set(selected)
    source[variant] = {'commit': commit, 'ciRun': ci, 'archiveSha256': sha(archive), 'sourceSha256': checks,
                       'elfNotes': {exe: subprocess.check_output(['readelf', '-n', str(build / exe)], text=True) for exe in EXES}}
    for exe in EXES:
        p = build / exe
        files.append({'path': variant + '/' + exe, 'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
    library = build / 'squashfs-root/usr/lib'
    current = {p.name: sha(p) for p in library.iterdir()}
    assert len(current) == 38
    if libraries is None:
        libraries = current
        for name in sorted(current):
            p = library / name
            files.append({'path': 'lib/' + name, 'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
    else:
        assert current == libraries, 'Corresponding libraries differ.'
for name in tracked[:2]:
    assert source['reference']['sourceSha256'][name] == source['candidate']['sourceSha256'][name]
# The reader optimization from #197 must not enter either build.
assert subprocess.check_output(['git', 'diff', receipt_parent := 'ee5ce48b48784f999af374c1452003f8b2b1230f',
                                VARIANTS['reference'][0], '--', 'hw'], cwd=REPO) == b''
assert subprocess.check_output(['git', 'diff', 'c4d36ecfa3111b60744225e966c0d12bc44cf007',
                                VARIANTS['candidate'][0], '--', 'hw'], cwd=REPO) == b''
for variant in VARIANTS:
    data = (OUT / 'source' / variant / 'hw/xbox/mcpx/apu/vp/vp.c').read_text()
    assert 'mcpx_apu_sample_memory' not in data
receipt = {'qualified': True, 'fixedOriginal': 'ee5ce48b48784f999af374c1452003f8b2b1230f',
           'source': source, 'compilerSettings': compiler, 'runtimeLibrariesIdentical': True,
           'runtimeLibraryCount': 38, 'files': files,
           'scope': 'Actual production VP fixed work with independent output/offset oracles; no game, DSP, vCPU or renderer.'}
(OUT / 'matched-build-qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'qualified': True, 'files': len(files), 'libraries': 38, 'compilerSettings': compiler}))

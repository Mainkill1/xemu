"""Package verified measurements in the owning xemu repository."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store')
OUT = REPO / 'docs/evidence/issue247-deck-voice-frame-20261002'
OUT.mkdir(parents=True, exist_ok=True)
summary = json.loads((RAW / 'VERIFIED-SUMMARY.json').read_text())
identity = json.loads((RAW / 'matched-build-qualification.json').read_text())
ci = {v:json.loads((RAW / (v+'-ci.json')).read_text()) for v in ('reference','candidate')}
assert all(c['conclusion'] == 'success' for c in ci.values())
assert len(summary['attempts']) == 88 and summary['canonicalCohortKeysMatch']
payloads, omissions = {}, []
for path in sorted(RAW.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.name == 'package.log':
        continue
    name = path.relative_to(RAW).as_posix()
    omit = name.startswith('native-builds/') and not name.endswith('.log')
    omit |= name.startswith('deck-native/package/')
    omit |= path.suffix == '.o' or path.name in ('negative-memory-test','negative-progress-test','negative-voice-frame')
    if omit:
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream,'sha256').hexdigest()
        omissions.append({'path':name,'bytes':path.stat().st_size,'sha256':digest,
                          'reason':'large build or test binary retained locally; exact source, CI identities and runtime hashes retained in packet'})
    else:
        payloads['raw/'+name] = path.read_bytes()
for name in ('testlog.txt','testlog.json'):
    payloads['local-meson/'+name] = (REPO/'build-voice-frame/meson-logs'/name).read_bytes()
payloads['source/harness.patch'] = subprocess.check_output(['git','diff','c4d36ecfa3111b60744225e966c0d12bc44cf007','5d832c02c3ed6e1f56ef1b808fe74d8f3ea565ee'],cwd=REPO)
payloads['source/production.patch'] = subprocess.check_output(['git','diff','ee5ce48b48784f999af374c1452003f8b2b1230f','c4d36ecfa3111b60744225e966c0d12bc44cf007','--','hw','tests/unit','tests/unit/meson.build'],cwd=REPO)
payloads['SUMMARY.json'] = (json.dumps(summary,indent=2)+'\n').encode()
entries = []
archive = OUT/'EVIDENCE.tar.gz'
with archive.open('wb') as stream:
    with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,data in sorted(payloads.items()):
                item = tarfile.TarInfo(name)
                item.size,item.mode,item.mtime = len(data),0o644,0
                tar.addfile(item,io.BytesIO(data))
                entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries)
    for entry in entries:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
with archive.open('rb') as stream:
    archive_hash = hashlib.file_digest(stream,'sha256').hexdigest()
(OUT/'INDEX.json').write_text(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':archive_hash,'payloads':entries,'omissions':omissions},indent=2)+'\n')
(OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
names = {'mono-adpcm':'Mono ADPCM','stereo-adpcm':'Stereo ADPCM','mono-pcm':'Mono PCM'}
table = ['| Voice format | Worker threads | Baseline s | Candidate s | Saved s | Improvement % |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
variation = ['| Voice format | Worker threads | Baseline A/A spread | ABBA improvement | BAAB improvement | Four adjacent pair improvements |',
             '| --- | ---: | ---: | ---: | ---: | --- |']
for row in summary['results']:
    table.append(f"| {names[row['profile']]} | {row['workers']} | {row['baseline_us']/1e6:.6f} | {row['candidate_us']/1e6:.6f} | {row['saved_us']/1e6:+.6f} | {row['improvement_percent']:+.2f}% |")
    pairs = ', '.join(f'{p:+.2f}%' for p in row['adjacentPairs_percent'])
    variation.append(f"| {names[row['profile']]} | {row['workers']} | {row['originalControlSpread_percent']:.2f}% | {row['orders']['abba']:+.2f}% | {row['orders']['baab']:+.2f}% | {pairs} |")
counts = ['| Voice format | Worker threads | Baseline physical stores | Candidate physical stores | Unchanged physical stores removed |',
          '| --- | ---: | ---: | ---: | ---: |']
for row in summary['counts']:
    counts.append(f"| {names[row['profile']]} | {row['workers']} | {row['original_physical_stores']:,} | {row['candidate_physical_stores']:,} | {row['removed_unchanged_physical_stores']:,} |")
hashes = {v:next(f['sha256'] for f in identity['files'] if f['path'] == v+'/test-xbox-mcpx-apu-voice-frame') for v in ('reference','candidate')}
positive_pairs = sum(p>0 for r in summary['results'] for p in r['adjacentPairs_percent'])
report = f'''# Equal voice store performance on Steam Deck

**Decision: HOLD.** This report evaluates the existing RAM equal-store
candidate in [xemu draft PR276](https://github.com/Mainkill1/xemu/pull/276),
issue #247. It extends the earlier unchanged-store attribution and capped
Windows game measurement with actual production VP work on the Deck.
Required guest ordering, audio, lifecycle and XISO qualification remain open.

## Baseline and candidate

Each process performs **20,000 voice-processing frames, 45 voices and 32
samples per voice per frame**. The numbers are host elapsed seconds for this
fixed batch, including identical output validation. They are not game frame
times or FPS. Mono and stereo ADPCM use encoded samples; PCM uses uncompressed
samples. All three formats exercise the changed store helper. Worker threads
are the actual production VP workers, using either one or eight threads.

**A** is the original physical-store implementation; **B** is the candidate
that validates an unchanged RAM word using a same-value compare-exchange.
The saved runner tests physically execute four original A/A controls, then
**A B B A**, then **B A A B**, for each row. Main medians use the four A and
four B processes in those balanced orders. A/A controls are separate.
Positive Improvement % means less elapsed time:
`100*(baseline-candidate)/baseline`.

{chr(10).join(table)}

{positive_pairs} of 24 adjacent A/B or B/A pairs use less time for the candidate.
Use the order and variation table below when interpreting small differences.
This small campaign provides no confidence interval or general game speedup
claim. [SUMMARY.json](SUMMARY.json) retains every range and pair;
no attempt was omitted or replaced.

## Variation and execution order

{chr(10).join(variation)}

A/A spread is `(maximum-minimum)/median` for the four original controls.
No CPU affinity or power policy was changed or pinned. The first 256 frames
and one qualified frame precede timing. Sinc startup is excluded, while each
timed frame checks all 1,024 output samples and computes 64 checksum
contributions. That common validation cost can dilute the relative saving.

## What work was removed

Store counts come from **12 separate diagnostic processes**, not the timing
executables. The wrapper forwards every physical store to the real QEMU
implementation. Diagnostic elapsed values are retained but are
**diagnostic-only / NOT COMPARABLE** as performance measurements.

{chr(10).join(counts)}

Every profile keeps exactly 900,000 changed physical stores, one per voice
per frame, and removes the 4,500,000 unchanged physical stores observed in
the original. The candidate still reads and translates RAM and executes an
atomic same-value compare-exchange; the count reduction does not mean those
updates become free. The ordinary timing executable has no store-count code.

This connects #270's earlier roughly 88% unchanged-store observation to the
actual candidate mechanism. This fixture's unchanged fraction is 83.33%.
It does not combine the #197 sample-reader optimization with #247, and its
elapsed values must not be pooled with #197's separate processing campaign.

## Builds and native execution

- Original production commit: `ee5ce48b48784f999af374c1452003f8b2b1230f`.
- Reference fixture commit: `dd1a8f48690803975d9e97b8e1139dcc4164fc83`.
  It adds only the identical fixture, documentation and Meson/CI registration.
- Candidate input: `5d832c02c3ed6e1f56ef1b808fe74d8f3ea565ee`.
  The production algorithm is unchanged from prior reviewed `c4d36ecfa3`.
- CI [reference 37038506712](https://github.com/Mainkill1/xemu/actions/runs/37038506712)
  and [candidate 37038440974](https://github.com/Mainkill1/xemu/actions/runs/37038440974)
  both complete successfully. Both Linux release builds pass six ordinary
  and six diagnostic fixture cases.
- Source archives match the exact fixture and production inputs. Clang/LLD
  **21.1.8**, release ThinLTO, x86 version 3 and all **38 corresponding runtime
  libraries** match. All 42 executable/library files are explicitly declared
  as replaceable build inputs before the first run.
- Ordinary executable SHA-256: baseline `{hashes['reference']}`;
  candidate `{hashes['candidate']}`. Diagnostic hashes, full compiler logs
  and every library hash are in the archive.
- Native host: **Steam Deck 10.0.0.123**, HTTP port **9368**, maintained
  runner revision **f5b3e58**. Upload, execution and collection use HTTP.
  This campaign does not use the Windows box or SSH for measurements.

The fixture owns 2 MiB of system RAM mapped at zero; voice data begins above
1 MiB. It enables all three NV2A dirty clients. No renderer clears or consumes
their dirty bitmaps, and no vCPU/TCG code executes. The work therefore has no
Mesa cache or shader compilation. It does not qualify or repair the earlier
game campaign's uncontrolled Mesa cache and input-start failures.

## Correctness and retained tools

All **88 native attempts** exit zero, report completed/passed/complete/eligible,
and have complete artifact collection with zero excluded files. Four TAP
processes pass six cases each. The 72 ordinary timing and 12 diagnostic
processes match checksum **3,686,400,000**, independently expected signed
mixes, the 32-unit signed-24-bit error bound, exactly 45 dispatched and active
voices, independently expected final buffer offsets, and poisoned SGE gaps.
Worker and SRC finalization complete in every process.

The output signal is constant, so equal offsets across voices alone would
miss uniformly dropped changed writes. A read-only review found that gap.
The retained fixture now separately runs a libsamplerate consumption oracle
outside timing; it never reads VP state or invokes the store helper. Dropping
changed stores makes the ordinary fixture abort at offset 0 versus independently
expected 3392 in the local 1,000-frame negative. The repeated negative script
passes. Deliberate monitor silence also aborts. This covers those mutations,
not general sample ordering or concurrent guest writers.

Local policy 3/3, real-memory 1/1, ordinary VP 6/6 and diagnostic VP 6/6 checks
pass. The attempted full local unit build fails in unchanged resampler-test
source because GCC 14 rejects missing `sinf`/`cosf` declarations. That failure
is retained; the full local suite is not claimed green. The initial unadapted
#197 fixture crashed on this branch because it omitted the APU RAM owner;
the adapted fixture initializes that owner. This was a fixture setup failure.
An initial negative-link command found no retained linker response file;
the repeatable script explicitly retains it. An initial format preflight
also failed and was corrected before the matched CI builds. These setup
failures precede native execution and caused no native rerun.

Both executables and their documentation remain in `tests/xbox/mcpx-apu`;
Linux CI builds, verifies and retains them. Twenty-eight saved profile,
worker, build and mode definitions remain installed on the Deck with pinned
revisions. Frozen requests, all launch and host records, paginated server
results, full comparison CSV, negative controls and reusable orchestration
scripts are in [EVIDENCE.tar.gz](EVIDENCE.tar.gz).

Independent verification matches every ordinary raw elapsed value to its
indexed metric and checks equal A/B workload/environment keys in all six
cohorts. The server comparison pools eight A processes, including controls,
against four B processes; the opening table keeps the balanced four/four
medians. Untimed TAP and diagnostic records remain separate.

All 72 timing records are index-eligible. The 16 correctness/count records
deliberately declare no measurement metric and appear as `metrics_missing`
in the performance index. They are not failed timing attempts. The first
verification script incorrectly required metrics for those untimed records;
its assertion failure and corrected reparse are retained. No native attempt
was rerun to correct that verifier. Full server output includes the ineligible
untimed TAP row; all six `validated-vp-frame-time` rows are comparable.

[INDEX.json](INDEX.json) lists every payload hash and large-binary omission.
Archive SHA-256: `{archive_hash}`.

## Earlier evidence and remaining work

The earlier Windows Vulkan PGR2 campaign remains separate: **318.428 to
311.444 core percent**, 2.19% less sampled process CPU, at a 30 FPS cap;
p95/p99 were slightly worse. Its original eight runs and failed/ineligible
attempts remain in the [atomic revision report](../../../evidence/wiki-xiso-per-test/pr-276-issue247/ATOMIC-REVISION.md).
No new Windows game or Deck FPS result is claimed here.

The #247 candidate still needs the complete guest-writer and mapping ordering
contract, sample-order/affected audio validation, reset/save-load coverage,
and the maintained APU XISO fixture with approved references and usable
measurements. The [XISO fixture draft #52](https://github.com/Mainkill1/xemu-perf-tests/pull/52)
has useful affected leaves but remains unqualified for this PR. This synthetic
steady-state workload cannot establish full audio/DSP scheduling, hardware
notifications, audible playback or renderer interference. Keep PR276 draft
and HOLD until those remaining gates are satisfied.
'''
(OUT/'REPORT.md').write_text(report)
print(json.dumps({'archiveBytes':archive.stat().st_size,'sha256':archive_hash,'payloads':len(entries),'omissions':len(omissions)}))

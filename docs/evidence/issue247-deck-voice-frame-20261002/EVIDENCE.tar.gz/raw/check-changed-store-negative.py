"""Rebuild a separate mutated helper and require the normal VP oracle to fail.

Use only outside performance collection. Production source contents and
production object files are preserved. Build response files are retained by
relinking the fixture after updating its source timestamp.
"""
from pathlib import Path
import argparse
import json
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store'))
parser.add_argument('--build', default='build-voice-frame')
parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent / 'repeatable-negative')
args = parser.parse_args()
build = args.repo / args.build
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
source = args.repo / 'hw/xbox/mcpx/apu/vp/voice-store.c'
original = source.read_text()
store = 'stl_le_phys(as, address, new_value);'
assert original.count(store) == 1
mutation = out / 'drop-changed-store.c'
mutation.write_text(original.replace(store, '/* Test mutation: omit required changed store. */'))
commands = json.loads((build / 'compile_commands.json').read_text())
command = next(r for r in commands if r['file'].endswith('/voice-store.c'))
argv = shlex.split(command['command'])
argv[argv.index('-c') + 1] = str(mutation)
argv[argv.index('-o') + 1] = str(out / 'drop-changed-store.o')
argv[argv.index('-MF') + 1] = str(out / 'drop-changed-store.d')
target = 'test-xbox-mcpx-apu-voice-frame'
with (out / 'build.log').open('w') as log:
    subprocess.run(argv, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)
    (args.repo / 'tests/xbox/mcpx-apu/test-voice-frame.c').touch()
    subprocess.run(['ninja', '-d', 'keeprsp', '-C', str(build), target], stdout=log, stderr=subprocess.STDOUT, check=True)
    link = shlex.split(subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', target], text=True).splitlines()[-1])
    response = next(x for x in link if x.startswith('@'))
    rsp = shlex.split((build / response[1:]).read_text())
    index = [i for i, value in enumerate(rsp) if value.endswith('hw_xbox_mcpx_apu_vp_voice-store.c.o')]
    assert len(index) == 1
    rsp[index[0]] = str(out / 'drop-changed-store.o')
    rsp[rsp.index('-o') + 1] = str(out / 'negative-voice-frame')
    link = [x for x in link if x != response] + rsp
    subprocess.run(link, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)
result = subprocess.run([str(out / 'negative-voice-frame'), '--benchmark', 'mono-adpcm', '1000', '8'], capture_output=True, text=True)
text = result.stdout + result.stderr
(out / 'output.log').write_text(text)
(out / 'receipt.json').write_text(json.dumps({'exitCode': result.returncode, 'mutation': 'omit changed physical stores', 'ordinaryFixture': True}, indent=2) + '\n')
assert result.returncode != 0 and 'expected_cbo' in text
assert source.read_text() == original
print(json.dumps({'negativeExitCode': result.returncode, 'ordinaryOffsetOracleRejectedMutation': True}))

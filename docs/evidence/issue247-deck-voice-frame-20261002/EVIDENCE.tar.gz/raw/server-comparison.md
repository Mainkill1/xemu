A 7adfaf350bf0 -> B ad727eb78880 | partial
Attempts 49/25; blocked 2. Reference: explicit A.

### issue247-vp-stereo-adpcm-w8-candidate-timing-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 6838362.50 | 6651581.50 | 6836364.63 [6807593.00,6858934.00] | 6652637.00 [6626219.00,6681166.00] | 8/4 | improved | +2.73% |

### issue247-vp-ordinary-candidate-tap-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| (none) () | N/A | N/A | N/A | N/A | 1/1 | ineligible | N/A |

### issue247-vp-mono-adpcm-w1-candidate-timing-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 5592376.00 | 5379433.50 | 5604967.25 [5567544.00,5656533.00] | 5378212.75 [5351891.00,5402093.00] | 8/4 | improved | +3.81% |

### issue247-vp-mono-pcm-w8-candidate-timing-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 6399211.50 | 6224968.00 | 6393510.25 [6348195.00,6434930.00] | 6232303.25 [6200086.00,6279191.00] | 8/4 | improved | +2.72% |

### issue247-vp-stereo-adpcm-w1-candidate-timing-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 6596188.50 | 6407072.50 | 6604805.75 [6562600.00,6660375.00] | 6410248.00 [6391955.00,6434892.00] | 8/4 | improved | +2.87% |

### issue247-vp-mono-adpcm-w8-candidate-timing-v1 / Reported workload metrics / a8f8f3c63269
| Metric | A median | B median | A mean [min,max] | B mean [min,max] | n A/B | Result | Improvement % |
|---|---:|---:|---:|---:|---:|---|---:|
| validated-vp-frame-time (us) | 5835206.50 | 5651250.50 | 5839605.38 [5808045.00,5873806.00] | 5652370.00 [5626144.00,5680835.00] | 8/4 | improved | +3.15% |
1 additional rows omitted; use comparison CSV.
Improvement: positive is better; lower=(A-B)/A, higher=(B-A)/A. Medians and distributions are across attempts, not pooled guest samples. Descriptive, not a significance test.

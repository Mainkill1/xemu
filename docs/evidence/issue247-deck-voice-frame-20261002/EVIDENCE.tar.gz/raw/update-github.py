"""Update canonical xemu PR/issue descriptions, then verify exact readback."""
from pathlib import Path
import json
import subprocess

RAW = Path(__file__).resolve().parent
REPO = Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store')
summary = json.loads((RAW/'VERIFIED-SUMMARY.json').read_text())
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
evidence = f'https://github.com/Mainkill1/xemu/blob/{head}/docs/evidence/issue247-deck-voice-frame-20261002'
old = 'https://github.com/Mainkill1/xemu/blob/c4d36ecfa3111b60744225e966c0d12bc44cf007/evidence/wiki-xiso-per-test/pr-276-issue247'
names = {'mono-adpcm':'Mono ADPCM','stereo-adpcm':'Stereo ADPCM','mono-pcm':'Mono PCM'}
table = ['| Voice format | Worker threads | Baseline s | Candidate s | Saved s | Improvement % |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
for r in summary['results']:
    table.append(f"| {names[r['profile']]} | {r['workers']} | {r['baseline_us']/1e6:.6f} | {r['candidate_us']/1e6:.6f} | {r['saved_us']/1e6:+.6f} | {r['improvement_percent']:+.2f}% |")
low = min(r['improvement_percent'] for r in summary['results'])
high = max(r['improvement_percent'] for r in summary['results'])
body = f'''## Recommendation: HOLD

**Summary:** Roughly 88% of sampled APU voice-state stores in #270 wrote unchanged words. This branch validates equal, aligned direct-RAM words with a same-value atomic compare-exchange and preserves the original physical-store fallback. Matched Deck median improvements span **{low:+.2f}% to {high:+.2f}%** for fixed production VP work, with separate diagnostics proving which physical-store calls disappeared. Keep this draft: guest-writer ordering, affected audio and reset/save-load qualification remain incomplete.
**Remaining:** Establish the complete guest-writer/mapping ordering contract; qualify sample ordering, affected audio and reset/save-load; run the maintained affected APU XISO leaves with approved references and usable measurements; qualify any further game comparison's start procedure and Mesa cache state.

**Quick comparison:** seconds for 20,000 frames of 45 voices, including output checks. Medians use four baseline and four candidate processes in ABBA/BAAB. Positive Improvement % means less time. Worker threads are actual VP workers; these are not game FPS measurements.

{chr(10).join(table)}

### Problem

`voice_set_mask()` physically stores every voice-state read/modify/write, including unchanged values. #270 observed 88.19–88.23% unchanged stores in three Windows PGR2 runs and 88.62% in one admitted Deck run. These observations identify work exposure; performance must be measured separately.

### What this PR changes

- `vp.c` calls the production helper in `voice-store.c`. Equality admission in `voice-store.h` requires a whole aligned word in the configured Xbox RAM range. The helper resolves the writable mapping under RCU, checks the RAM owner and direct access, then compares/exchanges the expected little-endian word with itself. A changed word, failed validation, Xen or unsupported mapping uses the original physical store. No shadow cache or APU scheduling change is added.
- Policy tests and the actual QEMU `AddressSpace` test cover direct RAM, dirty logging, whole/partial MMIO overlays and a synchronized writer changing RAM between the APU read and validation. That test covers a defined interleaving, not every concurrent guest-writer case.
- Retained `tests/xbox/mcpx-apu/test-voice-frame.c` and `VOICE-FRAME.md` drive actual VP dispatch, decoding, libsamplerate and mixing with 45 voices. They initialize the real system-RAM owner and NV2A dirty clients, use independently expected mixes and offsets, and cover mono ADPCM, stereo ADPCM and mono PCM with one/eight worker threads.
- Meson and Linux CI build, test and retain an ordinary timing executable and a separate `-stores` diagnostic. The ordinary executable has no store-count probe. The diagnostic forwards every physical store and aggregates counters per voice after production dispatch completes.
- [Deck report]({evidence}/REPORT.md), [full evidence archive]({evidence}/EVIDENCE.tar.gz) and [payload index]({evidence}/INDEX.json) retain all native attempts, source/build/library identities, comparisons, failed local setup checks and repeatable qualification scripts. Results belong to this xemu PR.

### Why this approach

The existing physical read supplies the expected word. Resolving the `MemoryRegion` and checking direct access exclude overlays and special RAM. A sequentially consistent same-value compare-exchange validates the word; the original physical store executes if a writer changed it before validation. Equal RAM contents do not need content dirty marking. The CAS still performs a host atomic operation, so these updates are not free.

QEMU guest direct writes can use ordinary RAM accesses. The synchronized-writer test and CAS do not establish a complete cross-writer ordering contract. That proof remains required. The approach was informed by [izzy2lost's prototype](https://github.com/izzy2lost/xemu/commit/a7765290d17750e10a2bfc2d94cd85279f3b591e); this branch adds resolved-mapping guards and atomic validation.

### Validation

- Measured original production: `ee5ce48b48784f999af374c1452003f8b2b1230f`; identical reference fixture: `dd1a8f48690803975d9e97b8e1139dcc4164fc83`; candidate input: `5d832c02c3ed6e1f56ef1b808fe74d8f3ea565ee`. The production algorithm is unchanged from reviewed `c4d36ecfa3`; this publication adds evidence. The #197 reader optimization is in neither build.
- [Reference CI](https://github.com/Mainkill1/xemu/actions/runs/37038506712) and [candidate CI](https://github.com/Mainkill1/xemu/actions/runs/37038440974) succeed. Clang/LLD 21.1.8, release ThinLTO, x86 version 3 and all 38 corresponding libraries match. Both release builds pass six ordinary and six diagnostic VP cases. CI for the evidence publication follows separately.
- **Steam Deck 10.0.0.123**, maintained HTTP runner `f5b3e58`: four six-case correctness processes, twelve diagnostic processes and **72 ordinary timing processes** all exit zero with complete collection and completed/passed/complete/eligible outcomes. All 72 timing records are index-eligible; the 16 correctness/count records intentionally declare no metric and are excluded from performance comparisons. All 42 build slots are declared before execution; independently verified A/B workload and environment keys match in every timing cohort. No Windows or SSH measurements are used in this new campaign.
- Each workload runs four baseline A/A controls, then physical **ABBA and BAAB**, with 20,000 frames of 45 voices and 32 samples per voice per frame. Timed output checks and final independent offset checks pass. Diagnostics preserve **900,000 changed physical stores** and remove **4,500,000 unchanged physical stores** in every row. Diagnostic times are retained as diagnostic-only, not performance evidence.
- Local checks: policy 3/3, real-memory 1/1, ordinary VP 6/6 and diagnostic VP 6/6 pass. The review's common-offset oracle gap was corrected using a separate SRC consumption oracle outside timing. Omitting changed stores aborts the ordinary fixture; deliberate monitor silence also aborts. The repeatable negative tool is retained.
- Full local unit build remains failed in unchanged resampler-test source: GCC 14 rejects missing `sinf`/`cosf` declarations. That attempt is preserved; the full local suite is not claimed green.
- The earlier Windows atomic PGR2 campaign tested `d3ccb5420c`, with the same production algorithm and different retained build identity. Eight balanced Vulkan runs completed at a 30 FPS cap. Earlier diagnostic-transfer and disk-full attempts remain excluded and recorded in the [atomic revision evidence]({old}/ATOMIC-REVISION.md).
- The earlier Deck PGR2 A/B/B attempts were comparison-ineligible due uncontrolled Mesa cache; the next baseline tested Event Select rather than the race start and failed correctness. [Runner issue81](https://github.com/Mainkill1/Xemu-Test-Runner/issues/81) preserves that input failure. This headless VP campaign does not qualify those game attempts or resolve their Mesa cache gate.

### Results

**New Deck production VP workload:** host seconds for the entire fixed batch, including identical output validation. The opening medians use four baseline and four candidate processes from ABBA/BAAB; A/A controls are separate. Positive Improvement % means less time: `100*(baseline-candidate)/baseline`. Worker threads are actual VP workers. All three formats exercise the store helper; PCM is an affected format control.

The [report]({evidence}/REPORT.md) shows A/A spreads, each order and all adjacent pairs. No repetition was dropped. CPU affinity and power policy were not pinned, and this small campaign supplies no confidence interval. These are synthetic production-processing results, not FPS, full DSP scheduling or audible playback.

**Earlier Windows PGR2 result, separate workload and build:** sampled process CPU **318.428 to 311.444 core %**, **2.19% lower**, while guest cadence stays capped at 30 FPS. Average frame time stays 33.333 ms; p95 **33.597 to 33.651 ms** and p99 **33.977 to 34.097 ms** worsen slightly. Mean per-run maximum falls **34.500 to 34.338 ms**. Original raw values and all eight runs remain in the atomic revision report; no Windows values are pooled with the Deck workload. The pre-review 1.98% CPU observation is historical and remains separate.

### Risks and remaining questions

Full guest-writer/mapping ordering, observers beyond tested dirty logging, sample ordering, reset/save-load and audible affected audio remain unqualified. The new fixture has enabled NV2A dirty clients but no renderer consuming their bitmaps and no vCPU/TCG execution. The constant signal checks the demonstrated mutations but does not prove arbitrary sample ordering. A successful synthetic workload cannot replace game or hardware correctness.

The maintained [APU XISO fixture draft52](https://github.com/Mainkill1/xemu-perf-tests/pull/52) has five affected audio leaves, but references and timer-paced measurement qualification remain incomplete; it has not qualified this candidate. Further game comparisons still need controlled Mesa cache and consumed start inputs. Keep this PR draft and HOLD until these bounded gates close.

### Related work

Addresses #247. #270 provided opt-in attribution and is closed without merge. #197's reader optimization and its separate measurements are not combined here. #200 studied VP worker count. [Runner draft89](https://github.com/Mainkill1/Xemu-Test-Runner/pull/89) retains the standalone process capability used by this campaign; its repo contains tooling, not these xemu results.

> **Agent Declaration**: This pull request was created with assistance from Codex.
'''
issue = json.loads((RAW/'issue-before.json').read_text())['body']
original_scope = issue.split('\n---\n',1)[1].lstrip()
issue = f'''**Current status: HOLD / draft PR276.** Attribution-only PR270 closed without merge after measuring roughly 88% unchanged voice-state stores. The RAM equal-store candidate now has matched production VP evidence on **Steam Deck 10.0.0.123**, with median improvements spanning **{low:+.2f}% to {high:+.2f}%**. Guest-writer ordering, affected audio and lifecycle qualification remain open.

## Steam Deck production VP qualification

Draft [PR276](https://github.com/Mainkill1/xemu/pull/276) now carries the retained production VP fixture and matched **Deck 10.0.0.123 ABBA/BAAB** evidence. The existing equal-RAM-store algorithm is unchanged. All 88 native attempts pass their independent output/offset checks and have complete collection; twelve separate diagnostics reduce physical-store calls from 5,400,000 to 900,000 while preserving every changed store.

Host elapsed seconds for 20,000 frames of 45 voices, including output validation; four original and four candidate processes from balanced orders. Positive Improvement % means less time. One/eight means actual VP worker threads; all formats are affected.

{chr(10).join(table)}

[Report with controls and order variation]({evidence}/REPORT.md), [raw packet]({evidence}/EVIDENCE.tar.gz). These results extend earlier roughly 88% unchanged-store attribution and the separate capped Windows 2.19% CPU observation. They do not establish game FPS, guest ordering or audible parity. The #197 reader patch is in neither build. **HOLD:** complete writer/mapping contract, affected audio/sample ordering, reset/save-load and qualified APU XISO evidence remain required. Earlier failed/cache-ineligible game attempts are preserved.

---

{original_scope}
'''
for kind, number, text in (('pulls',276,body),('issues',247,issue)):
    request = RAW/f'{kind}-final-request.json'
    request.write_text(json.dumps({'body':text})+'\n')
    (RAW/f'{kind}-final-body.md').write_text(text)
    endpoint = f'repos/Mainkill1/xemu/{kind}/{number}'
    with (RAW/f'{kind}-final-response.json').open('w') as stream:
        subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(request)],stdout=stream,check=True)
    current = json.loads(subprocess.check_output(['gh','api',endpoint],text=True))
    assert current['body'] == text
    assert current['state'] == 'open'
    if kind == 'pulls':
        assert current['draft'] is True and current['head']['sha'] == head
    (RAW/f'{kind}-final-readback.json').write_text(json.dumps(current,indent=2)+'\n')
    print('Verified canonical',kind,number,head)

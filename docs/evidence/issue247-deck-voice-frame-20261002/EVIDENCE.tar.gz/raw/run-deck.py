"""Retained #247 campaign, native execution and collection via Deck HTTP only.

Upload assets without execution, then save every definition with all native
build slots before any attempt. Resume observes the existing job; it never
reruns a failed or unfinished attempt under another identity.
"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import shutil
import sys
import urllib.parse

ROOT = Path('/home/codex/src/steamdeck-xemu')
OUT = Path(__file__).resolve().parent
NATIVE = OUT / 'deck-native'
PACKAGE = NATIVE / 'package'
FRAMES = 20000
PRIMARY = 'test-xbox-mcpx-apu-voice-frame'
DIAGNOSTIC = PRIMARY + '-stores'
sys.path.insert(0, str(ROOT / 'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_tests import upload_application
from runner_wait import execute as completion_wait

api = RunnerApi('http://10.0.0.123:9368')
work = Workflows(api)

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

identity = json.loads((OUT / 'matched-build-qualification.json').read_text())
assert identity['qualified'] is True
files = []
for item in identity['files']:
    source = Path(item['source'])
    assert sha(source) == item['sha256']
    dest = PACKAGE / item['path']
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    if '/test-xbox-' in item['path']:
        dest.chmod(0o755)
    files.append({k: item[k] for k in ('path', 'bytes', 'sha256')})
assert len(files) == 42
save(NATIVE / 'payload-manifest.json', {'files': files, 'qualification': identity})
schedule = []
for variant in ('reference', 'candidate'):
    for target in ('ordinary', 'diagnostic'):
        schedule.append({'label': variant + '-' + target + '-correctness',
                         'variant': variant, 'kind': 'tap', 'target': target})
for workers in (1, 8):
    for profile in ('mono-adpcm', 'stereo-adpcm', 'mono-pcm'):
        for variant in ('reference', 'candidate'):
            schedule.append({'label': f'{profile}-w{workers}-{variant}-counts',
                             'variant': variant, 'kind': 'counts', 'target': 'diagnostic',
                             'workers': workers, 'profile': profile})
for workers in (1, 8):
    for profile in ('mono-adpcm', 'stereo-adpcm', 'mono-pcm'):
        for phase, order in (('aaaa', 'AAAA'), ('abba', 'ABBA'), ('baab', 'BAAB')):
            for ordinal, letter in enumerate(order, 1):
                schedule.append({'label': f'{profile}-w{workers}-{phase}-{ordinal}-{letter.lower()}',
                                 'variant': 'reference' if letter == 'A' else 'candidate',
                                 'kind': 'timing', 'target': 'ordinary',
                                 'workers': workers, 'profile': profile,
                                 'phase': phase, 'ordinal': ordinal})
plan = {'host': '10.0.0.123', 'runner': 'f5b3e58', 'frames': FRAMES, 'voices': 45,
        'warmupFrames': 256, 'timedValidationIncluded': True, 'order': schedule,
        'provenance': 'pinned saved configurations with all 42 native build slots before execution',
        'interventions': 'none; no power/affinity change, renderer or Mesa; fresh process per attempt'}
if (NATIVE / 'matrix-plan.json').exists():
    assert json.loads((NATIVE / 'matrix-plan.json').read_text()) == plan
else:
    status = api.json('/api/v1/status')
    assert status['Phase'] == 'idle' and status['CurrentJob'] is None
    assert status['Queue']['Pending'] == status['Queue']['Testing'] == 0
    save(NATIVE / 'preflight.json', status)
    save(NATIVE / 'matrix-plan.json', plan)

assets = 'issue247-vp-build-assets-20261002'
if not (NATIVE / 'assets-uploaded.json').exists():
    actual = upload_application(api, PACKAGE, 'reference/' + PRIMARY, assets)
    assert actual == next(f['sha256'] for f in files if f['path'] == 'reference/' + PRIMARY)
    save(NATIVE / 'assets-uploaded.json', {'id': assets, 'sha256': actual, 'state': work.status(assets)})

base = json.loads((ROOT / 'artifacts/issue197-sample-memory/remaining-gates/memory-lifetime/deck-native/candidate/definition.json').read_text())
base['TimeoutSeconds'] = 180
base['Experiment']['Id'] = 'issue247-production-voice-frame-20261002'
base['RequiredFiles'] = [f['path'] for f in files]

def test_name(item):
    stem = 'issue247-vp-'
    if item['kind'] == 'tap':
        return stem + item['target'] + '-' + item['variant'] + '-tap-v1'
    return stem + item['profile'] + '-w' + str(item['workers']) + '-' + item['variant'] + '-' + item['kind'] + '-v1'

tests = {}
for item in schedule:
    test = test_name(item)
    if test in tests:
        continue
    job = json.loads(json.dumps(base))
    job['Id'] = test
    job['Executable'] = item['variant'] + '/' + (PRIMARY if item['target'] == 'ordinary' else DIAGNOSTIC)
    job['ExpectedExecutableSha256'] = next(f['sha256'] for f in files if f['path'] == job['Executable'])
    job['Experiment']['Variant'] = item['variant']
    if item['kind'] == 'tap':
        job['Arguments'] = ['--tap']
        job['Workload'] = {'CorrectnessChecks': [
            {'Name': 'six-case-plan', 'Path': 'stdout.log', 'ContainsText': '1..6'},
            {'Name': 'last-case', 'Path': 'stdout.log', 'ContainsText': 'ok 6 /mcpx-apu/voice-frame/mono-pcm-worker8'}],
            'EvidenceRequirements': [{'Name': 'full-TAP', 'Path': 'stdout.log', 'MinimumBytes': 200}]}
    else:
        job['Arguments'] = ['--benchmark', item['profile'], str(FRAMES), str(item['workers'])]
        job['Workload'] = {'CorrectnessChecks': [
            {'Name': 'fixed-checksum', 'Path': 'stdout.log', 'ContainsText': f'"checksum":{FRAMES*184320},"expected_checksum":{FRAMES*184320}'},
            {'Name': 'oracle-pass', 'Path': 'stdout.log', 'ContainsText': '"correctness":"PASS"'}],
            'EvidenceRequirements': [{'Name': 'fixed-work-output', 'Path': 'stdout.log', 'MinimumBytes': 200}]}
        if item['kind'] == 'timing':
            job['Workload']['ReportedMetrics'] = [{'Name': 'validated-vp-frame-time', 'Path': 'stdout.log', 'JsonProperty': 'elapsed_us', 'Unit': 'us', 'Direction': 'lower'}]
        else:
            job['Workload']['CorrectnessChecks'].append({'Name': 'counts-only', 'Path': 'stdout.log', 'ContainsText': '"timing_contract":"diagnostic-only"'})
    request = {'sourceJobId': assets, 'job': job,
               'description': 'Actual 45-voice VP work; independent mix and offset oracles. Timings include output checks; counts separate. No game/FPS, DSP or audible claim.',
               'buildFiles': [f['path'] for f in files]}
    folder = NATIVE / 'saved-tests'
    marker = folder / (test + '-request.json')
    receipt = folder / (test + '.json')
    if receipt.exists():
        assert json.loads(marker.read_text()) == request
        tests[test] = json.loads(receipt.read_text())
    else:
        save(marker, request)
        tests[test] = api.json('/api/v1/test-configs/' + urllib.parse.quote(test, safe=''), 'POST', request)
        save(receipt, tests[test])
    assert tests[test]['buildFileCount'] == 42

rows, correctness = [], []
for item in schedule:
    test = test_name(item)
    job = 'issue247-vp-' + item['label'] + '-20261002'
    folder = NATIVE / item['label']
    marker = folder / 'submission.json'
    request = {'testId': test, 'revision': tests[test]['revision'], 'jobId': job}
    if marker.exists():
        assert json.loads(marker.read_text()) == request
        assert work.status(job)['state'] in ('testing', 'tested', 'queued'), 'Observe the same handle before resuming.'
    else:
        save(marker, request)
        save(folder / 'submit.json', work.run_test(test, tests[test]['revision'], job, None, {}, 8*1024*1024))
    wait = completion_wait(api, SimpleNamespace(id=job, job=True, updates=False))
    save(folder / 'wait.json', wait)
    result = work.result(job)
    save(folder / 'result-summary.json', result)
    collection = work.collect(job, folder / 'collected', None, True)
    save(folder / 'collection.json', collection)
    assert wait['terminal'] and collection['complete'] and collection['excluded'] == 0
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}, result
    run = folder / 'collected' / result['runId']
    assert json.loads((run / 'result.json').read_text())['exitCode'] == 0
    assert (run / 'stderr.log').stat().st_size == 0
    text = (run / 'stdout.log').read_text()
    if item['kind'] == 'tap':
        assert '1..6' in text and sum(line.startswith('ok ') for line in text.splitlines()) == 6
        assert not any(line.startswith('not ok') for line in text.splitlines())
        correctness.append({**item, 'runId': result['runId'], 'passed': 6})
        save(NATIVE / 'correctness-summary.json', correctness)
    else:
        raw = json.loads(text)
        assert raw['profile'] == item['profile'] and raw['workers'] == item['workers']
        assert raw['frames'] == FRAMES and raw['voices'] == 45 and raw['warmup_frames'] == 256
        assert raw['checksum'] == raw['expected_checksum'] == FRAMES*184320
        assert raw['final_cbo'] == raw['expected_cbo']
        assert 0 <= raw['maximum_error_24bit_units'] <= 32 and raw['elapsed_us'] > 0
        if item['kind'] == 'counts':
            assert raw['timing_contract'] == 'diagnostic-only'
            assert raw['diagnostic_physical_stores'] > 0
        else:
            assert not any(key.startswith('diagnostic_') for key in raw)
        rows.append({**item, **raw, 'jobId': job, 'runId': result['runId']})
        save(NATIVE / 'observations.json', rows)
    print(json.dumps({'label': item['label'], 'runId': result['runId'], 'elapsed_us': raw['elapsed_us'] if item['kind'] != 'tap' else None}), flush=True)
status = api.json('/api/v1/status')
save(NATIVE / 'post-status.json', status)
assert status['Phase'] == 'idle' and status['CurrentJob'] is None
print('COMPLETE', len(rows) + len(correctness), flush=True)

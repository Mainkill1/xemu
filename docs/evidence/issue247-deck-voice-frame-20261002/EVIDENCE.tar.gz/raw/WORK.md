# Issue 247 Deck qualification scope

Evaluate the existing equal-RAM-store candidate without changing its production algorithm or combining the issue 197 reader optimization.

Retain the production VP fixture with 2 MiB of system RAM at physical zero, the actual APU RAM owner, voice data above 1 MiB, and all three NV2A dirty clients. Keep physical-store counting in a separate diagnostic executable. Qualify output and independently expected buffer progress, with silence and dropped-changed-store negative controls.

Match fixed original production ee5ce48 with reference fixture dd1a8f4 and candidate fixture 5d832c0; the candidate production helper remains identical to c4d36ec. Bind exact source, compiler options and all libraries before native work. Execute through the maintained HTTP runner on Steam Deck 10.0.0.123. Save every build slot before four original A/A controls, physical ABBA and BAAB.

Publish all attempts and a readable baseline/candidate/time-saved table in the owning xemu PR276. No game FPS, audio, full guest-ordering or lifecycle readiness follows from this steady-state workload. Keep missing gates and prior game failures visible.

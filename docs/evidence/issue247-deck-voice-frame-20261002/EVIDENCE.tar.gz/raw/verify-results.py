"""Independently reparse native records and verify canonical comparisons."""
from pathlib import Path
import csv
import json
import statistics

OUT = Path(__file__).resolve().parent
NATIVE = OUT / 'deck-native'
plan = json.loads((NATIVE / 'matrix-plan.json').read_text())
identity = json.loads((OUT / 'matched-build-qualification.json').read_text())
indexed = {}
for variant in ('reference', 'candidate'):
    for target in ('ordinary', 'diagnostic'):
        data = json.loads((OUT / f'server-{variant}-{target}-runs.json').read_text())
        indexed.update({r['runId']: r for r in data['items']})
with (OUT / 'server-comparison.csv').open(newline='') as stream:
    server = list(csv.DictReader(stream))
rows, attempts = [], []
for item in plan['order']:
    folder = NATIVE / item['label']
    result = json.loads((folder / 'result-summary.json').read_text())
    collection = json.loads((folder / 'collection.json').read_text())
    assert result['outcome'] == {'execution': 'completed', 'correctness': 'passed', 'evidence': 'complete', 'comparison': 'eligible'}
    assert collection['complete'] and collection['excluded'] == 0
    run = folder / 'collected' / result['runId']
    job = json.loads((run / 'job.json').read_text())
    submission = json.loads((folder / 'submission.json').read_text())
    assert job['Id'] == submission['jobId']
    exe = next(f for f in identity['files'] if f['path'] == job['Executable'])
    assert job['ExpectedExecutableSha256'] == exe['sha256']
    assert json.loads((run / 'result.json').read_text())['exitCode'] == 0
    assert (run / 'stderr.log').stat().st_size == 0
    text = (run / 'stdout.log').read_text()
    index = indexed[result['runId']]
    assert index['sha256'] == exe['sha256']
    if item['kind'] == 'timing':
        assert index['eligible'] and not index['issues']
    else:
        # Correctness and count runs deliberately publish no timing metric.
        assert not index['eligible'] and index['issues'] == ['metrics_missing']
        assert not index['metrics']
    if item['kind'] == 'tap':
        assert '1..6' in text and sum(line.startswith('ok ') for line in text.splitlines()) == 6
        assert not any(line.startswith('not ok') for line in text.splitlines())
    else:
        raw = json.loads(text)
        assert raw['profile'] == item['profile'] and raw['workers'] == item['workers']
        assert raw['frames'] == plan['frames'] and raw['voices'] == 45
        assert raw['warmup_frames'] == 256 and raw['samples_per_voice_frame'] == 32
        assert raw['checksum'] == raw['expected_checksum'] == plan['frames'] * 184320
        assert raw['final_cbo'] == raw['expected_cbo']
        assert raw['correctness'] == 'PASS' and 0 <= raw['maximum_error_24bit_units'] <= 32
        assert raw['elapsed_us'] > 0
        if item['kind'] == 'timing':
            assert not any(k.startswith('diagnostic_') for k in raw)
            metric = next(m for m in index['metrics'] if m['name'] == 'validated-vp-frame-time')
            assert metric['value'] == raw['elapsed_us'] and metric['unit'] == 'us' and metric['direction'] == 'lower'
        else:
            assert raw['timing_contract'] == 'diagnostic-only' and not index['metrics']
        rows.append({**item, **raw, 'jobId': job['Id'], 'runId': result['runId']})
    attempts.append({'label': item['label'], 'runId': result['runId'], 'kind': item['kind'],
                     'fileCount': collection['fileCount'], 'outcome': result['outcome']})
assert len(attempts) == 88 and len(rows) == 84
observations = json.loads((NATIVE / 'observations.json').read_text())
assert rows == observations

def improvement(a, b):
    return 100 * (a - b) / a

def spread(values):
    return 100 * (max(values) - min(values)) / statistics.median(values)

results, counts = [], []
for workers in (1, 8):
    for profile in ('mono-adpcm', 'stereo-adpcm', 'mono-pcm'):
        group = [r for r in rows if r['profile'] == profile and r['workers'] == workers and r['kind'] == 'timing']
        assert len(group) == 12
        assert len({indexed[r['runId']]['testKey'] for r in group}) == 1
        assert len({indexed[r['runId']]['environmentKey'] for r in group}) == 1
        for variant in ('reference', 'candidate'):
            assert len({indexed[r['runId']]['buildKey'] for r in group if r['variant'] == variant}) == 1
        key = indexed[group[0]['runId']]['testKey'][:12]
        context = indexed[group[0]['runId']]['environmentKey'][:12]
        match = [r for r in server if r['test_key'] == key and r['context'] == context and r['metric'] == 'validated-vp-frame-time']
        assert len(match) == 1 and match[0]['improvement_percent'], match
        sr = match[0]
        assert int(sr['n_a']) == 8 and int(sr['n_b']) == 4
        assert float(sr['a']) == statistics.median(r['elapsed_us'] for r in group if r['variant'] == 'reference')
        assert float(sr['b']) == statistics.median(r['elapsed_us'] for r in group if r['variant'] == 'candidate')
        control = [r['elapsed_us'] for r in group if r['phase'] == 'aaaa']
        balanced = [r for r in group if r['phase'] != 'aaaa']
        a = [r['elapsed_us'] for r in balanced if r['variant'] == 'reference']
        b = [r['elapsed_us'] for r in balanced if r['variant'] == 'candidate']
        assert len(a) == len(b) == len(control) == 4
        assert len({r['final_cbo'] for r in group}) == 1
        ma, mb = statistics.median(a), statistics.median(b)
        orders, pairs = {}, []
        for phase in ('abba', 'baab'):
            ordered = [r for r in group if r['phase'] == phase]
            pa = statistics.median(r['elapsed_us'] for r in ordered if r['variant'] == 'reference')
            pb = statistics.median(r['elapsed_us'] for r in ordered if r['variant'] == 'candidate')
            orders[phase] = improvement(pa, pb)
            for chunk in (ordered[:2], ordered[2:]):
                ra = next(r['elapsed_us'] for r in chunk if r['variant'] == 'reference')
                rb = next(r['elapsed_us'] for r in chunk if r['variant'] == 'candidate')
                pairs.append(improvement(ra, rb))
        results.append({'profile': profile, 'workers': workers, 'baseline_us': ma, 'candidate_us': mb,
                        'saved_us': ma-mb, 'improvement_percent': improvement(ma,mb),
                        'baselineRange_us': [min(a),max(a)], 'candidateRange_us': [min(b),max(b)],
                        'originalControlRange_us': [min(control),max(control)], 'originalControlSpread_percent': spread(control),
                        'balancedOriginalSpread_percent': spread(a), 'balancedCandidateSpread_percent': spread(b),
                        'orders': orders, 'adjacentPairs_percent': pairs, 'allPairsBetter': min(pairs)>0,
                        'serverIncludingControls': sr, 'correctness': 'PASS'})
        diagnostic = [r for r in rows if r['profile'] == profile and r['workers'] == workers and r['kind'] == 'counts']
        assert len(diagnostic) == 2
        ca = next(r for r in diagnostic if r['variant'] == 'reference')
        cb = next(r for r in diagnostic if r['variant'] == 'candidate')
        assert ca['final_cbo'] == cb['final_cbo']
        assert cb['diagnostic_unchanged_physical_stores'] == 0
        assert ca['diagnostic_physical_stores'] - ca['diagnostic_unchanged_physical_stores'] == cb['diagnostic_physical_stores'] == 45*plan['frames']
        counts.append({'profile':profile,'workers':workers,'original_physical_stores':ca['diagnostic_physical_stores'],
                       'candidate_physical_stores':cb['diagnostic_physical_stores'],
                       'removed_unchanged_physical_stores':ca['diagnostic_unchanged_physical_stores'],
                       'candidate_unchanged_physical_stores':0,'timing_contract':'diagnostic-only / NOT COMPARABLE'})
summary = {'scope':'Fixed production VP work including output validation; all three formats affected. No game FPS, DSP, audible playback or concurrent guest proof.',
           'formula':'100*(median original_us-median candidate_us)/median original_us; positive is better',
           'results':results,'counts':counts,'attempts':attempts,'timingProcesses':72,'diagnosticProcesses':12,'correctnessProcesses':4,
           'completeCollection':True,'excludedFiles':0,'allExitZero':True,'canonicalCohortKeysMatch':True,
           'eligibleIndexedTimingProcesses':72,'untimedIndexedRecords':16,'untimedIndexReason':'intentional metrics_missing; no timing metric declared',
           'controlledHostPowerOrAffinity':False,
           'recommendation':'HOLD: native fixed-work performance is separate from remaining guest ordering, audio, lifecycle and XISO qualification.'}
(OUT/'VERIFIED-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'results':results,'counts':counts},indent=2))

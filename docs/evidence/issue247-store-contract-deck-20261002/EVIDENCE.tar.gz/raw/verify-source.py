"""Bind new contract checks and unchanged measurements to the tested source."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/home/codex/src/steamdeck-xemu')
OUT=Path(__file__).resolve().parent
REPO=ROOT/'worktrees/issue247-equal-store'
MEASURED='5d832c02c3ed6e1f56ef1b808fe74d8f3ea565ee'
paths=['tests/xbox/mcpx-apu/test-voice-frame.c','hw/xbox/mcpx/apu/vp/voice-store.c','hw/xbox/mcpx/apu/vp/voice-store.h','hw/xbox/mcpx/apu/vp/vp.c']
assert subprocess.check_output(['git','diff',MEASURED,'--','hw'],cwd=REPO)==b''
checks={}
for name in paths:
    data=(REPO/name).read_bytes()
    assert data==subprocess.check_output(['git','show',MEASURED+':'+name],cwd=REPO),name
    checks[name]=hashlib.sha256(data).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
receipt={'head':head,'measuredCandidate':MEASURED,'entireHardwareTreeUnchanged':True,'ordinaryAndDiagnosticFixtureUnchanged':True,'sha256':checks,'scope':'Earlier matched Deck VP performance applies through verified source equivalence. This added integration fixture provides correctness coverage, not a new timing result.'}
(OUT/'source-equivalence.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))

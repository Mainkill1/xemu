## Recommendation: HOLD

**Summary:** Roughly 88% of sampled APU voice-state stores in #270 wrote unchanged words. This branch validates equal, aligned direct-RAM words with a same-value atomic compare-exchange and preserves the original physical-store fallback. Matched Deck median improvements span **+2.64% to +4.08%** for fixed production VP work, with separate diagnostics proving which physical-store calls disappeared. Keep this draft: guest-writer ordering, affected audio and reset/save-load qualification remain incomplete.
**Remaining:** Establish the complete concurrent guest-writer and observer contract; qualify sample ordering, affected audio and reset/save-load; run the maintained affected APU XISO leaves with approved references and usable measurements; qualify any further game comparison's start procedure and Mesa cache state.

**Quick comparison:** seconds for 20,000 frames of 45 voices, including output checks. Medians use four baseline and four candidate processes in ABBA/BAAB. Positive Improvement % means less time. Worker threads are actual VP workers; these are not game FPS measurements.

| Voice format | Worker threads | Baseline s | Candidate s | Saved s | Improvement % |
| --- | ---: | ---: | ---: | ---: | ---: |
| Mono ADPCM | 1 | 5.598410 | 5.379434 | +0.218976 | +3.91% |
| Stereo ADPCM | 1 | 6.619660 | 6.407072 | +0.212588 | +3.21% |
| Mono PCM | 1 | 6.174472 | 5.922336 | +0.252136 | +4.08% |
| Mono ADPCM | 8 | 5.850624 | 5.651250 | +0.199374 | +3.41% |
| Stereo ADPCM | 8 | 6.839053 | 6.651581 | +0.187472 | +2.74% |
| Mono PCM | 8 | 6.393477 | 6.224968 | +0.168509 | +2.64% |

### Problem

`voice_set_mask()` physically stores every voice-state read/modify/write, including unchanged values. #270 observed 88.19–88.23% unchanged stores in three Windows PGR2 runs and 88.62% in one admitted Deck run. These observations identify work exposure; performance must be measured separately.

### What this PR changes

- `vp.c` calls the production helper in `voice-store.c`. Equality admission in `voice-store.h` requires a whole aligned word in the configured Xbox RAM range. The helper resolves the writable mapping under RCU, checks the RAM owner and direct access, then compares/exchanges the expected little-endian word with itself. A changed word, failed validation, Xen or unsupported mapping uses the original physical store. No shadow cache or APU scheduling change is added.
- Policy tests and the actual QEMU `AddressSpace` test cover direct RAM, dirty logging, whole/partial MMIO overlays and a synchronized writer changing RAM between the APU read and validation. That test covers a defined interleaving, not every concurrent guest-writer case.
- Retained `test-voice-store-integration.c` and `VOICE-STORE-CONTRACT.md` add nine actual-production memory cases: literal changed masks, three NV2A dirty clients, conservative fallback, alias/other-owner/MMIO remaps, legal shrink/regrowth, 20,000 event-ordered writes outside the selected mask, and 64 owner retirements. QOM owners and actual RAM allocation replace no CPU hooks. This proves defined interleavings, not unsynchronized guest concurrency. Meson and Linux CI run and retain the new executable.
- Retained `tests/xbox/mcpx-apu/test-voice-frame.c` and `VOICE-FRAME.md` drive actual VP dispatch, decoding, libsamplerate and mixing with 45 voices. They initialize the real system-RAM owner and NV2A dirty clients, use independently expected mixes and offsets, and cover mono ADPCM, stereo ADPCM and mono PCM with one/eight worker threads.
- Meson and Linux CI build, test and retain an ordinary timing executable and a separate `-stores` diagnostic. The ordinary executable has no store-count probe. The diagnostic forwards every physical store and aggregates counters per voice after production dispatch completes.
- [Deck report](https://github.com/Mainkill1/xemu/blob/e371f9c422cc6b8c61b7cdc5fe243dcd1ef8d603/docs/evidence/issue247-deck-voice-frame-20261002/REPORT.md), [full evidence archive](https://github.com/Mainkill1/xemu/blob/e371f9c422cc6b8c61b7cdc5fe243dcd1ef8d603/docs/evidence/issue247-deck-voice-frame-20261002/EVIDENCE.tar.gz) and [payload index](https://github.com/Mainkill1/xemu/blob/e371f9c422cc6b8c61b7cdc5fe243dcd1ef8d603/docs/evidence/issue247-deck-voice-frame-20261002/INDEX.json) retain all native attempts, source/build/library identities, comparisons, failed local setup checks and repeatable qualification scripts. Results belong to this xemu PR.

### Why this approach

The existing physical read supplies the expected word. Resolving the `MemoryRegion` and checking direct access exclude overlays and special RAM. A sequentially consistent same-value compare-exchange validates the word; the original physical store executes if a writer changed it before validation. Equal RAM contents do not need content dirty marking. The CAS still performs a host atomic operation, so these updates are not free.

QEMU guest direct writes can use ordinary RAM accesses. The synchronized-writer test and CAS do not establish a complete cross-writer ordering contract. That proof remains required. The approach was informed by [izzy2lost's prototype](https://github.com/izzy2lost/xemu/commit/a7765290d17750e10a2bfc2d94cd85279f3b591e); this branch adds resolved-mapping guards and atomic validation.


**BEFORE**

```text
physical read -> masked result -> physical store -> dirty/observer work
```

**AFTER**

```text
physical read -> masked result
  changed or unsupported -> original physical store
  equal -> resolve current writable mapping under RCU
    wrong owner / non-direct / short / unaligned / Xen -> original store
    admitted -> same-value CAS of the entire expected word
      mismatch -> original physical store
      match -> return without physical-store dirty/observer work
```

### Validation

- Measured original production: `ee5ce48b48784f999af374c1452003f8b2b1230f`; identical reference fixture: `dd1a8f48690803975d9e97b8e1139dcc4164fc83`; candidate input: `5d832c02c3ed6e1f56ef1b808fe74d8f3ea565ee`. The production algorithm is unchanged from reviewed `c4d36ecfa3`; contract-test source `abcb752ca4211922511eb76de32b6b9d2e803daa` changes only tests, their documentation and registration. Hardware sources and the existing VP fixture are byte-identical to the measured candidate. The #197 reader optimization is in neither build.
- [Reference CI](https://github.com/Mainkill1/xemu/actions/runs/37038506712) and [candidate CI](https://github.com/Mainkill1/xemu/actions/runs/37038440974) succeed. Clang/LLD 21.1.8, release ThinLTO, x86 version 3 and all 38 corresponding libraries match. Both release builds pass six ordinary and six diagnostic VP cases. The prior evidence publication CI also succeeds ([37043024265](https://github.com/Mainkill1/xemu/actions/runs/37043024265)); new contract-source CI is tracked separately below.
- **Steam Deck 10.0.0.123**, maintained HTTP runner `f5b3e58`: four six-case correctness processes, twelve diagnostic processes and **72 ordinary timing processes** all exit zero with complete collection and completed/passed/complete/eligible outcomes. All 72 timing records are index-eligible; the 16 correctness/count records intentionally declare no metric and are excluded from performance comparisons. All 42 build slots are declared before execution; independently verified A/B workload and environment keys match in every timing cohort. No Windows or SSH measurements are used in this new campaign.
- Each workload runs four baseline A/A controls, then physical **ABBA and BAAB**, with 20,000 frames of 45 voices and 32 samples per voice per frame. Timed output checks and final independent offset checks pass. Diagnostics preserve **900,000 changed physical stores** and remove **4,500,000 unchanged physical stores** in every row. Diagnostic times are retained as diagnostic-only, not performance evidence.
- Local checks: policy 3/3, real-memory 1/1, ordinary VP 6/6 and diagnostic VP 6/6 pass. The review's common-offset oracle gap was corrected using a separate SRC consumption oracle outside timing. Omitting changed stores aborts the ordinary fixture; deliberate monitor silence also aborts. The repeatable negative tool is retained.
- Full local unit build remains failed in unchanged resampler-test source: GCC 14 rejects missing `sinf`/`cosf` declarations. That attempt is preserved; the full local suite is not claimed green.
- The earlier Windows atomic PGR2 campaign tested `d3ccb5420c`, with the same production algorithm and different retained build identity. Eight balanced Vulkan runs completed at a 30 FPS cap. Earlier diagnostic-transfer and disk-full attempts remain excluded and recorded in the [atomic revision evidence](https://github.com/Mainkill1/xemu/blob/c4d36ecfa3111b60744225e966c0d12bc44cf007/evidence/wiki-xiso-per-test/pr-276-issue247/ATOMIC-REVISION.md).
- The earlier Deck PGR2 A/B/B attempts were comparison-ineligible due uncontrolled Mesa cache; the next baseline tested Event Select rather than the race start and failed correctness. [Runner issue81](https://github.com/Mainkill1/Xemu-Test-Runner/issues/81) preserves that input failure. This headless VP campaign does not qualify those game attempts or resolve their Mesa cache gate.

- New contract checks: five focused local executables pass (3 policy, 1 prior memory, 6 VP, 6 diagnostic VP and 9 new integration cases). Five negative executions reject premature equality, masked-only validation, other-owner admission and dropped changed stores. The existing full-unit GCC 14 resampler declaration failure remains preserved. Native Deck qualification of this source and its CI build is pending; no new timing claim. [Fixture contract](https://github.com/Mainkill1/xemu/blob/abcb752ca4211922511eb76de32b6b9d2e803daa/tests/xbox/mcpx-apu/VOICE-STORE-CONTRACT.md).

### Results

**New Deck production VP workload:** host seconds for the entire fixed batch, including identical output validation. The opening medians use four baseline and four candidate processes from ABBA/BAAB; A/A controls are separate. Positive Improvement % means less time: `100*(baseline-candidate)/baseline`. Worker threads are actual VP workers. All three formats exercise the store helper; PCM is an affected format control.

The [report](https://github.com/Mainkill1/xemu/blob/e371f9c422cc6b8c61b7cdc5fe243dcd1ef8d603/docs/evidence/issue247-deck-voice-frame-20261002/REPORT.md) shows A/A spreads, each order and all adjacent pairs. No repetition was dropped. CPU affinity and power policy were not pinned, and this small campaign supplies no confidence interval. These are synthetic production-processing results, not FPS, full DSP scheduling or audible playback.

**Earlier Windows PGR2 result, separate workload and build:** sampled process CPU **318.428 to 311.444 core %**, **2.19% lower**, while guest cadence stays capped at 30 FPS. Average frame time stays 33.333 ms; p95 **33.597 to 33.651 ms** and p99 **33.977 to 34.097 ms** worsen slightly. Mean per-run maximum falls **34.500 to 34.338 ms**. Original raw values and all eight runs remain in the atomic revision report; no Windows values are pooled with the Deck workload. The pre-review 1.98% CPU observation is historical and remains separate.

### Risks and remaining questions

Concurrent guest-writer ordering, observers beyond the tested mapping and dirty-client cases, sample ordering, reset/save-load and audible affected audio remain unqualified. The new fixture has enabled NV2A dirty clients but no renderer consuming their bitmaps and no vCPU/TCG execution. The constant signal checks the demonstrated mutations but does not prove arbitrary sample ordering. A successful synthetic workload cannot replace game or hardware correctness.

The maintained [APU XISO fixture draft52](https://github.com/Mainkill1/xemu-perf-tests/pull/52) has five affected audio leaves, but references and timer-paced measurement qualification remain incomplete; it has not qualified this candidate. Further game comparisons still need controlled Mesa cache and consumed start inputs. Keep this PR draft and HOLD until these bounded gates close.

### Related work

Addresses #247. #270 provided opt-in attribution and is closed without merge. #197's reader optimization and its separate measurements are not combined here. #200 studied VP worker count. [Runner draft89](https://github.com/Mainkill1/Xemu-Test-Runner/pull/89) retains the standalone process capability used by this campaign; its repo contains tooling, not these xemu results.

> **Agent Declaration**: This pull request was created with assistance from Codex / GPT-6.

"""Retained negative controls against the actual linked voice-store helper."""
from pathlib import Path
import argparse
import json
import hashlib
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store'))
parser.add_argument('--build', default='build-voice-frame')
parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'mutations')
args = parser.parse_args()
build = args.repo/args.build
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
source = args.repo/'hw/xbox/mcpx/apu/vp/voice-store.c'
original = source.read_text()
fixture = args.repo/'tests/xbox/mcpx-apu/test-voice-store-integration.c'
fixture_data = fixture.read_bytes()
(out/'test-voice-store-integration.c').write_bytes(fixture_data)
(out/'source-identity.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=args.repo,text=True).strip(),'helperSha256':hashlib.sha256(original.encode()).hexdigest(),'fixtureSha256':hashlib.sha256(fixture_data).hexdigest()},indent=2)+'\n')
site = '    if (!mcpx_apu_voice_store_required('
assert original.count(site) == 1
call = 'mcpx_apu_voice_try_equal_store(ram_word, old_value)'
assert original.count(call) == 1
mutants = {
    'read-equality': (original.replace(site, '    if (new_value == old_value) { return; }\n'+site),
                      [('ordered-writers','0xaabbcc44'),('mmio-remap','io.writes')]),
    'masked-validation': (original.replace(call, '(qatomic_read(ram_word) & cpu_to_le32(mask)) == (cpu_to_le32(old_value) & cpu_to_le32(mask))'),
                          [('ordered-writers','0xaabbcc44')]),
    'owner-check': (original.replace('region == ram', 'memory_region_is_ram(region)'),
                    [('other-ram-owner','expected')]),
    'drop-changed': (original.replace('stl_le_phys(as, address, new_value);','/* Test mutation: omit the required physical store. */'),
                     [('changed-masks','0x11223399')]),
}
commands = json.loads((build/'compile_commands.json').read_text())
command = next(r for r in commands if r['file'].endswith('/voice-store.c'))
target = 'test-xbox-mcpx-apu-voice-store-integration'
# This tool is for qualification outside performance collection. Preserve
# production source contents and objects; keep a linker response for negatives.
(args.repo/'tests/xbox/mcpx-apu/test-voice-store-integration.c').touch()
with (out/'prepare.log').open('w') as log:
    subprocess.run(['ninja','-d','keeprsp','-C',str(build),target],stdout=log,stderr=subprocess.STDOUT,check=True)
link = shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],text=True).splitlines()[-1])
response = next(x for x in link if x.startswith('@'))
base_rsp = shlex.split((build/response[1:]).read_text())
index = [i for i,x in enumerate(base_rsp) if x.endswith('hw_xbox_mcpx_apu_vp_voice-store.c.o')]
assert len(index) == 1
receipts = []
for name,(text,cases) in mutants.items():
    folder = out/name
    folder.mkdir(parents=True,exist_ok=True)
    mutation = folder/'voice-store.c'
    mutation.write_text(text)
    argv = shlex.split(command['command'])
    argv[argv.index('-c')+1] = str(mutation)
    argv[argv.index('-o')+1] = str(folder/'voice-store.o')
    argv[argv.index('-MF')+1] = str(folder/'voice-store.d')
    with (folder/'build.log').open('w') as log:
        subprocess.run(argv,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
        rsp = list(base_rsp)
        rsp[index[0]] = str(folder/'voice-store.o')
        rsp[rsp.index('-o')+1] = str(folder/'negative-integration')
        subprocess.run([x for x in link if x!=response]+rsp,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    for test,expected in cases:
        result = subprocess.run([str(folder/'negative-integration'),'--tap','-p','/mcpx-apu/voice-store/'+test],capture_output=True,text=True,timeout=60)
        output = result.stdout+result.stderr
        (folder/(test+'.log')).write_text(output)
        receipt = {'mutation':name,'test':test,'exitCode':result.returncode,'expectedFailureText':expected}
        (folder/(test+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        assert result.returncode!=0 and expected in output,(receipt,output)
        receipts.append(receipt)
assert source.read_text()==original
(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps({'negativeCases':len(receipts),'allRejected':True,'productionSourceUnchanged':True}))

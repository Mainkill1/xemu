"""Save all build slots before one correctness job, resume only that job."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,shutil,sys,time,urllib.parse
ROOT=Path('/home/codex/src/steamdeck-xemu')
OUT=Path(__file__).resolve().parent
NATIVE=OUT/'deck-native'
PACKAGE=NATIVE/'package'
sys.path.insert(0,str(ROOT/'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi,ClientError
from runner_workflows import Workflows
from runner_tests import upload_application
from runner_wait import execute as completion_wait
api=RunnerApi('http://10.0.0.123:9368');work=Workflows(api)

def save(p,value):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=json.loads((OUT/'build-qualification.json').read_text());assert identity['qualified']
files=identity['files'];assert len(files)==39
for item in files:
    src=Path(item['source']);assert sha(src)==item['sha256']
    dst=PACKAGE/item['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    if item['path'].startswith('test-xbox-'): dst.chmod(0o755)
save(NATIVE/'manifest.json',identity)
assets='issue247-store-contract-assets-20261002'
exe='test-xbox-mcpx-apu-voice-store-integration'
if not (NATIVE/'assets.json').exists():
    status=api.json('/api/v1/status');assert status['Phase']=='idle' and status['CurrentJob'] is None
    save(NATIVE/'preflight.json',status)
    digest=upload_application(api,PACKAGE,exe,assets);assert digest==files[0]['sha256']
    save(NATIVE/'assets.json',{'id':assets,'sha256':digest,'state':work.status(assets)})
job=json.loads((ROOT/'artifacts/issue197-sample-memory/remaining-gates/memory-lifetime/deck-native/candidate/definition.json').read_text())
test='issue247-store-contract-tap-v1'
job['Id']=test;job['Executable']=exe;job['ExpectedExecutableSha256']=files[0]['sha256'];job['RequiredFiles']=[f['path'] for f in files]
job['TimeoutSeconds']=180
job['Experiment']['Id']='issue247-store-contract-20261002';job['Experiment']['Variant']='candidate-correctness'
cases=['changed-masks','equal-clients','fallback-guards','alias-remap','other-ram-owner','mmio-remap','ram-resize','ordered-writers','owner-retirement']
job['Workload']={'CorrectnessChecks':[{'Name':'nine-case-plan','Path':'stdout.log','ContainsText':'1..9'}]+[{'Name':case,'Path':'stdout.log','ContainsText':f'ok {i} /mcpx-apu/voice-store/{case}'} for i,case in enumerate(cases,1)],'EvidenceRequirements':[{'Name':'full-TAP','Path':'stdout.log','MinimumBytes':500}],'ReportedMetrics':[],'MinimumMetricSamples':0,'RequirePlanCompletion':True}
request={'sourceJobId':assets,'job':job,'description':'Nine actual-production memory contract checks. Event-ordered writers; no unsynchronized guest/lifecycle/audio/XISO claim. Correctness only; no timing metric.','buildFiles':[f['path'] for f in files]}
marker=NATIVE/'saved-test-request.json';receipt=NATIVE/'saved-test.json'
if receipt.exists():
    assert json.loads(marker.read_text())==request;config=json.loads(receipt.read_text())
else:
    save(marker,request);config=api.json('/api/v1/test-configs/'+urllib.parse.quote(test,safe=''),'POST',request);save(receipt,config)
assert config['buildFileCount']==39
handle='issue247-store-contract-correctness-20261002'
submission={'testId':test,'revision':config['revision'],'jobId':handle}
if (NATIVE/'submission.json').exists():
    assert json.loads((NATIVE/'submission.json').read_text())==submission
    assert work.status(handle)['state'] in ('testing','tested','queued'),'Observe same handle; never rerun.'
else:
    save(NATIVE/'submission.json',submission);save(NATIVE/'submit.json',work.run_test(test,config['revision'],handle,None,{},8*1024*1024))
wait=completion_wait(api,SimpleNamespace(id=handle,job=True,updates=False));save(NATIVE/'wait.json',wait)
result=work.result(handle);save(NATIVE/'result-summary.json',result)
collection=work.collect(handle,NATIVE/'collected',None,True);save(NATIVE/'collection.json',collection)
assert wait['terminal'] and collection['complete'] and collection['excluded']==0
assert result['outcome']=={'execution':'completed','correctness':'passed','evidence':'complete','comparison':'eligible'},result
run=NATIVE/'collected'/result['runId']
raw=json.loads((run/'result.json').read_text());assert raw['exitCode']==0
assert raw['host']['runnerVersion']=='0.2.0+f5b3e58de71ce6fb56450679a456fd049aa95b29'
assert raw['host']['machine']=='steamdeck' and raw['host']['os']=='SteamOS'
assert (run/'stderr.log').stat().st_size==0
text=(run/'stdout.log').read_text();assert '1..9' in text
assert sum(s.startswith('ok ') for s in text.splitlines())==9 and not any(s.startswith('not ok') for s in text.splitlines())
for i,case in enumerate(cases,1):assert f'ok {i} /mcpx-apu/voice-store/{case}' in text
status=api.json('/api/v1/status');save(NATIVE/'post-status.json',status);assert status['Phase']=='idle' and status['CurrentJob'] is None
pages=[];items=[];offset=0
while True:
    observations=[]
    for attempt in range(20):
        try:
            page=api.json('/api/v1/build-results/'+files[0]['sha256']+'/runs?offset='+str(offset)+'&limit=20')
            observations.append({'attempt':attempt,'found':True})
            break
        except ClientError as e:
            observations.append({'attempt':attempt,**e.document()})
            save(NATIVE/('index-observations-'+str(offset)+'.json'),observations)
            if e.code!='build_results_not_found' or attempt==19:raise
            time.sleep(1)
    save(NATIVE/('index-observations-'+str(offset)+'.json'),observations)
    pages.append(page);items+=page['items']
    if len(page['items'])<20:break
    offset+=len(page['items'])
save(OUT/'server-runs.json',{'items':items,'pages':pages})
indexed=[r for r in items if r['runId']==result['runId']]
assert len(indexed)==1
indexed=indexed[0]
assert indexed['outcome']==result['outcome'] and indexed['eligible'] is False
assert indexed['issues']==['metrics_missing'] and indexed['metrics']==[]
receipt={'passed':9,'jobId':handle,'runId':result['runId'],'exeSha256':files[0]['sha256'],'sourceHead':identity['sourceHead'],'ciRun':identity['ciRun'],'negativeRejected':5,'ownerFinalizations':73,'orderedWrites':20000,'ownerRetirements':64,'nativeAttempts':1,'collection':collection,'outcome':result['outcome'],'performanceIndexIssues':indexed['issues'],'scope':'Correctness only. No new timing metric. Event-ordered C accesses do not qualify unsynchronized guest stores.'}
save(OUT/'VERIFIED-SUMMARY.json',receipt)
print(json.dumps(receipt),flush=True)

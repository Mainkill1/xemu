"""Bind the retained contract executable to CI source and unchanged product."""
from pathlib import Path
import hashlib,json,re,subprocess,tarfile
ROOT=Path('/home/codex/src/steamdeck-xemu')
OUT=Path(__file__).resolve().parent
REPO=ROOT/'worktrees/issue247-equal-store'
BUILD=OUT/'native-build'
EXE='test-xbox-mcpx-apu-voice-store-integration'
head=json.loads((OUT/'source-head.json').read_text())['head']
run=37046677970

def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
ci=json.loads((OUT/'source-ci-final.json').read_text())
assert ci['status']=='completed' and ci['conclusion']=='success'
log=re.sub(r'\x1b\[[0-9;]*m','',(OUT/'release-ci-api.log').read_text())
assert re.search(re.escape(EXE)+r'\s+OK\b.*9 subtests passed',log)
assert 'clang 21.1.8' in log and 'ld.lld 21.1.8' in log
assert all(x in log for x in ('-Db_lto=true','-Db_lto_mode=thin','-Dx86_version=3'))
selected=['tests/xbox/mcpx-apu/test-voice-store-integration.c','tests/xbox/mcpx-apu/VOICE-STORE-CONTRACT.md','meson.build','.github/workflows/build-linux.yml','hw/xbox/mcpx/apu/vp/voice-store.c','hw/xbox/mcpx/apu/vp/voice-store.h','hw/xbox/mcpx/apu/vp/vp.c']
archive=next((BUILD/'source').glob('*.tar.zst'))
checks={}
p=subprocess.Popen(['zstd','-dc',str(archive)],stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as t:
    for m in t:
        parts=m.name.removeprefix('./').split('/',1)
        if len(parts)!=2 or parts[1] not in selected: continue
        name=parts[1]; data=t.extractfile(m).read()
        assert data==subprocess.check_output(['git','show',head+':'+name],cwd=REPO),name
        dest=OUT/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        checks[name]=hashlib.sha256(data).hexdigest()
assert p.wait()==0 and set(checks)==set(selected)
files=[{'path':EXE,'source':str(BUILD/EXE),'sha256':sha(BUILD/EXE),'bytes':(BUILD/EXE).stat().st_size}]
library=BUILD/'squashfs-root/usr/lib'
libs={p.name:sha(p) for p in library.iterdir()}
assert len(libs)==38
for name in sorted(libs):
    p=library/name;files.append({'path':'lib/'+name,'source':str(p),'sha256':libs[name],'bytes':p.stat().st_size})
old=json.loads((ROOT/'artifacts/issue247-equal-store-deck-20261002/matched-build-qualification.json').read_text())
previous={Path(f['path']).name:f['sha256'] for f in old['files'] if f['path'].startswith('lib/')}
assert libs==previous,'Runtime libraries changed from measured VP campaign.'
subprocess.run(['python3',str(OUT/'verify-source.py')],check=True)
receipt={'qualified':True,'sourceHead':head,'ciRun':run,'ciSuccess':True,'sourceArchiveSha256':sha(archive),'sourceSha256':checks,'files':files,'librariesIdenticalToMeasuredVP':True,'libraryCount':38,'build':'Clang/LLD21.1.8 release ThinLTO x86-v3','elfNotes':subprocess.check_output(['readelf','-n',str(BUILD/EXE)],text=True),'scope':'Nine-case actual-production memory correctness only; no new timing metric.'}
(OUT/'build-qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'qualified':True,'sourceHead':head,'ciRun':run,'buildSlots':len(files),'libraries':len(libs)}))

"""Update the owning draft's canonical body; preserve existing performance rows."""
from pathlib import Path
import json,subprocess,sys
OUT=Path(__file__).resolve().parent
REPO=Path('/home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store')
phase=sys.argv[1]
assert phase in ('source','final')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
source=json.loads((OUT/'source-head.json').read_text())['head']
body=json.loads((OUT/'pr-before.json').read_text())['body']
body=body.replace('Establish the complete guest-writer/mapping ordering contract;', 'Establish the complete concurrent guest-writer and observer contract;')
needle='- Retained `tests/xbox/mcpx-apu/test-voice-frame.c`'
insert='- Retained `test-voice-store-integration.c` and `VOICE-STORE-CONTRACT.md` add nine actual-production memory cases: literal changed masks, three NV2A dirty clients, conservative fallback, alias/other-owner/MMIO remaps, legal shrink/regrowth, 20,000 event-ordered writes outside the selected mask, and 64 owner retirements. QOM owners and actual RAM allocation replace no CPU hooks. This proves defined interleavings, not unsynchronized guest concurrency. Meson and Linux CI run and retain the new executable.\n'
assert needle in body
body=body.replace(needle,insert+needle,1)
body=body.replace('The production algorithm is unchanged from reviewed `c4d36ecfa3`; this publication adds evidence.',f'The production algorithm is unchanged from reviewed `c4d36ecfa3`; contract-test source `{source}` changes only tests, their documentation and registration. Hardware sources and the existing VP fixture are byte-identical to the measured candidate.')
body=body.replace('CI for the evidence publication follows separately.','The prior evidence publication CI also succeeds ([37043024265](https://github.com/Mainkill1/xemu/actions/runs/37043024265)); new contract-source CI is tracked separately below.')
flow='''
**BEFORE**

```text
physical read -> masked result -> physical store -> dirty/observer work
```

**AFTER**

```text
physical read -> masked result
  changed or unsupported -> original physical store
  equal -> resolve current writable mapping under RCU
    wrong owner / non-direct / short / unaligned / Xen -> original store
    admitted -> same-value CAS of the entire expected word
      mismatch -> original physical store
      match -> return without physical-store dirty/observer work
```
'''
body=body.replace('### Validation\n',flow+'\n### Validation\n',1)
local='- New contract checks: five focused local executables pass (3 policy, 1 prior memory, 6 VP, 6 diagnostic VP and 9 new integration cases). Five negative executions reject premature equality, masked-only validation, other-owner admission and dropped changed stores. The existing full-unit GCC 14 resampler declaration failure remains preserved. '
if phase=='source':
    detail=f'Native Deck qualification of this source and its CI build is pending; no new timing claim. [Fixture contract](https://github.com/Mainkill1/xemu/blob/{source}/tests/xbox/mcpx-apu/VOICE-STORE-CONTRACT.md).'
else:
    s=json.loads((OUT/'VERIFIED-SUMMARY.json').read_text())
    assert s['passed']==9 and s['negativeRejected']==5
    evidence=f'https://github.com/Mainkill1/xemu/blob/{head}/docs/evidence/issue247-store-contract-deck-20261002'
    detail=f"Steam Deck **10.0.0.123** runs the release CI executable via maintained HTTP runner: **9/9 pass**, zero exit code, empty stderr, full collection, no rerun. [Source CI](https://github.com/Mainkill1/xemu/actions/runs/{s['ciRun']}) succeeds; [contract report]({evidence}/REPORT.md), [complete packet]({evidence}/EVIDENCE.tar.gz), [payload index]({evidence}/INDEX.json) bind source/build/library identities and preserve all local setup failures. Correctness-only record has no performance metric."
body=body.replace('### Results\n',local+detail+'\n\n### Results\n',1)
body=body.replace('Full guest-writer/mapping ordering, observers beyond tested dirty logging,', 'Concurrent guest-writer ordering, observers beyond the tested mapping and dirty-client cases,')
body=body.replace('assistance from Codex.', 'assistance from Codex / GPT-6.')
request=OUT/f'pr-{phase}-request.json'
request.write_text(json.dumps({'body':body})+'\n')
(OUT/f'pr-{phase}-body.md').write_text(body)
endpoint='repos/Mainkill1/xemu/pulls/276'
current=json.loads(subprocess.check_output(['gh','api',endpoint],text=True))
expected=json.loads((OUT/'pr-before.json').read_text())['body'] if phase=='source' else (OUT/'pr-source-body.md').read_text()
assert current['body']==expected,'Canonical body changed externally; reconcile before PATCH.'
assert current['draft'] and current['head']['sha']==head and not current['merged']
with (OUT/f'pr-{phase}-response.json').open('w') as f:
    subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(request)],stdout=f,check=True)
readback=json.loads(subprocess.check_output(['gh','api',endpoint],text=True))
assert readback['body']==body and readback['draft'] and readback['head']['sha']==head
(OUT/f'pr-{phase}-readback.json').write_text(json.dumps(readback,indent=2)+'\n')
if phase=='final':
    endpoint='repos/Mainkill1/xemu/issues/247'
    issue=json.loads(subprocess.check_output(['gh','api',endpoint],text=True))
    (OUT/'issue-before.json').write_text(json.dumps(issue,indent=2)+'\n')
    separator='\n---\n'
    assert separator in issue['body']
    status,original=issue['body'].split(separator,1)
    status += f"\n\n**Additional contract qualification:** retained nine-case production-memory fixture passes locally and on Steam Deck **10.0.0.123**; five deliberately broken-helper executions fail. It covers literal masked results, all three NV2A dirty clients, current alias/RAM-owner/MMIO mappings, shrink/regrowth, 20,000 event-ordered writes and 64 legal owner retirements (73 total finalizations). [Report and limits]({evidence}/REPORT.md). Production and measured VP sources are unchanged; these checks add no timing result and do not establish concurrent guest-store or APU reset/save-load/audio/XISO qualification. PR276 remains draft/HOLD."
    text=status+separator+original
    req=OUT/'issue-final-request.json';req.write_text(json.dumps({'body':text})+'\n')
    with (OUT/'issue-final-response.json').open('w') as f:
        subprocess.run(['gh','api',endpoint,'--method','PATCH','--input',str(req)],stdout=f,check=True)
    readback=json.loads(subprocess.check_output(['gh','api',endpoint],text=True))
    assert readback['body']==text and readback['state']=='open'
    (OUT/'issue-final-readback.json').write_text(json.dumps(readback,indent=2)+'\n')
print('Verified canonical draft',phase,head)

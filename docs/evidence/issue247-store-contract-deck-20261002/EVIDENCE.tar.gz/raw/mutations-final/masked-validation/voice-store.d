libqemu-i386-softmmu.a.p/hw_xbox_mcpx_apu_vp_voice-store.c.o: \
 /home/codex/src/steamdeck-xemu/artifacts/issue247-store-contract-deck-20261002/mutations-final/masked-validation/voice-store.c \
 /usr/include/stdc-predef.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/osdep.h \
 config-host.h i386-softmmu-config-target.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/compiler.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/stdarg.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/stddef.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/stdbool.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/stdint.h /usr/include/stdint.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-least.h \
 /usr/include/x86_64-linux-gnu/sys/types.h \
 /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/timer_t.h /usr/include/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endianness.h \
 /usr/include/x86_64-linux-gnu/bits/byteswap.h \
 /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
 /usr/include/x86_64-linux-gnu/sys/select.h \
 /usr/include/x86_64-linux-gnu/bits/select.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/x86_64-linux-gnu/bits/select2.h \
 /usr/include/x86_64-linux-gnu/bits/select-decl.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
 /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h /usr/include/stdlib.h \
 /usr/include/x86_64-linux-gnu/bits/waitflags.h \
 /usr/include/x86_64-linux-gnu/bits/waitstatus.h \
 /usr/include/x86_64-linux-gnu/bits/floatn.h \
 /usr/include/x86_64-linux-gnu/bits/floatn-common.h \
 /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/alloca.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib-bsearch.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib-float.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib.h /usr/include/stdio.h \
 /usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
 /usr/include/x86_64-linux-gnu/bits/stdio2-decl.h \
 /usr/include/x86_64-linux-gnu/bits/stdio.h \
 /usr/include/x86_64-linux-gnu/bits/stdio2.h /usr/include/string.h \
 /usr/include/strings.h \
 /usr/include/x86_64-linux-gnu/bits/strings_fortified.h \
 /usr/include/x86_64-linux-gnu/bits/string_fortified.h \
 /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/limits.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/syslimits.h \
 /usr/include/limits.h /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
 /usr/include/x86_64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/x86_64-linux-gnu/bits/posix2_lim.h \
 /usr/include/x86_64-linux-gnu/bits/xopen_lim.h \
 /usr/include/x86_64-linux-gnu/bits/uio_lim.h /usr/include/unistd.h \
 /usr/include/x86_64-linux-gnu/bits/posix_opt.h \
 /usr/include/x86_64-linux-gnu/bits/environments.h \
 /usr/include/x86_64-linux-gnu/bits/confname.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_posix.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_core.h \
 /usr/include/x86_64-linux-gnu/bits/unistd.h \
 /usr/include/x86_64-linux-gnu/bits/unistd-decl.h \
 /usr/include/x86_64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h /usr/include/time.h \
 /usr/include/x86_64-linux-gnu/bits/time.h \
 /usr/include/x86_64-linux-gnu/bits/timex.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_tm.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_itimerspec.h \
 /usr/include/ctype.h /usr/include/errno.h \
 /usr/include/x86_64-linux-gnu/bits/errno.h /usr/include/linux/errno.h \
 /usr/lib/linux/uapi/x86/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h \
 /usr/include/x86_64-linux-gnu/bits/types/error_t.h /usr/include/fcntl.h \
 /usr/include/x86_64-linux-gnu/bits/fcntl.h \
 /usr/include/x86_64-linux-gnu/bits/fcntl-linux.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h \
 /usr/include/linux/falloc.h /usr/include/x86_64-linux-gnu/bits/stat.h \
 /usr/include/x86_64-linux-gnu/bits/struct_stat.h \
 /usr/include/x86_64-linux-gnu/bits/fcntl2.h /usr/include/getopt.h \
 /usr/include/x86_64-linux-gnu/bits/getopt_ext.h \
 /usr/include/x86_64-linux-gnu/sys/stat.h \
 /usr/include/x86_64-linux-gnu/bits/statx.h /usr/include/linux/stat.h \
 /usr/include/linux/types.h /usr/lib/linux/uapi/x86/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 linux-headers/asm/bitsperlong.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/linux-headers/asm-generic/bitsperlong.h \
 /usr/include/linux/posix_types.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/linux-headers/linux/stddef.h \
 /usr/lib/linux/uapi/x86/asm/posix_types.h \
 /usr/lib/linux/uapi/x86/asm/posix_types_64.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/x86_64-linux-gnu/bits/statx-generic.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_statx_timestamp.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_statx.h \
 /usr/include/x86_64-linux-gnu/sys/time.h /usr/include/assert.h \
 /usr/include/setjmp.h /usr/include/x86_64-linux-gnu/bits/setjmp.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct___jmp_buf_tag.h \
 /usr/include/x86_64-linux-gnu/bits/setjmp2.h /usr/include/signal.h \
 /usr/include/x86_64-linux-gnu/bits/signum-generic.h \
 /usr/include/x86_64-linux-gnu/bits/signum-arch.h \
 /usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__sigval_t.h \
 /usr/include/x86_64-linux-gnu/bits/siginfo-arch.h \
 /usr/include/x86_64-linux-gnu/bits/siginfo-consts.h \
 /usr/include/x86_64-linux-gnu/bits/siginfo-consts-arch.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigval_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigevent_t.h \
 /usr/include/x86_64-linux-gnu/bits/sigevent-consts.h \
 /usr/include/x86_64-linux-gnu/bits/sigaction.h \
 /usr/include/x86_64-linux-gnu/bits/sigcontext.h \
 /usr/include/x86_64-linux-gnu/bits/types/stack_t.h \
 /usr/include/x86_64-linux-gnu/sys/ucontext.h \
 /usr/include/x86_64-linux-gnu/bits/sigstack.h \
 /usr/include/x86_64-linux-gnu/bits/sigstksz.h \
 /usr/include/x86_64-linux-gnu/bits/ss_flags.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_sigstack.h \
 /usr/include/x86_64-linux-gnu/bits/sigthread.h \
 /usr/include/x86_64-linux-gnu/bits/signal_ext.h \
 /usr/include/x86_64-linux-gnu/sys/uio.h \
 /usr/include/x86_64-linux-gnu/bits/uio-ext.h \
 /usr/include/x86_64-linux-gnu/sys/wait.h \
 /usr/include/x86_64-linux-gnu/bits/types/idtype_t.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/glib-compat.h \
 /usr/include/glib-2.0/glib.h /usr/include/glib-2.0/glib/galloca.h \
 /usr/include/glib-2.0/glib/gtypes.h \
 /usr/lib/x86_64-linux-gnu/glib-2.0/include/glibconfig.h \
 /usr/include/glib-2.0/glib/gmacros.h \
 /usr/lib/gcc/x86_64-linux-gnu/14/include/float.h \
 /usr/include/glib-2.0/glib/gversionmacros.h \
 /usr/include/glib-2.0/glib/glib-visibility.h \
 /usr/include/glib-2.0/glib/garray.h \
 /usr/include/glib-2.0/glib/gasyncqueue.h \
 /usr/include/glib-2.0/glib/gthread.h \
 /usr/include/glib-2.0/glib/gatomic.h \
 /usr/include/glib-2.0/glib/glib-typeof.h \
 /usr/include/glib-2.0/glib/gerror.h /usr/include/glib-2.0/glib/gquark.h \
 /usr/include/glib-2.0/glib/gutils.h \
 /usr/include/glib-2.0/glib/gbacktrace.h \
 /usr/include/glib-2.0/glib/gbase64.h \
 /usr/include/glib-2.0/glib/gbitlock.h \
 /usr/include/glib-2.0/glib/gbookmarkfile.h \
 /usr/include/glib-2.0/glib/gdatetime.h \
 /usr/include/glib-2.0/glib/gtimezone.h \
 /usr/include/glib-2.0/glib/gbytes.h \
 /usr/include/glib-2.0/glib/gcharset.h \
 /usr/include/glib-2.0/glib/gchecksum.h \
 /usr/include/glib-2.0/glib/gconvert.h \
 /usr/include/glib-2.0/glib/gdataset.h /usr/include/glib-2.0/glib/gdate.h \
 /usr/include/glib-2.0/glib/gdir.h /usr/include/dirent.h \
 /usr/include/x86_64-linux-gnu/bits/dirent.h \
 /usr/include/x86_64-linux-gnu/bits/dirent_ext.h \
 /usr/include/glib-2.0/glib/genviron.h \
 /usr/include/glib-2.0/glib/gfileutils.h \
 /usr/include/glib-2.0/glib/ggettext.h /usr/include/glib-2.0/glib/ghash.h \
 /usr/include/glib-2.0/glib/glist.h /usr/include/glib-2.0/glib/gmem.h \
 /usr/include/glib-2.0/glib/gnode.h /usr/include/glib-2.0/glib/ghmac.h \
 /usr/include/glib-2.0/glib/gchecksum.h \
 /usr/include/glib-2.0/glib/ghook.h \
 /usr/include/glib-2.0/glib/ghostutils.h \
 /usr/include/glib-2.0/glib/giochannel.h \
 /usr/include/glib-2.0/glib/gmain.h /usr/include/glib-2.0/glib/gpoll.h \
 /usr/include/glib-2.0/glib/gslist.h /usr/include/glib-2.0/glib/gstring.h \
 /usr/include/glib-2.0/glib/gunicode.h \
 /usr/include/glib-2.0/glib/gstrfuncs.h \
 /usr/include/glib-2.0/glib/gkeyfile.h \
 /usr/include/glib-2.0/glib/gmappedfile.h \
 /usr/include/glib-2.0/glib/gmarkup.h \
 /usr/include/glib-2.0/glib/gmessages.h \
 /usr/include/glib-2.0/glib/gvariant.h \
 /usr/include/glib-2.0/glib/gvarianttype.h \
 /usr/include/glib-2.0/glib/goption.h \
 /usr/include/glib-2.0/glib/gpathbuf.h \
 /usr/include/glib-2.0/glib/gpattern.h \
 /usr/include/glib-2.0/glib/gprimes.h /usr/include/glib-2.0/glib/gqsort.h \
 /usr/include/glib-2.0/glib/gqueue.h /usr/include/glib-2.0/glib/grand.h \
 /usr/include/glib-2.0/glib/grcbox.h \
 /usr/include/glib-2.0/glib/grefcount.h \
 /usr/include/glib-2.0/glib/grefstring.h \
 /usr/include/glib-2.0/glib/gmem.h /usr/include/glib-2.0/glib/gmacros.h \
 /usr/include/glib-2.0/glib/gregex.h \
 /usr/include/glib-2.0/glib/gscanner.h \
 /usr/include/glib-2.0/glib/gsequence.h \
 /usr/include/glib-2.0/glib/gshell.h /usr/include/glib-2.0/glib/gslice.h \
 /usr/include/glib-2.0/glib/gspawn.h \
 /usr/include/glib-2.0/glib/gstringchunk.h \
 /usr/include/glib-2.0/glib/gstrvbuilder.h \
 /usr/include/glib-2.0/glib/gtestutils.h \
 /usr/include/glib-2.0/glib/gthreadpool.h \
 /usr/include/glib-2.0/glib/gtimer.h \
 /usr/include/glib-2.0/glib/gtrashstack.h \
 /usr/include/glib-2.0/glib/gtree.h /usr/include/glib-2.0/glib/guri.h \
 /usr/include/glib-2.0/glib/guuid.h /usr/include/glib-2.0/glib/gversion.h \
 /usr/include/glib-2.0/glib/deprecated/gallocator.h \
 /usr/include/glib-2.0/glib/deprecated/gcache.h \
 /usr/include/glib-2.0/glib/deprecated/gcompletion.h \
 /usr/include/glib-2.0/glib/deprecated/gmain.h \
 /usr/include/glib-2.0/glib/deprecated/grel.h \
 /usr/include/glib-2.0/glib/deprecated/gthread.h /usr/include/pthread.h \
 /usr/include/sched.h /usr/include/x86_64-linux-gnu/bits/sched.h \
 /usr/include/linux/sched/types.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_sched_param.h \
 /usr/include/x86_64-linux-gnu/bits/cpu-set.h \
 /usr/include/glib-2.0/glib/glib-autocleanups.h \
 /usr/include/glib-2.0/glib-unix.h /usr/include/glib-2.0/glib/gstdio.h \
 /usr/include/glib-2.0/glib/gprintf.h /usr/include/pwd.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/system/os-posix.h \
 /usr/include/x86_64-linux-gnu/sys/mman.h \
 /usr/include/x86_64-linux-gnu/bits/mman.h \
 /usr/include/x86_64-linux-gnu/bits/mman-map-flags-generic.h \
 /usr/include/x86_64-linux-gnu/bits/mman-linux.h \
 /usr/include/x86_64-linux-gnu/bits/mman-shared.h \
 /usr/include/x86_64-linux-gnu/bits/mman_ext.h \
 /usr/include/x86_64-linux-gnu/sys/socket.h \
 /usr/include/x86_64-linux-gnu/bits/socket.h \
 /usr/include/x86_64-linux-gnu/bits/socket_type.h \
 /usr/include/x86_64-linux-gnu/bits/sockaddr.h \
 /usr/lib/linux/uapi/x86/asm/socket.h /usr/include/asm-generic/socket.h \
 /usr/lib/linux/uapi/x86/asm/sockios.h /usr/include/asm-generic/sockios.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_osockaddr.h \
 /usr/include/x86_64-linux-gnu/bits/socket2.h /usr/include/netinet/in.h \
 /usr/include/x86_64-linux-gnu/bits/in.h /usr/include/netinet/tcp.h \
 /usr/include/arpa/inet.h /usr/include/netdb.h /usr/include/rpc/netdb.h \
 /usr/include/x86_64-linux-gnu/bits/netdb.h \
 /usr/include/x86_64-linux-gnu/sys/un.h \
 /usr/include/x86_64-linux-gnu/sys/sysmacros.h \
 /usr/include/x86_64-linux-gnu/bits/sysmacros.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/typedefs.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/bitops.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/host-utils.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/bswap.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/target-info.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/int128.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/atomic.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/compiler.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/rcu.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/thread.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/processor.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/atomic.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/futex.h \
 /usr/include/x86_64-linux-gnu/sys/syscall.h linux-headers/asm/unistd.h \
 linux-headers/asm/unistd_64.h \
 /usr/include/x86_64-linux-gnu/bits/syscall.h /usr/include/linux/futex.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/thread-posix.h \
 /usr/include/semaphore.h /usr/include/x86_64-linux-gnu/bits/semaphore.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/qsp.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/queue.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/notify.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/sys_membarrier.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/coroutine-tls.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/system/xen.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/cpu-common.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/vaddr.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/hwaddr.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/hw/core/cpu.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/hw/qdev-core.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/bitmap.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/rcu_queue.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qom/object.h \
 qapi/qapi-builtin-types.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qapi/util.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/module.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/hw/hotplug.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/hw/resettable.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/disas/dis-asm.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/breakpoint.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/memattrs.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/mmu-access-type.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/tlb-common.h \
 qapi/qapi-types-machine.h qapi/qapi-types-common.h \
 qapi/qapi-types-machine-common.h qapi/qapi-types-run-state.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/lockcnt.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/tcg/debug-assert.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/page-protection.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/hw/xbox/mcpx/apu/vp/voice-store.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/system/memory.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/memop.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/host-utils.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/ramlist.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/qemu/range.h \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/memory_ldst.h.inc \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/memory_ldst_phys.h.inc \
 /home/codex/src/steamdeck-xemu/worktrees/issue247-equal-store/include/exec/memory_ldst_cached.h.inc

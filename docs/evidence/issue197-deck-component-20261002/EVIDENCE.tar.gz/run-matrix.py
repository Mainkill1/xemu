"""Frozen component campaign; all execution/collection uses maintained HTTP clients."""
from pathlib import Path
import hashlib,json,sys
from types import SimpleNamespace
ROOT=Path('/home/codex/src/steamdeck-xemu')
sys.path.insert(0,str(ROOT/'worktrees/runner-standalone-process/scripts'))
from runner_transport import RunnerApi
from runner_workflows import Workflows
from runner_wait import execute as completion_wait
OUT=ROOT/'artifacts/issue197-sample-memory/deck-component'
PACKAGE=OUT/'package'
api=RunnerApi('http://10.0.0.123:9368');work=Workflows(api)
CONTROL='issue197-real-memory-controls-20261002'

def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n')

def attempt(job,label):
    directory=OUT/label;directory.mkdir(exist_ok=True)
    if (directory/'result-summary.json').exists():
        result=work.result(job['Id'])
        assert result['state']=='tested' and result['outcome']['comparison']=='eligible'
        run=directory/'collected'/result['runId']
        return json.loads((run/'stdout.log').read_text()) if job['Arguments'][0]=='--benchmark' else None
    save(directory/'definition.json',job);save(PACKAGE/'job.json',job)
    save(directory/'submit.json',work.submit(PACKAGE,job['Id'],CONTROL,8*1024*1024))
    wait=completion_wait(api,SimpleNamespace(id=job['Id'],job=True,updates=False))
    save(directory/'wait.json',wait)
    result=work.result(job['Id']);save(directory/'result-summary.json',result)
    collection=work.collect(job['Id'],directory/'collected',None,True)
    save(directory/'collection.json',collection)
    print(json.dumps({'label':label,'runId':result.get('runId'),'outcome':result.get('outcome'),'collection':collection.get('complete')}),flush=True)
    assert wait['terminal'] and collection['complete'] and collection['excluded']==0
    assert result['outcome']=={'execution':'completed','correctness':'passed','evidence':'complete','comparison':'eligible'},result
    run=directory/'collected'/result['runId']
    return json.loads((run/'stdout.log').read_text()) if job['Arguments'][0]=='--benchmark' else None

job=json.loads((OUT/'controls'/'20261002-102803214-96f43736fd4f4a05847769520e18b3e4'/'job.json').read_text())
job['Id']='issue197-real-memory-original-controls-20261002';job['Arguments']=['--baseline','--tap'];job['Experiment']['Variant']='original-correctness'
attempt(job,'original-controls')
plan=[]
for words in [9,18]:
    for phase,order in [('aaaa','AAAA'),('abba','ABBA'),('baab','BAAB')]:
        for ordinal,variant in enumerate(order,1):
            mode='baseline' if variant=='A' else 'candidate'
            plan.append({'label':f'w{words}-{phase}-{ordinal}-{variant.lower()}','words':words,'phase':phase,'ordinal':ordinal,'mode':mode})
save(OUT/'matrix-plan.json',{'host':'10.0.0.123','benchmark':'actual QEMU encoded-word reader component, not whole game','fixedBlocks':10000000,'warmupBlocksPerProcess':4096,'sameExecutableSha256':job['ExpectedExecutableSha256'],'order':plan,'interventions':'none; new process each attempt; no QMP, graphics, game or Mesa use'})
rows=[]
for item in plan:
    label=item['label'];words=item['words'];mode=item['mode'];checksum=191790886280000000 if words==9 else 386189776490000000
    job['Id']='issue197-component-'+label+'-20261002';job['Arguments']=['--benchmark',mode,str(words),'10000000'];job['Experiment']['Variant']=mode
    job['Workload']={'CorrectnessChecks':[{'Name':'fixed-output-checksum','Path':'stdout.log','ContainsText':f'"checksum":{checksum},"expectedChecksum":{checksum}'}],
      'EvidenceRequirements':[{'Name':'fixed-work-output','Path':'stdout.log','MinimumBytes':100}],
      'ReportedMetrics':[{'Name':'encoded-read-time','Path':'stdout.log','JsonProperty':'elapsedUs','Unit':'us','Direction':'lower'}]}
    output=attempt(job,label);assert output['checksum']==output['expectedChecksum']==checksum and output['blocks']==10000000 and output['wordsPerBlock']==words and output['mode']==mode
    rows.append({**item,**output});save(OUT/'observations.json',rows)
print('COMPLETE',len(rows),flush=True)
